﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void System.Xml.XmlReader::.cctor()
extern void XmlReader__cctor_m8C939FA4F60E046BCAEDF0969A6E3B89D9CB0A4E (void);
static Il2CppMethodPointer s_methodPointers[1] = 
{
	XmlReader__cctor_m8C939FA4F60E046BCAEDF0969A6E3B89D9CB0A4E,
};
static const int32_t s_InvokerIndices[1] = 
{
	3845,
};
extern const CustomAttributesCacheGenerator g_System_Xml_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_System_Xml_CodeGenModule;
const Il2CppCodeGenModule g_System_Xml_CodeGenModule = 
{
	"System.Xml.dll",
	1,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_System_Xml_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
