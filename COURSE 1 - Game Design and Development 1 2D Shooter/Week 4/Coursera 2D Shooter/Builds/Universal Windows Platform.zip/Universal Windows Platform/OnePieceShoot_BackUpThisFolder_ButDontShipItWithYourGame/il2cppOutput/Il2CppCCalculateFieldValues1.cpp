﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <stdint.h>
#include <limits>



// System.Collections.Generic.List`1<ShootingController>
struct List_1_tE1CA7B68837BDB140CFE4E57D54BBEDDFDAC51E2;
// System.Collections.Generic.List`1<UIPage>
struct List_1_tFCFF53D233888DFF08F2A45F1501E1057DA9B9BD;
// System.Collections.Generic.List`1<UIelement>
struct List_1_t03EA177FD37956FDC8B014EA43A09851D4856DF4;
// System.Byte[]
struct ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726;
// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
// UnityEngine.Camera
struct Camera_tC44E094BAB53AFC8A014C6F9CFCE11F4FC38006C;
// System.Globalization.CodePageDataItem
struct CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E;
// System.Text.DecoderFallback
struct DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D;
// System.Text.EncoderFallback
struct EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4;
// System.Text.Encoding
struct Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827;
// UnityEngine.EventSystems.EventSystem
struct EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C;
// UnityEngine.GameObject
struct GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319;
// System.Collections.Hashtable
struct Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC;
// InputManager
struct InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A;
// UnityEngine.Rigidbody2D
struct Rigidbody2D_tD23204FEE9CB4A36737043B97FD409DE05D5DCE5;
// UnityEngine.RuntimeAnimatorController
struct RuntimeAnimatorController_t6F70D5BE51CCBA99132F444EFFA41439DFE71BAB;
// System.String
struct String_t;
// UnityEngine.UI.Text
struct Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1;
// UnityEngine.Texture2D
struct Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF;
// UnityEngine.Transform
struct Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1;
// UIManager
struct UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858;
// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5;



IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct U3CModuleU3E_tFDCAFCBB4B3431CFF2DC4D3E03FBFDF54EFF7E9A 
{
public:

public:
};


// <Module>
struct U3CModuleU3E_tC32409AC2199417CDCD540CE3546A195D748B63F 
{
public:

public:
};


// <Module>
struct U3CModuleU3E_t370FEF6269CEE81916AFD11FED3C518012BA0C1B 
{
public:

public:
};


// <Module>
struct U3CModuleU3E_tE7281C0E269ACF224AB82F00FE8D46ED8C621032 
{
public:

public:
};


// System.Object


// Consts
struct Consts_t7E822DB6F6A0C317D838127336B92996500D2C17  : public RuntimeObject
{
public:

public:
};


// Consts
struct Consts_tA9B85AC55C8A4E6097B13364DB96E3337DBD3482  : public RuntimeObject
{
public:

public:
};


// System.Text.Encoding
struct Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827  : public RuntimeObject
{
public:
	// System.Int32 System.Text.Encoding::m_codePage
	int32_t ___m_codePage_9;
	// System.Globalization.CodePageDataItem System.Text.Encoding::dataItem
	CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E * ___dataItem_10;
	// System.Boolean System.Text.Encoding::m_deserializedFromEverett
	bool ___m_deserializedFromEverett_11;
	// System.Boolean System.Text.Encoding::m_isReadOnly
	bool ___m_isReadOnly_12;
	// System.Text.EncoderFallback System.Text.Encoding::encoderFallback
	EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 * ___encoderFallback_13;
	// System.Text.DecoderFallback System.Text.Encoding::decoderFallback
	DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D * ___decoderFallback_14;

public:
	inline static int32_t get_offset_of_m_codePage_9() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___m_codePage_9)); }
	inline int32_t get_m_codePage_9() const { return ___m_codePage_9; }
	inline int32_t* get_address_of_m_codePage_9() { return &___m_codePage_9; }
	inline void set_m_codePage_9(int32_t value)
	{
		___m_codePage_9 = value;
	}

	inline static int32_t get_offset_of_dataItem_10() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___dataItem_10)); }
	inline CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E * get_dataItem_10() const { return ___dataItem_10; }
	inline CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E ** get_address_of_dataItem_10() { return &___dataItem_10; }
	inline void set_dataItem_10(CodePageDataItem_t09A62F57142BF0456C8F414898A37E79BCC9F09E * value)
	{
		___dataItem_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___dataItem_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_deserializedFromEverett_11() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___m_deserializedFromEverett_11)); }
	inline bool get_m_deserializedFromEverett_11() const { return ___m_deserializedFromEverett_11; }
	inline bool* get_address_of_m_deserializedFromEverett_11() { return &___m_deserializedFromEverett_11; }
	inline void set_m_deserializedFromEverett_11(bool value)
	{
		___m_deserializedFromEverett_11 = value;
	}

	inline static int32_t get_offset_of_m_isReadOnly_12() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___m_isReadOnly_12)); }
	inline bool get_m_isReadOnly_12() const { return ___m_isReadOnly_12; }
	inline bool* get_address_of_m_isReadOnly_12() { return &___m_isReadOnly_12; }
	inline void set_m_isReadOnly_12(bool value)
	{
		___m_isReadOnly_12 = value;
	}

	inline static int32_t get_offset_of_encoderFallback_13() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___encoderFallback_13)); }
	inline EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 * get_encoderFallback_13() const { return ___encoderFallback_13; }
	inline EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 ** get_address_of_encoderFallback_13() { return &___encoderFallback_13; }
	inline void set_encoderFallback_13(EncoderFallback_t02AC990075E17EB09F0D7E4831C3B3F264025CC4 * value)
	{
		___encoderFallback_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encoderFallback_13), (void*)value);
	}

	inline static int32_t get_offset_of_decoderFallback_14() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827, ___decoderFallback_14)); }
	inline DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D * get_decoderFallback_14() const { return ___decoderFallback_14; }
	inline DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D ** get_address_of_decoderFallback_14() { return &___decoderFallback_14; }
	inline void set_decoderFallback_14(DecoderFallback_tF86D337D6576E81E5DA285E5673183EBC66DEF8D * value)
	{
		___decoderFallback_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___decoderFallback_14), (void*)value);
	}
};

struct Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields
{
public:
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::defaultEncoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___defaultEncoding_0;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::unicodeEncoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___unicodeEncoding_1;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::bigEndianUnicode
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___bigEndianUnicode_2;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf7Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___utf7Encoding_3;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf8Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___utf8Encoding_4;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf32Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___utf32Encoding_5;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::asciiEncoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___asciiEncoding_6;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::latin1Encoding
	Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * ___latin1Encoding_7;
	// System.Collections.Hashtable modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::encodings
	Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC * ___encodings_8;
	// System.Object System.Text.Encoding::s_InternalSyncObject
	RuntimeObject * ___s_InternalSyncObject_15;

public:
	inline static int32_t get_offset_of_defaultEncoding_0() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___defaultEncoding_0)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_defaultEncoding_0() const { return ___defaultEncoding_0; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_defaultEncoding_0() { return &___defaultEncoding_0; }
	inline void set_defaultEncoding_0(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___defaultEncoding_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultEncoding_0), (void*)value);
	}

	inline static int32_t get_offset_of_unicodeEncoding_1() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___unicodeEncoding_1)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_unicodeEncoding_1() const { return ___unicodeEncoding_1; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_unicodeEncoding_1() { return &___unicodeEncoding_1; }
	inline void set_unicodeEncoding_1(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___unicodeEncoding_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___unicodeEncoding_1), (void*)value);
	}

	inline static int32_t get_offset_of_bigEndianUnicode_2() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___bigEndianUnicode_2)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_bigEndianUnicode_2() const { return ___bigEndianUnicode_2; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_bigEndianUnicode_2() { return &___bigEndianUnicode_2; }
	inline void set_bigEndianUnicode_2(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___bigEndianUnicode_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bigEndianUnicode_2), (void*)value);
	}

	inline static int32_t get_offset_of_utf7Encoding_3() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___utf7Encoding_3)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_utf7Encoding_3() const { return ___utf7Encoding_3; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_utf7Encoding_3() { return &___utf7Encoding_3; }
	inline void set_utf7Encoding_3(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___utf7Encoding_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf7Encoding_3), (void*)value);
	}

	inline static int32_t get_offset_of_utf8Encoding_4() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___utf8Encoding_4)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_utf8Encoding_4() const { return ___utf8Encoding_4; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_utf8Encoding_4() { return &___utf8Encoding_4; }
	inline void set_utf8Encoding_4(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___utf8Encoding_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf8Encoding_4), (void*)value);
	}

	inline static int32_t get_offset_of_utf32Encoding_5() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___utf32Encoding_5)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_utf32Encoding_5() const { return ___utf32Encoding_5; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_utf32Encoding_5() { return &___utf32Encoding_5; }
	inline void set_utf32Encoding_5(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___utf32Encoding_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf32Encoding_5), (void*)value);
	}

	inline static int32_t get_offset_of_asciiEncoding_6() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___asciiEncoding_6)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_asciiEncoding_6() const { return ___asciiEncoding_6; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_asciiEncoding_6() { return &___asciiEncoding_6; }
	inline void set_asciiEncoding_6(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___asciiEncoding_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___asciiEncoding_6), (void*)value);
	}

	inline static int32_t get_offset_of_latin1Encoding_7() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___latin1Encoding_7)); }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * get_latin1Encoding_7() const { return ___latin1Encoding_7; }
	inline Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 ** get_address_of_latin1Encoding_7() { return &___latin1Encoding_7; }
	inline void set_latin1Encoding_7(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827 * value)
	{
		___latin1Encoding_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___latin1Encoding_7), (void*)value);
	}

	inline static int32_t get_offset_of_encodings_8() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___encodings_8)); }
	inline Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC * get_encodings_8() const { return ___encodings_8; }
	inline Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC ** get_address_of_encodings_8() { return &___encodings_8; }
	inline void set_encodings_8(Hashtable_t7565AB92A12227AD5BADD6911F10D87EE52509AC * value)
	{
		___encodings_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encodings_8), (void*)value);
	}

	inline static int32_t get_offset_of_s_InternalSyncObject_15() { return static_cast<int32_t>(offsetof(Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827_StaticFields, ___s_InternalSyncObject_15)); }
	inline RuntimeObject * get_s_InternalSyncObject_15() const { return ___s_InternalSyncObject_15; }
	inline RuntimeObject ** get_address_of_s_InternalSyncObject_15() { return &___s_InternalSyncObject_15; }
	inline void set_s_InternalSyncObject_15(RuntimeObject * value)
	{
		___s_InternalSyncObject_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_InternalSyncObject_15), (void*)value);
	}
};


// System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// InputManager/<ResetFireStart>d__12
struct U3CResetFireStartU3Ed__12_t703D0AC9F6668ACA05BD17A52A1634D66CCB089C  : public RuntimeObject
{
public:
	// System.Int32 InputManager/<ResetFireStart>d__12::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object InputManager/<ResetFireStart>d__12::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// InputManager InputManager/<ResetFireStart>d__12::<>4__this
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CResetFireStartU3Ed__12_t703D0AC9F6668ACA05BD17A52A1634D66CCB089C, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CResetFireStartU3Ed__12_t703D0AC9F6668ACA05BD17A52A1634D66CCB089C, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CResetFireStartU3Ed__12_t703D0AC9F6668ACA05BD17A52A1634D66CCB089C, ___U3CU3E4__this_2)); }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}
};


// InputManager/<ResetPausePressed>d__15
struct U3CResetPausePressedU3Ed__15_tCBBC7BFF3506403D2BAAB3720DE0BA6E6BE1C6CC  : public RuntimeObject
{
public:
	// System.Int32 InputManager/<ResetPausePressed>d__15::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object InputManager/<ResetPausePressed>d__15::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// InputManager InputManager/<ResetPausePressed>d__15::<>4__this
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CResetPausePressedU3Ed__15_tCBBC7BFF3506403D2BAAB3720DE0BA6E6BE1C6CC, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CResetPausePressedU3Ed__15_tCBBC7BFF3506403D2BAAB3720DE0BA6E6BE1C6CC, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CResetPausePressedU3Ed__15_tCBBC7BFF3506403D2BAAB3720DE0BA6E6BE1C6CC, ___U3CU3E4__this_2)); }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}
};


// UIManager/<>c__DisplayClass20_0
struct U3CU3Ec__DisplayClass20_0_t38A9DA3C3E987BD1E9895D07D36406EA3248CF12  : public RuntimeObject
{
public:
	// System.String UIManager/<>c__DisplayClass20_0::pageName
	String_t* ___pageName_0;

public:
	inline static int32_t get_offset_of_pageName_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass20_0_t38A9DA3C3E987BD1E9895D07D36406EA3248CF12, ___pageName_0)); }
	inline String_t* get_pageName_0() const { return ___pageName_0; }
	inline String_t** get_address_of_pageName_0() { return &___pageName_0; }
	inline void set_pageName_0(String_t* value)
	{
		___pageName_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___pageName_0), (void*)value);
	}
};


// System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA  : public ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52
{
public:

public:
};

struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_com
{
};

// System.IntPtr
struct IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// I18N.Common.MonoEncoding
struct MonoEncoding_tBF18AF9FA55C6A273B8B39F51D28ADE272E1B5FA  : public Encoding_tE901442411E2E70039D2A4AE77FB81C3D6064827
{
public:
	// System.Int32 I18N.Common.MonoEncoding::win_code_page
	int32_t ___win_code_page_16;

public:
	inline static int32_t get_offset_of_win_code_page_16() { return static_cast<int32_t>(offsetof(MonoEncoding_tBF18AF9FA55C6A273B8B39F51D28ADE272E1B5FA, ___win_code_page_16)); }
	inline int32_t get_win_code_page_16() const { return ___win_code_page_16; }
	inline int32_t* get_address_of_win_code_page_16() { return &___win_code_page_16; }
	inline void set_win_code_page_16(int32_t value)
	{
		___win_code_page_16 = value;
	}
};


// UnityEngine.Vector3
struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___zeroVector_5)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___oneVector_6)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___upVector_7)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___downVector_8)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___leftVector_9)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___rightVector_10)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___forwardVector_11)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___backVector_12)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___negativeInfinityVector_14 = value;
	}
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512
struct __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8__padding[512];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512
struct __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997__padding[512];
	};

public:
};


// <PrivateImplementationDetails>
struct U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields
{
public:
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::05B1E1067273E188A50BA4342B4BC09ABEE669CD
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___05B1E1067273E188A50BA4342B4BC09ABEE669CD_0;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::09885C8B0840E863B3A14261999895D896677D5A
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___09885C8B0840E863B3A14261999895D896677D5A_1;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::0BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___0BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::271EF3D1C1F8136E08DBCAB443CE02538A4156F0
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::2E1C78D5F4666324672DFACDC9307935CF14E98F
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___2E1C78D5F4666324672DFACDC9307935CF14E98F_4;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::3551F16F8A11003B8289B76B9E3D97969B68E7D9
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___3551F16F8A11003B8289B76B9E3D97969B68E7D9_5;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::36A0A1CE2E522AB1D22668B38F6126D2F6E17D44
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___36A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::37C03949C69BDDA042205E1A573B349E75F693B8
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___37C03949C69BDDA042205E1A573B349E75F693B8_7;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::47DCC01E928630EBCC018C5E0285145985F92532
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___47DCC01E928630EBCC018C5E0285145985F92532_8;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::52623ED7F33E8C1C541F1C3101FA981B173D795E
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___52623ED7F33E8C1C541F1C3101FA981B173D795E_9;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::5EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___5EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::659C24C855D0E50CBD366B2774AF841E29202E70
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___659C24C855D0E50CBD366B2774AF841E29202E70_11;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::6B2745F3AD679B4F2E844D23C3EE0BAD49E1528D
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___6B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::71D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___71D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::7A827DA5CD16B7AC8DB4221BABFA420A2B8668E8
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___7A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::7AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___7AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::82273BF74F02F3FDFABEED76BCA4B82DDB2C2761
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___82273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::8C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___8C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::8E958C1847104F390F9C9B64F0F39C98ED4AC63F
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___8E958C1847104F390F9C9B64F0F39C98ED4AC63F_18;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::94F89F72CC0508D891A0C71DD7B57B703869A3FB
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___94F89F72CC0508D891A0C71DD7B57B703869A3FB_19;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::9E66CEC4FA557D4655353E0A4F5940FA0D71CF3A
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___9E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::9EF46C677634CB82C0BD475E372C71C5F68C981A
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___9EF46C677634CB82C0BD475E372C71C5F68C981A_21;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::A5A5BE77BD3D095389FABC21D18BB648787E6618
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___A5A5BE77BD3D095389FABC21D18BB648787E6618_22;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::B1D1CEE08985760776A35065014EAF3D4D3CDE8D
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::B2574B82126B684C0CB3CF93BF7473F0FBB34400
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___B2574B82126B684C0CB3CF93BF7473F0FBB34400_25;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::B6BD9A82204938ABFE97CF3FAB5A47824080EAA0
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::BC1CEF8131E7F0D8206029373157806126E21026
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___BC1CEF8131E7F0D8206029373157806126E21026_27;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::C14817C33562352073848F1A8EA633C19CF1A4F5
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___C14817C33562352073848F1A8EA633C19CF1A4F5_28;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::C392E993B9E622A36C30E0BB997A9F41293CD9EF
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___C392E993B9E622A36C30E0BB997A9F41293CD9EF_29;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::CFB85A64A0D1FAB523C3DE56096F8803CDFEA674
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::D257291FBF3DA6F5C38B3275534902BC9EDE92EA
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::D4795500A3D0F00D8EE85626648C3FBAFA4F70C3
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::DF4C38A5E59685BBEC109623762B6914BE00E866
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___DF4C38A5E59685BBEC109623762B6914BE00E866_35;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::F632BE2E03B27F265F779A5D3D217E5C14AB6CB5
	__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  ___F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36;

public:
	inline static int32_t get_offset_of_U305B1E1067273E188A50BA4342B4BC09ABEE669CD_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___05B1E1067273E188A50BA4342B4BC09ABEE669CD_0)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U305B1E1067273E188A50BA4342B4BC09ABEE669CD_0() const { return ___05B1E1067273E188A50BA4342B4BC09ABEE669CD_0; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U305B1E1067273E188A50BA4342B4BC09ABEE669CD_0() { return &___05B1E1067273E188A50BA4342B4BC09ABEE669CD_0; }
	inline void set_U305B1E1067273E188A50BA4342B4BC09ABEE669CD_0(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___05B1E1067273E188A50BA4342B4BC09ABEE669CD_0 = value;
	}

	inline static int32_t get_offset_of_U309885C8B0840E863B3A14261999895D896677D5A_1() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___09885C8B0840E863B3A14261999895D896677D5A_1)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U309885C8B0840E863B3A14261999895D896677D5A_1() const { return ___09885C8B0840E863B3A14261999895D896677D5A_1; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U309885C8B0840E863B3A14261999895D896677D5A_1() { return &___09885C8B0840E863B3A14261999895D896677D5A_1; }
	inline void set_U309885C8B0840E863B3A14261999895D896677D5A_1(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___09885C8B0840E863B3A14261999895D896677D5A_1 = value;
	}

	inline static int32_t get_offset_of_U30BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___0BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U30BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2() const { return ___0BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U30BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2() { return &___0BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2; }
	inline void set_U30BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___0BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2 = value;
	}

	inline static int32_t get_offset_of_U3271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U3271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3() const { return ___271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U3271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3() { return &___271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3; }
	inline void set_U3271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3 = value;
	}

	inline static int32_t get_offset_of_U32E1C78D5F4666324672DFACDC9307935CF14E98F_4() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___2E1C78D5F4666324672DFACDC9307935CF14E98F_4)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U32E1C78D5F4666324672DFACDC9307935CF14E98F_4() const { return ___2E1C78D5F4666324672DFACDC9307935CF14E98F_4; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U32E1C78D5F4666324672DFACDC9307935CF14E98F_4() { return &___2E1C78D5F4666324672DFACDC9307935CF14E98F_4; }
	inline void set_U32E1C78D5F4666324672DFACDC9307935CF14E98F_4(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___2E1C78D5F4666324672DFACDC9307935CF14E98F_4 = value;
	}

	inline static int32_t get_offset_of_U33551F16F8A11003B8289B76B9E3D97969B68E7D9_5() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___3551F16F8A11003B8289B76B9E3D97969B68E7D9_5)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U33551F16F8A11003B8289B76B9E3D97969B68E7D9_5() const { return ___3551F16F8A11003B8289B76B9E3D97969B68E7D9_5; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U33551F16F8A11003B8289B76B9E3D97969B68E7D9_5() { return &___3551F16F8A11003B8289B76B9E3D97969B68E7D9_5; }
	inline void set_U33551F16F8A11003B8289B76B9E3D97969B68E7D9_5(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___3551F16F8A11003B8289B76B9E3D97969B68E7D9_5 = value;
	}

	inline static int32_t get_offset_of_U336A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___36A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U336A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6() const { return ___36A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U336A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6() { return &___36A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6; }
	inline void set_U336A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___36A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6 = value;
	}

	inline static int32_t get_offset_of_U337C03949C69BDDA042205E1A573B349E75F693B8_7() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___37C03949C69BDDA042205E1A573B349E75F693B8_7)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U337C03949C69BDDA042205E1A573B349E75F693B8_7() const { return ___37C03949C69BDDA042205E1A573B349E75F693B8_7; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U337C03949C69BDDA042205E1A573B349E75F693B8_7() { return &___37C03949C69BDDA042205E1A573B349E75F693B8_7; }
	inline void set_U337C03949C69BDDA042205E1A573B349E75F693B8_7(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___37C03949C69BDDA042205E1A573B349E75F693B8_7 = value;
	}

	inline static int32_t get_offset_of_U347DCC01E928630EBCC018C5E0285145985F92532_8() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___47DCC01E928630EBCC018C5E0285145985F92532_8)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U347DCC01E928630EBCC018C5E0285145985F92532_8() const { return ___47DCC01E928630EBCC018C5E0285145985F92532_8; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U347DCC01E928630EBCC018C5E0285145985F92532_8() { return &___47DCC01E928630EBCC018C5E0285145985F92532_8; }
	inline void set_U347DCC01E928630EBCC018C5E0285145985F92532_8(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___47DCC01E928630EBCC018C5E0285145985F92532_8 = value;
	}

	inline static int32_t get_offset_of_U352623ED7F33E8C1C541F1C3101FA981B173D795E_9() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___52623ED7F33E8C1C541F1C3101FA981B173D795E_9)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U352623ED7F33E8C1C541F1C3101FA981B173D795E_9() const { return ___52623ED7F33E8C1C541F1C3101FA981B173D795E_9; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U352623ED7F33E8C1C541F1C3101FA981B173D795E_9() { return &___52623ED7F33E8C1C541F1C3101FA981B173D795E_9; }
	inline void set_U352623ED7F33E8C1C541F1C3101FA981B173D795E_9(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___52623ED7F33E8C1C541F1C3101FA981B173D795E_9 = value;
	}

	inline static int32_t get_offset_of_U35EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___5EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U35EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10() const { return ___5EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U35EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10() { return &___5EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10; }
	inline void set_U35EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___5EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10 = value;
	}

	inline static int32_t get_offset_of_U3659C24C855D0E50CBD366B2774AF841E29202E70_11() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___659C24C855D0E50CBD366B2774AF841E29202E70_11)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U3659C24C855D0E50CBD366B2774AF841E29202E70_11() const { return ___659C24C855D0E50CBD366B2774AF841E29202E70_11; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U3659C24C855D0E50CBD366B2774AF841E29202E70_11() { return &___659C24C855D0E50CBD366B2774AF841E29202E70_11; }
	inline void set_U3659C24C855D0E50CBD366B2774AF841E29202E70_11(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___659C24C855D0E50CBD366B2774AF841E29202E70_11 = value;
	}

	inline static int32_t get_offset_of_U36B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___6B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U36B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12() const { return ___6B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U36B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12() { return &___6B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12; }
	inline void set_U36B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___6B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12 = value;
	}

	inline static int32_t get_offset_of_U371D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___71D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U371D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13() const { return ___71D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U371D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13() { return &___71D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13; }
	inline void set_U371D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___71D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13 = value;
	}

	inline static int32_t get_offset_of_U37A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___7A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U37A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14() const { return ___7A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U37A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14() { return &___7A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14; }
	inline void set_U37A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___7A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14 = value;
	}

	inline static int32_t get_offset_of_U37AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___7AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U37AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15() const { return ___7AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U37AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15() { return &___7AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15; }
	inline void set_U37AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___7AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15 = value;
	}

	inline static int32_t get_offset_of_U382273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___82273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U382273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16() const { return ___82273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U382273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16() { return &___82273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16; }
	inline void set_U382273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___82273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16 = value;
	}

	inline static int32_t get_offset_of_U38C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___8C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U38C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17() const { return ___8C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U38C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17() { return &___8C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17; }
	inline void set_U38C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___8C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17 = value;
	}

	inline static int32_t get_offset_of_U38E958C1847104F390F9C9B64F0F39C98ED4AC63F_18() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___8E958C1847104F390F9C9B64F0F39C98ED4AC63F_18)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U38E958C1847104F390F9C9B64F0F39C98ED4AC63F_18() const { return ___8E958C1847104F390F9C9B64F0F39C98ED4AC63F_18; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U38E958C1847104F390F9C9B64F0F39C98ED4AC63F_18() { return &___8E958C1847104F390F9C9B64F0F39C98ED4AC63F_18; }
	inline void set_U38E958C1847104F390F9C9B64F0F39C98ED4AC63F_18(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___8E958C1847104F390F9C9B64F0F39C98ED4AC63F_18 = value;
	}

	inline static int32_t get_offset_of_U394F89F72CC0508D891A0C71DD7B57B703869A3FB_19() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___94F89F72CC0508D891A0C71DD7B57B703869A3FB_19)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U394F89F72CC0508D891A0C71DD7B57B703869A3FB_19() const { return ___94F89F72CC0508D891A0C71DD7B57B703869A3FB_19; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U394F89F72CC0508D891A0C71DD7B57B703869A3FB_19() { return &___94F89F72CC0508D891A0C71DD7B57B703869A3FB_19; }
	inline void set_U394F89F72CC0508D891A0C71DD7B57B703869A3FB_19(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___94F89F72CC0508D891A0C71DD7B57B703869A3FB_19 = value;
	}

	inline static int32_t get_offset_of_U39E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___9E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U39E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20() const { return ___9E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U39E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20() { return &___9E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20; }
	inline void set_U39E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___9E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20 = value;
	}

	inline static int32_t get_offset_of_U39EF46C677634CB82C0BD475E372C71C5F68C981A_21() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___9EF46C677634CB82C0BD475E372C71C5F68C981A_21)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_U39EF46C677634CB82C0BD475E372C71C5F68C981A_21() const { return ___9EF46C677634CB82C0BD475E372C71C5F68C981A_21; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_U39EF46C677634CB82C0BD475E372C71C5F68C981A_21() { return &___9EF46C677634CB82C0BD475E372C71C5F68C981A_21; }
	inline void set_U39EF46C677634CB82C0BD475E372C71C5F68C981A_21(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___9EF46C677634CB82C0BD475E372C71C5F68C981A_21 = value;
	}

	inline static int32_t get_offset_of_A5A5BE77BD3D095389FABC21D18BB648787E6618_22() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___A5A5BE77BD3D095389FABC21D18BB648787E6618_22)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_A5A5BE77BD3D095389FABC21D18BB648787E6618_22() const { return ___A5A5BE77BD3D095389FABC21D18BB648787E6618_22; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_A5A5BE77BD3D095389FABC21D18BB648787E6618_22() { return &___A5A5BE77BD3D095389FABC21D18BB648787E6618_22; }
	inline void set_A5A5BE77BD3D095389FABC21D18BB648787E6618_22(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___A5A5BE77BD3D095389FABC21D18BB648787E6618_22 = value;
	}

	inline static int32_t get_offset_of_B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23() const { return ___B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23() { return &___B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23; }
	inline void set_B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23 = value;
	}

	inline static int32_t get_offset_of_B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24() const { return ___B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24() { return &___B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24; }
	inline void set_B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24 = value;
	}

	inline static int32_t get_offset_of_B2574B82126B684C0CB3CF93BF7473F0FBB34400_25() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___B2574B82126B684C0CB3CF93BF7473F0FBB34400_25)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_B2574B82126B684C0CB3CF93BF7473F0FBB34400_25() const { return ___B2574B82126B684C0CB3CF93BF7473F0FBB34400_25; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_B2574B82126B684C0CB3CF93BF7473F0FBB34400_25() { return &___B2574B82126B684C0CB3CF93BF7473F0FBB34400_25; }
	inline void set_B2574B82126B684C0CB3CF93BF7473F0FBB34400_25(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___B2574B82126B684C0CB3CF93BF7473F0FBB34400_25 = value;
	}

	inline static int32_t get_offset_of_B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26() const { return ___B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26() { return &___B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26; }
	inline void set_B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26 = value;
	}

	inline static int32_t get_offset_of_BC1CEF8131E7F0D8206029373157806126E21026_27() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___BC1CEF8131E7F0D8206029373157806126E21026_27)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_BC1CEF8131E7F0D8206029373157806126E21026_27() const { return ___BC1CEF8131E7F0D8206029373157806126E21026_27; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_BC1CEF8131E7F0D8206029373157806126E21026_27() { return &___BC1CEF8131E7F0D8206029373157806126E21026_27; }
	inline void set_BC1CEF8131E7F0D8206029373157806126E21026_27(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___BC1CEF8131E7F0D8206029373157806126E21026_27 = value;
	}

	inline static int32_t get_offset_of_C14817C33562352073848F1A8EA633C19CF1A4F5_28() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___C14817C33562352073848F1A8EA633C19CF1A4F5_28)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_C14817C33562352073848F1A8EA633C19CF1A4F5_28() const { return ___C14817C33562352073848F1A8EA633C19CF1A4F5_28; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_C14817C33562352073848F1A8EA633C19CF1A4F5_28() { return &___C14817C33562352073848F1A8EA633C19CF1A4F5_28; }
	inline void set_C14817C33562352073848F1A8EA633C19CF1A4F5_28(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___C14817C33562352073848F1A8EA633C19CF1A4F5_28 = value;
	}

	inline static int32_t get_offset_of_C392E993B9E622A36C30E0BB997A9F41293CD9EF_29() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___C392E993B9E622A36C30E0BB997A9F41293CD9EF_29)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_C392E993B9E622A36C30E0BB997A9F41293CD9EF_29() const { return ___C392E993B9E622A36C30E0BB997A9F41293CD9EF_29; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_C392E993B9E622A36C30E0BB997A9F41293CD9EF_29() { return &___C392E993B9E622A36C30E0BB997A9F41293CD9EF_29; }
	inline void set_C392E993B9E622A36C30E0BB997A9F41293CD9EF_29(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___C392E993B9E622A36C30E0BB997A9F41293CD9EF_29 = value;
	}

	inline static int32_t get_offset_of_C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30() const { return ___C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30() { return &___C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30; }
	inline void set_C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30 = value;
	}

	inline static int32_t get_offset_of_C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31() const { return ___C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31() { return &___C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31; }
	inline void set_C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31 = value;
	}

	inline static int32_t get_offset_of_CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32() const { return ___CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32() { return &___CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32; }
	inline void set_CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32 = value;
	}

	inline static int32_t get_offset_of_D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33() const { return ___D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33() { return &___D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33; }
	inline void set_D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33 = value;
	}

	inline static int32_t get_offset_of_D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34() const { return ___D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34() { return &___D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34; }
	inline void set_D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34 = value;
	}

	inline static int32_t get_offset_of_DF4C38A5E59685BBEC109623762B6914BE00E866_35() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___DF4C38A5E59685BBEC109623762B6914BE00E866_35)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_DF4C38A5E59685BBEC109623762B6914BE00E866_35() const { return ___DF4C38A5E59685BBEC109623762B6914BE00E866_35; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_DF4C38A5E59685BBEC109623762B6914BE00E866_35() { return &___DF4C38A5E59685BBEC109623762B6914BE00E866_35; }
	inline void set_DF4C38A5E59685BBEC109623762B6914BE00E866_35(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___DF4C38A5E59685BBEC109623762B6914BE00E866_35 = value;
	}

	inline static int32_t get_offset_of_F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields, ___F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36)); }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  get_F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36() const { return ___F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36; }
	inline __StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8 * get_address_of_F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36() { return &___F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36; }
	inline void set_F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36(__StaticArrayInitTypeSizeU3D512_t11CAAE6635178B988FFA19C4F9C2880B10650FA8  value)
	{
		___F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36 = value;
	}
};


// <PrivateImplementationDetails>
struct U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields
{
public:
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::05C64B887A4D766EEB5842345D6B609A0E3A91C9
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___05C64B887A4D766EEB5842345D6B609A0E3A91C9_0;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::148F346330E294B4157ED412259A7E7F373E26A8
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___148F346330E294B4157ED412259A7E7F373E26A8_1;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::1F867F0E96DB3A56943B8CB2662D1DA624023FCD
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___1F867F0E96DB3A56943B8CB2662D1DA624023FCD_2;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::3220DE2BE9769737429E0DE2C6D837CB7C5A02AD
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___3220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::356CE585046545CD2D0B109FF8A85DB88EE29074
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___356CE585046545CD2D0B109FF8A85DB88EE29074_4;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::4FEA2A6324C0192B29C90830F5D578051A4B1B16
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___4FEA2A6324C0192B29C90830F5D578051A4B1B16_5;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::598D9433A53523A59D462896B803E416AB0B1901
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___598D9433A53523A59D462896B803E416AB0B1901_6;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::6E6F169B075CACDE575F1FEA42B1376D31D5A7E5
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___6E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::7089F9820A6F9CC830909BCD1FAF2EF0A540F348
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___7089F9820A6F9CC830909BCD1FAF2EF0A540F348_8;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::9ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___9ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::D5DB24A984219B0001B4B86CDE1E0DF54572D83A
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::E11338F644FF140C0E23D8B7526DB4D2D73FC3F7
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=512 <PrivateImplementationDetails>::FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4
	__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  ___FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14;

public:
	inline static int32_t get_offset_of_U305C64B887A4D766EEB5842345D6B609A0E3A91C9_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___05C64B887A4D766EEB5842345D6B609A0E3A91C9_0)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U305C64B887A4D766EEB5842345D6B609A0E3A91C9_0() const { return ___05C64B887A4D766EEB5842345D6B609A0E3A91C9_0; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U305C64B887A4D766EEB5842345D6B609A0E3A91C9_0() { return &___05C64B887A4D766EEB5842345D6B609A0E3A91C9_0; }
	inline void set_U305C64B887A4D766EEB5842345D6B609A0E3A91C9_0(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___05C64B887A4D766EEB5842345D6B609A0E3A91C9_0 = value;
	}

	inline static int32_t get_offset_of_U3148F346330E294B4157ED412259A7E7F373E26A8_1() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___148F346330E294B4157ED412259A7E7F373E26A8_1)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U3148F346330E294B4157ED412259A7E7F373E26A8_1() const { return ___148F346330E294B4157ED412259A7E7F373E26A8_1; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U3148F346330E294B4157ED412259A7E7F373E26A8_1() { return &___148F346330E294B4157ED412259A7E7F373E26A8_1; }
	inline void set_U3148F346330E294B4157ED412259A7E7F373E26A8_1(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___148F346330E294B4157ED412259A7E7F373E26A8_1 = value;
	}

	inline static int32_t get_offset_of_U31F867F0E96DB3A56943B8CB2662D1DA624023FCD_2() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___1F867F0E96DB3A56943B8CB2662D1DA624023FCD_2)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U31F867F0E96DB3A56943B8CB2662D1DA624023FCD_2() const { return ___1F867F0E96DB3A56943B8CB2662D1DA624023FCD_2; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U31F867F0E96DB3A56943B8CB2662D1DA624023FCD_2() { return &___1F867F0E96DB3A56943B8CB2662D1DA624023FCD_2; }
	inline void set_U31F867F0E96DB3A56943B8CB2662D1DA624023FCD_2(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___1F867F0E96DB3A56943B8CB2662D1DA624023FCD_2 = value;
	}

	inline static int32_t get_offset_of_U33220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___3220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U33220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3() const { return ___3220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U33220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3() { return &___3220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3; }
	inline void set_U33220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___3220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3 = value;
	}

	inline static int32_t get_offset_of_U3356CE585046545CD2D0B109FF8A85DB88EE29074_4() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___356CE585046545CD2D0B109FF8A85DB88EE29074_4)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U3356CE585046545CD2D0B109FF8A85DB88EE29074_4() const { return ___356CE585046545CD2D0B109FF8A85DB88EE29074_4; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U3356CE585046545CD2D0B109FF8A85DB88EE29074_4() { return &___356CE585046545CD2D0B109FF8A85DB88EE29074_4; }
	inline void set_U3356CE585046545CD2D0B109FF8A85DB88EE29074_4(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___356CE585046545CD2D0B109FF8A85DB88EE29074_4 = value;
	}

	inline static int32_t get_offset_of_U34FEA2A6324C0192B29C90830F5D578051A4B1B16_5() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___4FEA2A6324C0192B29C90830F5D578051A4B1B16_5)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U34FEA2A6324C0192B29C90830F5D578051A4B1B16_5() const { return ___4FEA2A6324C0192B29C90830F5D578051A4B1B16_5; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U34FEA2A6324C0192B29C90830F5D578051A4B1B16_5() { return &___4FEA2A6324C0192B29C90830F5D578051A4B1B16_5; }
	inline void set_U34FEA2A6324C0192B29C90830F5D578051A4B1B16_5(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___4FEA2A6324C0192B29C90830F5D578051A4B1B16_5 = value;
	}

	inline static int32_t get_offset_of_U3598D9433A53523A59D462896B803E416AB0B1901_6() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___598D9433A53523A59D462896B803E416AB0B1901_6)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U3598D9433A53523A59D462896B803E416AB0B1901_6() const { return ___598D9433A53523A59D462896B803E416AB0B1901_6; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U3598D9433A53523A59D462896B803E416AB0B1901_6() { return &___598D9433A53523A59D462896B803E416AB0B1901_6; }
	inline void set_U3598D9433A53523A59D462896B803E416AB0B1901_6(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___598D9433A53523A59D462896B803E416AB0B1901_6 = value;
	}

	inline static int32_t get_offset_of_U36E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___6E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U36E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7() const { return ___6E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U36E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7() { return &___6E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7; }
	inline void set_U36E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___6E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7 = value;
	}

	inline static int32_t get_offset_of_U37089F9820A6F9CC830909BCD1FAF2EF0A540F348_8() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___7089F9820A6F9CC830909BCD1FAF2EF0A540F348_8)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U37089F9820A6F9CC830909BCD1FAF2EF0A540F348_8() const { return ___7089F9820A6F9CC830909BCD1FAF2EF0A540F348_8; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U37089F9820A6F9CC830909BCD1FAF2EF0A540F348_8() { return &___7089F9820A6F9CC830909BCD1FAF2EF0A540F348_8; }
	inline void set_U37089F9820A6F9CC830909BCD1FAF2EF0A540F348_8(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___7089F9820A6F9CC830909BCD1FAF2EF0A540F348_8 = value;
	}

	inline static int32_t get_offset_of_U39ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___9ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_U39ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9() const { return ___9ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_U39ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9() { return &___9ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9; }
	inline void set_U39ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___9ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9 = value;
	}

	inline static int32_t get_offset_of_A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10() const { return ___A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10() { return &___A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10; }
	inline void set_A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10 = value;
	}

	inline static int32_t get_offset_of_B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11() const { return ___B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11() { return &___B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11; }
	inline void set_B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11 = value;
	}

	inline static int32_t get_offset_of_D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12() const { return ___D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12() { return &___D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12; }
	inline void set_D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12 = value;
	}

	inline static int32_t get_offset_of_E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13() const { return ___E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13() { return &___E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13; }
	inline void set_E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13 = value;
	}

	inline static int32_t get_offset_of_FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields, ___FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14)); }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  get_FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14() const { return ___FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14; }
	inline __StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997 * get_address_of_FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14() { return &___FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14; }
	inline void set_FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14(__StaticArrayInitTypeSizeU3D512_tBFD523E2342FD3D39194CE3D8E2593F36DE89997  value)
	{
		___FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14 = value;
	}
};


// I18N.Common.ByteEncoding
struct ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412  : public MonoEncoding_tBF18AF9FA55C6A273B8B39F51D28ADE272E1B5FA
{
public:
	// System.Char[] I18N.Common.ByteEncoding::toChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___toChars_17;
	// System.String I18N.Common.ByteEncoding::encodingName
	String_t* ___encodingName_18;
	// System.String I18N.Common.ByteEncoding::bodyName
	String_t* ___bodyName_19;
	// System.String I18N.Common.ByteEncoding::headerName
	String_t* ___headerName_20;
	// System.String I18N.Common.ByteEncoding::webName
	String_t* ___webName_21;
	// System.Boolean I18N.Common.ByteEncoding::isBrowserDisplay
	bool ___isBrowserDisplay_22;
	// System.Boolean I18N.Common.ByteEncoding::isBrowserSave
	bool ___isBrowserSave_23;
	// System.Boolean I18N.Common.ByteEncoding::isMailNewsDisplay
	bool ___isMailNewsDisplay_24;
	// System.Boolean I18N.Common.ByteEncoding::isMailNewsSave
	bool ___isMailNewsSave_25;
	// System.Int32 I18N.Common.ByteEncoding::windowsCodePage
	int32_t ___windowsCodePage_26;

public:
	inline static int32_t get_offset_of_toChars_17() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___toChars_17)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_toChars_17() const { return ___toChars_17; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_toChars_17() { return &___toChars_17; }
	inline void set_toChars_17(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___toChars_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___toChars_17), (void*)value);
	}

	inline static int32_t get_offset_of_encodingName_18() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___encodingName_18)); }
	inline String_t* get_encodingName_18() const { return ___encodingName_18; }
	inline String_t** get_address_of_encodingName_18() { return &___encodingName_18; }
	inline void set_encodingName_18(String_t* value)
	{
		___encodingName_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encodingName_18), (void*)value);
	}

	inline static int32_t get_offset_of_bodyName_19() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___bodyName_19)); }
	inline String_t* get_bodyName_19() const { return ___bodyName_19; }
	inline String_t** get_address_of_bodyName_19() { return &___bodyName_19; }
	inline void set_bodyName_19(String_t* value)
	{
		___bodyName_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bodyName_19), (void*)value);
	}

	inline static int32_t get_offset_of_headerName_20() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___headerName_20)); }
	inline String_t* get_headerName_20() const { return ___headerName_20; }
	inline String_t** get_address_of_headerName_20() { return &___headerName_20; }
	inline void set_headerName_20(String_t* value)
	{
		___headerName_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___headerName_20), (void*)value);
	}

	inline static int32_t get_offset_of_webName_21() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___webName_21)); }
	inline String_t* get_webName_21() const { return ___webName_21; }
	inline String_t** get_address_of_webName_21() { return &___webName_21; }
	inline void set_webName_21(String_t* value)
	{
		___webName_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___webName_21), (void*)value);
	}

	inline static int32_t get_offset_of_isBrowserDisplay_22() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___isBrowserDisplay_22)); }
	inline bool get_isBrowserDisplay_22() const { return ___isBrowserDisplay_22; }
	inline bool* get_address_of_isBrowserDisplay_22() { return &___isBrowserDisplay_22; }
	inline void set_isBrowserDisplay_22(bool value)
	{
		___isBrowserDisplay_22 = value;
	}

	inline static int32_t get_offset_of_isBrowserSave_23() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___isBrowserSave_23)); }
	inline bool get_isBrowserSave_23() const { return ___isBrowserSave_23; }
	inline bool* get_address_of_isBrowserSave_23() { return &___isBrowserSave_23; }
	inline void set_isBrowserSave_23(bool value)
	{
		___isBrowserSave_23 = value;
	}

	inline static int32_t get_offset_of_isMailNewsDisplay_24() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___isMailNewsDisplay_24)); }
	inline bool get_isMailNewsDisplay_24() const { return ___isMailNewsDisplay_24; }
	inline bool* get_address_of_isMailNewsDisplay_24() { return &___isMailNewsDisplay_24; }
	inline void set_isMailNewsDisplay_24(bool value)
	{
		___isMailNewsDisplay_24 = value;
	}

	inline static int32_t get_offset_of_isMailNewsSave_25() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___isMailNewsSave_25)); }
	inline bool get_isMailNewsSave_25() const { return ___isMailNewsSave_25; }
	inline bool* get_address_of_isMailNewsSave_25() { return &___isMailNewsSave_25; }
	inline void set_isMailNewsSave_25(bool value)
	{
		___isMailNewsSave_25 = value;
	}

	inline static int32_t get_offset_of_windowsCodePage_26() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412, ___windowsCodePage_26)); }
	inline int32_t get_windowsCodePage_26() const { return ___windowsCodePage_26; }
	inline int32_t* get_address_of_windowsCodePage_26() { return &___windowsCodePage_26; }
	inline void set_windowsCodePage_26(int32_t value)
	{
		___windowsCodePage_26 = value;
	}
};

struct ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412_StaticFields
{
public:
	// System.Byte[] I18N.Common.ByteEncoding::isNormalized
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___isNormalized_27;
	// System.Byte[] I18N.Common.ByteEncoding::isNormalizedComputed
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___isNormalizedComputed_28;
	// System.Byte[] I18N.Common.ByteEncoding::normalization_bytes
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___normalization_bytes_29;

public:
	inline static int32_t get_offset_of_isNormalized_27() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412_StaticFields, ___isNormalized_27)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_isNormalized_27() const { return ___isNormalized_27; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_isNormalized_27() { return &___isNormalized_27; }
	inline void set_isNormalized_27(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___isNormalized_27 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___isNormalized_27), (void*)value);
	}

	inline static int32_t get_offset_of_isNormalizedComputed_28() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412_StaticFields, ___isNormalizedComputed_28)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_isNormalizedComputed_28() const { return ___isNormalizedComputed_28; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_isNormalizedComputed_28() { return &___isNormalizedComputed_28; }
	inline void set_isNormalizedComputed_28(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___isNormalizedComputed_28 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___isNormalizedComputed_28), (void*)value);
	}

	inline static int32_t get_offset_of_normalization_bytes_29() { return static_cast<int32_t>(offsetof(ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412_StaticFields, ___normalization_bytes_29)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_normalization_bytes_29() const { return ___normalization_bytes_29; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_normalization_bytes_29() { return &___normalization_bytes_29; }
	inline void set_normalization_bytes_29(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___normalization_bytes_29 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___normalization_bytes_29), (void*)value);
	}
};


// UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// CameraController/CameraStyles
struct CameraStyles_t2263775A9F64A76075D435D49587237DC75AA8E5 
{
public:
	// System.Int32 CameraController/CameraStyles::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CameraStyles_t2263775A9F64A76075D435D49587237DC75AA8E5, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// Controller/AimModes
struct AimModes_tF67601938018899336774C126F7601A9194FF27D 
{
public:
	// System.Int32 Controller/AimModes::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AimModes_tF67601938018899336774C126F7601A9194FF27D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// Controller/MovementModes
struct MovementModes_tF14FB5F318012884A654444DB56F1853024D8294 
{
public:
	// System.Int32 Controller/MovementModes::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MovementModes_tF14FB5F318012884A654444DB56F1853024D8294, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// Enemy/MovementModes
struct MovementModes_tF73DA728A5026D1A2F694EE07D4C9C0741CA2370 
{
public:
	// System.Int32 Enemy/MovementModes::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MovementModes_tF73DA728A5026D1A2F694EE07D4C9C0741CA2370, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// Enemy/ShootMode
struct ShootMode_t8613AD43724BDDC529A4B1BD2CEF46A6F6851079 
{
public:
	// System.Int32 Enemy/ShootMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ShootMode_t8613AD43724BDDC529A4B1BD2CEF46A6F6851079, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// I18N.West.CP10000
struct CP10000_t90376227B31EAFB15D36A7C3121598F0A81B3D56  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP10000_t90376227B31EAFB15D36A7C3121598F0A81B3D56_StaticFields
{
public:
	// System.Char[] I18N.West.CP10000::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP10000_t90376227B31EAFB15D36A7C3121598F0A81B3D56_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP10079
struct CP10079_tC8E1B9E147870510266629449DF0718F1658524B  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP10079_tC8E1B9E147870510266629449DF0718F1658524B_StaticFields
{
public:
	// System.Char[] I18N.West.CP10079::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP10079_tC8E1B9E147870510266629449DF0718F1658524B_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1026
struct CP1026_t7F2AD192944C4A8039139B957212FB817FB4C7D1  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1026_t7F2AD192944C4A8039139B957212FB817FB4C7D1_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1026::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1026_t7F2AD192944C4A8039139B957212FB817FB4C7D1_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1047
struct CP1047_t29DE80FA04EABC616A50911A8FC6E8DFCCB84288  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1047_t29DE80FA04EABC616A50911A8FC6E8DFCCB84288_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1047::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1047_t29DE80FA04EABC616A50911A8FC6E8DFCCB84288_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1140
struct CP1140_t873912141C09EE972EAFFDC1D91526772AC6A260  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1140_t873912141C09EE972EAFFDC1D91526772AC6A260_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1140::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1140_t873912141C09EE972EAFFDC1D91526772AC6A260_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1141
struct CP1141_t21CEA37D76E47FF5DA7BCFF526DE210F6CCF402B  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1141_t21CEA37D76E47FF5DA7BCFF526DE210F6CCF402B_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1141::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1141_t21CEA37D76E47FF5DA7BCFF526DE210F6CCF402B_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1142
struct CP1142_t4237D12BC35C1AC9CB88D99109423DD755A0CD9E  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1142_t4237D12BC35C1AC9CB88D99109423DD755A0CD9E_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1142::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1142_t4237D12BC35C1AC9CB88D99109423DD755A0CD9E_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1143
struct CP1143_tFE85986C7DC1F082D30B71F329DA177B51CE7932  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1143_tFE85986C7DC1F082D30B71F329DA177B51CE7932_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1143::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1143_tFE85986C7DC1F082D30B71F329DA177B51CE7932_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1144
struct CP1144_tC91AEC0BDB44F79D4E291F2C80B0D50D576D970A  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1144_tC91AEC0BDB44F79D4E291F2C80B0D50D576D970A_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1144::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1144_tC91AEC0BDB44F79D4E291F2C80B0D50D576D970A_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1145
struct CP1145_t8A2FF34162510D80D9AA634563AE3C8A7549A4A5  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1145_t8A2FF34162510D80D9AA634563AE3C8A7549A4A5_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1145::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1145_t8A2FF34162510D80D9AA634563AE3C8A7549A4A5_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1146
struct CP1146_tB48428B26382E0E6C9F76CA61F1682F5D860B878  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1146_tB48428B26382E0E6C9F76CA61F1682F5D860B878_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1146::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1146_tB48428B26382E0E6C9F76CA61F1682F5D860B878_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1147
struct CP1147_t7E416A65156781470473BB31A8542FCE2463A18C  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1147_t7E416A65156781470473BB31A8542FCE2463A18C_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1147::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1147_t7E416A65156781470473BB31A8542FCE2463A18C_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1148
struct CP1148_t24312E6240420F06E929DD4B8EEB2C22ABCDF51C  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1148_t24312E6240420F06E929DD4B8EEB2C22ABCDF51C_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1148::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1148_t24312E6240420F06E929DD4B8EEB2C22ABCDF51C_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP1149
struct CP1149_t66722FA13A4C0E886DE6AD90ABF2F59DD616E371  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1149_t66722FA13A4C0E886DE6AD90ABF2F59DD616E371_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP1149::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1149_t66722FA13A4C0E886DE6AD90ABF2F59DD616E371_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP1250
struct CP1250_t9CEAE2D9077CF4BFF7A372B496362D26251F9C04  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1250_t9CEAE2D9077CF4BFF7A372B496362D26251F9C04_StaticFields
{
public:
	// System.Char[] I18N.West.CP1250::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1250_t9CEAE2D9077CF4BFF7A372B496362D26251F9C04_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP1252
struct CP1252_t83D225E8526CFC7079CE797954EB0E3C00CCF7AC  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1252_t83D225E8526CFC7079CE797954EB0E3C00CCF7AC_StaticFields
{
public:
	// System.Char[] I18N.West.CP1252::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1252_t83D225E8526CFC7079CE797954EB0E3C00CCF7AC_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP1253
struct CP1253_t9033E724E778CF0DABFE7A70C62ABAB8429EF04F  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP1253_t9033E724E778CF0DABFE7A70C62ABAB8429EF04F_StaticFields
{
public:
	// System.Char[] I18N.West.CP1253::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP1253_t9033E724E778CF0DABFE7A70C62ABAB8429EF04F_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20273
struct CP20273_tC8A029A53E6655DB818FD486569E519A3948FABA  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20273_tC8A029A53E6655DB818FD486569E519A3948FABA_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20273::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20273_tC8A029A53E6655DB818FD486569E519A3948FABA_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20277
struct CP20277_t6A07C14184E08AD84E2287437E58BD3DEAA3C5D8  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20277_t6A07C14184E08AD84E2287437E58BD3DEAA3C5D8_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20277::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20277_t6A07C14184E08AD84E2287437E58BD3DEAA3C5D8_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20278
struct CP20278_tE368E2CA0D30C8D3DDFC1761CCBF4E32BEB3F258  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20278_tE368E2CA0D30C8D3DDFC1761CCBF4E32BEB3F258_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20278::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20278_tE368E2CA0D30C8D3DDFC1761CCBF4E32BEB3F258_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20280
struct CP20280_t0B7E893AC6D2E78450853496D34F97EF05BA8A20  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20280_t0B7E893AC6D2E78450853496D34F97EF05BA8A20_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20280::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20280_t0B7E893AC6D2E78450853496D34F97EF05BA8A20_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20284
struct CP20284_tD286C0645FB422717E8505E976B424205604D08D  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20284_tD286C0645FB422717E8505E976B424205604D08D_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20284::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20284_tD286C0645FB422717E8505E976B424205604D08D_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20285
struct CP20285_t388031FDCA8D3D7562AD537DAF478C011D46DF52  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20285_t388031FDCA8D3D7562AD537DAF478C011D46DF52_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20285::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20285_t388031FDCA8D3D7562AD537DAF478C011D46DF52_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20290
struct CP20290_tE0D84B40EA1C7E83D7F2934C748EB880105FC6E1  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20290_tE0D84B40EA1C7E83D7F2934C748EB880105FC6E1_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20290::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20290_tE0D84B40EA1C7E83D7F2934C748EB880105FC6E1_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20297
struct CP20297_t634FB165810C6E04817DC4ED1FC38D15E9331E10  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20297_t634FB165810C6E04817DC4ED1FC38D15E9331E10_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20297::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20297_t634FB165810C6E04817DC4ED1FC38D15E9331E10_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20420
struct CP20420_tE4A7FEED843107D575A05FCCB5A18A64F62F5F96  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20420_tE4A7FEED843107D575A05FCCB5A18A64F62F5F96_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20420::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20420_tE4A7FEED843107D575A05FCCB5A18A64F62F5F96_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20424
struct CP20424_t6D1DC3AF312E703FEC49112901E74F5ACBFEA283  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20424_t6D1DC3AF312E703FEC49112901E74F5ACBFEA283_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20424::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20424_t6D1DC3AF312E703FEC49112901E74F5ACBFEA283_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP20871
struct CP20871_tE58915819DA570099C2FBF259B64A88CF9849DD9  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP20871_tE58915819DA570099C2FBF259B64A88CF9849DD9_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP20871::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP20871_tE58915819DA570099C2FBF259B64A88CF9849DD9_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP21025
struct CP21025_t383EB0008A9710AB1FB9869A9032A9A302722890  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP21025_t383EB0008A9710AB1FB9869A9032A9A302722890_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP21025::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP21025_t383EB0008A9710AB1FB9869A9032A9A302722890_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP28592
struct CP28592_tE3D280B4DDEA315869DBC23FDE487FA718D35D7A  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP28592_tE3D280B4DDEA315869DBC23FDE487FA718D35D7A_StaticFields
{
public:
	// System.Char[] I18N.West.CP28592::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP28592_tE3D280B4DDEA315869DBC23FDE487FA718D35D7A_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP28593
struct CP28593_t78DB4995E615D18BAC0DE9179311C4B5E6A3BCCC  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP28593_t78DB4995E615D18BAC0DE9179311C4B5E6A3BCCC_StaticFields
{
public:
	// System.Char[] I18N.West.CP28593::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP28593_t78DB4995E615D18BAC0DE9179311C4B5E6A3BCCC_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP28597
struct CP28597_t9F2C8B90A7BBA39F89A8612C43F85514640C5A0C  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP28597_t9F2C8B90A7BBA39F89A8612C43F85514640C5A0C_StaticFields
{
public:
	// System.Char[] I18N.West.CP28597::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP28597_t9F2C8B90A7BBA39F89A8612C43F85514640C5A0C_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP28605
struct CP28605_tF1D6657E73A685ABFFD29E25771515605CC3D669  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP28605_tF1D6657E73A685ABFFD29E25771515605CC3D669_StaticFields
{
public:
	// System.Char[] I18N.West.CP28605::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP28605_tF1D6657E73A685ABFFD29E25771515605CC3D669_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP37
struct CP37_tBBF6F32AB246E06A6CC878A4056A604983E6BA7B  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP37_tBBF6F32AB246E06A6CC878A4056A604983E6BA7B_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP37::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP37_tBBF6F32AB246E06A6CC878A4056A604983E6BA7B_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP437
struct CP437_t2C31EEEF782FD00487011B73793EC24908911248  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP437_t2C31EEEF782FD00487011B73793EC24908911248_StaticFields
{
public:
	// System.Char[] I18N.West.CP437::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP437_t2C31EEEF782FD00487011B73793EC24908911248_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP500
struct CP500_t1AC8EF017DB6B169900268C693B9D02197FAD8BE  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP500_t1AC8EF017DB6B169900268C693B9D02197FAD8BE_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP500::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP500_t1AC8EF017DB6B169900268C693B9D02197FAD8BE_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP708
struct CP708_t91BA271E408F78AF6AB834E9F8EEBD274D5D0F83  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP708_t91BA271E408F78AF6AB834E9F8EEBD274D5D0F83_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP708::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP708_t91BA271E408F78AF6AB834E9F8EEBD274D5D0F83_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP850
struct CP850_t1610E334425DCAD9C280EA79E711ECAD3A2DFA04  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP850_t1610E334425DCAD9C280EA79E711ECAD3A2DFA04_StaticFields
{
public:
	// System.Char[] I18N.West.CP850::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP850_t1610E334425DCAD9C280EA79E711ECAD3A2DFA04_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP852
struct CP852_t02AC6D88D7DCA14AF317C724151BB70D9989AFB9  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP852_t02AC6D88D7DCA14AF317C724151BB70D9989AFB9_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP852::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP852_t02AC6D88D7DCA14AF317C724151BB70D9989AFB9_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP855
struct CP855_t69F594AD6D3FCBE23BB8BCB14FB7987B1568B526  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP855_t69F594AD6D3FCBE23BB8BCB14FB7987B1568B526_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP855::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP855_t69F594AD6D3FCBE23BB8BCB14FB7987B1568B526_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP857
struct CP857_tFE092BE37477C1D4F73F5E4CF17EA447260B6802  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP857_tFE092BE37477C1D4F73F5E4CF17EA447260B6802_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP857::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP857_tFE092BE37477C1D4F73F5E4CF17EA447260B6802_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP858
struct CP858_t9590DB826647E000357E48E06D15AD3EA591260B  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP858_t9590DB826647E000357E48E06D15AD3EA591260B_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP858::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP858_t9590DB826647E000357E48E06D15AD3EA591260B_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP860
struct CP860_tA028A87A63E6DBFF5F24EC665BB7D4831941DF3E  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP860_tA028A87A63E6DBFF5F24EC665BB7D4831941DF3E_StaticFields
{
public:
	// System.Char[] I18N.West.CP860::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP860_tA028A87A63E6DBFF5F24EC665BB7D4831941DF3E_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP861
struct CP861_t48E89FE8388821D4AFF8406B2777299F505F40A2  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP861_t48E89FE8388821D4AFF8406B2777299F505F40A2_StaticFields
{
public:
	// System.Char[] I18N.West.CP861::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP861_t48E89FE8388821D4AFF8406B2777299F505F40A2_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP862
struct CP862_tBE982DFFA4B7608C5E5285F45A8B841F51B0F0BE  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP862_tBE982DFFA4B7608C5E5285F45A8B841F51B0F0BE_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP862::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP862_tBE982DFFA4B7608C5E5285F45A8B841F51B0F0BE_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP863
struct CP863_t43777DEB91042772AF52424C3283279BE92B1108  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP863_t43777DEB91042772AF52424C3283279BE92B1108_StaticFields
{
public:
	// System.Char[] I18N.West.CP863::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP863_t43777DEB91042772AF52424C3283279BE92B1108_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP864
struct CP864_t90F40EF744D65AEB4494B606D76EC8B1690F3A56  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP864_t90F40EF744D65AEB4494B606D76EC8B1690F3A56_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP864::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP864_t90F40EF744D65AEB4494B606D76EC8B1690F3A56_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.West.CP865
struct CP865_t832962C13E90BE9EA8B5924A6E349072AC33B995  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP865_t832962C13E90BE9EA8B5924A6E349072AC33B995_StaticFields
{
public:
	// System.Char[] I18N.West.CP865::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP865_t832962C13E90BE9EA8B5924A6E349072AC33B995_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP866
struct CP866_t8D0F2CC55C29421F8C3E6AAD2309D390F139F97E  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP866_t8D0F2CC55C29421F8C3E6AAD2309D390F139F97E_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP866::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP866_t8D0F2CC55C29421F8C3E6AAD2309D390F139F97E_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP869
struct CP869_t7F7805FE94FFC2B6CD8794C8E6B9FA4C9C9359F5  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP869_t7F7805FE94FFC2B6CD8794C8E6B9FA4C9C9359F5_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP869::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP869_t7F7805FE94FFC2B6CD8794C8E6B9FA4C9C9359F5_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP870
struct CP870_t6C5454214680B02D23E0DE81358A4C4CCF6F7451  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP870_t6C5454214680B02D23E0DE81358A4C4CCF6F7451_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP870::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP870_t6C5454214680B02D23E0DE81358A4C4CCF6F7451_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// I18N.Rare.CP875
struct CP875_tA1D77603588C9477B1005787CDFC826E235E27BD  : public ByteEncoding_t3A5A29C82549567239B7A342CC91EC5297A00412
{
public:

public:
};

struct CP875_tA1D77603588C9477B1005787CDFC826E235E27BD_StaticFields
{
public:
	// System.Char[] I18N.Rare.CP875::ToChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___ToChars_30;

public:
	inline static int32_t get_offset_of_ToChars_30() { return static_cast<int32_t>(offsetof(CP875_tA1D77603588C9477B1005787CDFC826E235E27BD_StaticFields, ___ToChars_30)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_ToChars_30() const { return ___ToChars_30; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_ToChars_30() { return &___ToChars_30; }
	inline void set_ToChars_30(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___ToChars_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToChars_30), (void*)value);
	}
};


// UnityEngine.Component
struct Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:

public:
};


// UnityEngine.Behaviour
struct Behaviour_t1A3DDDCF73B4627928FBFE02ED52B7251777DBD9  : public Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684
{
public:

public:
};


// I18N.Rare.ENCasmo_708
struct ENCasmo_708_t37297141B0D71D82F7EE26C430A76EADBE7365E4  : public CP708_t91BA271E408F78AF6AB834E9F8EEBD274D5D0F83
{
public:

public:
};


// I18N.Rare.ENCibm00858
struct ENCibm00858_t1B26E28E850C406EB0909C3E7E756EFA09F336CA  : public CP858_t9590DB826647E000357E48E06D15AD3EA591260B
{
public:

public:
};


// I18N.Rare.ENCibm01140
struct ENCibm01140_t1D5DD3520C273A66FD1D852C55C5280B4E957221  : public CP1140_t873912141C09EE972EAFFDC1D91526772AC6A260
{
public:

public:
};


// I18N.Rare.ENCibm01141
struct ENCibm01141_tA0CD5328A246D314288768FB7A1162D252822EAD  : public CP1141_t21CEA37D76E47FF5DA7BCFF526DE210F6CCF402B
{
public:

public:
};


// I18N.Rare.ENCibm01142
struct ENCibm01142_t7019F7D6569CC724675F397F07B0031D73AFE8C9  : public CP1142_t4237D12BC35C1AC9CB88D99109423DD755A0CD9E
{
public:

public:
};


// I18N.Rare.ENCibm01143
struct ENCibm01143_tB55B95E92CB39E94E20152AB1EC27ECC72BDC63A  : public CP1143_tFE85986C7DC1F082D30B71F329DA177B51CE7932
{
public:

public:
};


// I18N.Rare.ENCibm037
struct ENCibm037_t9222036F114F624E0E55A1AD07510F770B4D34FF  : public CP37_tBBF6F32AB246E06A6CC878A4056A604983E6BA7B
{
public:

public:
};


// I18N.Rare.ENCibm1025
struct ENCibm1025_t9A4C74DFBD5C4C6440E2BC183C36BF5B9E17212C  : public CP21025_t383EB0008A9710AB1FB9869A9032A9A302722890
{
public:

public:
};


// I18N.Rare.ENCibm1026
struct ENCibm1026_tB64D6C9D5691B73DD87F62DDB13B4C9C1D9D9648  : public CP1026_t7F2AD192944C4A8039139B957212FB817FB4C7D1
{
public:

public:
};


// I18N.Rare.ENCibm1047
struct ENCibm1047_t80857E2B5E1CE6AB6AC5733CDD99FBD29C1D4E6D  : public CP1047_t29DE80FA04EABC616A50911A8FC6E8DFCCB84288
{
public:

public:
};


// I18N.Rare.ENCibm1144
struct ENCibm1144_t3450E1FA892E46F706B36408D0D1FCF76826B682  : public CP1144_tC91AEC0BDB44F79D4E291F2C80B0D50D576D970A
{
public:

public:
};


// I18N.Rare.ENCibm1145
struct ENCibm1145_tD3C04D42301C00743AD433912EB5B6680877BAB5  : public CP1145_t8A2FF34162510D80D9AA634563AE3C8A7549A4A5
{
public:

public:
};


// I18N.Rare.ENCibm1146
struct ENCibm1146_t3006709EAFA4D46A4DFCC0D855196E16D535764C  : public CP1146_tB48428B26382E0E6C9F76CA61F1682F5D860B878
{
public:

public:
};


// I18N.Rare.ENCibm1147
struct ENCibm1147_t611B7013EF163D4A7CC73787C132FAB45DCAB2CB  : public CP1147_t7E416A65156781470473BB31A8542FCE2463A18C
{
public:

public:
};


// I18N.Rare.ENCibm1148
struct ENCibm1148_t8494453258F51D2E6F71DBE0142B776C671F07A3  : public CP1148_t24312E6240420F06E929DD4B8EEB2C22ABCDF51C
{
public:

public:
};


// I18N.Rare.ENCibm1149
struct ENCibm1149_t975C2B0DE5B1CA3BE24023D8B6AB7FB33F5D10A8  : public CP1149_t66722FA13A4C0E886DE6AD90ABF2F59DD616E371
{
public:

public:
};


// I18N.Rare.ENCibm273
struct ENCibm273_tF9832F30F9811FE1551E6521C6CD298FD91E3C36  : public CP20273_tC8A029A53E6655DB818FD486569E519A3948FABA
{
public:

public:
};


// I18N.Rare.ENCibm277
struct ENCibm277_t86B6066A407FC2AE75682014E5A35F3820224CE5  : public CP20277_t6A07C14184E08AD84E2287437E58BD3DEAA3C5D8
{
public:

public:
};


// I18N.Rare.ENCibm278
struct ENCibm278_tA93573263DDAEDCB0CFAD27FAC83D42A5547FFF5  : public CP20278_tE368E2CA0D30C8D3DDFC1761CCBF4E32BEB3F258
{
public:

public:
};


// I18N.Rare.ENCibm280
struct ENCibm280_t3C3C64FD68F11403B9236D982BBBE4181FE0C75B  : public CP20280_t0B7E893AC6D2E78450853496D34F97EF05BA8A20
{
public:

public:
};


// I18N.Rare.ENCibm284
struct ENCibm284_t9DCEE8251FC94FA6BD6D0874482BA42BE729B789  : public CP20284_tD286C0645FB422717E8505E976B424205604D08D
{
public:

public:
};


// I18N.Rare.ENCibm285
struct ENCibm285_tF7FE1CC61FDC3C951428FFFF451783DDAA2EA855  : public CP20285_t388031FDCA8D3D7562AD537DAF478C011D46DF52
{
public:

public:
};


// I18N.Rare.ENCibm290
struct ENCibm290_tF946CF42DB88C8A7F6343FC1204772880D0BCBB8  : public CP20290_tE0D84B40EA1C7E83D7F2934C748EB880105FC6E1
{
public:

public:
};


// I18N.Rare.ENCibm297
struct ENCibm297_t2BFFEB234F7CDB17D53153DBC63555D821B45C2E  : public CP20297_t634FB165810C6E04817DC4ED1FC38D15E9331E10
{
public:

public:
};


// I18N.Rare.ENCibm420
struct ENCibm420_t02094E32C1825BB3B7BA6386120B57EE24543A12  : public CP20420_tE4A7FEED843107D575A05FCCB5A18A64F62F5F96
{
public:

public:
};


// I18N.Rare.ENCibm424
struct ENCibm424_tFDF4EF67A0D5006D02B6423A5DF1749DE97589A0  : public CP20424_t6D1DC3AF312E703FEC49112901E74F5ACBFEA283
{
public:

public:
};


// I18N.West.ENCibm437
struct ENCibm437_t0777AA2C779E1239F448AD2EA4FE6A59B13C9252  : public CP437_t2C31EEEF782FD00487011B73793EC24908911248
{
public:

public:
};


// I18N.Rare.ENCibm500
struct ENCibm500_t083133477A120505D38AFD54EEF8D21C35703052  : public CP500_t1AC8EF017DB6B169900268C693B9D02197FAD8BE
{
public:

public:
};


// I18N.West.ENCibm850
struct ENCibm850_t2F1958089588B0F2B67BFC7BEF8CF3251BFE6577  : public CP850_t1610E334425DCAD9C280EA79E711ECAD3A2DFA04
{
public:

public:
};


// I18N.Rare.ENCibm852
struct ENCibm852_t1C69487C1B877F8D093458E864F66172815DFADA  : public CP852_t02AC6D88D7DCA14AF317C724151BB70D9989AFB9
{
public:

public:
};


// I18N.Rare.ENCibm855
struct ENCibm855_t4049AC3CE8D3F69E2D8A23909C8212F593F9DB90  : public CP855_t69F594AD6D3FCBE23BB8BCB14FB7987B1568B526
{
public:

public:
};


// I18N.Rare.ENCibm857
struct ENCibm857_t609949AC2B4680374995A65CA24A46EA0DB9C965  : public CP857_tFE092BE37477C1D4F73F5E4CF17EA447260B6802
{
public:

public:
};


// I18N.West.ENCibm860
struct ENCibm860_tE76E49F75FAF62506A2F6363A45CB7FCFFD90AFA  : public CP860_tA028A87A63E6DBFF5F24EC665BB7D4831941DF3E
{
public:

public:
};


// I18N.West.ENCibm861
struct ENCibm861_tC70C0D96708CB3FFCF9896361CE95B13DFBDAE62  : public CP861_t48E89FE8388821D4AFF8406B2777299F505F40A2
{
public:

public:
};


// I18N.Rare.ENCibm862
struct ENCibm862_t66E71B425BD583A5EB7AA60E25520F2B2FA0D9B1  : public CP862_tBE982DFFA4B7608C5E5285F45A8B841F51B0F0BE
{
public:

public:
};


// I18N.West.ENCibm863
struct ENCibm863_t64AF5FD7ADEE4478B878501C62A95F124F76622B  : public CP863_t43777DEB91042772AF52424C3283279BE92B1108
{
public:

public:
};


// I18N.Rare.ENCibm864
struct ENCibm864_t430C57FE6E5E17AE966C6BA47CA8F589B3141371  : public CP864_t90F40EF744D65AEB4494B606D76EC8B1690F3A56
{
public:

public:
};


// I18N.West.ENCibm865
struct ENCibm865_tD90AE5F367C31B147D6C45C6F8375190A6C46764  : public CP865_t832962C13E90BE9EA8B5924A6E349072AC33B995
{
public:

public:
};


// I18N.Rare.ENCibm866
struct ENCibm866_tF623AB5C687B30FD3377EDBAC4CF21BEFB9E99CD  : public CP866_t8D0F2CC55C29421F8C3E6AAD2309D390F139F97E
{
public:

public:
};


// I18N.Rare.ENCibm869
struct ENCibm869_t3232BF9389A182622896D30F755030F638FCA88E  : public CP869_t7F7805FE94FFC2B6CD8794C8E6B9FA4C9C9359F5
{
public:

public:
};


// I18N.Rare.ENCibm870
struct ENCibm870_t1F49E7003AEE944B99A55A0D3AEE0371F6A7EDE2  : public CP870_t6C5454214680B02D23E0DE81358A4C4CCF6F7451
{
public:

public:
};


// I18N.Rare.ENCibm871
struct ENCibm871_tF335E4618564CB819BC77B093C07A8CF1470DB5D  : public CP20871_tE58915819DA570099C2FBF259B64A88CF9849DD9
{
public:

public:
};


// I18N.Rare.ENCibm875
struct ENCibm875_t9932B015168F449C93F3FCDC81E4CC0F4C627DA8  : public CP875_tA1D77603588C9477B1005787CDFC826E235E27BD
{
public:

public:
};


// I18N.West.ENCiso_8859_15
struct ENCiso_8859_15_tF49F88D2B9A9ED08EE679E234DA2A1C914147F57  : public CP28605_tF1D6657E73A685ABFFD29E25771515605CC3D669
{
public:

public:
};


// I18N.West.ENCiso_8859_2
struct ENCiso_8859_2_tDAAF31391C84BCD5CE4205C06C120B59AD059F17  : public CP28592_tE3D280B4DDEA315869DBC23FDE487FA718D35D7A
{
public:

public:
};


// I18N.West.ENCiso_8859_3
struct ENCiso_8859_3_tC3129918AEFAF2163E2107AA4766733F28052050  : public CP28593_t78DB4995E615D18BAC0DE9179311C4B5E6A3BCCC
{
public:

public:
};


// I18N.West.ENCiso_8859_7
struct ENCiso_8859_7_t84073ABD88A86C3FEF3E701477F356FC11E352EE  : public CP28597_t9F2C8B90A7BBA39F89A8612C43F85514640C5A0C
{
public:

public:
};


// I18N.West.ENCmacintosh
struct ENCmacintosh_t0E03AAAA14AC4E44CF4A007EBA06D6B34CC6360E  : public CP10000_t90376227B31EAFB15D36A7C3121598F0A81B3D56
{
public:

public:
};


// I18N.West.ENCwindows_1250
struct ENCwindows_1250_tFDCC5EF5EF779D0B53B7B901FEFD9F1E85B170E3  : public CP1250_t9CEAE2D9077CF4BFF7A372B496362D26251F9C04
{
public:

public:
};


// I18N.West.ENCwindows_1252
struct ENCwindows_1252_tFD95C0B7E15DB08B9518FAEAE5B12FA10948E282  : public CP1252_t83D225E8526CFC7079CE797954EB0E3C00CCF7AC
{
public:

public:
};


// I18N.West.ENCwindows_1253
struct ENCwindows_1253_tE570C95204691CF7E427B18E518612833B893467  : public CP1253_t9033E724E778CF0DABFE7A70C62ABAB8429EF04F
{
public:

public:
};


// I18N.West.ENCx_mac_icelandic
struct ENCx_mac_icelandic_tBEACB4B4A74220F6AF006BAC2A3B560054F4A35F  : public CP10079_tC8E1B9E147870510266629449DF0718F1658524B
{
public:

public:
};


// UnityEngine.MonoBehaviour
struct MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A  : public Behaviour_t1A3DDDCF73B4627928FBFE02ED52B7251777DBD9
{
public:

public:
};


// CameraController
struct CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.Camera CameraController::playerCamera
	Camera_tC44E094BAB53AFC8A014C6F9CFCE11F4FC38006C * ___playerCamera_4;
	// UnityEngine.Transform CameraController::target
	Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * ___target_5;
	// CameraController/CameraStyles CameraController::cameraMovementStyle
	int32_t ___cameraMovementStyle_6;
	// System.Single CameraController::freeCameraMouseTracking
	float ___freeCameraMouseTracking_7;
	// System.Single CameraController::maxDistanceFromTarget
	float ___maxDistanceFromTarget_8;
	// System.Single CameraController::cameraZCoordinate
	float ___cameraZCoordinate_9;
	// InputManager CameraController::inputManager
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * ___inputManager_10;

public:
	inline static int32_t get_offset_of_playerCamera_4() { return static_cast<int32_t>(offsetof(CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0, ___playerCamera_4)); }
	inline Camera_tC44E094BAB53AFC8A014C6F9CFCE11F4FC38006C * get_playerCamera_4() const { return ___playerCamera_4; }
	inline Camera_tC44E094BAB53AFC8A014C6F9CFCE11F4FC38006C ** get_address_of_playerCamera_4() { return &___playerCamera_4; }
	inline void set_playerCamera_4(Camera_tC44E094BAB53AFC8A014C6F9CFCE11F4FC38006C * value)
	{
		___playerCamera_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___playerCamera_4), (void*)value);
	}

	inline static int32_t get_offset_of_target_5() { return static_cast<int32_t>(offsetof(CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0, ___target_5)); }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * get_target_5() const { return ___target_5; }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 ** get_address_of_target_5() { return &___target_5; }
	inline void set_target_5(Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * value)
	{
		___target_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___target_5), (void*)value);
	}

	inline static int32_t get_offset_of_cameraMovementStyle_6() { return static_cast<int32_t>(offsetof(CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0, ___cameraMovementStyle_6)); }
	inline int32_t get_cameraMovementStyle_6() const { return ___cameraMovementStyle_6; }
	inline int32_t* get_address_of_cameraMovementStyle_6() { return &___cameraMovementStyle_6; }
	inline void set_cameraMovementStyle_6(int32_t value)
	{
		___cameraMovementStyle_6 = value;
	}

	inline static int32_t get_offset_of_freeCameraMouseTracking_7() { return static_cast<int32_t>(offsetof(CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0, ___freeCameraMouseTracking_7)); }
	inline float get_freeCameraMouseTracking_7() const { return ___freeCameraMouseTracking_7; }
	inline float* get_address_of_freeCameraMouseTracking_7() { return &___freeCameraMouseTracking_7; }
	inline void set_freeCameraMouseTracking_7(float value)
	{
		___freeCameraMouseTracking_7 = value;
	}

	inline static int32_t get_offset_of_maxDistanceFromTarget_8() { return static_cast<int32_t>(offsetof(CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0, ___maxDistanceFromTarget_8)); }
	inline float get_maxDistanceFromTarget_8() const { return ___maxDistanceFromTarget_8; }
	inline float* get_address_of_maxDistanceFromTarget_8() { return &___maxDistanceFromTarget_8; }
	inline void set_maxDistanceFromTarget_8(float value)
	{
		___maxDistanceFromTarget_8 = value;
	}

	inline static int32_t get_offset_of_cameraZCoordinate_9() { return static_cast<int32_t>(offsetof(CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0, ___cameraZCoordinate_9)); }
	inline float get_cameraZCoordinate_9() const { return ___cameraZCoordinate_9; }
	inline float* get_address_of_cameraZCoordinate_9() { return &___cameraZCoordinate_9; }
	inline void set_cameraZCoordinate_9(float value)
	{
		___cameraZCoordinate_9 = value;
	}

	inline static int32_t get_offset_of_inputManager_10() { return static_cast<int32_t>(offsetof(CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0, ___inputManager_10)); }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * get_inputManager_10() const { return ___inputManager_10; }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A ** get_address_of_inputManager_10() { return &___inputManager_10; }
	inline void set_inputManager_10(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * value)
	{
		___inputManager_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___inputManager_10), (void*)value);
	}
};


// Controller
struct Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.RuntimeAnimatorController Controller::animator
	RuntimeAnimatorController_t6F70D5BE51CCBA99132F444EFFA41439DFE71BAB * ___animator_4;
	// UnityEngine.Rigidbody2D Controller::myRigidbody
	Rigidbody2D_tD23204FEE9CB4A36737043B97FD409DE05D5DCE5 * ___myRigidbody_5;
	// System.Single Controller::moveSpeed
	float ___moveSpeed_6;
	// System.Single Controller::rotationSpeed
	float ___rotationSpeed_7;
	// InputManager Controller::inputManager
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * ___inputManager_8;
	// Controller/AimModes Controller::aimMode
	int32_t ___aimMode_9;
	// Controller/MovementModes Controller::movementMode
	int32_t ___movementMode_10;

public:
	inline static int32_t get_offset_of_animator_4() { return static_cast<int32_t>(offsetof(Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC, ___animator_4)); }
	inline RuntimeAnimatorController_t6F70D5BE51CCBA99132F444EFFA41439DFE71BAB * get_animator_4() const { return ___animator_4; }
	inline RuntimeAnimatorController_t6F70D5BE51CCBA99132F444EFFA41439DFE71BAB ** get_address_of_animator_4() { return &___animator_4; }
	inline void set_animator_4(RuntimeAnimatorController_t6F70D5BE51CCBA99132F444EFFA41439DFE71BAB * value)
	{
		___animator_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___animator_4), (void*)value);
	}

	inline static int32_t get_offset_of_myRigidbody_5() { return static_cast<int32_t>(offsetof(Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC, ___myRigidbody_5)); }
	inline Rigidbody2D_tD23204FEE9CB4A36737043B97FD409DE05D5DCE5 * get_myRigidbody_5() const { return ___myRigidbody_5; }
	inline Rigidbody2D_tD23204FEE9CB4A36737043B97FD409DE05D5DCE5 ** get_address_of_myRigidbody_5() { return &___myRigidbody_5; }
	inline void set_myRigidbody_5(Rigidbody2D_tD23204FEE9CB4A36737043B97FD409DE05D5DCE5 * value)
	{
		___myRigidbody_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___myRigidbody_5), (void*)value);
	}

	inline static int32_t get_offset_of_moveSpeed_6() { return static_cast<int32_t>(offsetof(Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC, ___moveSpeed_6)); }
	inline float get_moveSpeed_6() const { return ___moveSpeed_6; }
	inline float* get_address_of_moveSpeed_6() { return &___moveSpeed_6; }
	inline void set_moveSpeed_6(float value)
	{
		___moveSpeed_6 = value;
	}

	inline static int32_t get_offset_of_rotationSpeed_7() { return static_cast<int32_t>(offsetof(Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC, ___rotationSpeed_7)); }
	inline float get_rotationSpeed_7() const { return ___rotationSpeed_7; }
	inline float* get_address_of_rotationSpeed_7() { return &___rotationSpeed_7; }
	inline void set_rotationSpeed_7(float value)
	{
		___rotationSpeed_7 = value;
	}

	inline static int32_t get_offset_of_inputManager_8() { return static_cast<int32_t>(offsetof(Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC, ___inputManager_8)); }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * get_inputManager_8() const { return ___inputManager_8; }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A ** get_address_of_inputManager_8() { return &___inputManager_8; }
	inline void set_inputManager_8(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * value)
	{
		___inputManager_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___inputManager_8), (void*)value);
	}

	inline static int32_t get_offset_of_aimMode_9() { return static_cast<int32_t>(offsetof(Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC, ___aimMode_9)); }
	inline int32_t get_aimMode_9() const { return ___aimMode_9; }
	inline int32_t* get_address_of_aimMode_9() { return &___aimMode_9; }
	inline void set_aimMode_9(int32_t value)
	{
		___aimMode_9 = value;
	}

	inline static int32_t get_offset_of_movementMode_10() { return static_cast<int32_t>(offsetof(Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC, ___movementMode_10)); }
	inline int32_t get_movementMode_10() const { return ___movementMode_10; }
	inline int32_t* get_address_of_movementMode_10() { return &___movementMode_10; }
	inline void set_movementMode_10(int32_t value)
	{
		___movementMode_10 = value;
	}
};


// CursorChanger
struct CursorChanger_tF96791A48F42EF65902156CCA7FE7185F6B403F5  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.Texture2D CursorChanger::newCursorSprite
	Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * ___newCursorSprite_4;

public:
	inline static int32_t get_offset_of_newCursorSprite_4() { return static_cast<int32_t>(offsetof(CursorChanger_tF96791A48F42EF65902156CCA7FE7185F6B403F5, ___newCursorSprite_4)); }
	inline Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * get_newCursorSprite_4() const { return ___newCursorSprite_4; }
	inline Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF ** get_address_of_newCursorSprite_4() { return &___newCursorSprite_4; }
	inline void set_newCursorSprite_4(Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * value)
	{
		___newCursorSprite_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___newCursorSprite_4), (void*)value);
	}
};


// Damage
struct Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Int32 Damage::teamId
	int32_t ___teamId_4;
	// System.Int32 Damage::damageAmount
	int32_t ___damageAmount_5;
	// UnityEngine.GameObject Damage::hitEffect
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___hitEffect_6;
	// System.Boolean Damage::destroyAfterDamage
	bool ___destroyAfterDamage_7;
	// System.Boolean Damage::dealDamageOnTriggerEnter
	bool ___dealDamageOnTriggerEnter_8;
	// System.Boolean Damage::dealDamageOnTriggerStay
	bool ___dealDamageOnTriggerStay_9;
	// System.Boolean Damage::dealDamageOnCollision
	bool ___dealDamageOnCollision_10;

public:
	inline static int32_t get_offset_of_teamId_4() { return static_cast<int32_t>(offsetof(Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631, ___teamId_4)); }
	inline int32_t get_teamId_4() const { return ___teamId_4; }
	inline int32_t* get_address_of_teamId_4() { return &___teamId_4; }
	inline void set_teamId_4(int32_t value)
	{
		___teamId_4 = value;
	}

	inline static int32_t get_offset_of_damageAmount_5() { return static_cast<int32_t>(offsetof(Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631, ___damageAmount_5)); }
	inline int32_t get_damageAmount_5() const { return ___damageAmount_5; }
	inline int32_t* get_address_of_damageAmount_5() { return &___damageAmount_5; }
	inline void set_damageAmount_5(int32_t value)
	{
		___damageAmount_5 = value;
	}

	inline static int32_t get_offset_of_hitEffect_6() { return static_cast<int32_t>(offsetof(Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631, ___hitEffect_6)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_hitEffect_6() const { return ___hitEffect_6; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_hitEffect_6() { return &___hitEffect_6; }
	inline void set_hitEffect_6(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___hitEffect_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___hitEffect_6), (void*)value);
	}

	inline static int32_t get_offset_of_destroyAfterDamage_7() { return static_cast<int32_t>(offsetof(Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631, ___destroyAfterDamage_7)); }
	inline bool get_destroyAfterDamage_7() const { return ___destroyAfterDamage_7; }
	inline bool* get_address_of_destroyAfterDamage_7() { return &___destroyAfterDamage_7; }
	inline void set_destroyAfterDamage_7(bool value)
	{
		___destroyAfterDamage_7 = value;
	}

	inline static int32_t get_offset_of_dealDamageOnTriggerEnter_8() { return static_cast<int32_t>(offsetof(Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631, ___dealDamageOnTriggerEnter_8)); }
	inline bool get_dealDamageOnTriggerEnter_8() const { return ___dealDamageOnTriggerEnter_8; }
	inline bool* get_address_of_dealDamageOnTriggerEnter_8() { return &___dealDamageOnTriggerEnter_8; }
	inline void set_dealDamageOnTriggerEnter_8(bool value)
	{
		___dealDamageOnTriggerEnter_8 = value;
	}

	inline static int32_t get_offset_of_dealDamageOnTriggerStay_9() { return static_cast<int32_t>(offsetof(Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631, ___dealDamageOnTriggerStay_9)); }
	inline bool get_dealDamageOnTriggerStay_9() const { return ___dealDamageOnTriggerStay_9; }
	inline bool* get_address_of_dealDamageOnTriggerStay_9() { return &___dealDamageOnTriggerStay_9; }
	inline void set_dealDamageOnTriggerStay_9(bool value)
	{
		___dealDamageOnTriggerStay_9 = value;
	}

	inline static int32_t get_offset_of_dealDamageOnCollision_10() { return static_cast<int32_t>(offsetof(Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631, ___dealDamageOnCollision_10)); }
	inline bool get_dealDamageOnCollision_10() const { return ___dealDamageOnCollision_10; }
	inline bool* get_address_of_dealDamageOnCollision_10() { return &___dealDamageOnCollision_10; }
	inline void set_dealDamageOnCollision_10(bool value)
	{
		___dealDamageOnCollision_10 = value;
	}
};


// DirectionalMover
struct DirectionalMover_t7B90C8B7A99533C1181CF6625716C8C88E3F94AC  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.Vector3 DirectionalMover::direction
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___direction_4;
	// System.Single DirectionalMover::speed
	float ___speed_5;

public:
	inline static int32_t get_offset_of_direction_4() { return static_cast<int32_t>(offsetof(DirectionalMover_t7B90C8B7A99533C1181CF6625716C8C88E3F94AC, ___direction_4)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_direction_4() const { return ___direction_4; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_direction_4() { return &___direction_4; }
	inline void set_direction_4(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___direction_4 = value;
	}

	inline static int32_t get_offset_of_speed_5() { return static_cast<int32_t>(offsetof(DirectionalMover_t7B90C8B7A99533C1181CF6625716C8C88E3F94AC, ___speed_5)); }
	inline float get_speed_5() const { return ___speed_5; }
	inline float* get_address_of_speed_5() { return &___speed_5; }
	inline void set_speed_5(float value)
	{
		___speed_5 = value;
	}
};


// Enemy
struct Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Single Enemy::moveSpeed
	float ___moveSpeed_4;
	// System.Int32 Enemy::scoreValue
	int32_t ___scoreValue_5;
	// UnityEngine.Transform Enemy::followTarget
	Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * ___followTarget_6;
	// System.Single Enemy::followRange
	float ___followRange_7;
	// System.Collections.Generic.List`1<ShootingController> Enemy::guns
	List_1_tE1CA7B68837BDB140CFE4E57D54BBEDDFDAC51E2 * ___guns_8;
	// Enemy/ShootMode Enemy::shootMode
	int32_t ___shootMode_9;
	// Enemy/MovementModes Enemy::movementMode
	int32_t ___movementMode_10;
	// UnityEngine.Vector3 Enemy::scrollDirection
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___scrollDirection_11;

public:
	inline static int32_t get_offset_of_moveSpeed_4() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___moveSpeed_4)); }
	inline float get_moveSpeed_4() const { return ___moveSpeed_4; }
	inline float* get_address_of_moveSpeed_4() { return &___moveSpeed_4; }
	inline void set_moveSpeed_4(float value)
	{
		___moveSpeed_4 = value;
	}

	inline static int32_t get_offset_of_scoreValue_5() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___scoreValue_5)); }
	inline int32_t get_scoreValue_5() const { return ___scoreValue_5; }
	inline int32_t* get_address_of_scoreValue_5() { return &___scoreValue_5; }
	inline void set_scoreValue_5(int32_t value)
	{
		___scoreValue_5 = value;
	}

	inline static int32_t get_offset_of_followTarget_6() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___followTarget_6)); }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * get_followTarget_6() const { return ___followTarget_6; }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 ** get_address_of_followTarget_6() { return &___followTarget_6; }
	inline void set_followTarget_6(Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * value)
	{
		___followTarget_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___followTarget_6), (void*)value);
	}

	inline static int32_t get_offset_of_followRange_7() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___followRange_7)); }
	inline float get_followRange_7() const { return ___followRange_7; }
	inline float* get_address_of_followRange_7() { return &___followRange_7; }
	inline void set_followRange_7(float value)
	{
		___followRange_7 = value;
	}

	inline static int32_t get_offset_of_guns_8() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___guns_8)); }
	inline List_1_tE1CA7B68837BDB140CFE4E57D54BBEDDFDAC51E2 * get_guns_8() const { return ___guns_8; }
	inline List_1_tE1CA7B68837BDB140CFE4E57D54BBEDDFDAC51E2 ** get_address_of_guns_8() { return &___guns_8; }
	inline void set_guns_8(List_1_tE1CA7B68837BDB140CFE4E57D54BBEDDFDAC51E2 * value)
	{
		___guns_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___guns_8), (void*)value);
	}

	inline static int32_t get_offset_of_shootMode_9() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___shootMode_9)); }
	inline int32_t get_shootMode_9() const { return ___shootMode_9; }
	inline int32_t* get_address_of_shootMode_9() { return &___shootMode_9; }
	inline void set_shootMode_9(int32_t value)
	{
		___shootMode_9 = value;
	}

	inline static int32_t get_offset_of_movementMode_10() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___movementMode_10)); }
	inline int32_t get_movementMode_10() const { return ___movementMode_10; }
	inline int32_t* get_address_of_movementMode_10() { return &___movementMode_10; }
	inline void set_movementMode_10(int32_t value)
	{
		___movementMode_10 = value;
	}

	inline static int32_t get_offset_of_scrollDirection_11() { return static_cast<int32_t>(offsetof(Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627, ___scrollDirection_11)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_scrollDirection_11() const { return ___scrollDirection_11; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_scrollDirection_11() { return &___scrollDirection_11; }
	inline void set_scrollDirection_11(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___scrollDirection_11 = value;
	}
};


// EnemySpawner
struct EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.GameObject EnemySpawner::enemyPrefab
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___enemyPrefab_4;
	// UnityEngine.Transform EnemySpawner::target
	Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * ___target_5;
	// System.Single EnemySpawner::spawnRangeX
	float ___spawnRangeX_6;
	// System.Single EnemySpawner::spawnRangeY
	float ___spawnRangeY_7;
	// System.Int32 EnemySpawner::maxSpawn
	int32_t ___maxSpawn_8;
	// System.Boolean EnemySpawner::spawnInfinite
	bool ___spawnInfinite_9;
	// System.Int32 EnemySpawner::currentlySpawned
	int32_t ___currentlySpawned_10;
	// System.Single EnemySpawner::spawnDelay
	float ___spawnDelay_11;
	// System.Single EnemySpawner::lastSpawnTime
	float ___lastSpawnTime_12;
	// UnityEngine.Transform EnemySpawner::projectileHolder
	Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * ___projectileHolder_13;

public:
	inline static int32_t get_offset_of_enemyPrefab_4() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___enemyPrefab_4)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_enemyPrefab_4() const { return ___enemyPrefab_4; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_enemyPrefab_4() { return &___enemyPrefab_4; }
	inline void set_enemyPrefab_4(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___enemyPrefab_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enemyPrefab_4), (void*)value);
	}

	inline static int32_t get_offset_of_target_5() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___target_5)); }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * get_target_5() const { return ___target_5; }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 ** get_address_of_target_5() { return &___target_5; }
	inline void set_target_5(Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * value)
	{
		___target_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___target_5), (void*)value);
	}

	inline static int32_t get_offset_of_spawnRangeX_6() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___spawnRangeX_6)); }
	inline float get_spawnRangeX_6() const { return ___spawnRangeX_6; }
	inline float* get_address_of_spawnRangeX_6() { return &___spawnRangeX_6; }
	inline void set_spawnRangeX_6(float value)
	{
		___spawnRangeX_6 = value;
	}

	inline static int32_t get_offset_of_spawnRangeY_7() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___spawnRangeY_7)); }
	inline float get_spawnRangeY_7() const { return ___spawnRangeY_7; }
	inline float* get_address_of_spawnRangeY_7() { return &___spawnRangeY_7; }
	inline void set_spawnRangeY_7(float value)
	{
		___spawnRangeY_7 = value;
	}

	inline static int32_t get_offset_of_maxSpawn_8() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___maxSpawn_8)); }
	inline int32_t get_maxSpawn_8() const { return ___maxSpawn_8; }
	inline int32_t* get_address_of_maxSpawn_8() { return &___maxSpawn_8; }
	inline void set_maxSpawn_8(int32_t value)
	{
		___maxSpawn_8 = value;
	}

	inline static int32_t get_offset_of_spawnInfinite_9() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___spawnInfinite_9)); }
	inline bool get_spawnInfinite_9() const { return ___spawnInfinite_9; }
	inline bool* get_address_of_spawnInfinite_9() { return &___spawnInfinite_9; }
	inline void set_spawnInfinite_9(bool value)
	{
		___spawnInfinite_9 = value;
	}

	inline static int32_t get_offset_of_currentlySpawned_10() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___currentlySpawned_10)); }
	inline int32_t get_currentlySpawned_10() const { return ___currentlySpawned_10; }
	inline int32_t* get_address_of_currentlySpawned_10() { return &___currentlySpawned_10; }
	inline void set_currentlySpawned_10(int32_t value)
	{
		___currentlySpawned_10 = value;
	}

	inline static int32_t get_offset_of_spawnDelay_11() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___spawnDelay_11)); }
	inline float get_spawnDelay_11() const { return ___spawnDelay_11; }
	inline float* get_address_of_spawnDelay_11() { return &___spawnDelay_11; }
	inline void set_spawnDelay_11(float value)
	{
		___spawnDelay_11 = value;
	}

	inline static int32_t get_offset_of_lastSpawnTime_12() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___lastSpawnTime_12)); }
	inline float get_lastSpawnTime_12() const { return ___lastSpawnTime_12; }
	inline float* get_address_of_lastSpawnTime_12() { return &___lastSpawnTime_12; }
	inline void set_lastSpawnTime_12(float value)
	{
		___lastSpawnTime_12 = value;
	}

	inline static int32_t get_offset_of_projectileHolder_13() { return static_cast<int32_t>(offsetof(EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E, ___projectileHolder_13)); }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * get_projectileHolder_13() const { return ___projectileHolder_13; }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 ** get_address_of_projectileHolder_13() { return &___projectileHolder_13; }
	inline void set_projectileHolder_13(Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * value)
	{
		___projectileHolder_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___projectileHolder_13), (void*)value);
	}
};


// GameManager
struct GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UIManager GameManager::uiManager
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858 * ___uiManager_5;
	// UnityEngine.GameObject GameManager::player
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___player_6;
	// System.Int32 GameManager::gameManagerScore
	int32_t ___gameManagerScore_7;
	// System.Int32 GameManager::highScore
	int32_t ___highScore_8;
	// System.Boolean GameManager::gameIsWinnable
	bool ___gameIsWinnable_9;
	// System.Int32 GameManager::enemiesToDefeat
	int32_t ___enemiesToDefeat_10;
	// System.Int32 GameManager::enemiesDefeated
	int32_t ___enemiesDefeated_11;
	// System.Boolean GameManager::printDebugOfWinnableStatus
	bool ___printDebugOfWinnableStatus_12;
	// System.Int32 GameManager::gameVictoryPageIndex
	int32_t ___gameVictoryPageIndex_13;
	// UnityEngine.GameObject GameManager::victoryEffect
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___victoryEffect_14;
	// System.Int32 GameManager::numberOfEnemiesFoundAtStart
	int32_t ___numberOfEnemiesFoundAtStart_15;
	// System.Int32 GameManager::gameOverPageIndex
	int32_t ___gameOverPageIndex_16;
	// UnityEngine.GameObject GameManager::gameOverEffect
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___gameOverEffect_17;
	// System.Boolean GameManager::gameIsOver
	bool ___gameIsOver_18;

public:
	inline static int32_t get_offset_of_uiManager_5() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___uiManager_5)); }
	inline UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858 * get_uiManager_5() const { return ___uiManager_5; }
	inline UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858 ** get_address_of_uiManager_5() { return &___uiManager_5; }
	inline void set_uiManager_5(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858 * value)
	{
		___uiManager_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___uiManager_5), (void*)value);
	}

	inline static int32_t get_offset_of_player_6() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___player_6)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_player_6() const { return ___player_6; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_player_6() { return &___player_6; }
	inline void set_player_6(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___player_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___player_6), (void*)value);
	}

	inline static int32_t get_offset_of_gameManagerScore_7() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___gameManagerScore_7)); }
	inline int32_t get_gameManagerScore_7() const { return ___gameManagerScore_7; }
	inline int32_t* get_address_of_gameManagerScore_7() { return &___gameManagerScore_7; }
	inline void set_gameManagerScore_7(int32_t value)
	{
		___gameManagerScore_7 = value;
	}

	inline static int32_t get_offset_of_highScore_8() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___highScore_8)); }
	inline int32_t get_highScore_8() const { return ___highScore_8; }
	inline int32_t* get_address_of_highScore_8() { return &___highScore_8; }
	inline void set_highScore_8(int32_t value)
	{
		___highScore_8 = value;
	}

	inline static int32_t get_offset_of_gameIsWinnable_9() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___gameIsWinnable_9)); }
	inline bool get_gameIsWinnable_9() const { return ___gameIsWinnable_9; }
	inline bool* get_address_of_gameIsWinnable_9() { return &___gameIsWinnable_9; }
	inline void set_gameIsWinnable_9(bool value)
	{
		___gameIsWinnable_9 = value;
	}

	inline static int32_t get_offset_of_enemiesToDefeat_10() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___enemiesToDefeat_10)); }
	inline int32_t get_enemiesToDefeat_10() const { return ___enemiesToDefeat_10; }
	inline int32_t* get_address_of_enemiesToDefeat_10() { return &___enemiesToDefeat_10; }
	inline void set_enemiesToDefeat_10(int32_t value)
	{
		___enemiesToDefeat_10 = value;
	}

	inline static int32_t get_offset_of_enemiesDefeated_11() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___enemiesDefeated_11)); }
	inline int32_t get_enemiesDefeated_11() const { return ___enemiesDefeated_11; }
	inline int32_t* get_address_of_enemiesDefeated_11() { return &___enemiesDefeated_11; }
	inline void set_enemiesDefeated_11(int32_t value)
	{
		___enemiesDefeated_11 = value;
	}

	inline static int32_t get_offset_of_printDebugOfWinnableStatus_12() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___printDebugOfWinnableStatus_12)); }
	inline bool get_printDebugOfWinnableStatus_12() const { return ___printDebugOfWinnableStatus_12; }
	inline bool* get_address_of_printDebugOfWinnableStatus_12() { return &___printDebugOfWinnableStatus_12; }
	inline void set_printDebugOfWinnableStatus_12(bool value)
	{
		___printDebugOfWinnableStatus_12 = value;
	}

	inline static int32_t get_offset_of_gameVictoryPageIndex_13() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___gameVictoryPageIndex_13)); }
	inline int32_t get_gameVictoryPageIndex_13() const { return ___gameVictoryPageIndex_13; }
	inline int32_t* get_address_of_gameVictoryPageIndex_13() { return &___gameVictoryPageIndex_13; }
	inline void set_gameVictoryPageIndex_13(int32_t value)
	{
		___gameVictoryPageIndex_13 = value;
	}

	inline static int32_t get_offset_of_victoryEffect_14() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___victoryEffect_14)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_victoryEffect_14() const { return ___victoryEffect_14; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_victoryEffect_14() { return &___victoryEffect_14; }
	inline void set_victoryEffect_14(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___victoryEffect_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___victoryEffect_14), (void*)value);
	}

	inline static int32_t get_offset_of_numberOfEnemiesFoundAtStart_15() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___numberOfEnemiesFoundAtStart_15)); }
	inline int32_t get_numberOfEnemiesFoundAtStart_15() const { return ___numberOfEnemiesFoundAtStart_15; }
	inline int32_t* get_address_of_numberOfEnemiesFoundAtStart_15() { return &___numberOfEnemiesFoundAtStart_15; }
	inline void set_numberOfEnemiesFoundAtStart_15(int32_t value)
	{
		___numberOfEnemiesFoundAtStart_15 = value;
	}

	inline static int32_t get_offset_of_gameOverPageIndex_16() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___gameOverPageIndex_16)); }
	inline int32_t get_gameOverPageIndex_16() const { return ___gameOverPageIndex_16; }
	inline int32_t* get_address_of_gameOverPageIndex_16() { return &___gameOverPageIndex_16; }
	inline void set_gameOverPageIndex_16(int32_t value)
	{
		___gameOverPageIndex_16 = value;
	}

	inline static int32_t get_offset_of_gameOverEffect_17() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___gameOverEffect_17)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_gameOverEffect_17() const { return ___gameOverEffect_17; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_gameOverEffect_17() { return &___gameOverEffect_17; }
	inline void set_gameOverEffect_17(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___gameOverEffect_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___gameOverEffect_17), (void*)value);
	}

	inline static int32_t get_offset_of_gameIsOver_18() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1, ___gameIsOver_18)); }
	inline bool get_gameIsOver_18() const { return ___gameIsOver_18; }
	inline bool* get_address_of_gameIsOver_18() { return &___gameIsOver_18; }
	inline void set_gameIsOver_18(bool value)
	{
		___gameIsOver_18 = value;
	}
};

struct GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1_StaticFields
{
public:
	// GameManager GameManager::instance
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1 * ___instance_4;

public:
	inline static int32_t get_offset_of_instance_4() { return static_cast<int32_t>(offsetof(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1_StaticFields, ___instance_4)); }
	inline GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1 * get_instance_4() const { return ___instance_4; }
	inline GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1 ** get_address_of_instance_4() { return &___instance_4; }
	inline void set_instance_4(GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1 * value)
	{
		___instance_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___instance_4), (void*)value);
	}
};


// Health
struct Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Int32 Health::teamId
	int32_t ___teamId_4;
	// System.Int32 Health::defaultHealth
	int32_t ___defaultHealth_5;
	// System.Int32 Health::maximumHealth
	int32_t ___maximumHealth_6;
	// System.Int32 Health::currentHealth
	int32_t ___currentHealth_7;
	// System.Single Health::invincibilityTime
	float ___invincibilityTime_8;
	// System.Boolean Health::isAlwaysInvincible
	bool ___isAlwaysInvincible_9;
	// System.Boolean Health::useLives
	bool ___useLives_10;
	// System.Int32 Health::currentLives
	int32_t ___currentLives_11;
	// System.Int32 Health::maximumLives
	int32_t ___maximumLives_12;
	// System.Single Health::timeToBecomeDamagableAgain
	float ___timeToBecomeDamagableAgain_13;
	// System.Boolean Health::isInvincableFromDamage
	bool ___isInvincableFromDamage_14;
	// UnityEngine.Vector3 Health::respawnPosition
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___respawnPosition_15;
	// UnityEngine.GameObject Health::deathEffect
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___deathEffect_16;
	// UnityEngine.GameObject Health::hitEffect
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___hitEffect_17;

public:
	inline static int32_t get_offset_of_teamId_4() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___teamId_4)); }
	inline int32_t get_teamId_4() const { return ___teamId_4; }
	inline int32_t* get_address_of_teamId_4() { return &___teamId_4; }
	inline void set_teamId_4(int32_t value)
	{
		___teamId_4 = value;
	}

	inline static int32_t get_offset_of_defaultHealth_5() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___defaultHealth_5)); }
	inline int32_t get_defaultHealth_5() const { return ___defaultHealth_5; }
	inline int32_t* get_address_of_defaultHealth_5() { return &___defaultHealth_5; }
	inline void set_defaultHealth_5(int32_t value)
	{
		___defaultHealth_5 = value;
	}

	inline static int32_t get_offset_of_maximumHealth_6() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___maximumHealth_6)); }
	inline int32_t get_maximumHealth_6() const { return ___maximumHealth_6; }
	inline int32_t* get_address_of_maximumHealth_6() { return &___maximumHealth_6; }
	inline void set_maximumHealth_6(int32_t value)
	{
		___maximumHealth_6 = value;
	}

	inline static int32_t get_offset_of_currentHealth_7() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___currentHealth_7)); }
	inline int32_t get_currentHealth_7() const { return ___currentHealth_7; }
	inline int32_t* get_address_of_currentHealth_7() { return &___currentHealth_7; }
	inline void set_currentHealth_7(int32_t value)
	{
		___currentHealth_7 = value;
	}

	inline static int32_t get_offset_of_invincibilityTime_8() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___invincibilityTime_8)); }
	inline float get_invincibilityTime_8() const { return ___invincibilityTime_8; }
	inline float* get_address_of_invincibilityTime_8() { return &___invincibilityTime_8; }
	inline void set_invincibilityTime_8(float value)
	{
		___invincibilityTime_8 = value;
	}

	inline static int32_t get_offset_of_isAlwaysInvincible_9() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___isAlwaysInvincible_9)); }
	inline bool get_isAlwaysInvincible_9() const { return ___isAlwaysInvincible_9; }
	inline bool* get_address_of_isAlwaysInvincible_9() { return &___isAlwaysInvincible_9; }
	inline void set_isAlwaysInvincible_9(bool value)
	{
		___isAlwaysInvincible_9 = value;
	}

	inline static int32_t get_offset_of_useLives_10() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___useLives_10)); }
	inline bool get_useLives_10() const { return ___useLives_10; }
	inline bool* get_address_of_useLives_10() { return &___useLives_10; }
	inline void set_useLives_10(bool value)
	{
		___useLives_10 = value;
	}

	inline static int32_t get_offset_of_currentLives_11() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___currentLives_11)); }
	inline int32_t get_currentLives_11() const { return ___currentLives_11; }
	inline int32_t* get_address_of_currentLives_11() { return &___currentLives_11; }
	inline void set_currentLives_11(int32_t value)
	{
		___currentLives_11 = value;
	}

	inline static int32_t get_offset_of_maximumLives_12() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___maximumLives_12)); }
	inline int32_t get_maximumLives_12() const { return ___maximumLives_12; }
	inline int32_t* get_address_of_maximumLives_12() { return &___maximumLives_12; }
	inline void set_maximumLives_12(int32_t value)
	{
		___maximumLives_12 = value;
	}

	inline static int32_t get_offset_of_timeToBecomeDamagableAgain_13() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___timeToBecomeDamagableAgain_13)); }
	inline float get_timeToBecomeDamagableAgain_13() const { return ___timeToBecomeDamagableAgain_13; }
	inline float* get_address_of_timeToBecomeDamagableAgain_13() { return &___timeToBecomeDamagableAgain_13; }
	inline void set_timeToBecomeDamagableAgain_13(float value)
	{
		___timeToBecomeDamagableAgain_13 = value;
	}

	inline static int32_t get_offset_of_isInvincableFromDamage_14() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___isInvincableFromDamage_14)); }
	inline bool get_isInvincableFromDamage_14() const { return ___isInvincableFromDamage_14; }
	inline bool* get_address_of_isInvincableFromDamage_14() { return &___isInvincableFromDamage_14; }
	inline void set_isInvincableFromDamage_14(bool value)
	{
		___isInvincableFromDamage_14 = value;
	}

	inline static int32_t get_offset_of_respawnPosition_15() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___respawnPosition_15)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_respawnPosition_15() const { return ___respawnPosition_15; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_respawnPosition_15() { return &___respawnPosition_15; }
	inline void set_respawnPosition_15(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___respawnPosition_15 = value;
	}

	inline static int32_t get_offset_of_deathEffect_16() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___deathEffect_16)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_deathEffect_16() const { return ___deathEffect_16; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_deathEffect_16() { return &___deathEffect_16; }
	inline void set_deathEffect_16(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___deathEffect_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___deathEffect_16), (void*)value);
	}

	inline static int32_t get_offset_of_hitEffect_17() { return static_cast<int32_t>(offsetof(Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96, ___hitEffect_17)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_hitEffect_17() const { return ___hitEffect_17; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_hitEffect_17() { return &___hitEffect_17; }
	inline void set_hitEffect_17(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___hitEffect_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___hitEffect_17), (void*)value);
	}
};


// HighlightFix
struct HighlightFix_t78E5E5D7159CB92B74587BE3B49A3CDC51829B3C  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// InputManager
struct InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Single InputManager::horizontalMoveAxis
	float ___horizontalMoveAxis_5;
	// System.Single InputManager::verticalMoveAxis
	float ___verticalMoveAxis_6;
	// System.Single InputManager::horizontalLookAxis
	float ___horizontalLookAxis_7;
	// System.Single InputManager::verticalLookAxis
	float ___verticalLookAxis_8;
	// System.Boolean InputManager::firePressed
	bool ___firePressed_9;
	// System.Boolean InputManager::fireHeld
	bool ___fireHeld_10;
	// System.Boolean InputManager::pausePressed
	bool ___pausePressed_11;

public:
	inline static int32_t get_offset_of_horizontalMoveAxis_5() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A, ___horizontalMoveAxis_5)); }
	inline float get_horizontalMoveAxis_5() const { return ___horizontalMoveAxis_5; }
	inline float* get_address_of_horizontalMoveAxis_5() { return &___horizontalMoveAxis_5; }
	inline void set_horizontalMoveAxis_5(float value)
	{
		___horizontalMoveAxis_5 = value;
	}

	inline static int32_t get_offset_of_verticalMoveAxis_6() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A, ___verticalMoveAxis_6)); }
	inline float get_verticalMoveAxis_6() const { return ___verticalMoveAxis_6; }
	inline float* get_address_of_verticalMoveAxis_6() { return &___verticalMoveAxis_6; }
	inline void set_verticalMoveAxis_6(float value)
	{
		___verticalMoveAxis_6 = value;
	}

	inline static int32_t get_offset_of_horizontalLookAxis_7() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A, ___horizontalLookAxis_7)); }
	inline float get_horizontalLookAxis_7() const { return ___horizontalLookAxis_7; }
	inline float* get_address_of_horizontalLookAxis_7() { return &___horizontalLookAxis_7; }
	inline void set_horizontalLookAxis_7(float value)
	{
		___horizontalLookAxis_7 = value;
	}

	inline static int32_t get_offset_of_verticalLookAxis_8() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A, ___verticalLookAxis_8)); }
	inline float get_verticalLookAxis_8() const { return ___verticalLookAxis_8; }
	inline float* get_address_of_verticalLookAxis_8() { return &___verticalLookAxis_8; }
	inline void set_verticalLookAxis_8(float value)
	{
		___verticalLookAxis_8 = value;
	}

	inline static int32_t get_offset_of_firePressed_9() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A, ___firePressed_9)); }
	inline bool get_firePressed_9() const { return ___firePressed_9; }
	inline bool* get_address_of_firePressed_9() { return &___firePressed_9; }
	inline void set_firePressed_9(bool value)
	{
		___firePressed_9 = value;
	}

	inline static int32_t get_offset_of_fireHeld_10() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A, ___fireHeld_10)); }
	inline bool get_fireHeld_10() const { return ___fireHeld_10; }
	inline bool* get_address_of_fireHeld_10() { return &___fireHeld_10; }
	inline void set_fireHeld_10(bool value)
	{
		___fireHeld_10 = value;
	}

	inline static int32_t get_offset_of_pausePressed_11() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A, ___pausePressed_11)); }
	inline bool get_pausePressed_11() const { return ___pausePressed_11; }
	inline bool* get_address_of_pausePressed_11() { return &___pausePressed_11; }
	inline void set_pausePressed_11(bool value)
	{
		___pausePressed_11 = value;
	}
};

struct InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A_StaticFields
{
public:
	// InputManager InputManager::instance
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * ___instance_4;

public:
	inline static int32_t get_offset_of_instance_4() { return static_cast<int32_t>(offsetof(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A_StaticFields, ___instance_4)); }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * get_instance_4() const { return ___instance_4; }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A ** get_address_of_instance_4() { return &___instance_4; }
	inline void set_instance_4(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * value)
	{
		___instance_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___instance_4), (void*)value);
	}
};


// LevelLoadButton
struct LevelLoadButton_t82AF66BD3147D5694F41F1C2E1E22F0BBA1A194B  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// Projectile
struct Projectile_t8BAB3D47786918922F97CC7FADEB6146D6E31B9F  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Single Projectile::projectileSpeed
	float ___projectileSpeed_4;

public:
	inline static int32_t get_offset_of_projectileSpeed_4() { return static_cast<int32_t>(offsetof(Projectile_t8BAB3D47786918922F97CC7FADEB6146D6E31B9F, ___projectileSpeed_4)); }
	inline float get_projectileSpeed_4() const { return ___projectileSpeed_4; }
	inline float* get_address_of_projectileSpeed_4() { return &___projectileSpeed_4; }
	inline void set_projectileSpeed_4(float value)
	{
		___projectileSpeed_4 = value;
	}
};


// QuitGameButton
struct QuitGameButton_t3E0ABE520A7973062C0E581168B878FE1F6AC215  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// ScoreReseter
struct ScoreReseter_tEDB5071910ACDAF7E9456B270B5DEEAABD9D07E4  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// ScreenshotUtility
struct ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Boolean ScreenshotUtility::runOnlyInEditor
	bool ___runOnlyInEditor_5;
	// System.String ScreenshotUtility::m_ScreenshotKey
	String_t* ___m_ScreenshotKey_6;
	// System.Int32 ScreenshotUtility::m_ScaleFactor
	int32_t ___m_ScaleFactor_7;
	// System.Boolean ScreenshotUtility::includeImageSizeInFilename
	bool ___includeImageSizeInFilename_8;
	// System.Int32 ScreenshotUtility::m_ImageCount
	int32_t ___m_ImageCount_9;

public:
	inline static int32_t get_offset_of_runOnlyInEditor_5() { return static_cast<int32_t>(offsetof(ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D, ___runOnlyInEditor_5)); }
	inline bool get_runOnlyInEditor_5() const { return ___runOnlyInEditor_5; }
	inline bool* get_address_of_runOnlyInEditor_5() { return &___runOnlyInEditor_5; }
	inline void set_runOnlyInEditor_5(bool value)
	{
		___runOnlyInEditor_5 = value;
	}

	inline static int32_t get_offset_of_m_ScreenshotKey_6() { return static_cast<int32_t>(offsetof(ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D, ___m_ScreenshotKey_6)); }
	inline String_t* get_m_ScreenshotKey_6() const { return ___m_ScreenshotKey_6; }
	inline String_t** get_address_of_m_ScreenshotKey_6() { return &___m_ScreenshotKey_6; }
	inline void set_m_ScreenshotKey_6(String_t* value)
	{
		___m_ScreenshotKey_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ScreenshotKey_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_ScaleFactor_7() { return static_cast<int32_t>(offsetof(ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D, ___m_ScaleFactor_7)); }
	inline int32_t get_m_ScaleFactor_7() const { return ___m_ScaleFactor_7; }
	inline int32_t* get_address_of_m_ScaleFactor_7() { return &___m_ScaleFactor_7; }
	inline void set_m_ScaleFactor_7(int32_t value)
	{
		___m_ScaleFactor_7 = value;
	}

	inline static int32_t get_offset_of_includeImageSizeInFilename_8() { return static_cast<int32_t>(offsetof(ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D, ___includeImageSizeInFilename_8)); }
	inline bool get_includeImageSizeInFilename_8() const { return ___includeImageSizeInFilename_8; }
	inline bool* get_address_of_includeImageSizeInFilename_8() { return &___includeImageSizeInFilename_8; }
	inline void set_includeImageSizeInFilename_8(bool value)
	{
		___includeImageSizeInFilename_8 = value;
	}

	inline static int32_t get_offset_of_m_ImageCount_9() { return static_cast<int32_t>(offsetof(ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D, ___m_ImageCount_9)); }
	inline int32_t get_m_ImageCount_9() const { return ___m_ImageCount_9; }
	inline int32_t* get_address_of_m_ImageCount_9() { return &___m_ImageCount_9; }
	inline void set_m_ImageCount_9(int32_t value)
	{
		___m_ImageCount_9 = value;
	}
};

struct ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D_StaticFields
{
public:
	// ScreenshotUtility ScreenshotUtility::screenShotUtility
	ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D * ___screenShotUtility_4;

public:
	inline static int32_t get_offset_of_screenShotUtility_4() { return static_cast<int32_t>(offsetof(ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D_StaticFields, ___screenShotUtility_4)); }
	inline ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D * get_screenShotUtility_4() const { return ___screenShotUtility_4; }
	inline ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D ** get_address_of_screenShotUtility_4() { return &___screenShotUtility_4; }
	inline void set_screenShotUtility_4(ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D * value)
	{
		___screenShotUtility_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___screenShotUtility_4), (void*)value);
	}
};


// ShootingController
struct ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.GameObject ShootingController::projectilePrefab
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___projectilePrefab_4;
	// UnityEngine.Transform ShootingController::projectileHolder
	Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * ___projectileHolder_5;
	// System.Boolean ShootingController::isPlayerControlled
	bool ___isPlayerControlled_6;
	// System.Single ShootingController::fireRate
	float ___fireRate_7;
	// System.Single ShootingController::projectileSpread
	float ___projectileSpread_8;
	// System.Single ShootingController::lastFired
	float ___lastFired_9;
	// UnityEngine.GameObject ShootingController::fireEffect
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___fireEffect_10;
	// InputManager ShootingController::inputManager
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * ___inputManager_11;

public:
	inline static int32_t get_offset_of_projectilePrefab_4() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___projectilePrefab_4)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_projectilePrefab_4() const { return ___projectilePrefab_4; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_projectilePrefab_4() { return &___projectilePrefab_4; }
	inline void set_projectilePrefab_4(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___projectilePrefab_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___projectilePrefab_4), (void*)value);
	}

	inline static int32_t get_offset_of_projectileHolder_5() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___projectileHolder_5)); }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * get_projectileHolder_5() const { return ___projectileHolder_5; }
	inline Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 ** get_address_of_projectileHolder_5() { return &___projectileHolder_5; }
	inline void set_projectileHolder_5(Transform_tA8193BB29D4D2C7EC04918F3ED1816345186C3F1 * value)
	{
		___projectileHolder_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___projectileHolder_5), (void*)value);
	}

	inline static int32_t get_offset_of_isPlayerControlled_6() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___isPlayerControlled_6)); }
	inline bool get_isPlayerControlled_6() const { return ___isPlayerControlled_6; }
	inline bool* get_address_of_isPlayerControlled_6() { return &___isPlayerControlled_6; }
	inline void set_isPlayerControlled_6(bool value)
	{
		___isPlayerControlled_6 = value;
	}

	inline static int32_t get_offset_of_fireRate_7() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___fireRate_7)); }
	inline float get_fireRate_7() const { return ___fireRate_7; }
	inline float* get_address_of_fireRate_7() { return &___fireRate_7; }
	inline void set_fireRate_7(float value)
	{
		___fireRate_7 = value;
	}

	inline static int32_t get_offset_of_projectileSpread_8() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___projectileSpread_8)); }
	inline float get_projectileSpread_8() const { return ___projectileSpread_8; }
	inline float* get_address_of_projectileSpread_8() { return &___projectileSpread_8; }
	inline void set_projectileSpread_8(float value)
	{
		___projectileSpread_8 = value;
	}

	inline static int32_t get_offset_of_lastFired_9() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___lastFired_9)); }
	inline float get_lastFired_9() const { return ___lastFired_9; }
	inline float* get_address_of_lastFired_9() { return &___lastFired_9; }
	inline void set_lastFired_9(float value)
	{
		___lastFired_9 = value;
	}

	inline static int32_t get_offset_of_fireEffect_10() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___fireEffect_10)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_fireEffect_10() const { return ___fireEffect_10; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_fireEffect_10() { return &___fireEffect_10; }
	inline void set_fireEffect_10(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___fireEffect_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___fireEffect_10), (void*)value);
	}

	inline static int32_t get_offset_of_inputManager_11() { return static_cast<int32_t>(offsetof(ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4, ___inputManager_11)); }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * get_inputManager_11() const { return ___inputManager_11; }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A ** get_address_of_inputManager_11() { return &___inputManager_11; }
	inline void set_inputManager_11(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * value)
	{
		___inputManager_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___inputManager_11), (void*)value);
	}
};


// TimedObjectDestroyer
struct TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Single TimedObjectDestroyer::lifetime
	float ___lifetime_4;
	// System.Single TimedObjectDestroyer::timeAlive
	float ___timeAlive_5;
	// System.Boolean TimedObjectDestroyer::destroyChildrenOnDeath
	bool ___destroyChildrenOnDeath_6;

public:
	inline static int32_t get_offset_of_lifetime_4() { return static_cast<int32_t>(offsetof(TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365, ___lifetime_4)); }
	inline float get_lifetime_4() const { return ___lifetime_4; }
	inline float* get_address_of_lifetime_4() { return &___lifetime_4; }
	inline void set_lifetime_4(float value)
	{
		___lifetime_4 = value;
	}

	inline static int32_t get_offset_of_timeAlive_5() { return static_cast<int32_t>(offsetof(TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365, ___timeAlive_5)); }
	inline float get_timeAlive_5() const { return ___timeAlive_5; }
	inline float* get_address_of_timeAlive_5() { return &___timeAlive_5; }
	inline void set_timeAlive_5(float value)
	{
		___timeAlive_5 = value;
	}

	inline static int32_t get_offset_of_destroyChildrenOnDeath_6() { return static_cast<int32_t>(offsetof(TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365, ___destroyChildrenOnDeath_6)); }
	inline bool get_destroyChildrenOnDeath_6() const { return ___destroyChildrenOnDeath_6; }
	inline bool* get_address_of_destroyChildrenOnDeath_6() { return &___destroyChildrenOnDeath_6; }
	inline void set_destroyChildrenOnDeath_6(bool value)
	{
		___destroyChildrenOnDeath_6 = value;
	}
};

struct TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365_StaticFields
{
public:
	// System.Boolean TimedObjectDestroyer::quitting
	bool ___quitting_7;

public:
	inline static int32_t get_offset_of_quitting_7() { return static_cast<int32_t>(offsetof(TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365_StaticFields, ___quitting_7)); }
	inline bool get_quitting_7() const { return ___quitting_7; }
	inline bool* get_address_of_quitting_7() { return &___quitting_7; }
	inline void set_quitting_7(bool value)
	{
		___quitting_7 = value;
	}
};


// UIManager
struct UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// System.Collections.Generic.List`1<UIPage> UIManager::pages
	List_1_tFCFF53D233888DFF08F2A45F1501E1057DA9B9BD * ___pages_4;
	// System.Int32 UIManager::currentPage
	int32_t ___currentPage_5;
	// System.Int32 UIManager::defaultPage
	int32_t ___defaultPage_6;
	// System.Int32 UIManager::pausePageIndex
	int32_t ___pausePageIndex_7;
	// System.Boolean UIManager::allowPause
	bool ___allowPause_8;
	// System.Boolean UIManager::isPaused
	bool ___isPaused_9;
	// System.Collections.Generic.List`1<UIelement> UIManager::UIelements
	List_1_t03EA177FD37956FDC8B014EA43A09851D4856DF4 * ___UIelements_10;
	// UnityEngine.EventSystems.EventSystem UIManager::eventSystem
	EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * ___eventSystem_11;
	// InputManager UIManager::inputManager
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * ___inputManager_12;

public:
	inline static int32_t get_offset_of_pages_4() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___pages_4)); }
	inline List_1_tFCFF53D233888DFF08F2A45F1501E1057DA9B9BD * get_pages_4() const { return ___pages_4; }
	inline List_1_tFCFF53D233888DFF08F2A45F1501E1057DA9B9BD ** get_address_of_pages_4() { return &___pages_4; }
	inline void set_pages_4(List_1_tFCFF53D233888DFF08F2A45F1501E1057DA9B9BD * value)
	{
		___pages_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___pages_4), (void*)value);
	}

	inline static int32_t get_offset_of_currentPage_5() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___currentPage_5)); }
	inline int32_t get_currentPage_5() const { return ___currentPage_5; }
	inline int32_t* get_address_of_currentPage_5() { return &___currentPage_5; }
	inline void set_currentPage_5(int32_t value)
	{
		___currentPage_5 = value;
	}

	inline static int32_t get_offset_of_defaultPage_6() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___defaultPage_6)); }
	inline int32_t get_defaultPage_6() const { return ___defaultPage_6; }
	inline int32_t* get_address_of_defaultPage_6() { return &___defaultPage_6; }
	inline void set_defaultPage_6(int32_t value)
	{
		___defaultPage_6 = value;
	}

	inline static int32_t get_offset_of_pausePageIndex_7() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___pausePageIndex_7)); }
	inline int32_t get_pausePageIndex_7() const { return ___pausePageIndex_7; }
	inline int32_t* get_address_of_pausePageIndex_7() { return &___pausePageIndex_7; }
	inline void set_pausePageIndex_7(int32_t value)
	{
		___pausePageIndex_7 = value;
	}

	inline static int32_t get_offset_of_allowPause_8() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___allowPause_8)); }
	inline bool get_allowPause_8() const { return ___allowPause_8; }
	inline bool* get_address_of_allowPause_8() { return &___allowPause_8; }
	inline void set_allowPause_8(bool value)
	{
		___allowPause_8 = value;
	}

	inline static int32_t get_offset_of_isPaused_9() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___isPaused_9)); }
	inline bool get_isPaused_9() const { return ___isPaused_9; }
	inline bool* get_address_of_isPaused_9() { return &___isPaused_9; }
	inline void set_isPaused_9(bool value)
	{
		___isPaused_9 = value;
	}

	inline static int32_t get_offset_of_UIelements_10() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___UIelements_10)); }
	inline List_1_t03EA177FD37956FDC8B014EA43A09851D4856DF4 * get_UIelements_10() const { return ___UIelements_10; }
	inline List_1_t03EA177FD37956FDC8B014EA43A09851D4856DF4 ** get_address_of_UIelements_10() { return &___UIelements_10; }
	inline void set_UIelements_10(List_1_t03EA177FD37956FDC8B014EA43A09851D4856DF4 * value)
	{
		___UIelements_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UIelements_10), (void*)value);
	}

	inline static int32_t get_offset_of_eventSystem_11() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___eventSystem_11)); }
	inline EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * get_eventSystem_11() const { return ___eventSystem_11; }
	inline EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C ** get_address_of_eventSystem_11() { return &___eventSystem_11; }
	inline void set_eventSystem_11(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * value)
	{
		___eventSystem_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___eventSystem_11), (void*)value);
	}

	inline static int32_t get_offset_of_inputManager_12() { return static_cast<int32_t>(offsetof(UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858, ___inputManager_12)); }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * get_inputManager_12() const { return ___inputManager_12; }
	inline InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A ** get_address_of_inputManager_12() { return &___inputManager_12; }
	inline void set_inputManager_12(InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A * value)
	{
		___inputManager_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___inputManager_12), (void*)value);
	}
};


// UIPage
struct UIPage_tADF49EF8B9EED1D62A11512AA91755302E988EFF  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:
	// UnityEngine.GameObject UIPage::defaultSelected
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___defaultSelected_4;

public:
	inline static int32_t get_offset_of_defaultSelected_4() { return static_cast<int32_t>(offsetof(UIPage_tADF49EF8B9EED1D62A11512AA91755302E988EFF, ___defaultSelected_4)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_defaultSelected_4() const { return ___defaultSelected_4; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_defaultSelected_4() { return &___defaultSelected_4; }
	inline void set_defaultSelected_4(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___defaultSelected_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultSelected_4), (void*)value);
	}
};


// UIelement
struct UIelement_tCDCC1215DEE7AFCA254CEFA33C4C7E1A68D36CFF  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// HighScoreDisplay
struct HighScoreDisplay_t5048A49C2F80ABFD44736CBCE44BA71881B455AE  : public UIelement_tCDCC1215DEE7AFCA254CEFA33C4C7E1A68D36CFF
{
public:
	// UnityEngine.UI.Text HighScoreDisplay::displayText
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___displayText_4;

public:
	inline static int32_t get_offset_of_displayText_4() { return static_cast<int32_t>(offsetof(HighScoreDisplay_t5048A49C2F80ABFD44736CBCE44BA71881B455AE, ___displayText_4)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_displayText_4() const { return ___displayText_4; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_displayText_4() { return &___displayText_4; }
	inline void set_displayText_4(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___displayText_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___displayText_4), (void*)value);
	}
};


// ScoreDisplay
struct ScoreDisplay_tEAFBD4A2ECA347ED7DAB8799E87DF7A626F5773A  : public UIelement_tCDCC1215DEE7AFCA254CEFA33C4C7E1A68D36CFF
{
public:
	// UnityEngine.UI.Text ScoreDisplay::displayText
	Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * ___displayText_4;

public:
	inline static int32_t get_offset_of_displayText_4() { return static_cast<int32_t>(offsetof(ScoreDisplay_tEAFBD4A2ECA347ED7DAB8799E87DF7A626F5773A, ___displayText_4)); }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * get_displayText_4() const { return ___displayText_4; }
	inline Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 ** get_address_of_displayText_4() { return &___displayText_4; }
	inline void set_displayText_4(Text_t6A2339DA6C05AE2646FC1A6C8FCC127391BE7FA1 * value)
	{
		___displayText_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___displayText_4), (void*)value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3387[41] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3388[1] = 
{
	CP1026_t7F2AD192944C4A8039139B957212FB817FB4C7D1_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3390[1] = 
{
	CP1047_t29DE80FA04EABC616A50911A8FC6E8DFCCB84288_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3392[1] = 
{
	CP1140_t873912141C09EE972EAFFDC1D91526772AC6A260_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3394[1] = 
{
	CP1141_t21CEA37D76E47FF5DA7BCFF526DE210F6CCF402B_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3396[1] = 
{
	CP1142_t4237D12BC35C1AC9CB88D99109423DD755A0CD9E_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3398[1] = 
{
	CP1143_tFE85986C7DC1F082D30B71F329DA177B51CE7932_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3400[1] = 
{
	CP1144_tC91AEC0BDB44F79D4E291F2C80B0D50D576D970A_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3402[1] = 
{
	CP1145_t8A2FF34162510D80D9AA634563AE3C8A7549A4A5_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3404[1] = 
{
	CP1146_tB48428B26382E0E6C9F76CA61F1682F5D860B878_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3406[1] = 
{
	CP1147_t7E416A65156781470473BB31A8542FCE2463A18C_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3408[1] = 
{
	CP1148_t24312E6240420F06E929DD4B8EEB2C22ABCDF51C_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3410[1] = 
{
	CP1149_t66722FA13A4C0E886DE6AD90ABF2F59DD616E371_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3412[1] = 
{
	CP20273_tC8A029A53E6655DB818FD486569E519A3948FABA_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3414[1] = 
{
	CP20277_t6A07C14184E08AD84E2287437E58BD3DEAA3C5D8_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3416[1] = 
{
	CP20278_tE368E2CA0D30C8D3DDFC1761CCBF4E32BEB3F258_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3418[1] = 
{
	CP20280_t0B7E893AC6D2E78450853496D34F97EF05BA8A20_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3420[1] = 
{
	CP20284_tD286C0645FB422717E8505E976B424205604D08D_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3422[1] = 
{
	CP20285_t388031FDCA8D3D7562AD537DAF478C011D46DF52_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3424[1] = 
{
	CP20290_tE0D84B40EA1C7E83D7F2934C748EB880105FC6E1_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3426[1] = 
{
	CP20297_t634FB165810C6E04817DC4ED1FC38D15E9331E10_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3428[1] = 
{
	CP20420_tE4A7FEED843107D575A05FCCB5A18A64F62F5F96_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3430[1] = 
{
	CP20424_t6D1DC3AF312E703FEC49112901E74F5ACBFEA283_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3432[1] = 
{
	CP20871_tE58915819DA570099C2FBF259B64A88CF9849DD9_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3434[1] = 
{
	CP21025_t383EB0008A9710AB1FB9869A9032A9A302722890_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3436[1] = 
{
	CP37_tBBF6F32AB246E06A6CC878A4056A604983E6BA7B_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3438[1] = 
{
	CP500_t1AC8EF017DB6B169900268C693B9D02197FAD8BE_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3440[1] = 
{
	CP708_t91BA271E408F78AF6AB834E9F8EEBD274D5D0F83_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3442[1] = 
{
	CP852_t02AC6D88D7DCA14AF317C724151BB70D9989AFB9_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3444[1] = 
{
	CP855_t69F594AD6D3FCBE23BB8BCB14FB7987B1568B526_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3446[1] = 
{
	CP857_tFE092BE37477C1D4F73F5E4CF17EA447260B6802_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3448[1] = 
{
	CP858_t9590DB826647E000357E48E06D15AD3EA591260B_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3450[1] = 
{
	CP862_tBE982DFFA4B7608C5E5285F45A8B841F51B0F0BE_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3452[1] = 
{
	CP864_t90F40EF744D65AEB4494B606D76EC8B1690F3A56_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3454[1] = 
{
	CP866_t8D0F2CC55C29421F8C3E6AAD2309D390F139F97E_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3456[1] = 
{
	CP869_t7F7805FE94FFC2B6CD8794C8E6B9FA4C9C9359F5_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3458[1] = 
{
	CP870_t6C5454214680B02D23E0DE81358A4C4CCF6F7451_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3460[1] = 
{
	CP875_tA1D77603588C9477B1005787CDFC826E235E27BD_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3463[37] = 
{
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U305B1E1067273E188A50BA4342B4BC09ABEE669CD_0(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U309885C8B0840E863B3A14261999895D896677D5A_1(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U30BBB1FA6CCD88EF7F8B73A4A7AF064FE4A421486_2(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U3271EF3D1C1F8136E08DBCAB443CE02538A4156F0_3(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U32E1C78D5F4666324672DFACDC9307935CF14E98F_4(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U33551F16F8A11003B8289B76B9E3D97969B68E7D9_5(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U336A0A1CE2E522AB1D22668B38F6126D2F6E17D44_6(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U337C03949C69BDDA042205E1A573B349E75F693B8_7(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U347DCC01E928630EBCC018C5E0285145985F92532_8(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U352623ED7F33E8C1C541F1C3101FA981B173D795E_9(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U35EF781A18260A43AA5EAF73D4DAAA126F7ACAB4A_10(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U3659C24C855D0E50CBD366B2774AF841E29202E70_11(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U36B2745F3AD679B4F2E844D23C3EE0BAD49E1528D_12(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U371D13FFA93C0CC3F813C0B17C0FDFAC1D1AAA8CE_13(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U37A827DA5CD16B7AC8DB4221BABFA420A2B8668E8_14(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U37AF949FCE93CBEA9FAE4D22F2BCD5756396C6BB9_15(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U382273BF74F02F3FDFABEED76BCA4B82DDB2C2761_16(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U38C32A1D05EF81F6F81E519ECE45CC6D67AEC5A32_17(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U38E958C1847104F390F9C9B64F0F39C98ED4AC63F_18(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U394F89F72CC0508D891A0C71DD7B57B703869A3FB_19(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U39E66CEC4FA557D4655353E0A4F5940FA0D71CF3A_20(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_U39EF46C677634CB82C0BD475E372C71C5F68C981A_21(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_A5A5BE77BD3D095389FABC21D18BB648787E6618_22(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_B0D57A37D962AF56458E04E1BAAB3C4BC1B146F5_23(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_B1D1CEE08985760776A35065014EAF3D4D3CDE8D_24(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_B2574B82126B684C0CB3CF93BF7473F0FBB34400_25(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_B6BD9A82204938ABFE97CF3FAB5A47824080EAA0_26(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_BC1CEF8131E7F0D8206029373157806126E21026_27(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_C14817C33562352073848F1A8EA633C19CF1A4F5_28(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_C392E993B9E622A36C30E0BB997A9F41293CD9EF_29(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_C74F2436F5FE448E6F8A9D1C5C95D8DD53B39F1E_30(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_C8E6884C6631D74572185DA8E1E35BD7BBCCD6C4_31(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_CFB85A64A0D1FAB523C3DE56096F8803CDFEA674_32(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_D257291FBF3DA6F5C38B3275534902BC9EDE92EA_33(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_D4795500A3D0F00D8EE85626648C3FBAFA4F70C3_34(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_DF4C38A5E59685BBEC109623762B6914BE00E866_35(),
	U3CPrivateImplementationDetailsU3E_tCAFB62525B5E255600BF2C6B88F69472BAECA7F9_StaticFields::get_offset_of_F632BE2E03B27F265F779A5D3D217E5C14AB6CB5_36(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3465[41] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3466[1] = 
{
	CP10000_t90376227B31EAFB15D36A7C3121598F0A81B3D56_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3468[1] = 
{
	CP10079_tC8E1B9E147870510266629449DF0718F1658524B_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3470[1] = 
{
	CP1250_t9CEAE2D9077CF4BFF7A372B496362D26251F9C04_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3472[1] = 
{
	CP1252_t83D225E8526CFC7079CE797954EB0E3C00CCF7AC_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3474[1] = 
{
	CP1253_t9033E724E778CF0DABFE7A70C62ABAB8429EF04F_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3476[1] = 
{
	CP28592_tE3D280B4DDEA315869DBC23FDE487FA718D35D7A_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3478[1] = 
{
	CP28593_t78DB4995E615D18BAC0DE9179311C4B5E6A3BCCC_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3480[1] = 
{
	CP28597_t9F2C8B90A7BBA39F89A8612C43F85514640C5A0C_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3482[1] = 
{
	CP28605_tF1D6657E73A685ABFFD29E25771515605CC3D669_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3484[1] = 
{
	CP437_t2C31EEEF782FD00487011B73793EC24908911248_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3486[1] = 
{
	CP850_t1610E334425DCAD9C280EA79E711ECAD3A2DFA04_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3488[1] = 
{
	CP860_tA028A87A63E6DBFF5F24EC665BB7D4831941DF3E_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3490[1] = 
{
	CP861_t48E89FE8388821D4AFF8406B2777299F505F40A2_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3492[1] = 
{
	CP863_t43777DEB91042772AF52424C3283279BE92B1108_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3494[1] = 
{
	CP865_t832962C13E90BE9EA8B5924A6E349072AC33B995_StaticFields::get_offset_of_ToChars_30(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3497[15] = 
{
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U305C64B887A4D766EEB5842345D6B609A0E3A91C9_0(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U3148F346330E294B4157ED412259A7E7F373E26A8_1(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U31F867F0E96DB3A56943B8CB2662D1DA624023FCD_2(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U33220DE2BE9769737429E0DE2C6D837CB7C5A02AD_3(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U3356CE585046545CD2D0B109FF8A85DB88EE29074_4(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U34FEA2A6324C0192B29C90830F5D578051A4B1B16_5(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U3598D9433A53523A59D462896B803E416AB0B1901_6(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U36E6F169B075CACDE575F1FEA42B1376D31D5A7E5_7(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U37089F9820A6F9CC830909BCD1FAF2EF0A540F348_8(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_U39ACD15FF06BC5A9B676BDBD6BFF4025F9CCE845D_9(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_A394B4578F1DC8407FC72C0514F23F5AE4EDEBA8_10(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_B676CC7861A57EFB9BD0D7BEA61CD8E2484C57ED_11(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_D5DB24A984219B0001B4B86CDE1E0DF54572D83A_12(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_E11338F644FF140C0E23D8B7526DB4D2D73FC3F7_13(),
	U3CPrivateImplementationDetailsU3E_t9D83D173285FBC75E748DEE00D2F09709A66E28D_StaticFields::get_offset_of_FBB979B39B3DE95C52CD45C1036F61ABCE6B17D4_14(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3500[4] = 
{
	CameraStyles_t2263775A9F64A76075D435D49587237DC75AA8E5::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3501[7] = 
{
	CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0::get_offset_of_playerCamera_4(),
	CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0::get_offset_of_target_5(),
	CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0::get_offset_of_cameraMovementStyle_6(),
	CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0::get_offset_of_freeCameraMouseTracking_7(),
	CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0::get_offset_of_maxDistanceFromTarget_8(),
	CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0::get_offset_of_cameraZCoordinate_9(),
	CameraController_tCFCE51ADE50A46097682FD3E2CEA53100D84E7E0::get_offset_of_inputManager_10(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3502[3] = 
{
	ShootMode_t8613AD43724BDDC529A4B1BD2CEF46A6F6851079::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3503[4] = 
{
	MovementModes_tF73DA728A5026D1A2F694EE07D4C9C0741CA2370::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3504[8] = 
{
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_moveSpeed_4(),
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_scoreValue_5(),
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_followTarget_6(),
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_followRange_7(),
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_guns_8(),
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_shootMode_9(),
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_movementMode_10(),
	Enemy_tF0E5C8811BC93A523814C562C545DB3C1A755627::get_offset_of_scrollDirection_11(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3505[10] = 
{
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_enemyPrefab_4(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_target_5(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_spawnRangeX_6(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_spawnRangeY_7(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_maxSpawn_8(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_spawnInfinite_9(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_currentlySpawned_10(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_spawnDelay_11(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_lastSpawnTime_12(),
	EnemySpawner_t02731B295570E1C2E63CE6A23D2A64D1E5985C9E::get_offset_of_projectileHolder_13(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3506[7] = 
{
	Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631::get_offset_of_teamId_4(),
	Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631::get_offset_of_damageAmount_5(),
	Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631::get_offset_of_hitEffect_6(),
	Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631::get_offset_of_destroyAfterDamage_7(),
	Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631::get_offset_of_dealDamageOnTriggerEnter_8(),
	Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631::get_offset_of_dealDamageOnTriggerStay_9(),
	Damage_tF03686559EE2A75E7FB5C86FDC5B966CB31BE631::get_offset_of_dealDamageOnCollision_10(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3507[14] = 
{
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_teamId_4(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_defaultHealth_5(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_maximumHealth_6(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_currentHealth_7(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_invincibilityTime_8(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_isAlwaysInvincible_9(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_useLives_10(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_currentLives_11(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_maximumLives_12(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_timeToBecomeDamagableAgain_13(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_isInvincableFromDamage_14(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_respawnPosition_15(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_deathEffect_16(),
	Health_tB86D9293C9CF1E5B8E4C7271395F56DD4C67AE96::get_offset_of_hitEffect_17(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3508[3] = 
{
	AimModes_tF67601938018899336774C126F7601A9194FF27D::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3509[5] = 
{
	MovementModes_tF14FB5F318012884A654444DB56F1853024D8294::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3510[7] = 
{
	Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC::get_offset_of_animator_4(),
	Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC::get_offset_of_myRigidbody_5(),
	Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC::get_offset_of_moveSpeed_6(),
	Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC::get_offset_of_rotationSpeed_7(),
	Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC::get_offset_of_inputManager_8(),
	Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC::get_offset_of_aimMode_9(),
	Controller_tB694EDC1BC19B0E57E8D94237A07C19F0D3992FC::get_offset_of_movementMode_10(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3511[1] = 
{
	Projectile_t8BAB3D47786918922F97CC7FADEB6146D6E31B9F::get_offset_of_projectileSpeed_4(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3512[8] = 
{
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_projectilePrefab_4(),
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_projectileHolder_5(),
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_isPlayerControlled_6(),
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_fireRate_7(),
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_projectileSpread_8(),
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_lastFired_9(),
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_fireEffect_10(),
	ShootingController_tE258331CE0BD71C0727F36C338EFDA1E2D5285D4::get_offset_of_inputManager_11(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3513[1] = 
{
	CursorChanger_tF96791A48F42EF65902156CCA7FE7185F6B403F5::get_offset_of_newCursorSprite_4(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3514[1] = 
{
	HighScoreDisplay_t5048A49C2F80ABFD44736CBCE44BA71881B455AE::get_offset_of_displayText_4(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3518[1] = 
{
	ScoreDisplay_tEAFBD4A2ECA347ED7DAB8799E87DF7A626F5773A::get_offset_of_displayText_4(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3519[1] = 
{
	U3CU3Ec__DisplayClass20_0_t38A9DA3C3E987BD1E9895D07D36406EA3248CF12::get_offset_of_pageName_0(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3520[9] = 
{
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_pages_4(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_currentPage_5(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_defaultPage_6(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_pausePageIndex_7(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_allowPause_8(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_isPaused_9(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_UIelements_10(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_eventSystem_11(),
	UIManager_t77C2B965B55C450F7226A05FE391FF12B5CE7858::get_offset_of_inputManager_12(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3521[1] = 
{
	UIPage_tADF49EF8B9EED1D62A11512AA91755302E988EFF::get_offset_of_defaultSelected_4(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3523[2] = 
{
	DirectionalMover_t7B90C8B7A99533C1181CF6625716C8C88E3F94AC::get_offset_of_direction_4(),
	DirectionalMover_t7B90C8B7A99533C1181CF6625716C8C88E3F94AC::get_offset_of_speed_5(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3524[15] = 
{
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1_StaticFields::get_offset_of_instance_4(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_uiManager_5(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_player_6(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_gameManagerScore_7(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_highScore_8(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_gameIsWinnable_9(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_enemiesToDefeat_10(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_enemiesDefeated_11(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_printDebugOfWinnableStatus_12(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_gameVictoryPageIndex_13(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_victoryEffect_14(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_numberOfEnemiesFoundAtStart_15(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_gameOverPageIndex_16(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_gameOverEffect_17(),
	GameManager_t9013B33302D2B40A51D0E8059DEE0DC180218AA1::get_offset_of_gameIsOver_18(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3525[3] = 
{
	U3CResetFireStartU3Ed__12_t703D0AC9F6668ACA05BD17A52A1634D66CCB089C::get_offset_of_U3CU3E1__state_0(),
	U3CResetFireStartU3Ed__12_t703D0AC9F6668ACA05BD17A52A1634D66CCB089C::get_offset_of_U3CU3E2__current_1(),
	U3CResetFireStartU3Ed__12_t703D0AC9F6668ACA05BD17A52A1634D66CCB089C::get_offset_of_U3CU3E4__this_2(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3526[3] = 
{
	U3CResetPausePressedU3Ed__15_tCBBC7BFF3506403D2BAAB3720DE0BA6E6BE1C6CC::get_offset_of_U3CU3E1__state_0(),
	U3CResetPausePressedU3Ed__15_tCBBC7BFF3506403D2BAAB3720DE0BA6E6BE1C6CC::get_offset_of_U3CU3E2__current_1(),
	U3CResetPausePressedU3Ed__15_tCBBC7BFF3506403D2BAAB3720DE0BA6E6BE1C6CC::get_offset_of_U3CU3E4__this_2(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3527[8] = 
{
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A_StaticFields::get_offset_of_instance_4(),
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A::get_offset_of_horizontalMoveAxis_5(),
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A::get_offset_of_verticalMoveAxis_6(),
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A::get_offset_of_horizontalLookAxis_7(),
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A::get_offset_of_verticalLookAxis_8(),
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A::get_offset_of_firePressed_9(),
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A::get_offset_of_fireHeld_10(),
	InputManager_tA87D02E2EAE74F98ECCF2AF13C75554B63A1F89A::get_offset_of_pausePressed_11(),
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3529[7] = 
{
	ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D_StaticFields::get_offset_of_screenShotUtility_4(),
	ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D::get_offset_of_runOnlyInEditor_5(),
	ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D::get_offset_of_m_ScreenshotKey_6(),
	ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D::get_offset_of_m_ScaleFactor_7(),
	ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D::get_offset_of_includeImageSizeInFilename_8(),
	ScreenshotUtility_tA08E36962BEB67BEC7A496EDB25E95914F1C0B9D::get_offset_of_m_ImageCount_9(),
	0,
};
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3530[4] = 
{
	TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365::get_offset_of_lifetime_4(),
	TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365::get_offset_of_timeAlive_5(),
	TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365::get_offset_of_destroyChildrenOnDeath_6(),
	TimedObjectDestroyer_t9324016ECEF7482F7FE870D1363F9816A3611365_StaticFields::get_offset_of_quitting_7(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
