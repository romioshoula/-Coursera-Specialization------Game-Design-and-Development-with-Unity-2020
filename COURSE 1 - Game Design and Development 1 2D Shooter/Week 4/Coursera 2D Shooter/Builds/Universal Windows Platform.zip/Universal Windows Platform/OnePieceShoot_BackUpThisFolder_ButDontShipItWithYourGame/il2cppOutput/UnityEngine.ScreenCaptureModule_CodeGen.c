﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.ScreenCapture::CaptureScreenshot(System.String,System.Int32)
extern void ScreenCapture_CaptureScreenshot_mB0DE010388F478603FB22C2DE37E2E01C5F49A28 (void);
// 0x00000002 System.Void UnityEngine.ScreenCapture::CaptureScreenshot(System.String,System.Int32,UnityEngine.ScreenCapture/StereoScreenCaptureMode)
extern void ScreenCapture_CaptureScreenshot_m856F202DB6C6CA5D98A5C0EE5ED41096E3CC66E7 (void);
static Il2CppMethodPointer s_methodPointers[2] = 
{
	ScreenCapture_CaptureScreenshot_mB0DE010388F478603FB22C2DE37E2E01C5F49A28,
	ScreenCapture_CaptureScreenshot_m856F202DB6C6CA5D98A5C0EE5ED41096E3CC66E7,
};
static const int32_t s_InvokerIndices[2] = 
{
	3445,
	3142,
};
extern const CustomAttributesCacheGenerator g_UnityEngine_ScreenCaptureModule_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_ScreenCaptureModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_ScreenCaptureModule_CodeGenModule = 
{
	"UnityEngine.ScreenCaptureModule.dll",
	2,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_UnityEngine_ScreenCaptureModule_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
