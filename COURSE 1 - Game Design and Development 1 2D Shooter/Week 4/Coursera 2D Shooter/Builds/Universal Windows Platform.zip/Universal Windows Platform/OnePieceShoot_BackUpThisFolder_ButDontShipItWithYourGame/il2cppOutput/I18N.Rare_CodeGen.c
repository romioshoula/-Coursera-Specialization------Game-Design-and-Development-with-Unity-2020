﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void I18N.Rare.CP1026::.ctor()
extern void CP1026__ctor_mBE7E1FDBC2F36804087B489479346A3BE7894606 (void);
// 0x00000002 System.Int32 I18N.Rare.CP1026::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1026_GetByteCountImpl_m0951F2AA8DE8DC3A2C71138F81243E91869CBDBD (void);
// 0x00000003 System.Int32 I18N.Rare.CP1026::GetByteCount(System.String)
extern void CP1026_GetByteCount_mED3540E8131976ED7B1FE92B92A63A8FBBC4420F (void);
// 0x00000004 System.Void I18N.Rare.CP1026::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1026_ToBytes_mAEE5B4B1D1EEDE4C8D6BF367751258A5A8E682E0 (void);
// 0x00000005 System.Int32 I18N.Rare.CP1026::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1026_GetBytesImpl_m06FD11101AFFFD24DAB16DF2ED84B341692A4898 (void);
// 0x00000006 System.Void I18N.Rare.CP1026::.cctor()
extern void CP1026__cctor_m95E00E85DC8250B5A1D51556756F3D3008046039 (void);
// 0x00000007 System.Void I18N.Rare.ENCibm1026::.ctor()
extern void ENCibm1026__ctor_m68D4D8EFC4ED0D2AFE97DBA95BD74A5F92C585F4 (void);
// 0x00000008 System.Void I18N.Rare.CP1047::.ctor()
extern void CP1047__ctor_m106F0E5C32FE86B3F0D14B28F8EB1869C5FBB802 (void);
// 0x00000009 System.Int32 I18N.Rare.CP1047::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1047_GetByteCountImpl_m00610CBC767720BCD8DE4CD49B9666CA68A24624 (void);
// 0x0000000A System.Int32 I18N.Rare.CP1047::GetByteCount(System.String)
extern void CP1047_GetByteCount_m8D6CDEED3D97E1FBBB7E171DE7C0D5661B400919 (void);
// 0x0000000B System.Void I18N.Rare.CP1047::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1047_ToBytes_m07DC45C6CCB2627D21B634C01E03CBAC33823967 (void);
// 0x0000000C System.Int32 I18N.Rare.CP1047::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1047_GetBytesImpl_m94109585B3EBDE724ED9C8DA1C736ABF1259D584 (void);
// 0x0000000D System.Void I18N.Rare.CP1047::.cctor()
extern void CP1047__cctor_m6169C2415ACCF4ADAA7702413D6549F572B0ACDE (void);
// 0x0000000E System.Void I18N.Rare.ENCibm1047::.ctor()
extern void ENCibm1047__ctor_m1A960141DE8407B0005974F2BC02C9D9F6F8CED4 (void);
// 0x0000000F System.Void I18N.Rare.CP1140::.ctor()
extern void CP1140__ctor_m4FBE117C8202DA388B774586B08F34287FEC3A91 (void);
// 0x00000010 System.Int32 I18N.Rare.CP1140::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1140_GetByteCountImpl_mC100617E32692E0B5B7F5A2ED971B2153B900D49 (void);
// 0x00000011 System.Int32 I18N.Rare.CP1140::GetByteCount(System.String)
extern void CP1140_GetByteCount_mA469C26790D3C71B66FA3555843C4BCBF2E2FCE9 (void);
// 0x00000012 System.Void I18N.Rare.CP1140::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1140_ToBytes_mDF80238CA38298EFE2F0976CE3210A7E9C972251 (void);
// 0x00000013 System.Int32 I18N.Rare.CP1140::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1140_GetBytesImpl_mD563E595B4DEC752389E3936272AE25A7FF00718 (void);
// 0x00000014 System.Void I18N.Rare.CP1140::.cctor()
extern void CP1140__cctor_mA358059AFAAE5520E2C0B0B535A727209B820BBF (void);
// 0x00000015 System.Void I18N.Rare.ENCibm01140::.ctor()
extern void ENCibm01140__ctor_mD943FE65D2C82A01A8F222B2BA57B2D961F8C5C2 (void);
// 0x00000016 System.Void I18N.Rare.CP1141::.ctor()
extern void CP1141__ctor_m593646B7306894E63AB88B0C74455457935836FA (void);
// 0x00000017 System.Int32 I18N.Rare.CP1141::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1141_GetByteCountImpl_m4884B46AE1188820E4E3599F738B6193AF83EA1C (void);
// 0x00000018 System.Int32 I18N.Rare.CP1141::GetByteCount(System.String)
extern void CP1141_GetByteCount_mC07141DEC6CEA1708E3BDCB4F8D1D9A071AB3723 (void);
// 0x00000019 System.Void I18N.Rare.CP1141::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1141_ToBytes_m4EFB5B6F19E53C65A7F556EC1AE9ACEF3C81C2B0 (void);
// 0x0000001A System.Int32 I18N.Rare.CP1141::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1141_GetBytesImpl_m57345AA161988FADCECF8008A88F4F20054B78A5 (void);
// 0x0000001B System.Void I18N.Rare.CP1141::.cctor()
extern void CP1141__cctor_mF4212A9A21E8129715E5E31C35E9150C53DEB5CB (void);
// 0x0000001C System.Void I18N.Rare.ENCibm01141::.ctor()
extern void ENCibm01141__ctor_mB368ADBFF31CB64E238BFFD39091998625469281 (void);
// 0x0000001D System.Void I18N.Rare.CP1142::.ctor()
extern void CP1142__ctor_m0AA7588BAC01A6B468B718873504AD2C00CD1E4F (void);
// 0x0000001E System.Int32 I18N.Rare.CP1142::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1142_GetByteCountImpl_m774BE0572DD0794DC2A31B366A59614CCC7F0916 (void);
// 0x0000001F System.Int32 I18N.Rare.CP1142::GetByteCount(System.String)
extern void CP1142_GetByteCount_mC1F343278B2BF54AF50C862DD9F300B8183AFE01 (void);
// 0x00000020 System.Void I18N.Rare.CP1142::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1142_ToBytes_mA035338AB6087B78B0F3391F27561FB598BAF063 (void);
// 0x00000021 System.Int32 I18N.Rare.CP1142::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1142_GetBytesImpl_m48097D39A810BD695B1CD20ACC9631ABFF68B326 (void);
// 0x00000022 System.Void I18N.Rare.CP1142::.cctor()
extern void CP1142__cctor_mB0417FFE93D4FD59531AD4B5AAA69AEB02176AF7 (void);
// 0x00000023 System.Void I18N.Rare.ENCibm01142::.ctor()
extern void ENCibm01142__ctor_m4EE0559BFD84BD51B4F2A2220A935F6A06C4AEB2 (void);
// 0x00000024 System.Void I18N.Rare.CP1143::.ctor()
extern void CP1143__ctor_m34B6B6C5D2198D12DF5F122FA70423CBE0F4FDA1 (void);
// 0x00000025 System.Int32 I18N.Rare.CP1143::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1143_GetByteCountImpl_m35A5D4B7AFED0D24C10D469FA204892592AA482C (void);
// 0x00000026 System.Int32 I18N.Rare.CP1143::GetByteCount(System.String)
extern void CP1143_GetByteCount_mA02E4644339355106CEA2F7267CE7675DD5EA9DB (void);
// 0x00000027 System.Void I18N.Rare.CP1143::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1143_ToBytes_m63B3A0A155B8E4B6CB733FF1F7F741FBDA4EE3FF (void);
// 0x00000028 System.Int32 I18N.Rare.CP1143::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1143_GetBytesImpl_m50554B117E6F09B9CC065E105DFB7730E70269E6 (void);
// 0x00000029 System.Void I18N.Rare.CP1143::.cctor()
extern void CP1143__cctor_mD4F20A9342D4ADCA8ADF7B200118F76AFFFF8ED6 (void);
// 0x0000002A System.Void I18N.Rare.ENCibm01143::.ctor()
extern void ENCibm01143__ctor_mD5C2BCE1263B347EFDD0C0FCE0CF73F2F67946C0 (void);
// 0x0000002B System.Void I18N.Rare.CP1144::.ctor()
extern void CP1144__ctor_m305F0F8B6FEB38C340EE7394FD4CC1633DE2AB89 (void);
// 0x0000002C System.Int32 I18N.Rare.CP1144::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1144_GetByteCountImpl_mDC4C3531A1750F8D967CDFA535681B370642BC81 (void);
// 0x0000002D System.Int32 I18N.Rare.CP1144::GetByteCount(System.String)
extern void CP1144_GetByteCount_mC65D9E0E8750FA73163EC7AF420C86327540C207 (void);
// 0x0000002E System.Void I18N.Rare.CP1144::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1144_ToBytes_m15189FE0EC3166231B0C53A85CA0060E00DE1FC4 (void);
// 0x0000002F System.Int32 I18N.Rare.CP1144::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1144_GetBytesImpl_m37167053F518BC0BCFCE963C14DF3082FE8C3CFF (void);
// 0x00000030 System.Void I18N.Rare.CP1144::.cctor()
extern void CP1144__cctor_m62EBACF5711A52BDA74CB0C6303DD7DD93303AF5 (void);
// 0x00000031 System.Void I18N.Rare.ENCibm1144::.ctor()
extern void ENCibm1144__ctor_m70EFE1181DE06AF78B201BA740CFDD3DE7F543A9 (void);
// 0x00000032 System.Void I18N.Rare.CP1145::.ctor()
extern void CP1145__ctor_mB82B61022BFC6C75D090BB577D797D7B803E7923 (void);
// 0x00000033 System.Int32 I18N.Rare.CP1145::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1145_GetByteCountImpl_m6673188CA44F0684673827648B9FA815224DAE30 (void);
// 0x00000034 System.Int32 I18N.Rare.CP1145::GetByteCount(System.String)
extern void CP1145_GetByteCount_mAFECA7B301CB32C5FC2A773B24CADEF3DE3699E2 (void);
// 0x00000035 System.Void I18N.Rare.CP1145::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1145_ToBytes_m973FB55326CD55E115B57A78CFE99A43F61CA3E8 (void);
// 0x00000036 System.Int32 I18N.Rare.CP1145::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1145_GetBytesImpl_mFFF2F613FEE3A0FE0E1C57F6FE29CE4DFB48B8F4 (void);
// 0x00000037 System.Void I18N.Rare.CP1145::.cctor()
extern void CP1145__cctor_m58AF8D1B5B191F810331C94756592A27FD2EDB53 (void);
// 0x00000038 System.Void I18N.Rare.ENCibm1145::.ctor()
extern void ENCibm1145__ctor_m311C939AB0715783C41E04DE01FFD7E8B2C3B6B6 (void);
// 0x00000039 System.Void I18N.Rare.CP1146::.ctor()
extern void CP1146__ctor_mE07FBE83FF8AFD5E2C3BF260B860975D7B570A8B (void);
// 0x0000003A System.Int32 I18N.Rare.CP1146::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1146_GetByteCountImpl_mDF05E09FEF3F3FFB4F25DDE5D9E828DFC9ADD3E6 (void);
// 0x0000003B System.Int32 I18N.Rare.CP1146::GetByteCount(System.String)
extern void CP1146_GetByteCount_m0E3676B3292902A7855EF2BBAD56C49CE82FEF85 (void);
// 0x0000003C System.Void I18N.Rare.CP1146::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1146_ToBytes_mA6563F2B7ED7FF92A34707E85EF3069E4A4DC7D2 (void);
// 0x0000003D System.Int32 I18N.Rare.CP1146::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1146_GetBytesImpl_m60A99AA83474E07B29C671312DF2288110DE8759 (void);
// 0x0000003E System.Void I18N.Rare.CP1146::.cctor()
extern void CP1146__cctor_mF7E8A429980065AD8DC13ED77FEAF2158077B616 (void);
// 0x0000003F System.Void I18N.Rare.ENCibm1146::.ctor()
extern void ENCibm1146__ctor_mB6F774FAA607E3239ED7CDBFE7C844E607D6084E (void);
// 0x00000040 System.Void I18N.Rare.CP1147::.ctor()
extern void CP1147__ctor_mCBEF8549C9311B28C6DE5A34200FB88568227EEC (void);
// 0x00000041 System.Int32 I18N.Rare.CP1147::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1147_GetByteCountImpl_mB6C6E3642FDB6656E5BB379AE7AAAB999B8D0C8F (void);
// 0x00000042 System.Int32 I18N.Rare.CP1147::GetByteCount(System.String)
extern void CP1147_GetByteCount_m58B96DC34B8239C449E11A7EBC30752CB4DFBE50 (void);
// 0x00000043 System.Void I18N.Rare.CP1147::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1147_ToBytes_m6F077FABEDF8A9C7ABA93E0F3C6C33800D201F12 (void);
// 0x00000044 System.Int32 I18N.Rare.CP1147::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1147_GetBytesImpl_m862A58EE0328C5BDA8DC73A2A7E138A3B380597D (void);
// 0x00000045 System.Void I18N.Rare.CP1147::.cctor()
extern void CP1147__cctor_m79BBAE735524F96BE26EADAC99A8EED854D610DF (void);
// 0x00000046 System.Void I18N.Rare.ENCibm1147::.ctor()
extern void ENCibm1147__ctor_m4615006EF1CF40832D1D8DB6AEE7AF214E2E8128 (void);
// 0x00000047 System.Void I18N.Rare.CP1148::.ctor()
extern void CP1148__ctor_m22328F26DAC83D8630486A7A0738D95257ED6B28 (void);
// 0x00000048 System.Int32 I18N.Rare.CP1148::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1148_GetByteCountImpl_mD799D4DB7833339E91D785B07498728AF0DC4A32 (void);
// 0x00000049 System.Int32 I18N.Rare.CP1148::GetByteCount(System.String)
extern void CP1148_GetByteCount_mECC7F9693853BE4E1F7D7DF2CD4FA24AF09886CD (void);
// 0x0000004A System.Void I18N.Rare.CP1148::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1148_ToBytes_m6B3EB7FD2856A849FF2A2DC8F638683EFD196F00 (void);
// 0x0000004B System.Int32 I18N.Rare.CP1148::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1148_GetBytesImpl_m6A2869BE09F4570035B2BEF4E861B0FC3932DD67 (void);
// 0x0000004C System.Void I18N.Rare.CP1148::.cctor()
extern void CP1148__cctor_m516B48B826BA9079FA692CE58BC4C128432FDC67 (void);
// 0x0000004D System.Void I18N.Rare.ENCibm1148::.ctor()
extern void ENCibm1148__ctor_mAF03FBDB428F5C0251393C9F8C3ED745015192DB (void);
// 0x0000004E System.Void I18N.Rare.CP1149::.ctor()
extern void CP1149__ctor_mCD7E890094C096AD8323B783A94C2DF479BCD262 (void);
// 0x0000004F System.Int32 I18N.Rare.CP1149::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1149_GetByteCountImpl_m415AC61641CB79C86CB82C39FCDF23A7FA4872ED (void);
// 0x00000050 System.Int32 I18N.Rare.CP1149::GetByteCount(System.String)
extern void CP1149_GetByteCount_m7A3902D2725E918447A22CD226B4F0E1FCA58E8E (void);
// 0x00000051 System.Void I18N.Rare.CP1149::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1149_ToBytes_mF7F99F6F7F6C8B88EB9DBB9FCACC4AEAAC29FEF6 (void);
// 0x00000052 System.Int32 I18N.Rare.CP1149::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1149_GetBytesImpl_mEE73359626412F66A64CB8DF98A9242C7447404A (void);
// 0x00000053 System.Void I18N.Rare.CP1149::.cctor()
extern void CP1149__cctor_m4B0D66AF62ADEBA9949478902DD9850CAAF50E62 (void);
// 0x00000054 System.Void I18N.Rare.ENCibm1149::.ctor()
extern void ENCibm1149__ctor_m7F7BACB6A61041E9B272A7677AA2EB825A1F2171 (void);
// 0x00000055 System.Void I18N.Rare.CP20273::.ctor()
extern void CP20273__ctor_m31506F91007FF0709985205D9D309D2AB82105C6 (void);
// 0x00000056 System.Int32 I18N.Rare.CP20273::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20273_GetByteCountImpl_m970E35AD0D8A9E68A0F72E707E066FC883894917 (void);
// 0x00000057 System.Int32 I18N.Rare.CP20273::GetByteCount(System.String)
extern void CP20273_GetByteCount_m84BEE558B0C1119942145A6730119F49580E0791 (void);
// 0x00000058 System.Void I18N.Rare.CP20273::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20273_ToBytes_m72D53F2442FD4F191BAB2821EDF9EA2E4276D7B7 (void);
// 0x00000059 System.Int32 I18N.Rare.CP20273::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20273_GetBytesImpl_m423EBAA0D9C0C27A1F0371229917DAF9ACD472B7 (void);
// 0x0000005A System.Void I18N.Rare.CP20273::.cctor()
extern void CP20273__cctor_m49288DD98C4B85FB2B36208278835E94823E544F (void);
// 0x0000005B System.Void I18N.Rare.ENCibm273::.ctor()
extern void ENCibm273__ctor_mD9DDC0D0E3C4707145A374E4BF029A19AC9E306B (void);
// 0x0000005C System.Void I18N.Rare.CP20277::.ctor()
extern void CP20277__ctor_mD8FB025F7FE90C544AFACE88555EC0A6113F92AD (void);
// 0x0000005D System.Int32 I18N.Rare.CP20277::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20277_GetByteCountImpl_mAE7BA6EBD8A79517BF3D6D2EA9E418899C9E2EE2 (void);
// 0x0000005E System.Int32 I18N.Rare.CP20277::GetByteCount(System.String)
extern void CP20277_GetByteCount_mA5FA2CA2BC4BAA6A464EBA31CE28A003C7B01BC9 (void);
// 0x0000005F System.Void I18N.Rare.CP20277::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20277_ToBytes_m31BEF7279A4E47CAA3D9C20B10A1401351A8A05C (void);
// 0x00000060 System.Int32 I18N.Rare.CP20277::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20277_GetBytesImpl_m91ED75284C4496229F2C6548D654395E6CF85591 (void);
// 0x00000061 System.Void I18N.Rare.CP20277::.cctor()
extern void CP20277__cctor_m054C9386034A5A2A811AB9148590D0C7AF8FDC22 (void);
// 0x00000062 System.Void I18N.Rare.ENCibm277::.ctor()
extern void ENCibm277__ctor_m1F3BAA97E9E9A6C5172E2925A46BF9D8AC2EB068 (void);
// 0x00000063 System.Void I18N.Rare.CP20278::.ctor()
extern void CP20278__ctor_mC414EF110FDB493B3573F2BF7F831BE324AA10B8 (void);
// 0x00000064 System.Int32 I18N.Rare.CP20278::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20278_GetByteCountImpl_m6FCCE18645D2BAD267A32A0B38BF3F687FFC9C10 (void);
// 0x00000065 System.Int32 I18N.Rare.CP20278::GetByteCount(System.String)
extern void CP20278_GetByteCount_m442893AC3FC65C68DC5A71A6D38B68353C37B61F (void);
// 0x00000066 System.Void I18N.Rare.CP20278::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20278_ToBytes_mE13F7C8F86985F3208689295D9D1C32C2611C013 (void);
// 0x00000067 System.Int32 I18N.Rare.CP20278::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20278_GetBytesImpl_m1412F657896FFD6B858C95FA02C78892497E8E1D (void);
// 0x00000068 System.Void I18N.Rare.CP20278::.cctor()
extern void CP20278__cctor_m3C32EF460F78E27DF9C7725765C40A5A62D0D476 (void);
// 0x00000069 System.Void I18N.Rare.ENCibm278::.ctor()
extern void ENCibm278__ctor_mC86C9078B7EA0F9F525131D63055208B0CBF6988 (void);
// 0x0000006A System.Void I18N.Rare.CP20280::.ctor()
extern void CP20280__ctor_m184A9CF00D7CB0E66A371C9980239D491E7F7BA8 (void);
// 0x0000006B System.Int32 I18N.Rare.CP20280::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20280_GetByteCountImpl_m82F571A24BB5730146199675F4C2426C1E1BA25C (void);
// 0x0000006C System.Int32 I18N.Rare.CP20280::GetByteCount(System.String)
extern void CP20280_GetByteCount_mDEE96C83B90591930A8D5022D150329834DAA672 (void);
// 0x0000006D System.Void I18N.Rare.CP20280::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20280_ToBytes_mBACC82476E7357FD208951BE91B81C5CA7FC8839 (void);
// 0x0000006E System.Int32 I18N.Rare.CP20280::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20280_GetBytesImpl_m13D48448800AA8B827A0D3792C9DADF9C818A66B (void);
// 0x0000006F System.Void I18N.Rare.CP20280::.cctor()
extern void CP20280__cctor_mFAF9235E6554E80C497A1DD8AABB9FC6FF7DEEBB (void);
// 0x00000070 System.Void I18N.Rare.ENCibm280::.ctor()
extern void ENCibm280__ctor_mDF958A1E0200D20D0939D9C0BB710903C0CA714B (void);
// 0x00000071 System.Void I18N.Rare.CP20284::.ctor()
extern void CP20284__ctor_mDCAC0C691475E69A0CAE6632F84A5052CB794BEC (void);
// 0x00000072 System.Int32 I18N.Rare.CP20284::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20284_GetByteCountImpl_m9FB6D5200598DB4B71BBACCA564474617482F278 (void);
// 0x00000073 System.Int32 I18N.Rare.CP20284::GetByteCount(System.String)
extern void CP20284_GetByteCount_m59F70338F243464689925A0F8271A632BB9FC2BC (void);
// 0x00000074 System.Void I18N.Rare.CP20284::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20284_ToBytes_m8981AAA6A8F7AB817E743784B6D6C385E1FD3E7E (void);
// 0x00000075 System.Int32 I18N.Rare.CP20284::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20284_GetBytesImpl_m8BFA932D1D86CD753A5A08310067D74BAA108638 (void);
// 0x00000076 System.Void I18N.Rare.CP20284::.cctor()
extern void CP20284__cctor_m49C0AB319CDDAD2731D1337F9711B2F7B62A8A40 (void);
// 0x00000077 System.Void I18N.Rare.ENCibm284::.ctor()
extern void ENCibm284__ctor_m4577E7D30C00DC6648A37B8B4D730CB25791E0ED (void);
// 0x00000078 System.Void I18N.Rare.CP20285::.ctor()
extern void CP20285__ctor_m645397174B9D539741A250BF96E11AF5CDBB8960 (void);
// 0x00000079 System.Int32 I18N.Rare.CP20285::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20285_GetByteCountImpl_m7614603A5E584E133AB0CF54CC9E37C9713B46AC (void);
// 0x0000007A System.Int32 I18N.Rare.CP20285::GetByteCount(System.String)
extern void CP20285_GetByteCount_mC1A73DFE41B6CAFF01586F715844888A46EE6E66 (void);
// 0x0000007B System.Void I18N.Rare.CP20285::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20285_ToBytes_m8E6CFED34C1842A772543C123CA216DBDAB2B43B (void);
// 0x0000007C System.Int32 I18N.Rare.CP20285::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20285_GetBytesImpl_m16785F87C1E8B6A8CD810742A9CE3F742FD5A9AF (void);
// 0x0000007D System.Void I18N.Rare.CP20285::.cctor()
extern void CP20285__cctor_mFD3737CE5E7D9DFC2F36E0D77C1A4807B73405E3 (void);
// 0x0000007E System.Void I18N.Rare.ENCibm285::.ctor()
extern void ENCibm285__ctor_mA42F590B0920D25523E3822CD1CED0D5B83F9E0C (void);
// 0x0000007F System.Void I18N.Rare.CP20290::.ctor()
extern void CP20290__ctor_m3EE93053BBE5602D53344AB639D8C4E239CC9DDB (void);
// 0x00000080 System.Int32 I18N.Rare.CP20290::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20290_GetByteCountImpl_m5B1BB04CBC4F40F3722743D45857410FB40700B9 (void);
// 0x00000081 System.Int32 I18N.Rare.CP20290::GetByteCount(System.String)
extern void CP20290_GetByteCount_mF511A80867F867B0B9AB550B9A0D88E484B3716A (void);
// 0x00000082 System.Void I18N.Rare.CP20290::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20290_ToBytes_m09857E305F90DDF06257BD362F43BEF2237BECCC (void);
// 0x00000083 System.Int32 I18N.Rare.CP20290::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20290_GetBytesImpl_mCFBD6B0862060DC05962ABE7353E64BF40C75DD1 (void);
// 0x00000084 System.Void I18N.Rare.CP20290::.cctor()
extern void CP20290__cctor_m83A58C7BF7BAB1F2B2691487A42106BB8A946897 (void);
// 0x00000085 System.Void I18N.Rare.ENCibm290::.ctor()
extern void ENCibm290__ctor_m3D75785AFF1C53A4DBE7301E0835CDAB6CEFBF7B (void);
// 0x00000086 System.Void I18N.Rare.CP20297::.ctor()
extern void CP20297__ctor_mB0B18139293F2F070EAA460149F13308C1F58FD3 (void);
// 0x00000087 System.Int32 I18N.Rare.CP20297::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20297_GetByteCountImpl_mE715D1BD10F951712FC91307FD87A1AF9F4B43D4 (void);
// 0x00000088 System.Int32 I18N.Rare.CP20297::GetByteCount(System.String)
extern void CP20297_GetByteCount_mAA607D7379AF1E33E12218482040E88B639CEF72 (void);
// 0x00000089 System.Void I18N.Rare.CP20297::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20297_ToBytes_mBCF517000380E1D5363E756CE3CE629A3E85F09F (void);
// 0x0000008A System.Int32 I18N.Rare.CP20297::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20297_GetBytesImpl_m2E8FCAAAC73D46F4C92D275EA9CBBDD249D6C6E5 (void);
// 0x0000008B System.Void I18N.Rare.CP20297::.cctor()
extern void CP20297__cctor_m297DE893C035C3778FDF6B8186A04BBA5ED8CB66 (void);
// 0x0000008C System.Void I18N.Rare.ENCibm297::.ctor()
extern void ENCibm297__ctor_m6A1C165B56F02C149A4853DDA48B52156BDB0DB3 (void);
// 0x0000008D System.Void I18N.Rare.CP20420::.ctor()
extern void CP20420__ctor_m9437FCE48B96406D74781B2A23EDA057F49EA8A4 (void);
// 0x0000008E System.Int32 I18N.Rare.CP20420::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20420_GetByteCountImpl_m9B9E7852F310EB65CE59F08E019F7CA4C0FD18B2 (void);
// 0x0000008F System.Int32 I18N.Rare.CP20420::GetByteCount(System.String)
extern void CP20420_GetByteCount_m974B6CF62A166B2367FA78DFE4AC0918963772BA (void);
// 0x00000090 System.Void I18N.Rare.CP20420::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20420_ToBytes_mBE6018C82D904EA46A73644755090A1C66AE7513 (void);
// 0x00000091 System.Int32 I18N.Rare.CP20420::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20420_GetBytesImpl_m4683F84E9E346B339B0061F3E9DB2A9362971B9B (void);
// 0x00000092 System.Void I18N.Rare.CP20420::.cctor()
extern void CP20420__cctor_mC03635EF51815C4E71D168165A6311AA0F4E80C5 (void);
// 0x00000093 System.Void I18N.Rare.ENCibm420::.ctor()
extern void ENCibm420__ctor_m2A8CF7BE8DE57DBF1C1BF0BAEB5CE43DB50B30DA (void);
// 0x00000094 System.Void I18N.Rare.CP20424::.ctor()
extern void CP20424__ctor_mDF4FEA6B436E2539A7D00268EDD261BB1F125DFB (void);
// 0x00000095 System.Int32 I18N.Rare.CP20424::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20424_GetByteCountImpl_m7F6E7BBA5FD2784506504166615DF6A0B5A7B297 (void);
// 0x00000096 System.Int32 I18N.Rare.CP20424::GetByteCount(System.String)
extern void CP20424_GetByteCount_m962A92A65F79B2469BF8BC5BB89C3BECDE6C99DA (void);
// 0x00000097 System.Void I18N.Rare.CP20424::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20424_ToBytes_m671C428C003F2FCCC585B0F2E453DE7AB2C30975 (void);
// 0x00000098 System.Int32 I18N.Rare.CP20424::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20424_GetBytesImpl_m8250C37C2E3097C24C56A4A50773FE590692C233 (void);
// 0x00000099 System.Void I18N.Rare.CP20424::.cctor()
extern void CP20424__cctor_mF89FD94F424D19023418DB9ED165E0516786912C (void);
// 0x0000009A System.Void I18N.Rare.ENCibm424::.ctor()
extern void ENCibm424__ctor_m9D4CA3C97CDE0D8E5C92F7C6A927CF6D79659505 (void);
// 0x0000009B System.Void I18N.Rare.CP20871::.ctor()
extern void CP20871__ctor_mAE95CB0E1B3BE8B833F1AADDFA5329EF4B9451E5 (void);
// 0x0000009C System.Int32 I18N.Rare.CP20871::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20871_GetByteCountImpl_m100E4A27BD53DCAE8D227D606538C6D9BA4E8CFF (void);
// 0x0000009D System.Int32 I18N.Rare.CP20871::GetByteCount(System.String)
extern void CP20871_GetByteCount_m8521CC0BA40CEDDA249918BBBB964E2BFE913E79 (void);
// 0x0000009E System.Void I18N.Rare.CP20871::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20871_ToBytes_m7747E2AB5DAE4C04F672A5C0E2C9C538945F03EB (void);
// 0x0000009F System.Int32 I18N.Rare.CP20871::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20871_GetBytesImpl_m25EAD7C461C50D3F6E92AA9881DB5221C904B309 (void);
// 0x000000A0 System.Void I18N.Rare.CP20871::.cctor()
extern void CP20871__cctor_mCF8CF96027F2D6ED26BCD72942C2348534F6DB6B (void);
// 0x000000A1 System.Void I18N.Rare.ENCibm871::.ctor()
extern void ENCibm871__ctor_mDC691DA473DB9E3117618F332B0276D171A9FCCA (void);
// 0x000000A2 System.Void I18N.Rare.CP21025::.ctor()
extern void CP21025__ctor_m981475E0F3019E8AB702C8A853322566D9CADD43 (void);
// 0x000000A3 System.Int32 I18N.Rare.CP21025::GetByteCountImpl(System.Char*,System.Int32)
extern void CP21025_GetByteCountImpl_m4B221EDEC784FE9A68AF1648E5985E6CA25B466F (void);
// 0x000000A4 System.Int32 I18N.Rare.CP21025::GetByteCount(System.String)
extern void CP21025_GetByteCount_mE40158422844003778E7E25AC808CE893EF66D26 (void);
// 0x000000A5 System.Void I18N.Rare.CP21025::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP21025_ToBytes_mD6862B12D83A9F94FD75203D970D4C5773512E82 (void);
// 0x000000A6 System.Int32 I18N.Rare.CP21025::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP21025_GetBytesImpl_m671BA92EB84F40C2C4D44331F8AEF6EE8FBAF1B1 (void);
// 0x000000A7 System.Void I18N.Rare.CP21025::.cctor()
extern void CP21025__cctor_m71040BAC76DEC7A158630ACEA4421CF364E166EA (void);
// 0x000000A8 System.Void I18N.Rare.ENCibm1025::.ctor()
extern void ENCibm1025__ctor_m4BB61AA5AEE4BBA83CED9981FB45896F5EF5B6EE (void);
// 0x000000A9 System.Void I18N.Rare.CP37::.ctor()
extern void CP37__ctor_m868AADC055620AA620A131F389139ECD9D72B728 (void);
// 0x000000AA System.Int32 I18N.Rare.CP37::GetByteCountImpl(System.Char*,System.Int32)
extern void CP37_GetByteCountImpl_mB9FAF4552E9220E5D8E00B038ED9A5A085417751 (void);
// 0x000000AB System.Int32 I18N.Rare.CP37::GetByteCount(System.String)
extern void CP37_GetByteCount_m90E9B600601F1A4FF8BA9ECC7492C372C61606BB (void);
// 0x000000AC System.Void I18N.Rare.CP37::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP37_ToBytes_m7C5D04966208AA73A3AE4BA331F761C9D4BB6EF0 (void);
// 0x000000AD System.Int32 I18N.Rare.CP37::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP37_GetBytesImpl_m15F163C004170295C06D4AFCD6004DC4F6C8EEEE (void);
// 0x000000AE System.Void I18N.Rare.CP37::.cctor()
extern void CP37__cctor_mA4FB9F427CA906A45DFE7391AA7A2336E1C54AD5 (void);
// 0x000000AF System.Void I18N.Rare.ENCibm037::.ctor()
extern void ENCibm037__ctor_m8A8FD7029D30A5D06E768C148FF241DB12A35E21 (void);
// 0x000000B0 System.Void I18N.Rare.CP500::.ctor()
extern void CP500__ctor_m257863DE2C78AE0E8D5EFA5D9A51CF269428C8D4 (void);
// 0x000000B1 System.Int32 I18N.Rare.CP500::GetByteCountImpl(System.Char*,System.Int32)
extern void CP500_GetByteCountImpl_m6A9DF1230F29C833F02EDA5BF4D6AF13FCD2C76C (void);
// 0x000000B2 System.Int32 I18N.Rare.CP500::GetByteCount(System.String)
extern void CP500_GetByteCount_mA6EAA698599B1E9A68766BA068089555C0390C90 (void);
// 0x000000B3 System.Void I18N.Rare.CP500::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP500_ToBytes_m9981E260366ABAE94FFA239E0949B4CA63A6F3F7 (void);
// 0x000000B4 System.Int32 I18N.Rare.CP500::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP500_GetBytesImpl_m0A10736329773A964BEEF191D79C8D8FA1153F7A (void);
// 0x000000B5 System.Void I18N.Rare.CP500::.cctor()
extern void CP500__cctor_mC79CA8895D39AA2FC909F5CAC6C7BE83A6349850 (void);
// 0x000000B6 System.Void I18N.Rare.ENCibm500::.ctor()
extern void ENCibm500__ctor_m28FD4D9820C304913C6CD27D27E2904F5C1C7C10 (void);
// 0x000000B7 System.Void I18N.Rare.CP708::.ctor()
extern void CP708__ctor_mDD0B3CF20A07D1BE0072B4AC1B737BFD69245D1E (void);
// 0x000000B8 System.Int32 I18N.Rare.CP708::GetByteCountImpl(System.Char*,System.Int32)
extern void CP708_GetByteCountImpl_m6E3950E37E01EE4699F991215050CB801FB2341B (void);
// 0x000000B9 System.Int32 I18N.Rare.CP708::GetByteCount(System.String)
extern void CP708_GetByteCount_m2561CD22A120677D287C521258A8A66A4B477B54 (void);
// 0x000000BA System.Void I18N.Rare.CP708::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP708_ToBytes_mB6C2990A354F7E33DD73DBEF73D558FEDBE18EC4 (void);
// 0x000000BB System.Int32 I18N.Rare.CP708::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP708_GetBytesImpl_m6369955F9BD1DDC52553DFD869619A51AF4ECEC4 (void);
// 0x000000BC System.Void I18N.Rare.CP708::.cctor()
extern void CP708__cctor_m045E7C23ECF1C6BEEF688BC2141B78D28F7E4A01 (void);
// 0x000000BD System.Void I18N.Rare.ENCasmo_708::.ctor()
extern void ENCasmo_708__ctor_mF489D3AF383945B9530F522CF33569905D78D069 (void);
// 0x000000BE System.Void I18N.Rare.CP852::.ctor()
extern void CP852__ctor_mE4333273FD3055F7201E459F6E6D918E916117BA (void);
// 0x000000BF System.Int32 I18N.Rare.CP852::GetByteCountImpl(System.Char*,System.Int32)
extern void CP852_GetByteCountImpl_m7B44EDEC88FB77E2714797608B4EBF6932A53DE2 (void);
// 0x000000C0 System.Int32 I18N.Rare.CP852::GetByteCount(System.String)
extern void CP852_GetByteCount_mE4FE116FFADB3EB61B5B61773E3C72E7AD5F50D2 (void);
// 0x000000C1 System.Void I18N.Rare.CP852::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP852_ToBytes_m6A212A5CE2304FF3C103A42BAA27F841B5D18E44 (void);
// 0x000000C2 System.Int32 I18N.Rare.CP852::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP852_GetBytesImpl_mD4DFF69E2B1EBC47174C723DE338A4FC47C902E0 (void);
// 0x000000C3 System.Void I18N.Rare.CP852::.cctor()
extern void CP852__cctor_m04D15F72E69A66F31812609289E9E3732F3B39C9 (void);
// 0x000000C4 System.Void I18N.Rare.ENCibm852::.ctor()
extern void ENCibm852__ctor_m8B6A73A2FBC4B0C69ADA4C5DE6EB3FE74D4D7F45 (void);
// 0x000000C5 System.Void I18N.Rare.CP855::.ctor()
extern void CP855__ctor_m2172E4BDA6E16A35A30B075FA587AB72743D31C2 (void);
// 0x000000C6 System.Int32 I18N.Rare.CP855::GetByteCountImpl(System.Char*,System.Int32)
extern void CP855_GetByteCountImpl_mB2D923D2F49198EFF4FEEB33A15A031FF0E463A5 (void);
// 0x000000C7 System.Int32 I18N.Rare.CP855::GetByteCount(System.String)
extern void CP855_GetByteCount_mCEA8F5787F93318C44C996D36D05DB0EF72496DE (void);
// 0x000000C8 System.Void I18N.Rare.CP855::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP855_ToBytes_m9A2F6DDA23B17B5EDBBAD3299FC952F94D51BEF2 (void);
// 0x000000C9 System.Int32 I18N.Rare.CP855::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP855_GetBytesImpl_mF71D3783D1B95DA7D602BBA6AF1D1F9F39576D45 (void);
// 0x000000CA System.Void I18N.Rare.CP855::.cctor()
extern void CP855__cctor_m24120C19AF065BBE09CB49E826EDDAE4CCA45A1B (void);
// 0x000000CB System.Void I18N.Rare.ENCibm855::.ctor()
extern void ENCibm855__ctor_m5BF86A4EF1B5F063F92278FA55DDAED0861CD175 (void);
// 0x000000CC System.Void I18N.Rare.CP857::.ctor()
extern void CP857__ctor_mA2532FDF60B5D50570F83B888E6F54EB1958D915 (void);
// 0x000000CD System.Int32 I18N.Rare.CP857::GetByteCountImpl(System.Char*,System.Int32)
extern void CP857_GetByteCountImpl_mEFD2C2D79BAFF70EFDE7B476FDAF28A6B08DFEBF (void);
// 0x000000CE System.Int32 I18N.Rare.CP857::GetByteCount(System.String)
extern void CP857_GetByteCount_m5FABE0C07CF564D8429B248540CADEAE8B4E0CE4 (void);
// 0x000000CF System.Void I18N.Rare.CP857::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP857_ToBytes_mBF0C99DE26FB4FB7110A783477F8565A56BD158E (void);
// 0x000000D0 System.Int32 I18N.Rare.CP857::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP857_GetBytesImpl_m0640F6D49AEC2D13F57232A51F1908044F59C33A (void);
// 0x000000D1 System.Void I18N.Rare.CP857::.cctor()
extern void CP857__cctor_m81C2523619A9DC012384218717AAE784B3DEF218 (void);
// 0x000000D2 System.Void I18N.Rare.ENCibm857::.ctor()
extern void ENCibm857__ctor_mB11A056FA3A65167363CA8B11FCD18CE71BD3F78 (void);
// 0x000000D3 System.Void I18N.Rare.CP858::.ctor()
extern void CP858__ctor_mCABC58A716587CBD417C5DB61AC2AADA0580873F (void);
// 0x000000D4 System.Int32 I18N.Rare.CP858::GetByteCountImpl(System.Char*,System.Int32)
extern void CP858_GetByteCountImpl_m586F0116D8CB5228823FB7E4195197410C5C9B55 (void);
// 0x000000D5 System.Int32 I18N.Rare.CP858::GetByteCount(System.String)
extern void CP858_GetByteCount_m6143798B2875150DCC29664D009C85EBCE43DDBB (void);
// 0x000000D6 System.Void I18N.Rare.CP858::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP858_ToBytes_m2F96B9361BD75E1D11C6464B3694E681A7882199 (void);
// 0x000000D7 System.Int32 I18N.Rare.CP858::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP858_GetBytesImpl_m485899D471327569EB5A4738C6A62CE73D5D4A50 (void);
// 0x000000D8 System.Void I18N.Rare.CP858::.cctor()
extern void CP858__cctor_m24AA0741EB175BA6E1302535A1736DBB21BAE0DF (void);
// 0x000000D9 System.Void I18N.Rare.ENCibm00858::.ctor()
extern void ENCibm00858__ctor_mFA74D2D7AB572F83A1958F806746734718571F78 (void);
// 0x000000DA System.Void I18N.Rare.CP862::.ctor()
extern void CP862__ctor_mEA17600A0FA4B45BB88FA3CA1960416C23DC14A7 (void);
// 0x000000DB System.Int32 I18N.Rare.CP862::GetByteCountImpl(System.Char*,System.Int32)
extern void CP862_GetByteCountImpl_m980ECE272971E3541C27F9B76FA8EDE8CE2AA30A (void);
// 0x000000DC System.Int32 I18N.Rare.CP862::GetByteCount(System.String)
extern void CP862_GetByteCount_m9BCB42FCB15ACA6D828B50BC8DB3FC887E677645 (void);
// 0x000000DD System.Void I18N.Rare.CP862::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP862_ToBytes_m76192E2BB8CF9C9BC2E2FC5ABDD9BC3520295559 (void);
// 0x000000DE System.Int32 I18N.Rare.CP862::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP862_GetBytesImpl_m5B4E4DC4B285BE88EB89DF2A008699C4B2A8B7E9 (void);
// 0x000000DF System.Void I18N.Rare.CP862::.cctor()
extern void CP862__cctor_mE4C27EC733587CAFF4DE2C5A02F83895898D9154 (void);
// 0x000000E0 System.Void I18N.Rare.ENCibm862::.ctor()
extern void ENCibm862__ctor_mF76284FD2A47C27F4973069B15A2BC27C4D9E7DF (void);
// 0x000000E1 System.Void I18N.Rare.CP864::.ctor()
extern void CP864__ctor_m6517F4636C645085286B8132FE855452D2029297 (void);
// 0x000000E2 System.Int32 I18N.Rare.CP864::GetByteCountImpl(System.Char*,System.Int32)
extern void CP864_GetByteCountImpl_m00E38CBECF48FAB21530B84DC84DBED0A6412809 (void);
// 0x000000E3 System.Int32 I18N.Rare.CP864::GetByteCount(System.String)
extern void CP864_GetByteCount_m8FA00E05020D79EF1E4EDF2879457B932B160908 (void);
// 0x000000E4 System.Void I18N.Rare.CP864::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP864_ToBytes_mEFB6C94EF5C3CD4CB27D8F067774D782A526BFC9 (void);
// 0x000000E5 System.Int32 I18N.Rare.CP864::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP864_GetBytesImpl_mF4C31D0B189BB28904C6786DCECB888C202DA805 (void);
// 0x000000E6 System.Void I18N.Rare.CP864::.cctor()
extern void CP864__cctor_mB9D10F7662BC37510801CB0857B82B94284E439B (void);
// 0x000000E7 System.Void I18N.Rare.ENCibm864::.ctor()
extern void ENCibm864__ctor_m2F92D4D0AF60031BFF6762AB61260E5974EE6B6A (void);
// 0x000000E8 System.Void I18N.Rare.CP866::.ctor()
extern void CP866__ctor_mEBE3DA0BD51C53C9B73A09AD9973292CDA08DBF8 (void);
// 0x000000E9 System.Int32 I18N.Rare.CP866::GetByteCountImpl(System.Char*,System.Int32)
extern void CP866_GetByteCountImpl_m64FB31D56306918A1468B6B24F9A63FBB323D1B5 (void);
// 0x000000EA System.Int32 I18N.Rare.CP866::GetByteCount(System.String)
extern void CP866_GetByteCount_m8600E425AE7A64F1243F3C5A6763714F543DD7C8 (void);
// 0x000000EB System.Void I18N.Rare.CP866::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP866_ToBytes_m4C75A3BE37E0B9DD633385388C9CEDC820A00E9E (void);
// 0x000000EC System.Int32 I18N.Rare.CP866::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP866_GetBytesImpl_mAA942D6ABF08EDFDBD85C2D680CA9FD0E6D66467 (void);
// 0x000000ED System.Void I18N.Rare.CP866::.cctor()
extern void CP866__cctor_m538905765E833A235EF9D496999D461B9A6B3BCF (void);
// 0x000000EE System.Void I18N.Rare.ENCibm866::.ctor()
extern void ENCibm866__ctor_m461FA20385B180D6D845F0B38116FF57E8C462E0 (void);
// 0x000000EF System.Void I18N.Rare.CP869::.ctor()
extern void CP869__ctor_m4B903927E5B74AEFD810BF8161F2F44733D87E93 (void);
// 0x000000F0 System.Int32 I18N.Rare.CP869::GetByteCountImpl(System.Char*,System.Int32)
extern void CP869_GetByteCountImpl_mB3E1B70F89054A91D895E166E0EFADA4834BEF28 (void);
// 0x000000F1 System.Int32 I18N.Rare.CP869::GetByteCount(System.String)
extern void CP869_GetByteCount_m93CD21D2BAAC2DD47AEA254C42AF62E598D31D95 (void);
// 0x000000F2 System.Void I18N.Rare.CP869::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP869_ToBytes_m78FCF500AB5CDD978EF3F529BCFC80CEFBBA4BF0 (void);
// 0x000000F3 System.Int32 I18N.Rare.CP869::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP869_GetBytesImpl_mEF86E8BA313A36FE32C0F0D228268F029C2C85C1 (void);
// 0x000000F4 System.Void I18N.Rare.CP869::.cctor()
extern void CP869__cctor_m5E354758F9C76FAB1994FA2C6AB166EA40AF3362 (void);
// 0x000000F5 System.Void I18N.Rare.ENCibm869::.ctor()
extern void ENCibm869__ctor_m1635C042CE477AD9888EAE76CB8080CC5012D8DF (void);
// 0x000000F6 System.Void I18N.Rare.CP870::.ctor()
extern void CP870__ctor_m25757A6B07BA12D2536FEB8BE77A9C9B018AE70C (void);
// 0x000000F7 System.Int32 I18N.Rare.CP870::GetByteCountImpl(System.Char*,System.Int32)
extern void CP870_GetByteCountImpl_m1D9F3A222B5535F2AEE217E473719A4654FB866C (void);
// 0x000000F8 System.Int32 I18N.Rare.CP870::GetByteCount(System.String)
extern void CP870_GetByteCount_m4F2010533F854EC73C5404BA712ADC2F3BAD32BA (void);
// 0x000000F9 System.Void I18N.Rare.CP870::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP870_ToBytes_mB38739CC8DD77C6D3CC773D8D1145615B69288F1 (void);
// 0x000000FA System.Int32 I18N.Rare.CP870::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP870_GetBytesImpl_m6E225F289CCDA30529F998C1DFC5A9AF671AAFC6 (void);
// 0x000000FB System.Void I18N.Rare.CP870::.cctor()
extern void CP870__cctor_mDAFF8C32CCCDD6706504FEED55892C5F9C57C7BF (void);
// 0x000000FC System.Void I18N.Rare.ENCibm870::.ctor()
extern void ENCibm870__ctor_m45B10A20BED73EB5FD4FEFEF51739C1E25E1ECEA (void);
// 0x000000FD System.Void I18N.Rare.CP875::.ctor()
extern void CP875__ctor_m549C26D952147626FF376EE139B225C76C84A35E (void);
// 0x000000FE System.Int32 I18N.Rare.CP875::GetByteCountImpl(System.Char*,System.Int32)
extern void CP875_GetByteCountImpl_m8B88498CA4DE55072389C11C3209DB88EABB8E3B (void);
// 0x000000FF System.Int32 I18N.Rare.CP875::GetByteCount(System.String)
extern void CP875_GetByteCount_mAD0AEB13C86A8CA8C6C11B52279521688421192E (void);
// 0x00000100 System.Void I18N.Rare.CP875::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP875_ToBytes_m228BF8058B9E77813AE1719288B6E163412A8D2F (void);
// 0x00000101 System.Int32 I18N.Rare.CP875::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP875_GetBytesImpl_m4D2286759951124C32466ACBB59F2B024CB4EC63 (void);
// 0x00000102 System.Void I18N.Rare.CP875::.cctor()
extern void CP875__cctor_m2AB2F626897153328F375BE8FE3BDAA98E6B9139 (void);
// 0x00000103 System.Void I18N.Rare.ENCibm875::.ctor()
extern void ENCibm875__ctor_mCBDE7574E5CC3711CEBA6DCA8B53347F096872E6 (void);
static Il2CppMethodPointer s_methodPointers[259] = 
{
	CP1026__ctor_mBE7E1FDBC2F36804087B489479346A3BE7894606,
	CP1026_GetByteCountImpl_m0951F2AA8DE8DC3A2C71138F81243E91869CBDBD,
	CP1026_GetByteCount_mED3540E8131976ED7B1FE92B92A63A8FBBC4420F,
	CP1026_ToBytes_mAEE5B4B1D1EEDE4C8D6BF367751258A5A8E682E0,
	CP1026_GetBytesImpl_m06FD11101AFFFD24DAB16DF2ED84B341692A4898,
	CP1026__cctor_m95E00E85DC8250B5A1D51556756F3D3008046039,
	ENCibm1026__ctor_m68D4D8EFC4ED0D2AFE97DBA95BD74A5F92C585F4,
	CP1047__ctor_m106F0E5C32FE86B3F0D14B28F8EB1869C5FBB802,
	CP1047_GetByteCountImpl_m00610CBC767720BCD8DE4CD49B9666CA68A24624,
	CP1047_GetByteCount_m8D6CDEED3D97E1FBBB7E171DE7C0D5661B400919,
	CP1047_ToBytes_m07DC45C6CCB2627D21B634C01E03CBAC33823967,
	CP1047_GetBytesImpl_m94109585B3EBDE724ED9C8DA1C736ABF1259D584,
	CP1047__cctor_m6169C2415ACCF4ADAA7702413D6549F572B0ACDE,
	ENCibm1047__ctor_m1A960141DE8407B0005974F2BC02C9D9F6F8CED4,
	CP1140__ctor_m4FBE117C8202DA388B774586B08F34287FEC3A91,
	CP1140_GetByteCountImpl_mC100617E32692E0B5B7F5A2ED971B2153B900D49,
	CP1140_GetByteCount_mA469C26790D3C71B66FA3555843C4BCBF2E2FCE9,
	CP1140_ToBytes_mDF80238CA38298EFE2F0976CE3210A7E9C972251,
	CP1140_GetBytesImpl_mD563E595B4DEC752389E3936272AE25A7FF00718,
	CP1140__cctor_mA358059AFAAE5520E2C0B0B535A727209B820BBF,
	ENCibm01140__ctor_mD943FE65D2C82A01A8F222B2BA57B2D961F8C5C2,
	CP1141__ctor_m593646B7306894E63AB88B0C74455457935836FA,
	CP1141_GetByteCountImpl_m4884B46AE1188820E4E3599F738B6193AF83EA1C,
	CP1141_GetByteCount_mC07141DEC6CEA1708E3BDCB4F8D1D9A071AB3723,
	CP1141_ToBytes_m4EFB5B6F19E53C65A7F556EC1AE9ACEF3C81C2B0,
	CP1141_GetBytesImpl_m57345AA161988FADCECF8008A88F4F20054B78A5,
	CP1141__cctor_mF4212A9A21E8129715E5E31C35E9150C53DEB5CB,
	ENCibm01141__ctor_mB368ADBFF31CB64E238BFFD39091998625469281,
	CP1142__ctor_m0AA7588BAC01A6B468B718873504AD2C00CD1E4F,
	CP1142_GetByteCountImpl_m774BE0572DD0794DC2A31B366A59614CCC7F0916,
	CP1142_GetByteCount_mC1F343278B2BF54AF50C862DD9F300B8183AFE01,
	CP1142_ToBytes_mA035338AB6087B78B0F3391F27561FB598BAF063,
	CP1142_GetBytesImpl_m48097D39A810BD695B1CD20ACC9631ABFF68B326,
	CP1142__cctor_mB0417FFE93D4FD59531AD4B5AAA69AEB02176AF7,
	ENCibm01142__ctor_m4EE0559BFD84BD51B4F2A2220A935F6A06C4AEB2,
	CP1143__ctor_m34B6B6C5D2198D12DF5F122FA70423CBE0F4FDA1,
	CP1143_GetByteCountImpl_m35A5D4B7AFED0D24C10D469FA204892592AA482C,
	CP1143_GetByteCount_mA02E4644339355106CEA2F7267CE7675DD5EA9DB,
	CP1143_ToBytes_m63B3A0A155B8E4B6CB733FF1F7F741FBDA4EE3FF,
	CP1143_GetBytesImpl_m50554B117E6F09B9CC065E105DFB7730E70269E6,
	CP1143__cctor_mD4F20A9342D4ADCA8ADF7B200118F76AFFFF8ED6,
	ENCibm01143__ctor_mD5C2BCE1263B347EFDD0C0FCE0CF73F2F67946C0,
	CP1144__ctor_m305F0F8B6FEB38C340EE7394FD4CC1633DE2AB89,
	CP1144_GetByteCountImpl_mDC4C3531A1750F8D967CDFA535681B370642BC81,
	CP1144_GetByteCount_mC65D9E0E8750FA73163EC7AF420C86327540C207,
	CP1144_ToBytes_m15189FE0EC3166231B0C53A85CA0060E00DE1FC4,
	CP1144_GetBytesImpl_m37167053F518BC0BCFCE963C14DF3082FE8C3CFF,
	CP1144__cctor_m62EBACF5711A52BDA74CB0C6303DD7DD93303AF5,
	ENCibm1144__ctor_m70EFE1181DE06AF78B201BA740CFDD3DE7F543A9,
	CP1145__ctor_mB82B61022BFC6C75D090BB577D797D7B803E7923,
	CP1145_GetByteCountImpl_m6673188CA44F0684673827648B9FA815224DAE30,
	CP1145_GetByteCount_mAFECA7B301CB32C5FC2A773B24CADEF3DE3699E2,
	CP1145_ToBytes_m973FB55326CD55E115B57A78CFE99A43F61CA3E8,
	CP1145_GetBytesImpl_mFFF2F613FEE3A0FE0E1C57F6FE29CE4DFB48B8F4,
	CP1145__cctor_m58AF8D1B5B191F810331C94756592A27FD2EDB53,
	ENCibm1145__ctor_m311C939AB0715783C41E04DE01FFD7E8B2C3B6B6,
	CP1146__ctor_mE07FBE83FF8AFD5E2C3BF260B860975D7B570A8B,
	CP1146_GetByteCountImpl_mDF05E09FEF3F3FFB4F25DDE5D9E828DFC9ADD3E6,
	CP1146_GetByteCount_m0E3676B3292902A7855EF2BBAD56C49CE82FEF85,
	CP1146_ToBytes_mA6563F2B7ED7FF92A34707E85EF3069E4A4DC7D2,
	CP1146_GetBytesImpl_m60A99AA83474E07B29C671312DF2288110DE8759,
	CP1146__cctor_mF7E8A429980065AD8DC13ED77FEAF2158077B616,
	ENCibm1146__ctor_mB6F774FAA607E3239ED7CDBFE7C844E607D6084E,
	CP1147__ctor_mCBEF8549C9311B28C6DE5A34200FB88568227EEC,
	CP1147_GetByteCountImpl_mB6C6E3642FDB6656E5BB379AE7AAAB999B8D0C8F,
	CP1147_GetByteCount_m58B96DC34B8239C449E11A7EBC30752CB4DFBE50,
	CP1147_ToBytes_m6F077FABEDF8A9C7ABA93E0F3C6C33800D201F12,
	CP1147_GetBytesImpl_m862A58EE0328C5BDA8DC73A2A7E138A3B380597D,
	CP1147__cctor_m79BBAE735524F96BE26EADAC99A8EED854D610DF,
	ENCibm1147__ctor_m4615006EF1CF40832D1D8DB6AEE7AF214E2E8128,
	CP1148__ctor_m22328F26DAC83D8630486A7A0738D95257ED6B28,
	CP1148_GetByteCountImpl_mD799D4DB7833339E91D785B07498728AF0DC4A32,
	CP1148_GetByteCount_mECC7F9693853BE4E1F7D7DF2CD4FA24AF09886CD,
	CP1148_ToBytes_m6B3EB7FD2856A849FF2A2DC8F638683EFD196F00,
	CP1148_GetBytesImpl_m6A2869BE09F4570035B2BEF4E861B0FC3932DD67,
	CP1148__cctor_m516B48B826BA9079FA692CE58BC4C128432FDC67,
	ENCibm1148__ctor_mAF03FBDB428F5C0251393C9F8C3ED745015192DB,
	CP1149__ctor_mCD7E890094C096AD8323B783A94C2DF479BCD262,
	CP1149_GetByteCountImpl_m415AC61641CB79C86CB82C39FCDF23A7FA4872ED,
	CP1149_GetByteCount_m7A3902D2725E918447A22CD226B4F0E1FCA58E8E,
	CP1149_ToBytes_mF7F99F6F7F6C8B88EB9DBB9FCACC4AEAAC29FEF6,
	CP1149_GetBytesImpl_mEE73359626412F66A64CB8DF98A9242C7447404A,
	CP1149__cctor_m4B0D66AF62ADEBA9949478902DD9850CAAF50E62,
	ENCibm1149__ctor_m7F7BACB6A61041E9B272A7677AA2EB825A1F2171,
	CP20273__ctor_m31506F91007FF0709985205D9D309D2AB82105C6,
	CP20273_GetByteCountImpl_m970E35AD0D8A9E68A0F72E707E066FC883894917,
	CP20273_GetByteCount_m84BEE558B0C1119942145A6730119F49580E0791,
	CP20273_ToBytes_m72D53F2442FD4F191BAB2821EDF9EA2E4276D7B7,
	CP20273_GetBytesImpl_m423EBAA0D9C0C27A1F0371229917DAF9ACD472B7,
	CP20273__cctor_m49288DD98C4B85FB2B36208278835E94823E544F,
	ENCibm273__ctor_mD9DDC0D0E3C4707145A374E4BF029A19AC9E306B,
	CP20277__ctor_mD8FB025F7FE90C544AFACE88555EC0A6113F92AD,
	CP20277_GetByteCountImpl_mAE7BA6EBD8A79517BF3D6D2EA9E418899C9E2EE2,
	CP20277_GetByteCount_mA5FA2CA2BC4BAA6A464EBA31CE28A003C7B01BC9,
	CP20277_ToBytes_m31BEF7279A4E47CAA3D9C20B10A1401351A8A05C,
	CP20277_GetBytesImpl_m91ED75284C4496229F2C6548D654395E6CF85591,
	CP20277__cctor_m054C9386034A5A2A811AB9148590D0C7AF8FDC22,
	ENCibm277__ctor_m1F3BAA97E9E9A6C5172E2925A46BF9D8AC2EB068,
	CP20278__ctor_mC414EF110FDB493B3573F2BF7F831BE324AA10B8,
	CP20278_GetByteCountImpl_m6FCCE18645D2BAD267A32A0B38BF3F687FFC9C10,
	CP20278_GetByteCount_m442893AC3FC65C68DC5A71A6D38B68353C37B61F,
	CP20278_ToBytes_mE13F7C8F86985F3208689295D9D1C32C2611C013,
	CP20278_GetBytesImpl_m1412F657896FFD6B858C95FA02C78892497E8E1D,
	CP20278__cctor_m3C32EF460F78E27DF9C7725765C40A5A62D0D476,
	ENCibm278__ctor_mC86C9078B7EA0F9F525131D63055208B0CBF6988,
	CP20280__ctor_m184A9CF00D7CB0E66A371C9980239D491E7F7BA8,
	CP20280_GetByteCountImpl_m82F571A24BB5730146199675F4C2426C1E1BA25C,
	CP20280_GetByteCount_mDEE96C83B90591930A8D5022D150329834DAA672,
	CP20280_ToBytes_mBACC82476E7357FD208951BE91B81C5CA7FC8839,
	CP20280_GetBytesImpl_m13D48448800AA8B827A0D3792C9DADF9C818A66B,
	CP20280__cctor_mFAF9235E6554E80C497A1DD8AABB9FC6FF7DEEBB,
	ENCibm280__ctor_mDF958A1E0200D20D0939D9C0BB710903C0CA714B,
	CP20284__ctor_mDCAC0C691475E69A0CAE6632F84A5052CB794BEC,
	CP20284_GetByteCountImpl_m9FB6D5200598DB4B71BBACCA564474617482F278,
	CP20284_GetByteCount_m59F70338F243464689925A0F8271A632BB9FC2BC,
	CP20284_ToBytes_m8981AAA6A8F7AB817E743784B6D6C385E1FD3E7E,
	CP20284_GetBytesImpl_m8BFA932D1D86CD753A5A08310067D74BAA108638,
	CP20284__cctor_m49C0AB319CDDAD2731D1337F9711B2F7B62A8A40,
	ENCibm284__ctor_m4577E7D30C00DC6648A37B8B4D730CB25791E0ED,
	CP20285__ctor_m645397174B9D539741A250BF96E11AF5CDBB8960,
	CP20285_GetByteCountImpl_m7614603A5E584E133AB0CF54CC9E37C9713B46AC,
	CP20285_GetByteCount_mC1A73DFE41B6CAFF01586F715844888A46EE6E66,
	CP20285_ToBytes_m8E6CFED34C1842A772543C123CA216DBDAB2B43B,
	CP20285_GetBytesImpl_m16785F87C1E8B6A8CD810742A9CE3F742FD5A9AF,
	CP20285__cctor_mFD3737CE5E7D9DFC2F36E0D77C1A4807B73405E3,
	ENCibm285__ctor_mA42F590B0920D25523E3822CD1CED0D5B83F9E0C,
	CP20290__ctor_m3EE93053BBE5602D53344AB639D8C4E239CC9DDB,
	CP20290_GetByteCountImpl_m5B1BB04CBC4F40F3722743D45857410FB40700B9,
	CP20290_GetByteCount_mF511A80867F867B0B9AB550B9A0D88E484B3716A,
	CP20290_ToBytes_m09857E305F90DDF06257BD362F43BEF2237BECCC,
	CP20290_GetBytesImpl_mCFBD6B0862060DC05962ABE7353E64BF40C75DD1,
	CP20290__cctor_m83A58C7BF7BAB1F2B2691487A42106BB8A946897,
	ENCibm290__ctor_m3D75785AFF1C53A4DBE7301E0835CDAB6CEFBF7B,
	CP20297__ctor_mB0B18139293F2F070EAA460149F13308C1F58FD3,
	CP20297_GetByteCountImpl_mE715D1BD10F951712FC91307FD87A1AF9F4B43D4,
	CP20297_GetByteCount_mAA607D7379AF1E33E12218482040E88B639CEF72,
	CP20297_ToBytes_mBCF517000380E1D5363E756CE3CE629A3E85F09F,
	CP20297_GetBytesImpl_m2E8FCAAAC73D46F4C92D275EA9CBBDD249D6C6E5,
	CP20297__cctor_m297DE893C035C3778FDF6B8186A04BBA5ED8CB66,
	ENCibm297__ctor_m6A1C165B56F02C149A4853DDA48B52156BDB0DB3,
	CP20420__ctor_m9437FCE48B96406D74781B2A23EDA057F49EA8A4,
	CP20420_GetByteCountImpl_m9B9E7852F310EB65CE59F08E019F7CA4C0FD18B2,
	CP20420_GetByteCount_m974B6CF62A166B2367FA78DFE4AC0918963772BA,
	CP20420_ToBytes_mBE6018C82D904EA46A73644755090A1C66AE7513,
	CP20420_GetBytesImpl_m4683F84E9E346B339B0061F3E9DB2A9362971B9B,
	CP20420__cctor_mC03635EF51815C4E71D168165A6311AA0F4E80C5,
	ENCibm420__ctor_m2A8CF7BE8DE57DBF1C1BF0BAEB5CE43DB50B30DA,
	CP20424__ctor_mDF4FEA6B436E2539A7D00268EDD261BB1F125DFB,
	CP20424_GetByteCountImpl_m7F6E7BBA5FD2784506504166615DF6A0B5A7B297,
	CP20424_GetByteCount_m962A92A65F79B2469BF8BC5BB89C3BECDE6C99DA,
	CP20424_ToBytes_m671C428C003F2FCCC585B0F2E453DE7AB2C30975,
	CP20424_GetBytesImpl_m8250C37C2E3097C24C56A4A50773FE590692C233,
	CP20424__cctor_mF89FD94F424D19023418DB9ED165E0516786912C,
	ENCibm424__ctor_m9D4CA3C97CDE0D8E5C92F7C6A927CF6D79659505,
	CP20871__ctor_mAE95CB0E1B3BE8B833F1AADDFA5329EF4B9451E5,
	CP20871_GetByteCountImpl_m100E4A27BD53DCAE8D227D606538C6D9BA4E8CFF,
	CP20871_GetByteCount_m8521CC0BA40CEDDA249918BBBB964E2BFE913E79,
	CP20871_ToBytes_m7747E2AB5DAE4C04F672A5C0E2C9C538945F03EB,
	CP20871_GetBytesImpl_m25EAD7C461C50D3F6E92AA9881DB5221C904B309,
	CP20871__cctor_mCF8CF96027F2D6ED26BCD72942C2348534F6DB6B,
	ENCibm871__ctor_mDC691DA473DB9E3117618F332B0276D171A9FCCA,
	CP21025__ctor_m981475E0F3019E8AB702C8A853322566D9CADD43,
	CP21025_GetByteCountImpl_m4B221EDEC784FE9A68AF1648E5985E6CA25B466F,
	CP21025_GetByteCount_mE40158422844003778E7E25AC808CE893EF66D26,
	CP21025_ToBytes_mD6862B12D83A9F94FD75203D970D4C5773512E82,
	CP21025_GetBytesImpl_m671BA92EB84F40C2C4D44331F8AEF6EE8FBAF1B1,
	CP21025__cctor_m71040BAC76DEC7A158630ACEA4421CF364E166EA,
	ENCibm1025__ctor_m4BB61AA5AEE4BBA83CED9981FB45896F5EF5B6EE,
	CP37__ctor_m868AADC055620AA620A131F389139ECD9D72B728,
	CP37_GetByteCountImpl_mB9FAF4552E9220E5D8E00B038ED9A5A085417751,
	CP37_GetByteCount_m90E9B600601F1A4FF8BA9ECC7492C372C61606BB,
	CP37_ToBytes_m7C5D04966208AA73A3AE4BA331F761C9D4BB6EF0,
	CP37_GetBytesImpl_m15F163C004170295C06D4AFCD6004DC4F6C8EEEE,
	CP37__cctor_mA4FB9F427CA906A45DFE7391AA7A2336E1C54AD5,
	ENCibm037__ctor_m8A8FD7029D30A5D06E768C148FF241DB12A35E21,
	CP500__ctor_m257863DE2C78AE0E8D5EFA5D9A51CF269428C8D4,
	CP500_GetByteCountImpl_m6A9DF1230F29C833F02EDA5BF4D6AF13FCD2C76C,
	CP500_GetByteCount_mA6EAA698599B1E9A68766BA068089555C0390C90,
	CP500_ToBytes_m9981E260366ABAE94FFA239E0949B4CA63A6F3F7,
	CP500_GetBytesImpl_m0A10736329773A964BEEF191D79C8D8FA1153F7A,
	CP500__cctor_mC79CA8895D39AA2FC909F5CAC6C7BE83A6349850,
	ENCibm500__ctor_m28FD4D9820C304913C6CD27D27E2904F5C1C7C10,
	CP708__ctor_mDD0B3CF20A07D1BE0072B4AC1B737BFD69245D1E,
	CP708_GetByteCountImpl_m6E3950E37E01EE4699F991215050CB801FB2341B,
	CP708_GetByteCount_m2561CD22A120677D287C521258A8A66A4B477B54,
	CP708_ToBytes_mB6C2990A354F7E33DD73DBEF73D558FEDBE18EC4,
	CP708_GetBytesImpl_m6369955F9BD1DDC52553DFD869619A51AF4ECEC4,
	CP708__cctor_m045E7C23ECF1C6BEEF688BC2141B78D28F7E4A01,
	ENCasmo_708__ctor_mF489D3AF383945B9530F522CF33569905D78D069,
	CP852__ctor_mE4333273FD3055F7201E459F6E6D918E916117BA,
	CP852_GetByteCountImpl_m7B44EDEC88FB77E2714797608B4EBF6932A53DE2,
	CP852_GetByteCount_mE4FE116FFADB3EB61B5B61773E3C72E7AD5F50D2,
	CP852_ToBytes_m6A212A5CE2304FF3C103A42BAA27F841B5D18E44,
	CP852_GetBytesImpl_mD4DFF69E2B1EBC47174C723DE338A4FC47C902E0,
	CP852__cctor_m04D15F72E69A66F31812609289E9E3732F3B39C9,
	ENCibm852__ctor_m8B6A73A2FBC4B0C69ADA4C5DE6EB3FE74D4D7F45,
	CP855__ctor_m2172E4BDA6E16A35A30B075FA587AB72743D31C2,
	CP855_GetByteCountImpl_mB2D923D2F49198EFF4FEEB33A15A031FF0E463A5,
	CP855_GetByteCount_mCEA8F5787F93318C44C996D36D05DB0EF72496DE,
	CP855_ToBytes_m9A2F6DDA23B17B5EDBBAD3299FC952F94D51BEF2,
	CP855_GetBytesImpl_mF71D3783D1B95DA7D602BBA6AF1D1F9F39576D45,
	CP855__cctor_m24120C19AF065BBE09CB49E826EDDAE4CCA45A1B,
	ENCibm855__ctor_m5BF86A4EF1B5F063F92278FA55DDAED0861CD175,
	CP857__ctor_mA2532FDF60B5D50570F83B888E6F54EB1958D915,
	CP857_GetByteCountImpl_mEFD2C2D79BAFF70EFDE7B476FDAF28A6B08DFEBF,
	CP857_GetByteCount_m5FABE0C07CF564D8429B248540CADEAE8B4E0CE4,
	CP857_ToBytes_mBF0C99DE26FB4FB7110A783477F8565A56BD158E,
	CP857_GetBytesImpl_m0640F6D49AEC2D13F57232A51F1908044F59C33A,
	CP857__cctor_m81C2523619A9DC012384218717AAE784B3DEF218,
	ENCibm857__ctor_mB11A056FA3A65167363CA8B11FCD18CE71BD3F78,
	CP858__ctor_mCABC58A716587CBD417C5DB61AC2AADA0580873F,
	CP858_GetByteCountImpl_m586F0116D8CB5228823FB7E4195197410C5C9B55,
	CP858_GetByteCount_m6143798B2875150DCC29664D009C85EBCE43DDBB,
	CP858_ToBytes_m2F96B9361BD75E1D11C6464B3694E681A7882199,
	CP858_GetBytesImpl_m485899D471327569EB5A4738C6A62CE73D5D4A50,
	CP858__cctor_m24AA0741EB175BA6E1302535A1736DBB21BAE0DF,
	ENCibm00858__ctor_mFA74D2D7AB572F83A1958F806746734718571F78,
	CP862__ctor_mEA17600A0FA4B45BB88FA3CA1960416C23DC14A7,
	CP862_GetByteCountImpl_m980ECE272971E3541C27F9B76FA8EDE8CE2AA30A,
	CP862_GetByteCount_m9BCB42FCB15ACA6D828B50BC8DB3FC887E677645,
	CP862_ToBytes_m76192E2BB8CF9C9BC2E2FC5ABDD9BC3520295559,
	CP862_GetBytesImpl_m5B4E4DC4B285BE88EB89DF2A008699C4B2A8B7E9,
	CP862__cctor_mE4C27EC733587CAFF4DE2C5A02F83895898D9154,
	ENCibm862__ctor_mF76284FD2A47C27F4973069B15A2BC27C4D9E7DF,
	CP864__ctor_m6517F4636C645085286B8132FE855452D2029297,
	CP864_GetByteCountImpl_m00E38CBECF48FAB21530B84DC84DBED0A6412809,
	CP864_GetByteCount_m8FA00E05020D79EF1E4EDF2879457B932B160908,
	CP864_ToBytes_mEFB6C94EF5C3CD4CB27D8F067774D782A526BFC9,
	CP864_GetBytesImpl_mF4C31D0B189BB28904C6786DCECB888C202DA805,
	CP864__cctor_mB9D10F7662BC37510801CB0857B82B94284E439B,
	ENCibm864__ctor_m2F92D4D0AF60031BFF6762AB61260E5974EE6B6A,
	CP866__ctor_mEBE3DA0BD51C53C9B73A09AD9973292CDA08DBF8,
	CP866_GetByteCountImpl_m64FB31D56306918A1468B6B24F9A63FBB323D1B5,
	CP866_GetByteCount_m8600E425AE7A64F1243F3C5A6763714F543DD7C8,
	CP866_ToBytes_m4C75A3BE37E0B9DD633385388C9CEDC820A00E9E,
	CP866_GetBytesImpl_mAA942D6ABF08EDFDBD85C2D680CA9FD0E6D66467,
	CP866__cctor_m538905765E833A235EF9D496999D461B9A6B3BCF,
	ENCibm866__ctor_m461FA20385B180D6D845F0B38116FF57E8C462E0,
	CP869__ctor_m4B903927E5B74AEFD810BF8161F2F44733D87E93,
	CP869_GetByteCountImpl_mB3E1B70F89054A91D895E166E0EFADA4834BEF28,
	CP869_GetByteCount_m93CD21D2BAAC2DD47AEA254C42AF62E598D31D95,
	CP869_ToBytes_m78FCF500AB5CDD978EF3F529BCFC80CEFBBA4BF0,
	CP869_GetBytesImpl_mEF86E8BA313A36FE32C0F0D228268F029C2C85C1,
	CP869__cctor_m5E354758F9C76FAB1994FA2C6AB166EA40AF3362,
	ENCibm869__ctor_m1635C042CE477AD9888EAE76CB8080CC5012D8DF,
	CP870__ctor_m25757A6B07BA12D2536FEB8BE77A9C9B018AE70C,
	CP870_GetByteCountImpl_m1D9F3A222B5535F2AEE217E473719A4654FB866C,
	CP870_GetByteCount_m4F2010533F854EC73C5404BA712ADC2F3BAD32BA,
	CP870_ToBytes_mB38739CC8DD77C6D3CC773D8D1145615B69288F1,
	CP870_GetBytesImpl_m6E225F289CCDA30529F998C1DFC5A9AF671AAFC6,
	CP870__cctor_mDAFF8C32CCCDD6706504FEED55892C5F9C57C7BF,
	ENCibm870__ctor_m45B10A20BED73EB5FD4FEFEF51739C1E25E1ECEA,
	CP875__ctor_m549C26D952147626FF376EE139B225C76C84A35E,
	CP875_GetByteCountImpl_m8B88498CA4DE55072389C11C3209DB88EABB8E3B,
	CP875_GetByteCount_mAD0AEB13C86A8CA8C6C11B52279521688421192E,
	CP875_ToBytes_m228BF8058B9E77813AE1719288B6E163412A8D2F,
	CP875_GetBytesImpl_m4D2286759951124C32466ACBB59F2B024CB4EC63,
	CP875__cctor_m2AB2F626897153328F375BE8FE3BDAA98E6B9139,
	ENCibm875__ctor_mCBDE7574E5CC3711CEBA6DCA8B53347F096872E6,
};
static const int32_t s_InvokerIndices[259] = 
{
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
	2413,
	744,
	1398,
	389,
	230,
	3845,
	2413,
};
extern const CustomAttributesCacheGenerator g_I18N_Rare_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_I18N_Rare_CodeGenModule;
const Il2CppCodeGenModule g_I18N_Rare_CodeGenModule = 
{
	"I18N.Rare.dll",
	259,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_I18N_Rare_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
