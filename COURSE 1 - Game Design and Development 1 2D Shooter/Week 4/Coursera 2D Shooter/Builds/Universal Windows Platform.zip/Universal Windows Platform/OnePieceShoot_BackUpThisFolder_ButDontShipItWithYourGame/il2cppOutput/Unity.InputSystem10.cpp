﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>



// System.Action`1<UnityEngine.InputSystem.EnhancedTouch.Finger>
struct Action_1_t910296A84A83F83A6C7BDEA38F223D61CE284869;
// System.Action`1<UnityEngine.InputSystem.LowLevel.InputStateHistory/Record>
struct Action_1_t50A4778324C38A4406F4AF30FB340C3B0903F628;
// System.Comparison`1<UnityEngine.InputSystem.LowLevel.InputEventPtr>
struct Comparison_1_t41E9C9F20C94FDFE7D646A69CA10AAEC1CCB8E8B;
// System.Comparison`1<UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData>
struct Comparison_1_t76CBD193DECF0CB539FFE660CA9A36E139DB4CF6;
// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,System.Func`1<UnityEngine.InputSystem.Layouts.InputControlLayout>>
struct Dictionary_2_t83E6A9593BAD78485A83686EF50657E81F026A07;
// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString[]>
struct Dictionary_2_tC2734D476B15C1160524848A5921197DCC5AA8F6;
// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Layouts.InputControlLayout>
struct Dictionary_2_t6CE8857E6EF0C2875C715AE940B95E61532EA296;
// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B;
// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,System.String>
struct Dictionary_2_tD1780174E451F0B475D43D8321D854C2B2B07D4C;
// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,System.Type>
struct Dictionary_2_tF31B1670D5F3FD89062596A16A6A3F982D3AA2B3;
// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout>
struct Dictionary_2_tD26AC342FBEBD317D2A4C15C5F6C03CBCBCBA2A6;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct Dictionary_2_t6559C3595494ACAFACFBD50DF3795F25E9D5FEB1;
// System.Func`1<UnityEngine.InputSystem.InputDevice>
struct Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548;
// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.String>
struct Func_2_tD8A0C985DAC7DECF7FEE05A852479FDB8738D89E;
// System.Func`2<System.Char,System.Boolean>
struct Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A;
// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String>
struct Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60;
// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.String>
struct Func_2_t65CB6A2986C2BB0067AD32730EB75A601F7B5DA9;
// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,System.String>
struct Func_2_tC0D2A1777B104BB75433E8B09FDA2B9ED8EA53FC;
// System.Func`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_tD58EEB7D030248D39CFED6A2AF6CF7A63FCB6A92;
// System.Func`2<System.String,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB;
// System.Func`2<UnityEngine.InputSystem.Utilities.Substring,System.String>
struct Func_2_t97CA568CCC4893AA7E8E988C3DEFC0301C896029;
// System.Func`2<UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem,System.String>
struct Func_2_t546D0CF059877C1E4D2FFB9FBF45017007B8D6CD;
// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.String>
struct Func_2_t1E02FFE04AF564CCC3318EE317C5A11B8E73FEB3;
// System.Func`4<UnityEngine.InputSystem.InputControl,System.Double,UnityEngine.InputSystem.LowLevel.InputEventPtr,System.Boolean>
struct Func_4_tC181B89FE77E225DD2208DFFF3D3152DD9923199;
// System.Collections.Generic.HashSet`1<UnityEngine.InputSystem.Utilities.InternedString>
struct HashSet_1_t1A7C54D585AA8C377AA954087C08CA6D18F6FA01;
// System.Collections.Generic.IEnumerable`1<UnityEngine.InputSystem.Utilities.InternedString>
struct IEnumerable_1_tE4BC3C9BAA1C964715F4617E85A281C9418BE362;
// System.Collections.Generic.IEnumerable`1<UnityEngine.InputSystem.Utilities.NameAndParameters>
struct IEnumerable_1_tB1216DA08ED360D37CC52F53E51531BF31A46F2A;
// System.Collections.Generic.IEnumerable`1<System.Object>
struct IEnumerable_1_t52B1AC8D9E5E1ED28DF6C46A37C9A1B00B394F9D;
// System.Collections.Generic.IEnumerable`1<System.String>
struct IEnumerable_1_tBD60400523D840591A17E4CBBACC79397F68FAA2;
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.InternedString>
struct IEnumerator_1_t4F2FFA112134F73C0BA23053330D506ACF942F3B;
// System.Collections.Generic.IEnumerator`1<System.String>
struct IEnumerator_1_t0DE5AA701B682A891412350E63D3E441F98F205C;
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.Substring>
struct IEnumerator_1_tA0D9A1FD40F186D8256B0F5EB6D3AEF0E6F249B3;
// System.Collections.Generic.IEqualityComparer`1<UnityEngine.InputSystem.Utilities.InternedString>
struct IEqualityComparer_1_tEF7302F3805E90C9B21F2F803D7279DB18A77F44;
// System.IObserver`1<UnityEngine.InputSystem.InputRemoting/Message>
struct IObserver_1_t81B67421C15515BB91146854EBCE842BA3089830;
// UnityEngine.InputSystem.LowLevel.InputStateHistory`1<UnityEngine.InputSystem.LowLevel.TouchState>
struct InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2;
// System.Collections.Generic.Dictionary`2/KeyCollection<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct KeyCollection_t006DB7CD4B9E4A07C48B399AFD597A02E092B38D;
// System.Collections.Generic.KeyValuePair`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>
struct KeyValuePair_2_t9217F6CF4678FF5176B3DA3A0671CFA8795CFA5B;
// System.Collections.Generic.List`1<UnityEngine.GameObject>
struct List_1_t6D0A10F47F3440798295D2FFFC6D016477AF38E5;
// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct List_1_tC2452E93E5B8E31149932C482B9B7286089CB38E;
// System.Collections.Generic.List`1<UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher>
struct List_1_tA532ACDF821E8BDDBE629683B902A55D9031A2A3;
// System.Predicate`1<UnityEngine.InputSystem.HID.HID/HIDElementDescriptor>
struct Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915;
// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween>
struct TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3;
// UnityEngine.InputSystem.Utilities.SavedStructState`1/TypedRestore<UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState>
struct TypedRestore_tABE09F2E6C9FC315B0091394AA981B947F92C359;
// UnityEngine.Events.UnityEvent`1<System.Object>
struct UnityEvent_1_t32063FE815890FF672DF76288FAC4ABE089B899F;
// UnityEngine.Events.UnityEvent`1<UnityEngine.InputSystem.PlayerInput>
struct UnityEvent_1_tD09E39AD92F90E8B662BC6003C65B108EC9B5EEC;
// System.Collections.Generic.Dictionary`2/ValueCollection<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct ValueCollection_tC6513C6A2A42B269397BAFD64F7EB3D168472C9C;
// System.Action`1<UnityEngine.InputSystem.EnhancedTouch.Finger>[]
struct Action_1U5BU5D_t37CFEBCC7F1205F6F9D6704CB99DEDC0C8824698;
// System.Collections.Generic.Dictionary`2/Entry<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>[]
struct EntryU5BU5D_t4F813D1ACE5E692DF8CA0547753EEDA315FDB0B1;
// System.Collections.Generic.KeyValuePair`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>[]
struct KeyValuePair_2U5BU5D_t8BAE944D06577C053998DBBC1FF7E54D1D5A2B86;
// System.Byte[]
struct ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726;
// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
// System.Delegate[]
struct DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8;
// UnityEngine.InputSystem.XR.FeatureType[]
struct FeatureTypeU5BU5D_tB3F2D80FA7A42C92DB342D932C6849786A8B3142;
// UnityEngine.InputSystem.EnhancedTouch.Finger[]
struct FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD;
// UnityEngine.InputSystem.InputControl[]
struct InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F;
// System.Int32[]
struct Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32;
// System.IntPtr[]
struct IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6;
// UnityEngine.InputSystem.Utilities.InternedString[]
struct InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11;
// UnityEngine.InputSystem.Utilities.NameAndParameters[]
struct NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83;
// UnityEngine.InputSystem.Utilities.NamedValue[]
struct NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B;
// System.Object[]
struct ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE;
// System.Diagnostics.StackTrace[]
struct StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971;
// System.String[]
struct StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A;
// UnityEngine.InputSystem.EnhancedTouch.Touch[]
struct TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D;
// UnityEngine.InputSystem.Controls.TouchControl[]
struct TouchControlU5BU5D_t3302F43FFA0BC474E3B9C53164567D693887D99D;
// UnityEngine.InputSystem.Touchscreen[]
struct TouchscreenU5BU5D_t8D58F4C9D6EAFDFFE7462D87A759E9BA0EAB1559;
// System.UInt32[]
struct UInt32U5BU5D_tCF06F1E9E72E0302C762578FF5358CC523F2A2CF;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA;
// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem[]
struct ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05;
// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement[]
struct DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F;
// UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber[]
struct SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D;
// System.Action
struct Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6;
// System.ArgumentException
struct ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00;
// System.AsyncCallback
struct AsyncCallback_tA7921BEF974919C46FF8F9D9867C567B200BB0EA;
// UnityEngine.InputSystem.Controls.AxisControl
struct AxisControl_tF6BA6DA28DAB8BBBAD80A596F12BF340EE883B22;
// UnityEngine.EventSystems.BaseRaycaster
struct BaseRaycaster_tBC0FB2CBE6D3D40991EC20F689C43F76AD82A876;
// UnityEngine.InputSystem.Controls.ButtonControl
struct ButtonControl_t7C71776B1EF54267612446DAC263673FCCA25E6D;
// UnityEngine.Canvas
struct Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA;
// UnityEngine.CanvasRenderer
struct CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E;
// System.DelegateData
struct DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288;
// UnityEngine.EventSystems.EventSystem
struct EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C;
// UnityEngine.InputSystem.EnhancedTouch.Finger
struct Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2;
// UnityEngine.GameObject
struct GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319;
// UnityEngine.UI.Graphic
struct Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24;
// System.IAsyncResult
struct IAsyncResult_tC9F97BF36FCF122D29D3101D80642278297BF370;
// System.Collections.IDictionary
struct IDictionary_t99871C56B8EC2452AC5C4CF3831695E617B89D3A;
// UnityEngine.Networking.PlayerConnection.IEditorPlayerConnection
struct IEditorPlayerConnection_tC7FC4678004FA1C195D6D959C21A1FCD8C424D95;
// System.Collections.IEnumerator
struct IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105;
// UnityEngine.InputSystem.InputControl
struct InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713;
// UnityEngine.InputSystem.Layouts.InputControlLayout
struct InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491;
// UnityEngine.InputSystem.InputDevice
struct InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154;
// UnityEngine.InputSystem.Layouts.InputDeviceDescription
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA;
// UnityEngine.InputSystem.Layouts.InputDeviceMatcher
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D;
// UnityEngine.InputSystem.LowLevel.InputEvent
struct InputEvent_t729ADDE8270E3791CB953F0BB7B365B0E726CBA2;
// UnityEngine.InputSystem.LowLevel.InputStateHistory
struct InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E;
// UnityEngine.InputSystem.Utilities.InternedString
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4;
// System.InvalidOperationException
struct InvalidOperationException_t10D3EE59AD28EC641ACEE05BCA4271A527E5ECAB;
// UnityEngine.Events.InvokableCallList
struct InvokableCallList_tB7C66AA0C00F9C102C8BDC17A144E569AC7527A9;
// UnityEngine.Material
struct Material_t8927C00353A72755313F046D0CE85178AE8218EE;
// UnityEngine.Mesh
struct Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.NotSupportedException
struct NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339;
// UnityEngine.Events.PersistentCallGroup
struct PersistentCallGroup_t9A1D83DA2BA3118C103FA87D93CE92557A956FDC;
// UnityEngine.EventSystems.PointerEventData
struct PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954;
// System.Security.Cryptography.RandomNumberGenerator
struct RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50;
// UnityEngine.EventSystems.RaycastResult
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE;
// UnityEngine.RectTransform
struct RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072;
// UnityEngine.InputSystem.RemoteInputPlayerConnection
struct RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0;
// System.Runtime.Serialization.SafeSerializationManager
struct SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F;
// System.String
struct String_t;
// UnityEngine.Texture2D
struct Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF;
// UnityEngine.InputSystem.EnhancedTouch.Touch
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA;
// UnityEngine.InputSystem.Controls.TouchControl
struct TouchControl_t19F62A1376F68BCD07C64142EEC035FFAF50F798;
// UnityEngine.InputSystem.Touchscreen
struct Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9;
// System.Type
struct Type_t;
// UnityEngine.Events.UnityAction
struct UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099;
// UnityEngine.InputSystem.Controls.Vector2Control
struct Vector2Control_t342BA848221108F8818F05BF3CB484934F582935;
// UnityEngine.UI.VertexHelper
struct VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55;
// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5;
// UnityEngine.InputSystem.XR.XRDeviceDescriptor
struct XRDeviceDescriptor_t3FF7AB53B1EFCAB6A4BF6C277A89AC7AACFCD8D1;
// UnityEngine.InputSystem.XR.XRLayoutBuilder
struct XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6;
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder
struct Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E;
// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807;
// UnityEngine.InputSystem.PlayerInputManager/PlayerLeftEvent
struct PlayerLeftEvent_tC4BBBDE1FE743F4EC06251E8554EE4EFF88EF34E;
// UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber
struct Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155;
// UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9
struct U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E;
// UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8
struct U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393;
// UnityEngine.InputSystem.EnhancedTouch.Touch/<>c
struct U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690;
// UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49;
// UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator
struct Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69;
// UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c
struct U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5;
// UnityEngine.InputSystem.Utilities.TypeTable/<>c
struct U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16;
// UnityEngine.InputSystem.XR.XRLayoutBuilder/<>c__DisplayClass5_0
struct U3CU3Ec__DisplayClass5_0_t61B431287C870188CE58D7B356636FD26AA4A34F;
// UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c
struct U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419;
// UnityEngine.InputSystem.InputActionRebindingExtensions/RebindingOperation/<>c__DisplayClass32_0
struct U3CU3Ec__DisplayClass32_0_tA271F31E878C96B5240F88C220A943476FA04921;
// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24
struct U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C;
// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c
struct U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707;
// UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c
struct U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404;
// UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c
struct U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47;
// UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c
struct U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD;
// UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c__DisplayClass43_0
struct U3CU3Ec__DisplayClass43_0_tD15BBA4A7D46373705B077359CCBC1214B7E4D70;
// UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c
struct U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A;
// UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c
struct U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8;
// UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c
struct U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB;
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c
struct U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3;

IL2CPP_EXTERN_C RuntimeClass* ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* InvalidOperationException_t10D3EE59AD28EC641ACEE05BCA4271A527E5ECAB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Match_tF8E25BC160894A799358F44EB19C42365DAF0828_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral546E64419B7FFEA645697C61A9E3845E8244EB14;
IL2CPP_EXTERN_C String_t* _stringLiteral670CBAB5C8A30A4C8DC68337B78F13CC30BC704D;
IL2CPP_EXTERN_C String_t* _stringLiteral73F1C0DB7E67894BD0991354AA6CB2DA4A3A5D88;
IL2CPP_EXTERN_C String_t* _stringLiteral8AA175FF4B1ED47D26B7A4841279300DE227A679;
IL2CPP_EXTERN_C String_t* _stringLiteral8E2BEC23B4BAF8EC6CCD9A01B38260B8517E930F;
IL2CPP_EXTERN_C String_t* _stringLiteral987DBAD62F58327E403CC7854409712A13BD33B8;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayHelpers_AppendWithCapacity_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m409299335D98E3EE47D99B3651327AFE91780D55_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayHelpers_Clear_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m02E4370667B74A8D105681DEA12E2DBE27F36792_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayHelpers_EnsureCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mA18B65BA5322F4F005396C4FCF34BFDD0D6C1C15_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayHelpers_EraseSliceWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_m725E5BB760C8DD2772361E372A579B925CDD99B5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayHelpers_Erase_TisSubscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155_mB50873C9A1871E7CB5BFBF691B77D4628B081764_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayHelpers_InsertAtWithCapacity_TisTouch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_m86CEA702743AA33B3B395BCEF7202CBA1CBB742C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ControlBuilder_WithLayout_mD3C038067BB92E5A917110E4FBABEA3AB1E253A8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ControlBuilder_WithUsages_m7766F0A2DE6A8E77E17C4CF777D71A7D2A63ECF6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_TryGetValue_m13A59E4AB21B1AFCC1D94C66A2F5689DD3DF7C31_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_Select_TisString_t_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_m322E9154E14BE81AD2AAF37A69AC92E6FE3D0E6F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_ToArray_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_mB81CDBC6648458E775977B0F5B0CD7DFDB092FF8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_ToArray_TisNameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_mDC5522CF62EDFA52EEA4E8F85D7FECD84CFF23AE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerator_get_Current_m89A82ED8B3FAEF6771859606DADC26A56149B8B2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Func_2__ctor_m244A853C4545AF28ABF654C7F16EAF3B6D52BD7B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* InputControlList_1_get_Item_mB3D2AEA475656D4495707F32D001D2192024A108_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* InputStateHistory_1__ctor_m4CC173D63A840D058F7D825BB7D7C3A4FDBC1C12_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* KeyValuePair_2_get_Key_m0981E567B61168C690B6342E523A320D15BC6949_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* KeyValuePair_2_get_Value_mBBA0D76AE55EE865EADCB26991005D244E481AFF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyArray_1__ctor_m2AEF1D3FB42E7980B7C8F4D40E775EEB1DAD8C8E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyArray_1__ctor_mAD8348E710A8187038E9A181FF8458AB4FD59447_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyArray_1__ctor_mEBC958B99E88055B976A48FD29182C367B255013_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyArray_1_get_Item_m6E99B3BAB50380469478C5CFCD2410E4F64B92F9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Record__ctor_mA6E01856DFCAF450BB1AAA06672DBFC8B5061DCC_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CGetBaseLayoutsU3Ed__24_System_Collections_IEnumerator_Reset_mEB1025F01E1CDA75A0CD2954359454D42E774E2E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CSplitU3Ed__9_System_Collections_IEnumerator_Reset_m39D8804A07E4F16DC701F7614415743F7AA2F943_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CTokenizeU3Ed__8_System_Collections_IEnumerator_Reset_m08B687E0418382B35AB74491FD953B5C591AF183_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CWithUsagesU3Eb__14_0_m8ED6A0DFF67848D3FB546D919E9B8987D9D7DB78_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* UnityEvent_1__ctor_mD8BFEFBF01C2160CFD91DD3E681A92B6D7C9A5B8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* UnsafeUtility_SizeOf_TisTouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8_m88C8A28D5EC1B03454E3980C49B61DEEAF2B665B_RuntimeMethod_var;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807;;
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com;
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com;;
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke;
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke;;
struct Exception_t_marshaled_com;
struct Exception_t_marshaled_pinvoke;
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49;;
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com;
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com;;
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke;
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke;;
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA;;
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_com;
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_com;;
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_pinvoke;
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_pinvoke;;
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D;;
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_com;
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_com;;
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_pinvoke;
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_pinvoke;;
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4;;
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com;
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com;;
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke;
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke;;
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE;;
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_com;
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_com;;
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_pinvoke;
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_pinvoke;;
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA;;
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_com;
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_com;;
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_pinvoke;
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_pinvoke;;

struct FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD;
struct InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F;
struct InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11;
struct NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83;
struct NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B;
struct StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A;
struct TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D;
struct ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05;
struct DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F;
struct SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object


// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::buckets
	Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* ___buckets_0;
	// System.Collections.Generic.Dictionary`2/Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::entries
	EntryU5BU5D_t4F813D1ACE5E692DF8CA0547753EEDA315FDB0B1* ___entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::version
	int32_t ___version_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeList
	int32_t ___freeList_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeCount
	int32_t ___freeCount_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::comparer
	RuntimeObject* ___comparer_6;
	// System.Collections.Generic.Dictionary`2/KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::keys
	KeyCollection_t006DB7CD4B9E4A07C48B399AFD597A02E092B38D * ___keys_7;
	// System.Collections.Generic.Dictionary`2/ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::values
	ValueCollection_tC6513C6A2A42B269397BAFD64F7EB3D168472C9C * ___values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject * ____syncRoot_9;

public:
	inline static int32_t get_offset_of_buckets_0() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___buckets_0)); }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* get_buckets_0() const { return ___buckets_0; }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32** get_address_of_buckets_0() { return &___buckets_0; }
	inline void set_buckets_0(Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* value)
	{
		___buckets_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___buckets_0), (void*)value);
	}

	inline static int32_t get_offset_of_entries_1() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___entries_1)); }
	inline EntryU5BU5D_t4F813D1ACE5E692DF8CA0547753EEDA315FDB0B1* get_entries_1() const { return ___entries_1; }
	inline EntryU5BU5D_t4F813D1ACE5E692DF8CA0547753EEDA315FDB0B1** get_address_of_entries_1() { return &___entries_1; }
	inline void set_entries_1(EntryU5BU5D_t4F813D1ACE5E692DF8CA0547753EEDA315FDB0B1* value)
	{
		___entries_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___entries_1), (void*)value);
	}

	inline static int32_t get_offset_of_count_2() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___count_2)); }
	inline int32_t get_count_2() const { return ___count_2; }
	inline int32_t* get_address_of_count_2() { return &___count_2; }
	inline void set_count_2(int32_t value)
	{
		___count_2 = value;
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}

	inline static int32_t get_offset_of_freeList_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___freeList_4)); }
	inline int32_t get_freeList_4() const { return ___freeList_4; }
	inline int32_t* get_address_of_freeList_4() { return &___freeList_4; }
	inline void set_freeList_4(int32_t value)
	{
		___freeList_4 = value;
	}

	inline static int32_t get_offset_of_freeCount_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___freeCount_5)); }
	inline int32_t get_freeCount_5() const { return ___freeCount_5; }
	inline int32_t* get_address_of_freeCount_5() { return &___freeCount_5; }
	inline void set_freeCount_5(int32_t value)
	{
		___freeCount_5 = value;
	}

	inline static int32_t get_offset_of_comparer_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___comparer_6)); }
	inline RuntimeObject* get_comparer_6() const { return ___comparer_6; }
	inline RuntimeObject** get_address_of_comparer_6() { return &___comparer_6; }
	inline void set_comparer_6(RuntimeObject* value)
	{
		___comparer_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___comparer_6), (void*)value);
	}

	inline static int32_t get_offset_of_keys_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___keys_7)); }
	inline KeyCollection_t006DB7CD4B9E4A07C48B399AFD597A02E092B38D * get_keys_7() const { return ___keys_7; }
	inline KeyCollection_t006DB7CD4B9E4A07C48B399AFD597A02E092B38D ** get_address_of_keys_7() { return &___keys_7; }
	inline void set_keys_7(KeyCollection_t006DB7CD4B9E4A07C48B399AFD597A02E092B38D * value)
	{
		___keys_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___keys_7), (void*)value);
	}

	inline static int32_t get_offset_of_values_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ___values_8)); }
	inline ValueCollection_tC6513C6A2A42B269397BAFD64F7EB3D168472C9C * get_values_8() const { return ___values_8; }
	inline ValueCollection_tC6513C6A2A42B269397BAFD64F7EB3D168472C9C ** get_address_of_values_8() { return &___values_8; }
	inline void set_values_8(ValueCollection_tC6513C6A2A42B269397BAFD64F7EB3D168472C9C * value)
	{
		___values_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___values_8), (void*)value);
	}

	inline static int32_t get_offset_of__syncRoot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B, ____syncRoot_9)); }
	inline RuntimeObject * get__syncRoot_9() const { return ____syncRoot_9; }
	inline RuntimeObject ** get_address_of__syncRoot_9() { return &____syncRoot_9; }
	inline void set__syncRoot_9(RuntimeObject * value)
	{
		____syncRoot_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_9), (void*)value);
	}
};


// UnityEngine.EventSystems.AbstractEventData
struct AbstractEventData_tA0B5065DE3430C0031ADE061668E1C7073D718DF  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.EventSystems.AbstractEventData::m_Used
	bool ___m_Used_0;

public:
	inline static int32_t get_offset_of_m_Used_0() { return static_cast<int32_t>(offsetof(AbstractEventData_tA0B5065DE3430C0031ADE061668E1C7073D718DF, ___m_Used_0)); }
	inline bool get_m_Used_0() const { return ___m_Used_0; }
	inline bool* get_address_of_m_Used_0() { return &___m_Used_0; }
	inline void set_m_Used_0(bool value)
	{
		___m_Used_0 = value;
	}
};

struct Il2CppArrayBounds;

// System.Array


// UnityEngine.InputSystem.EnhancedTouch.Finger
struct Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2  : public RuntimeObject
{
public:
	// UnityEngine.InputSystem.Touchscreen UnityEngine.InputSystem.EnhancedTouch.Finger::<screen>k__BackingField
	Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___U3CscreenU3Ek__BackingField_0;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.Finger::<index>k__BackingField
	int32_t ___U3CindexU3Ek__BackingField_1;
	// UnityEngine.InputSystem.LowLevel.InputStateHistory`1<UnityEngine.InputSystem.LowLevel.TouchState> UnityEngine.InputSystem.EnhancedTouch.Finger::m_StateHistory
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___m_StateHistory_2;

public:
	inline static int32_t get_offset_of_U3CscreenU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2, ___U3CscreenU3Ek__BackingField_0)); }
	inline Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * get_U3CscreenU3Ek__BackingField_0() const { return ___U3CscreenU3Ek__BackingField_0; }
	inline Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 ** get_address_of_U3CscreenU3Ek__BackingField_0() { return &___U3CscreenU3Ek__BackingField_0; }
	inline void set_U3CscreenU3Ek__BackingField_0(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * value)
	{
		___U3CscreenU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CscreenU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CindexU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2, ___U3CindexU3Ek__BackingField_1)); }
	inline int32_t get_U3CindexU3Ek__BackingField_1() const { return ___U3CindexU3Ek__BackingField_1; }
	inline int32_t* get_address_of_U3CindexU3Ek__BackingField_1() { return &___U3CindexU3Ek__BackingField_1; }
	inline void set_U3CindexU3Ek__BackingField_1(int32_t value)
	{
		___U3CindexU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_m_StateHistory_2() { return static_cast<int32_t>(offsetof(Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2, ___m_StateHistory_2)); }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * get_m_StateHistory_2() const { return ___m_StateHistory_2; }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 ** get_address_of_m_StateHistory_2() { return &___m_StateHistory_2; }
	inline void set_m_StateHistory_2(InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * value)
	{
		___m_StateHistory_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_StateHistory_2), (void*)value);
	}
};


// System.String
struct String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// UnityEngine.Events.UnityEventBase
struct UnityEventBase_tBB43047292084BA63C5CBB1A379A8BB88611C6FB  : public RuntimeObject
{
public:
	// UnityEngine.Events.InvokableCallList UnityEngine.Events.UnityEventBase::m_Calls
	InvokableCallList_tB7C66AA0C00F9C102C8BDC17A144E569AC7527A9 * ___m_Calls_0;
	// UnityEngine.Events.PersistentCallGroup UnityEngine.Events.UnityEventBase::m_PersistentCalls
	PersistentCallGroup_t9A1D83DA2BA3118C103FA87D93CE92557A956FDC * ___m_PersistentCalls_1;
	// System.Boolean UnityEngine.Events.UnityEventBase::m_CallsDirty
	bool ___m_CallsDirty_2;

public:
	inline static int32_t get_offset_of_m_Calls_0() { return static_cast<int32_t>(offsetof(UnityEventBase_tBB43047292084BA63C5CBB1A379A8BB88611C6FB, ___m_Calls_0)); }
	inline InvokableCallList_tB7C66AA0C00F9C102C8BDC17A144E569AC7527A9 * get_m_Calls_0() const { return ___m_Calls_0; }
	inline InvokableCallList_tB7C66AA0C00F9C102C8BDC17A144E569AC7527A9 ** get_address_of_m_Calls_0() { return &___m_Calls_0; }
	inline void set_m_Calls_0(InvokableCallList_tB7C66AA0C00F9C102C8BDC17A144E569AC7527A9 * value)
	{
		___m_Calls_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Calls_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_PersistentCalls_1() { return static_cast<int32_t>(offsetof(UnityEventBase_tBB43047292084BA63C5CBB1A379A8BB88611C6FB, ___m_PersistentCalls_1)); }
	inline PersistentCallGroup_t9A1D83DA2BA3118C103FA87D93CE92557A956FDC * get_m_PersistentCalls_1() const { return ___m_PersistentCalls_1; }
	inline PersistentCallGroup_t9A1D83DA2BA3118C103FA87D93CE92557A956FDC ** get_address_of_m_PersistentCalls_1() { return &___m_PersistentCalls_1; }
	inline void set_m_PersistentCalls_1(PersistentCallGroup_t9A1D83DA2BA3118C103FA87D93CE92557A956FDC * value)
	{
		___m_PersistentCalls_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_PersistentCalls_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_CallsDirty_2() { return static_cast<int32_t>(offsetof(UnityEventBase_tBB43047292084BA63C5CBB1A379A8BB88611C6FB, ___m_CallsDirty_2)); }
	inline bool get_m_CallsDirty_2() const { return ___m_CallsDirty_2; }
	inline bool* get_address_of_m_CallsDirty_2() { return &___m_CallsDirty_2; }
	inline void set_m_CallsDirty_2(bool value)
	{
		___m_CallsDirty_2 = value;
	}
};


// System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// UnityEngine.InputSystem.XR.XRLayoutBuilder
struct XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6  : public RuntimeObject
{
public:
	// System.String UnityEngine.InputSystem.XR.XRLayoutBuilder::parentLayout
	String_t* ___parentLayout_0;
	// System.String UnityEngine.InputSystem.XR.XRLayoutBuilder::interfaceName
	String_t* ___interfaceName_1;
	// UnityEngine.InputSystem.XR.XRDeviceDescriptor UnityEngine.InputSystem.XR.XRLayoutBuilder::descriptor
	XRDeviceDescriptor_t3FF7AB53B1EFCAB6A4BF6C277A89AC7AACFCD8D1 * ___descriptor_2;

public:
	inline static int32_t get_offset_of_parentLayout_0() { return static_cast<int32_t>(offsetof(XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6, ___parentLayout_0)); }
	inline String_t* get_parentLayout_0() const { return ___parentLayout_0; }
	inline String_t** get_address_of_parentLayout_0() { return &___parentLayout_0; }
	inline void set_parentLayout_0(String_t* value)
	{
		___parentLayout_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___parentLayout_0), (void*)value);
	}

	inline static int32_t get_offset_of_interfaceName_1() { return static_cast<int32_t>(offsetof(XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6, ___interfaceName_1)); }
	inline String_t* get_interfaceName_1() const { return ___interfaceName_1; }
	inline String_t** get_address_of_interfaceName_1() { return &___interfaceName_1; }
	inline void set_interfaceName_1(String_t* value)
	{
		___interfaceName_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___interfaceName_1), (void*)value);
	}

	inline static int32_t get_offset_of_descriptor_2() { return static_cast<int32_t>(offsetof(XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6, ___descriptor_2)); }
	inline XRDeviceDescriptor_t3FF7AB53B1EFCAB6A4BF6C277A89AC7AACFCD8D1 * get_descriptor_2() const { return ___descriptor_2; }
	inline XRDeviceDescriptor_t3FF7AB53B1EFCAB6A4BF6C277A89AC7AACFCD8D1 ** get_address_of_descriptor_2() { return &___descriptor_2; }
	inline void set_descriptor_2(XRDeviceDescriptor_t3FF7AB53B1EFCAB6A4BF6C277A89AC7AACFCD8D1 * value)
	{
		___descriptor_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___descriptor_2), (void*)value);
	}
};

struct XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6_StaticFields
{
public:
	// System.String[] UnityEngine.InputSystem.XR.XRLayoutBuilder::poseSubControlNames
	StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* ___poseSubControlNames_3;
	// UnityEngine.InputSystem.XR.FeatureType[] UnityEngine.InputSystem.XR.XRLayoutBuilder::poseSubControlTypes
	FeatureTypeU5BU5D_tB3F2D80FA7A42C92DB342D932C6849786A8B3142* ___poseSubControlTypes_4;

public:
	inline static int32_t get_offset_of_poseSubControlNames_3() { return static_cast<int32_t>(offsetof(XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6_StaticFields, ___poseSubControlNames_3)); }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* get_poseSubControlNames_3() const { return ___poseSubControlNames_3; }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A** get_address_of_poseSubControlNames_3() { return &___poseSubControlNames_3; }
	inline void set_poseSubControlNames_3(StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* value)
	{
		___poseSubControlNames_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___poseSubControlNames_3), (void*)value);
	}

	inline static int32_t get_offset_of_poseSubControlTypes_4() { return static_cast<int32_t>(offsetof(XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6_StaticFields, ___poseSubControlTypes_4)); }
	inline FeatureTypeU5BU5D_tB3F2D80FA7A42C92DB342D932C6849786A8B3142* get_poseSubControlTypes_4() const { return ___poseSubControlTypes_4; }
	inline FeatureTypeU5BU5D_tB3F2D80FA7A42C92DB342D932C6849786A8B3142** get_address_of_poseSubControlTypes_4() { return &___poseSubControlTypes_4; }
	inline void set_poseSubControlTypes_4(FeatureTypeU5BU5D_tB3F2D80FA7A42C92DB342D932C6849786A8B3142* value)
	{
		___poseSubControlTypes_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___poseSubControlTypes_4), (void*)value);
	}
};


// UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber
struct Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155  : public RuntimeObject
{
public:
	// UnityEngine.InputSystem.RemoteInputPlayerConnection UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber::owner
	RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0 * ___owner_0;
	// System.IObserver`1<UnityEngine.InputSystem.InputRemoting/Message> UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber::observer
	RuntimeObject* ___observer_1;

public:
	inline static int32_t get_offset_of_owner_0() { return static_cast<int32_t>(offsetof(Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155, ___owner_0)); }
	inline RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0 * get_owner_0() const { return ___owner_0; }
	inline RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0 ** get_address_of_owner_0() { return &___owner_0; }
	inline void set_owner_0(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0 * value)
	{
		___owner_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___owner_0), (void*)value);
	}

	inline static int32_t get_offset_of_observer_1() { return static_cast<int32_t>(offsetof(Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155, ___observer_1)); }
	inline RuntimeObject* get_observer_1() const { return ___observer_1; }
	inline RuntimeObject** get_address_of_observer_1() { return &___observer_1; }
	inline void set_observer_1(RuntimeObject* value)
	{
		___observer_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___observer_1), (void*)value);
	}
};


// UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9
struct U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E  : public RuntimeObject
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.String UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::<>2__current
	String_t* ___U3CU3E2__current_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::<>l__initialThreadId
	int32_t ___U3CU3El__initialThreadId_2;
	// System.String UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::str
	String_t* ___str_3;
	// System.String UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::<>3__str
	String_t* ___U3CU3E3__str_4;
	// System.Func`2<System.Char,System.Boolean> UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::predicate
	Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * ___predicate_5;
	// System.Func`2<System.Char,System.Boolean> UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::<>3__predicate
	Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * ___U3CU3E3__predicate_6;
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::<length>5__2
	int32_t ___U3ClengthU3E5__2_7;
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::<position>5__3
	int32_t ___U3CpositionU3E5__3_8;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___U3CU3E2__current_1)); }
	inline String_t* get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline String_t** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(String_t* value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3El__initialThreadId_2() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___U3CU3El__initialThreadId_2)); }
	inline int32_t get_U3CU3El__initialThreadId_2() const { return ___U3CU3El__initialThreadId_2; }
	inline int32_t* get_address_of_U3CU3El__initialThreadId_2() { return &___U3CU3El__initialThreadId_2; }
	inline void set_U3CU3El__initialThreadId_2(int32_t value)
	{
		___U3CU3El__initialThreadId_2 = value;
	}

	inline static int32_t get_offset_of_str_3() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___str_3)); }
	inline String_t* get_str_3() const { return ___str_3; }
	inline String_t** get_address_of_str_3() { return &___str_3; }
	inline void set_str_3(String_t* value)
	{
		___str_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___str_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E3__str_4() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___U3CU3E3__str_4)); }
	inline String_t* get_U3CU3E3__str_4() const { return ___U3CU3E3__str_4; }
	inline String_t** get_address_of_U3CU3E3__str_4() { return &___U3CU3E3__str_4; }
	inline void set_U3CU3E3__str_4(String_t* value)
	{
		___U3CU3E3__str_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E3__str_4), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_5() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___predicate_5)); }
	inline Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * get_predicate_5() const { return ___predicate_5; }
	inline Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A ** get_address_of_predicate_5() { return &___predicate_5; }
	inline void set_predicate_5(Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * value)
	{
		___predicate_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E3__predicate_6() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___U3CU3E3__predicate_6)); }
	inline Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * get_U3CU3E3__predicate_6() const { return ___U3CU3E3__predicate_6; }
	inline Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A ** get_address_of_U3CU3E3__predicate_6() { return &___U3CU3E3__predicate_6; }
	inline void set_U3CU3E3__predicate_6(Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * value)
	{
		___U3CU3E3__predicate_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E3__predicate_6), (void*)value);
	}

	inline static int32_t get_offset_of_U3ClengthU3E5__2_7() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___U3ClengthU3E5__2_7)); }
	inline int32_t get_U3ClengthU3E5__2_7() const { return ___U3ClengthU3E5__2_7; }
	inline int32_t* get_address_of_U3ClengthU3E5__2_7() { return &___U3ClengthU3E5__2_7; }
	inline void set_U3ClengthU3E5__2_7(int32_t value)
	{
		___U3ClengthU3E5__2_7 = value;
	}

	inline static int32_t get_offset_of_U3CpositionU3E5__3_8() { return static_cast<int32_t>(offsetof(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E, ___U3CpositionU3E5__3_8)); }
	inline int32_t get_U3CpositionU3E5__3_8() const { return ___U3CpositionU3E5__3_8; }
	inline int32_t* get_address_of_U3CpositionU3E5__3_8() { return &___U3CpositionU3E5__3_8; }
	inline void set_U3CpositionU3E5__3_8(int32_t value)
	{
		___U3CpositionU3E5__3_8 = value;
	}
};


// UnityEngine.InputSystem.EnhancedTouch.Touch/<>c
struct U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_StaticFields
{
public:
	// UnityEngine.InputSystem.EnhancedTouch.Touch/<>c UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::<>9
	U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * ___U3CU3E9_0;
	// UnityEngine.InputSystem.Utilities.SavedStructState`1/TypedRestore<UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState> UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::<>9__78_0
	TypedRestore_tABE09F2E6C9FC315B0091394AA981B947F92C359 * ___U3CU3E9__78_0_1;
	// System.Action UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::<>9__78_1
	Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 * ___U3CU3E9__78_1_2;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__78_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_StaticFields, ___U3CU3E9__78_0_1)); }
	inline TypedRestore_tABE09F2E6C9FC315B0091394AA981B947F92C359 * get_U3CU3E9__78_0_1() const { return ___U3CU3E9__78_0_1; }
	inline TypedRestore_tABE09F2E6C9FC315B0091394AA981B947F92C359 ** get_address_of_U3CU3E9__78_0_1() { return &___U3CU3E9__78_0_1; }
	inline void set_U3CU3E9__78_0_1(TypedRestore_tABE09F2E6C9FC315B0091394AA981B947F92C359 * value)
	{
		___U3CU3E9__78_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__78_0_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__78_1_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_StaticFields, ___U3CU3E9__78_1_2)); }
	inline Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 * get_U3CU3E9__78_1_2() const { return ___U3CU3E9__78_1_2; }
	inline Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 ** get_address_of_U3CU3E9__78_1_2() { return &___U3CU3E9__78_1_2; }
	inline void set_U3CU3E9__78_1_2(Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 * value)
	{
		___U3CU3E9__78_1_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__78_1_2), (void*)value);
	}
};


// UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c
struct U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_StaticFields
{
public:
	// UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c::<>9
	U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 * ___U3CU3E9_0;
	// System.Comparison`1<UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData> UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c::<>9__25_0
	Comparison_1_t76CBD193DECF0CB539FFE660CA9A36E139DB4CF6 * ___U3CU3E9__25_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__25_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_StaticFields, ___U3CU3E9__25_0_1)); }
	inline Comparison_1_t76CBD193DECF0CB539FFE660CA9A36E139DB4CF6 * get_U3CU3E9__25_0_1() const { return ___U3CU3E9__25_0_1; }
	inline Comparison_1_t76CBD193DECF0CB539FFE660CA9A36E139DB4CF6 ** get_address_of_U3CU3E9__25_0_1() { return &___U3CU3E9__25_0_1; }
	inline void set_U3CU3E9__25_0_1(Comparison_1_t76CBD193DECF0CB539FFE660CA9A36E139DB4CF6 * value)
	{
		___U3CU3E9__25_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__25_0_1), (void*)value);
	}
};


// UnityEngine.InputSystem.Utilities.TypeTable/<>c
struct U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_StaticFields
{
public:
	// UnityEngine.InputSystem.Utilities.TypeTable/<>c UnityEngine.InputSystem.Utilities.TypeTable/<>c::<>9
	U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 * ___U3CU3E9_0;
	// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.Utilities.TypeTable/<>c::<>9__2_0
	Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * ___U3CU3E9__2_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__2_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_StaticFields, ___U3CU3E9__2_0_1)); }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * get_U3CU3E9__2_0_1() const { return ___U3CU3E9__2_0_1; }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 ** get_address_of_U3CU3E9__2_0_1() { return &___U3CU3E9__2_0_1; }
	inline void set_U3CU3E9__2_0_1(Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * value)
	{
		___U3CU3E9__2_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__2_0_1), (void*)value);
	}
};


// UnityEngine.InputSystem.XR.XRLayoutBuilder/<>c__DisplayClass5_0
struct U3CU3Ec__DisplayClass5_0_t61B431287C870188CE58D7B356636FD26AA4A34F  : public RuntimeObject
{
public:
	// UnityEngine.InputSystem.XR.XRLayoutBuilder UnityEngine.InputSystem.XR.XRLayoutBuilder/<>c__DisplayClass5_0::layout
	XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6 * ___layout_0;

public:
	inline static int32_t get_offset_of_layout_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass5_0_t61B431287C870188CE58D7B356636FD26AA4A34F, ___layout_0)); }
	inline XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6 * get_layout_0() const { return ___layout_0; }
	inline XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6 ** get_address_of_layout_0() { return &___layout_0; }
	inline void set_layout_0(XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6 * value)
	{
		___layout_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layout_0), (void*)value);
	}
};


// UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c
struct U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_StaticFields
{
public:
	// UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::<>9
	U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * ___U3CU3E9_0;
	// System.Predicate`1<UnityEngine.InputSystem.HID.HID/HIDElementDescriptor> UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::<>9__4_0
	Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 * ___U3CU3E9__4_0_1;
	// System.Predicate`1<UnityEngine.InputSystem.HID.HID/HIDElementDescriptor> UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::<>9__4_1
	Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 * ___U3CU3E9__4_1_2;
	// System.Func`2<UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem,System.String> UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::<>9__4_2
	Func_2_t546D0CF059877C1E4D2FFB9FBF45017007B8D6CD * ___U3CU3E9__4_2_3;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__4_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_StaticFields, ___U3CU3E9__4_0_1)); }
	inline Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 * get_U3CU3E9__4_0_1() const { return ___U3CU3E9__4_0_1; }
	inline Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 ** get_address_of_U3CU3E9__4_0_1() { return &___U3CU3E9__4_0_1; }
	inline void set_U3CU3E9__4_0_1(Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 * value)
	{
		___U3CU3E9__4_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__4_0_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__4_1_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_StaticFields, ___U3CU3E9__4_1_2)); }
	inline Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 * get_U3CU3E9__4_1_2() const { return ___U3CU3E9__4_1_2; }
	inline Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 ** get_address_of_U3CU3E9__4_1_2() { return &___U3CU3E9__4_1_2; }
	inline void set_U3CU3E9__4_1_2(Predicate_1_tBE90CF010866B15BD421A3C34B3D7D6FDA179915 * value)
	{
		___U3CU3E9__4_1_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__4_1_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__4_2_3() { return static_cast<int32_t>(offsetof(U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_StaticFields, ___U3CU3E9__4_2_3)); }
	inline Func_2_t546D0CF059877C1E4D2FFB9FBF45017007B8D6CD * get_U3CU3E9__4_2_3() const { return ___U3CU3E9__4_2_3; }
	inline Func_2_t546D0CF059877C1E4D2FFB9FBF45017007B8D6CD ** get_address_of_U3CU3E9__4_2_3() { return &___U3CU3E9__4_2_3; }
	inline void set_U3CU3E9__4_2_3(Func_2_t546D0CF059877C1E4D2FFB9FBF45017007B8D6CD * value)
	{
		___U3CU3E9__4_2_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__4_2_3), (void*)value);
	}
};


// UnityEngine.InputSystem.InputActionRebindingExtensions/RebindingOperation/<>c__DisplayClass32_0
struct U3CU3Ec__DisplayClass32_0_tA271F31E878C96B5240F88C220A943476FA04921  : public RuntimeObject
{
public:
	// System.String UnityEngine.InputSystem.InputActionRebindingExtensions/RebindingOperation/<>c__DisplayClass32_0::group
	String_t* ___group_0;

public:
	inline static int32_t get_offset_of_group_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass32_0_tA271F31E878C96B5240F88C220A943476FA04921, ___group_0)); }
	inline String_t* get_group_0() const { return ___group_0; }
	inline String_t** get_address_of_group_0() { return &___group_0; }
	inline void set_group_0(String_t* value)
	{
		___group_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___group_0), (void*)value);
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c
struct U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields
{
public:
	// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<>9
	U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * ___U3CU3E9_0;
	// System.Func`2<System.String,UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<>9__24_0
	Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * ___U3CU3E9__24_0_1;
	// System.Func`2<System.String,UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<>9__24_1
	Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * ___U3CU3E9__24_1_2;
	// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,System.String> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<>9__25_0
	Func_2_tC0D2A1777B104BB75433E8B09FDA2B9ED8EA53FC * ___U3CU3E9__25_0_3;
	// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.String> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<>9__25_1
	Func_2_t65CB6A2986C2BB0067AD32730EB75A601F7B5DA9 * ___U3CU3E9__25_1_4;
	// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<>9__25_2
	Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * ___U3CU3E9__25_2_5;
	// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<>9__25_3
	Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * ___U3CU3E9__25_3_6;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__24_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields, ___U3CU3E9__24_0_1)); }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * get_U3CU3E9__24_0_1() const { return ___U3CU3E9__24_0_1; }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB ** get_address_of_U3CU3E9__24_0_1() { return &___U3CU3E9__24_0_1; }
	inline void set_U3CU3E9__24_0_1(Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * value)
	{
		___U3CU3E9__24_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__24_0_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__24_1_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields, ___U3CU3E9__24_1_2)); }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * get_U3CU3E9__24_1_2() const { return ___U3CU3E9__24_1_2; }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB ** get_address_of_U3CU3E9__24_1_2() { return &___U3CU3E9__24_1_2; }
	inline void set_U3CU3E9__24_1_2(Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * value)
	{
		___U3CU3E9__24_1_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__24_1_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__25_0_3() { return static_cast<int32_t>(offsetof(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields, ___U3CU3E9__25_0_3)); }
	inline Func_2_tC0D2A1777B104BB75433E8B09FDA2B9ED8EA53FC * get_U3CU3E9__25_0_3() const { return ___U3CU3E9__25_0_3; }
	inline Func_2_tC0D2A1777B104BB75433E8B09FDA2B9ED8EA53FC ** get_address_of_U3CU3E9__25_0_3() { return &___U3CU3E9__25_0_3; }
	inline void set_U3CU3E9__25_0_3(Func_2_tC0D2A1777B104BB75433E8B09FDA2B9ED8EA53FC * value)
	{
		___U3CU3E9__25_0_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__25_0_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__25_1_4() { return static_cast<int32_t>(offsetof(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields, ___U3CU3E9__25_1_4)); }
	inline Func_2_t65CB6A2986C2BB0067AD32730EB75A601F7B5DA9 * get_U3CU3E9__25_1_4() const { return ___U3CU3E9__25_1_4; }
	inline Func_2_t65CB6A2986C2BB0067AD32730EB75A601F7B5DA9 ** get_address_of_U3CU3E9__25_1_4() { return &___U3CU3E9__25_1_4; }
	inline void set_U3CU3E9__25_1_4(Func_2_t65CB6A2986C2BB0067AD32730EB75A601F7B5DA9 * value)
	{
		___U3CU3E9__25_1_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__25_1_4), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__25_2_5() { return static_cast<int32_t>(offsetof(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields, ___U3CU3E9__25_2_5)); }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * get_U3CU3E9__25_2_5() const { return ___U3CU3E9__25_2_5; }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 ** get_address_of_U3CU3E9__25_2_5() { return &___U3CU3E9__25_2_5; }
	inline void set_U3CU3E9__25_2_5(Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * value)
	{
		___U3CU3E9__25_2_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__25_2_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__25_3_6() { return static_cast<int32_t>(offsetof(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields, ___U3CU3E9__25_3_6)); }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * get_U3CU3E9__25_3_6() const { return ___U3CU3E9__25_3_6; }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 ** get_address_of_U3CU3E9__25_3_6() { return &___U3CU3E9__25_3_6; }
	inline void set_U3CU3E9__25_3_6(Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * value)
	{
		___U3CU3E9__25_3_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__25_3_6), (void*)value);
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c
struct U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_StaticFields
{
public:
	// UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::<>9
	U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * ___U3CU3E9_0;
	// System.Func`2<System.String,UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::<>9__14_0
	Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * ___U3CU3E9__14_0_1;
	// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::<>9__15_0
	Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * ___U3CU3E9__15_0_2;
	// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::<>9__15_1
	Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * ___U3CU3E9__15_1_3;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__14_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_StaticFields, ___U3CU3E9__14_0_1)); }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * get_U3CU3E9__14_0_1() const { return ___U3CU3E9__14_0_1; }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB ** get_address_of_U3CU3E9__14_0_1() { return &___U3CU3E9__14_0_1; }
	inline void set_U3CU3E9__14_0_1(Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * value)
	{
		___U3CU3E9__14_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__14_0_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__15_0_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_StaticFields, ___U3CU3E9__15_0_2)); }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * get_U3CU3E9__15_0_2() const { return ___U3CU3E9__15_0_2; }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 ** get_address_of_U3CU3E9__15_0_2() { return &___U3CU3E9__15_0_2; }
	inline void set_U3CU3E9__15_0_2(Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * value)
	{
		___U3CU3E9__15_0_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__15_0_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__15_1_3() { return static_cast<int32_t>(offsetof(U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_StaticFields, ___U3CU3E9__15_1_3)); }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * get_U3CU3E9__15_1_3() const { return ___U3CU3E9__15_1_3; }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 ** get_address_of_U3CU3E9__15_1_3() { return &___U3CU3E9__15_1_3; }
	inline void set_U3CU3E9__15_1_3(Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * value)
	{
		___U3CU3E9__15_1_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__15_1_3), (void*)value);
	}
};


// UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c
struct U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_StaticFields
{
public:
	// UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c::<>9
	U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 * ___U3CU3E9_0;
	// System.Func`2<UnityEngine.InputSystem.Utilities.Substring,System.String> UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c::<>9__7_0
	Func_2_t97CA568CCC4893AA7E8E988C3DEFC0301C896029 * ___U3CU3E9__7_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__7_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_StaticFields, ___U3CU3E9__7_0_1)); }
	inline Func_2_t97CA568CCC4893AA7E8E988C3DEFC0301C896029 * get_U3CU3E9__7_0_1() const { return ___U3CU3E9__7_0_1; }
	inline Func_2_t97CA568CCC4893AA7E8E988C3DEFC0301C896029 ** get_address_of_U3CU3E9__7_0_1() { return &___U3CU3E9__7_0_1; }
	inline void set_U3CU3E9__7_0_1(Func_2_t97CA568CCC4893AA7E8E988C3DEFC0301C896029 * value)
	{
		___U3CU3E9__7_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__7_0_1), (void*)value);
	}
};


// UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c
struct U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_StaticFields
{
public:
	// UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c::<>9
	U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD * ___U3CU3E9_0;
	// System.Comparison`1<UnityEngine.InputSystem.LowLevel.InputEventPtr> UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c::<>9__38_0
	Comparison_1_t41E9C9F20C94FDFE7D646A69CA10AAEC1CCB8E8B * ___U3CU3E9__38_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__38_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_StaticFields, ___U3CU3E9__38_0_1)); }
	inline Comparison_1_t41E9C9F20C94FDFE7D646A69CA10AAEC1CCB8E8B * get_U3CU3E9__38_0_1() const { return ___U3CU3E9__38_0_1; }
	inline Comparison_1_t41E9C9F20C94FDFE7D646A69CA10AAEC1CCB8E8B ** get_address_of_U3CU3E9__38_0_1() { return &___U3CU3E9__38_0_1; }
	inline void set_U3CU3E9__38_0_1(Comparison_1_t41E9C9F20C94FDFE7D646A69CA10AAEC1CCB8E8B * value)
	{
		___U3CU3E9__38_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__38_0_1), (void*)value);
	}
};


// UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c__DisplayClass43_0
struct U3CU3Ec__DisplayClass43_0_tD15BBA4A7D46373705B077359CCBC1214B7E4D70  : public RuntimeObject
{
public:
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c__DisplayClass43_0::originalDeviceId
	int32_t ___originalDeviceId_0;

public:
	inline static int32_t get_offset_of_originalDeviceId_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass43_0_tD15BBA4A7D46373705B077359CCBC1214B7E4D70, ___originalDeviceId_0)); }
	inline int32_t get_originalDeviceId_0() const { return ___originalDeviceId_0; }
	inline int32_t* get_address_of_originalDeviceId_0() { return &___originalDeviceId_0; }
	inline void set_originalDeviceId_0(int32_t value)
	{
		___originalDeviceId_0 = value;
	}
};


// UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c
struct U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_StaticFields
{
public:
	// UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c::<>9
	U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A * ___U3CU3E9_0;
	// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c::<>9__1_0
	Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * ___U3CU3E9__1_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__1_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_StaticFields, ___U3CU3E9__1_0_1)); }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * get_U3CU3E9__1_0_1() const { return ___U3CU3E9__1_0_1; }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 ** get_address_of_U3CU3E9__1_0_1() { return &___U3CU3E9__1_0_1; }
	inline void set_U3CU3E9__1_0_1(Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * value)
	{
		___U3CU3E9__1_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__1_0_1), (void*)value);
	}
};


// UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c
struct U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_StaticFields
{
public:
	// UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c::<>9
	U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 * ___U3CU3E9_0;
	// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c::<>9__1_0
	Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * ___U3CU3E9__1_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__1_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_StaticFields, ___U3CU3E9__1_0_1)); }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * get_U3CU3E9__1_0_1() const { return ___U3CU3E9__1_0_1; }
	inline Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 ** get_address_of_U3CU3E9__1_0_1() { return &___U3CU3E9__1_0_1; }
	inline void set_U3CU3E9__1_0_1(Func_2_tEC6D252A64EAF9BC3615EA0CF6337D24557C8A60 * value)
	{
		___U3CU3E9__1_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__1_0_1), (void*)value);
	}
};


// UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c
struct U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_StaticFields
{
public:
	// UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::<>9
	U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * ___U3CU3E9_0;
	// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.String> UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::<>9__11_0
	Func_2_t1E02FFE04AF564CCC3318EE317C5A11B8E73FEB3 * ___U3CU3E9__11_0_1;
	// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.String> UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::<>9__11_1
	Func_2_tD8A0C985DAC7DECF7FEE05A852479FDB8738D89E * ___U3CU3E9__11_1_2;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__11_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_StaticFields, ___U3CU3E9__11_0_1)); }
	inline Func_2_t1E02FFE04AF564CCC3318EE317C5A11B8E73FEB3 * get_U3CU3E9__11_0_1() const { return ___U3CU3E9__11_0_1; }
	inline Func_2_t1E02FFE04AF564CCC3318EE317C5A11B8E73FEB3 ** get_address_of_U3CU3E9__11_0_1() { return &___U3CU3E9__11_0_1; }
	inline void set_U3CU3E9__11_0_1(Func_2_t1E02FFE04AF564CCC3318EE317C5A11B8E73FEB3 * value)
	{
		___U3CU3E9__11_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__11_0_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__11_1_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_StaticFields, ___U3CU3E9__11_1_2)); }
	inline Func_2_tD8A0C985DAC7DECF7FEE05A852479FDB8738D89E * get_U3CU3E9__11_1_2() const { return ___U3CU3E9__11_1_2; }
	inline Func_2_tD8A0C985DAC7DECF7FEE05A852479FDB8738D89E ** get_address_of_U3CU3E9__11_1_2() { return &___U3CU3E9__11_1_2; }
	inline void set_U3CU3E9__11_1_2(Func_2_tD8A0C985DAC7DECF7FEE05A852479FDB8738D89E * value)
	{
		___U3CU3E9__11_1_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__11_1_2), (void*)value);
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c
struct U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_StaticFields
{
public:
	// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c::<>9
	U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * ___U3CU3E9_0;
	// System.Func`2<System.String,UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c::<>9__14_0
	Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * ___U3CU3E9__14_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__14_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_StaticFields, ___U3CU3E9__14_0_1)); }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * get_U3CU3E9__14_0_1() const { return ___U3CU3E9__14_0_1; }
	inline Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB ** get_address_of_U3CU3E9__14_0_1() { return &___U3CU3E9__14_0_1; }
	inline void set_U3CU3E9__14_0_1(Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * value)
	{
		___U3CU3E9__14_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__14_0_1), (void*)value);
	}
};


// UnityEngine.InputSystem.Utilities.InlinedArray`1<System.Action`1<UnityEngine.InputSystem.EnhancedTouch.Finger>>
struct InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A 
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.InlinedArray`1::length
	int32_t ___length_0;
	// TValue UnityEngine.InputSystem.Utilities.InlinedArray`1::firstValue
	Action_1_t910296A84A83F83A6C7BDEA38F223D61CE284869 * ___firstValue_1;
	// TValue[] UnityEngine.InputSystem.Utilities.InlinedArray`1::additionalValues
	Action_1U5BU5D_t37CFEBCC7F1205F6F9D6704CB99DEDC0C8824698* ___additionalValues_2;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_firstValue_1() { return static_cast<int32_t>(offsetof(InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A, ___firstValue_1)); }
	inline Action_1_t910296A84A83F83A6C7BDEA38F223D61CE284869 * get_firstValue_1() const { return ___firstValue_1; }
	inline Action_1_t910296A84A83F83A6C7BDEA38F223D61CE284869 ** get_address_of_firstValue_1() { return &___firstValue_1; }
	inline void set_firstValue_1(Action_1_t910296A84A83F83A6C7BDEA38F223D61CE284869 * value)
	{
		___firstValue_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___firstValue_1), (void*)value);
	}

	inline static int32_t get_offset_of_additionalValues_2() { return static_cast<int32_t>(offsetof(InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A, ___additionalValues_2)); }
	inline Action_1U5BU5D_t37CFEBCC7F1205F6F9D6704CB99DEDC0C8824698* get_additionalValues_2() const { return ___additionalValues_2; }
	inline Action_1U5BU5D_t37CFEBCC7F1205F6F9D6704CB99DEDC0C8824698** get_address_of_additionalValues_2() { return &___additionalValues_2; }
	inline void set_additionalValues_2(Action_1U5BU5D_t37CFEBCC7F1205F6F9D6704CB99DEDC0C8824698* value)
	{
		___additionalValues_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___additionalValues_2), (void*)value);
	}
};


// UnityEngine.InputSystem.Utilities.InlinedArray`1<UnityEngine.InputSystem.Touchscreen>
struct InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0 
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.InlinedArray`1::length
	int32_t ___length_0;
	// TValue UnityEngine.InputSystem.Utilities.InlinedArray`1::firstValue
	Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___firstValue_1;
	// TValue[] UnityEngine.InputSystem.Utilities.InlinedArray`1::additionalValues
	TouchscreenU5BU5D_t8D58F4C9D6EAFDFFE7462D87A759E9BA0EAB1559* ___additionalValues_2;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_firstValue_1() { return static_cast<int32_t>(offsetof(InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0, ___firstValue_1)); }
	inline Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * get_firstValue_1() const { return ___firstValue_1; }
	inline Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 ** get_address_of_firstValue_1() { return &___firstValue_1; }
	inline void set_firstValue_1(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * value)
	{
		___firstValue_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___firstValue_1), (void*)value);
	}

	inline static int32_t get_offset_of_additionalValues_2() { return static_cast<int32_t>(offsetof(InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0, ___additionalValues_2)); }
	inline TouchscreenU5BU5D_t8D58F4C9D6EAFDFFE7462D87A759E9BA0EAB1559* get_additionalValues_2() const { return ___additionalValues_2; }
	inline TouchscreenU5BU5D_t8D58F4C9D6EAFDFFE7462D87A759E9BA0EAB1559** get_address_of_additionalValues_2() { return &___additionalValues_2; }
	inline void set_additionalValues_2(TouchscreenU5BU5D_t8D58F4C9D6EAFDFFE7462D87A759E9BA0EAB1559* value)
	{
		___additionalValues_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___additionalValues_2), (void*)value);
	}
};


// System.Nullable`1<System.Boolean>
struct Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3 
{
public:
	// T System.Nullable`1::value
	bool ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3, ___value_0)); }
	inline bool get_value_0() const { return ___value_0; }
	inline bool* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(bool value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};


// System.Nullable`1<System.Int32>
struct Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};


// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.InputControl>
struct ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832 
{
public:
	// TValue[] UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Array
	InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* ___m_Array_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_StartIndex
	int32_t ___m_StartIndex_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_Array_0() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832, ___m_Array_0)); }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* get_m_Array_0() const { return ___m_Array_0; }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F** get_address_of_m_Array_0() { return &___m_Array_0; }
	inline void set_m_Array_0(InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* value)
	{
		___m_Array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Array_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StartIndex_1() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832, ___m_StartIndex_1)); }
	inline int32_t get_m_StartIndex_1() const { return ___m_StartIndex_1; }
	inline int32_t* get_address_of_m_StartIndex_1() { return &___m_StartIndex_1; }
	inline void set_m_StartIndex_1(int32_t value)
	{
		___m_StartIndex_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};


// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.InternedString>
struct ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C 
{
public:
	// TValue[] UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Array
	InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___m_Array_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_StartIndex
	int32_t ___m_StartIndex_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_Array_0() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C, ___m_Array_0)); }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* get_m_Array_0() const { return ___m_Array_0; }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11** get_address_of_m_Array_0() { return &___m_Array_0; }
	inline void set_m_Array_0(InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* value)
	{
		___m_Array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Array_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StartIndex_1() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C, ___m_StartIndex_1)); }
	inline int32_t get_m_StartIndex_1() const { return ___m_StartIndex_1; }
	inline int32_t* get_address_of_m_StartIndex_1() { return &___m_StartIndex_1; }
	inline void set_m_StartIndex_1(int32_t value)
	{
		___m_StartIndex_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};


// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NameAndParameters>
struct ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F 
{
public:
	// TValue[] UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Array
	NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* ___m_Array_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_StartIndex
	int32_t ___m_StartIndex_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_Array_0() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F, ___m_Array_0)); }
	inline NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* get_m_Array_0() const { return ___m_Array_0; }
	inline NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83** get_address_of_m_Array_0() { return &___m_Array_0; }
	inline void set_m_Array_0(NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* value)
	{
		___m_Array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Array_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StartIndex_1() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F, ___m_StartIndex_1)); }
	inline int32_t get_m_StartIndex_1() const { return ___m_StartIndex_1; }
	inline int32_t* get_address_of_m_StartIndex_1() { return &___m_StartIndex_1; }
	inline void set_m_StartIndex_1(int32_t value)
	{
		___m_StartIndex_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};


// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue>
struct ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8 
{
public:
	// TValue[] UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Array
	NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* ___m_Array_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_StartIndex
	int32_t ___m_StartIndex_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_Array_0() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8, ___m_Array_0)); }
	inline NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* get_m_Array_0() const { return ___m_Array_0; }
	inline NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B** get_address_of_m_Array_0() { return &___m_Array_0; }
	inline void set_m_Array_0(NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* value)
	{
		___m_Array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Array_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StartIndex_1() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8, ___m_StartIndex_1)); }
	inline int32_t get_m_StartIndex_1() const { return ___m_StartIndex_1; }
	inline int32_t* get_address_of_m_StartIndex_1() { return &___m_StartIndex_1; }
	inline void set_m_StartIndex_1(int32_t value)
	{
		___m_StartIndex_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};


// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<System.Object>
struct ReadOnlyArray_1_t838D76309E9783F02B1E4A7AA7DFD33F97256A03 
{
public:
	// TValue[] UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Array
	ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ___m_Array_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_StartIndex
	int32_t ___m_StartIndex_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_Array_0() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t838D76309E9783F02B1E4A7AA7DFD33F97256A03, ___m_Array_0)); }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* get_m_Array_0() const { return ___m_Array_0; }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** get_address_of_m_Array_0() { return &___m_Array_0; }
	inline void set_m_Array_0(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* value)
	{
		___m_Array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Array_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StartIndex_1() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t838D76309E9783F02B1E4A7AA7DFD33F97256A03, ___m_StartIndex_1)); }
	inline int32_t get_m_StartIndex_1() const { return ___m_StartIndex_1; }
	inline int32_t* get_address_of_m_StartIndex_1() { return &___m_StartIndex_1; }
	inline void set_m_StartIndex_1(int32_t value)
	{
		___m_StartIndex_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t838D76309E9783F02B1E4A7AA7DFD33F97256A03, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};


// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Controls.TouchControl>
struct ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3 
{
public:
	// TValue[] UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Array
	TouchControlU5BU5D_t3302F43FFA0BC474E3B9C53164567D693887D99D* ___m_Array_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_StartIndex
	int32_t ___m_StartIndex_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_Array_0() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3, ___m_Array_0)); }
	inline TouchControlU5BU5D_t3302F43FFA0BC474E3B9C53164567D693887D99D* get_m_Array_0() const { return ___m_Array_0; }
	inline TouchControlU5BU5D_t3302F43FFA0BC474E3B9C53164567D693887D99D** get_address_of_m_Array_0() { return &___m_Array_0; }
	inline void set_m_Array_0(TouchControlU5BU5D_t3302F43FFA0BC474E3B9C53164567D693887D99D* value)
	{
		___m_Array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Array_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StartIndex_1() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3, ___m_StartIndex_1)); }
	inline int32_t get_m_StartIndex_1() const { return ___m_StartIndex_1; }
	inline int32_t* get_address_of_m_StartIndex_1() { return &___m_StartIndex_1; }
	inline void set_m_StartIndex_1(int32_t value)
	{
		___m_StartIndex_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record<UnityEngine.InputSystem.LowLevel.TouchState>
struct Record_t6A3403317B951528E7A550FABE9EC42900ABFC48 
{
public:
	// UnityEngine.InputSystem.LowLevel.InputStateHistory`1<TValue> UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record::m_Owner
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___m_Owner_0;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record::m_IndexPlusOne
	int32_t ___m_IndexPlusOne_1;
	// System.UInt32 UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record::m_Version
	uint32_t ___m_Version_2;

public:
	inline static int32_t get_offset_of_m_Owner_0() { return static_cast<int32_t>(offsetof(Record_t6A3403317B951528E7A550FABE9EC42900ABFC48, ___m_Owner_0)); }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * get_m_Owner_0() const { return ___m_Owner_0; }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 ** get_address_of_m_Owner_0() { return &___m_Owner_0; }
	inline void set_m_Owner_0(InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * value)
	{
		___m_Owner_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Owner_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_IndexPlusOne_1() { return static_cast<int32_t>(offsetof(Record_t6A3403317B951528E7A550FABE9EC42900ABFC48, ___m_IndexPlusOne_1)); }
	inline int32_t get_m_IndexPlusOne_1() const { return ___m_IndexPlusOne_1; }
	inline int32_t* get_address_of_m_IndexPlusOne_1() { return &___m_IndexPlusOne_1; }
	inline void set_m_IndexPlusOne_1(int32_t value)
	{
		___m_IndexPlusOne_1 = value;
	}

	inline static int32_t get_offset_of_m_Version_2() { return static_cast<int32_t>(offsetof(Record_t6A3403317B951528E7A550FABE9EC42900ABFC48, ___m_Version_2)); }
	inline uint32_t get_m_Version_2() const { return ___m_Version_2; }
	inline uint32_t* get_address_of_m_Version_2() { return &___m_Version_2; }
	inline void set_m_Version_2(uint32_t value)
	{
		___m_Version_2 = value;
	}
};


// UnityEngine.Events.UnityEvent`1<UnityEngine.InputSystem.PlayerInput>
struct UnityEvent_1_tD09E39AD92F90E8B662BC6003C65B108EC9B5EEC  : public UnityEventBase_tBB43047292084BA63C5CBB1A379A8BB88611C6FB
{
public:
	// System.Object[] UnityEngine.Events.UnityEvent`1::m_InvokeArray
	ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ___m_InvokeArray_3;

public:
	inline static int32_t get_offset_of_m_InvokeArray_3() { return static_cast<int32_t>(offsetof(UnityEvent_1_tD09E39AD92F90E8B662BC6003C65B108EC9B5EEC, ___m_InvokeArray_3)); }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* get_m_InvokeArray_3() const { return ___m_InvokeArray_3; }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** get_address_of_m_InvokeArray_3() { return &___m_InvokeArray_3; }
	inline void set_m_InvokeArray_3(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* value)
	{
		___m_InvokeArray_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_InvokeArray_3), (void*)value);
	}
};


// UnityEngine.EventSystems.BaseEventData
struct BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E  : public AbstractEventData_tA0B5065DE3430C0031ADE061668E1C7073D718DF
{
public:
	// UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.BaseEventData::m_EventSystem
	EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * ___m_EventSystem_1;

public:
	inline static int32_t get_offset_of_m_EventSystem_1() { return static_cast<int32_t>(offsetof(BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E, ___m_EventSystem_1)); }
	inline EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * get_m_EventSystem_1() const { return ___m_EventSystem_1; }
	inline EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C ** get_address_of_m_EventSystem_1() { return &___m_EventSystem_1; }
	inline void set_m_EventSystem_1(EventSystem_t5DC458FCD0355A74CDCCE79287B38B9C4278E39C * value)
	{
		___m_EventSystem_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_EventSystem_1), (void*)value);
	}
};


// System.Boolean
struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Byte
struct Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056, ___m_value_0)); }
	inline uint8_t get_m_value_0() const { return ___m_value_0; }
	inline uint8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint8_t value)
	{
		___m_value_0 = value;
	}
};


// System.Char
struct Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14 
{
public:
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14, ___m_value_0)); }
	inline Il2CppChar get_m_value_0() const { return ___m_value_0; }
	inline Il2CppChar* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(Il2CppChar value)
	{
		___m_value_0 = value;
	}
};

struct Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_StaticFields
{
public:
	// System.Byte[] System.Char::categoryForLatin1
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___categoryForLatin1_3;

public:
	inline static int32_t get_offset_of_categoryForLatin1_3() { return static_cast<int32_t>(offsetof(Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_StaticFields, ___categoryForLatin1_3)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_categoryForLatin1_3() const { return ___categoryForLatin1_3; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_categoryForLatin1_3() { return &___categoryForLatin1_3; }
	inline void set_categoryForLatin1_3(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___categoryForLatin1_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___categoryForLatin1_3), (void*)value);
	}
};


// UnityEngine.Color
struct Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};


// System.Double
struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};


// System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA  : public ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52
{
public:

public:
};

struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_com
{
};

// UnityEngine.InputSystem.Utilities.FourCC
struct FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A 
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.FourCC::m_Code
	int32_t ___m_Code_0;

public:
	inline static int32_t get_offset_of_m_Code_0() { return static_cast<int32_t>(offsetof(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A, ___m_Code_0)); }
	inline int32_t get_m_Code_0() const { return ___m_Code_0; }
	inline int32_t* get_address_of_m_Code_0() { return &___m_Code_0; }
	inline void set_m_Code_0(int32_t value)
	{
		___m_Code_0 = value;
	}
};


// System.Guid
struct Guid_t 
{
public:
	// System.Int32 System.Guid::_a
	int32_t ____a_1;
	// System.Int16 System.Guid::_b
	int16_t ____b_2;
	// System.Int16 System.Guid::_c
	int16_t ____c_3;
	// System.Byte System.Guid::_d
	uint8_t ____d_4;
	// System.Byte System.Guid::_e
	uint8_t ____e_5;
	// System.Byte System.Guid::_f
	uint8_t ____f_6;
	// System.Byte System.Guid::_g
	uint8_t ____g_7;
	// System.Byte System.Guid::_h
	uint8_t ____h_8;
	// System.Byte System.Guid::_i
	uint8_t ____i_9;
	// System.Byte System.Guid::_j
	uint8_t ____j_10;
	// System.Byte System.Guid::_k
	uint8_t ____k_11;

public:
	inline static int32_t get_offset_of__a_1() { return static_cast<int32_t>(offsetof(Guid_t, ____a_1)); }
	inline int32_t get__a_1() const { return ____a_1; }
	inline int32_t* get_address_of__a_1() { return &____a_1; }
	inline void set__a_1(int32_t value)
	{
		____a_1 = value;
	}

	inline static int32_t get_offset_of__b_2() { return static_cast<int32_t>(offsetof(Guid_t, ____b_2)); }
	inline int16_t get__b_2() const { return ____b_2; }
	inline int16_t* get_address_of__b_2() { return &____b_2; }
	inline void set__b_2(int16_t value)
	{
		____b_2 = value;
	}

	inline static int32_t get_offset_of__c_3() { return static_cast<int32_t>(offsetof(Guid_t, ____c_3)); }
	inline int16_t get__c_3() const { return ____c_3; }
	inline int16_t* get_address_of__c_3() { return &____c_3; }
	inline void set__c_3(int16_t value)
	{
		____c_3 = value;
	}

	inline static int32_t get_offset_of__d_4() { return static_cast<int32_t>(offsetof(Guid_t, ____d_4)); }
	inline uint8_t get__d_4() const { return ____d_4; }
	inline uint8_t* get_address_of__d_4() { return &____d_4; }
	inline void set__d_4(uint8_t value)
	{
		____d_4 = value;
	}

	inline static int32_t get_offset_of__e_5() { return static_cast<int32_t>(offsetof(Guid_t, ____e_5)); }
	inline uint8_t get__e_5() const { return ____e_5; }
	inline uint8_t* get_address_of__e_5() { return &____e_5; }
	inline void set__e_5(uint8_t value)
	{
		____e_5 = value;
	}

	inline static int32_t get_offset_of__f_6() { return static_cast<int32_t>(offsetof(Guid_t, ____f_6)); }
	inline uint8_t get__f_6() const { return ____f_6; }
	inline uint8_t* get_address_of__f_6() { return &____f_6; }
	inline void set__f_6(uint8_t value)
	{
		____f_6 = value;
	}

	inline static int32_t get_offset_of__g_7() { return static_cast<int32_t>(offsetof(Guid_t, ____g_7)); }
	inline uint8_t get__g_7() const { return ____g_7; }
	inline uint8_t* get_address_of__g_7() { return &____g_7; }
	inline void set__g_7(uint8_t value)
	{
		____g_7 = value;
	}

	inline static int32_t get_offset_of__h_8() { return static_cast<int32_t>(offsetof(Guid_t, ____h_8)); }
	inline uint8_t get__h_8() const { return ____h_8; }
	inline uint8_t* get_address_of__h_8() { return &____h_8; }
	inline void set__h_8(uint8_t value)
	{
		____h_8 = value;
	}

	inline static int32_t get_offset_of__i_9() { return static_cast<int32_t>(offsetof(Guid_t, ____i_9)); }
	inline uint8_t get__i_9() const { return ____i_9; }
	inline uint8_t* get_address_of__i_9() { return &____i_9; }
	inline void set__i_9(uint8_t value)
	{
		____i_9 = value;
	}

	inline static int32_t get_offset_of__j_10() { return static_cast<int32_t>(offsetof(Guid_t, ____j_10)); }
	inline uint8_t get__j_10() const { return ____j_10; }
	inline uint8_t* get_address_of__j_10() { return &____j_10; }
	inline void set__j_10(uint8_t value)
	{
		____j_10 = value;
	}

	inline static int32_t get_offset_of__k_11() { return static_cast<int32_t>(offsetof(Guid_t, ____k_11)); }
	inline uint8_t get__k_11() const { return ____k_11; }
	inline uint8_t* get_address_of__k_11() { return &____k_11; }
	inline void set__k_11(uint8_t value)
	{
		____k_11 = value;
	}
};

struct Guid_t_StaticFields
{
public:
	// System.Guid System.Guid::Empty
	Guid_t  ___Empty_0;
	// System.Object System.Guid::_rngAccess
	RuntimeObject * ____rngAccess_12;
	// System.Security.Cryptography.RandomNumberGenerator System.Guid::_rng
	RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 * ____rng_13;
	// System.Security.Cryptography.RandomNumberGenerator System.Guid::_fastRng
	RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 * ____fastRng_14;

public:
	inline static int32_t get_offset_of_Empty_0() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ___Empty_0)); }
	inline Guid_t  get_Empty_0() const { return ___Empty_0; }
	inline Guid_t * get_address_of_Empty_0() { return &___Empty_0; }
	inline void set_Empty_0(Guid_t  value)
	{
		___Empty_0 = value;
	}

	inline static int32_t get_offset_of__rngAccess_12() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rngAccess_12)); }
	inline RuntimeObject * get__rngAccess_12() const { return ____rngAccess_12; }
	inline RuntimeObject ** get_address_of__rngAccess_12() { return &____rngAccess_12; }
	inline void set__rngAccess_12(RuntimeObject * value)
	{
		____rngAccess_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____rngAccess_12), (void*)value);
	}

	inline static int32_t get_offset_of__rng_13() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rng_13)); }
	inline RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 * get__rng_13() const { return ____rng_13; }
	inline RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 ** get_address_of__rng_13() { return &____rng_13; }
	inline void set__rng_13(RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 * value)
	{
		____rng_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____rng_13), (void*)value);
	}

	inline static int32_t get_offset_of__fastRng_14() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____fastRng_14)); }
	inline RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 * get__fastRng_14() const { return ____fastRng_14; }
	inline RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 ** get_address_of__fastRng_14() { return &____fastRng_14; }
	inline void set__fastRng_14(RandomNumberGenerator_t2CB5440F189986116A2FA9F907AE52644047AC50 * value)
	{
		____fastRng_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____fastRng_14), (void*)value);
	}
};


// UnityEngine.InputSystem.InputControlScheme
struct InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288 
{
public:
	// System.String UnityEngine.InputSystem.InputControlScheme::m_Name
	String_t* ___m_Name_0;
	// System.String UnityEngine.InputSystem.InputControlScheme::m_BindingGroup
	String_t* ___m_BindingGroup_1;
	// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement[] UnityEngine.InputSystem.InputControlScheme::m_DeviceRequirements
	DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* ___m_DeviceRequirements_2;

public:
	inline static int32_t get_offset_of_m_Name_0() { return static_cast<int32_t>(offsetof(InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288, ___m_Name_0)); }
	inline String_t* get_m_Name_0() const { return ___m_Name_0; }
	inline String_t** get_address_of_m_Name_0() { return &___m_Name_0; }
	inline void set_m_Name_0(String_t* value)
	{
		___m_Name_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Name_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_BindingGroup_1() { return static_cast<int32_t>(offsetof(InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288, ___m_BindingGroup_1)); }
	inline String_t* get_m_BindingGroup_1() const { return ___m_BindingGroup_1; }
	inline String_t** get_address_of_m_BindingGroup_1() { return &___m_BindingGroup_1; }
	inline void set_m_BindingGroup_1(String_t* value)
	{
		___m_BindingGroup_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_BindingGroup_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_DeviceRequirements_2() { return static_cast<int32_t>(offsetof(InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288, ___m_DeviceRequirements_2)); }
	inline DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* get_m_DeviceRequirements_2() const { return ___m_DeviceRequirements_2; }
	inline DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F** get_address_of_m_DeviceRequirements_2() { return &___m_DeviceRequirements_2; }
	inline void set_m_DeviceRequirements_2(DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* value)
	{
		___m_DeviceRequirements_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DeviceRequirements_2), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputControlScheme
struct InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288_marshaled_pinvoke
{
	char* ___m_Name_0;
	char* ___m_BindingGroup_1;
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke* ___m_DeviceRequirements_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputControlScheme
struct InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288_marshaled_com
{
	Il2CppChar* ___m_Name_0;
	Il2CppChar* ___m_BindingGroup_1;
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com* ___m_DeviceRequirements_2;
};

// UnityEngine.InputSystem.Layouts.InputDeviceDescription
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA 
{
public:
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceDescription::m_InterfaceName
	String_t* ___m_InterfaceName_0;
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceDescription::m_DeviceClass
	String_t* ___m_DeviceClass_1;
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceDescription::m_Manufacturer
	String_t* ___m_Manufacturer_2;
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceDescription::m_Product
	String_t* ___m_Product_3;
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceDescription::m_Serial
	String_t* ___m_Serial_4;
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceDescription::m_Version
	String_t* ___m_Version_5;
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceDescription::m_Capabilities
	String_t* ___m_Capabilities_6;

public:
	inline static int32_t get_offset_of_m_InterfaceName_0() { return static_cast<int32_t>(offsetof(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA, ___m_InterfaceName_0)); }
	inline String_t* get_m_InterfaceName_0() const { return ___m_InterfaceName_0; }
	inline String_t** get_address_of_m_InterfaceName_0() { return &___m_InterfaceName_0; }
	inline void set_m_InterfaceName_0(String_t* value)
	{
		___m_InterfaceName_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_InterfaceName_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_DeviceClass_1() { return static_cast<int32_t>(offsetof(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA, ___m_DeviceClass_1)); }
	inline String_t* get_m_DeviceClass_1() const { return ___m_DeviceClass_1; }
	inline String_t** get_address_of_m_DeviceClass_1() { return &___m_DeviceClass_1; }
	inline void set_m_DeviceClass_1(String_t* value)
	{
		___m_DeviceClass_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DeviceClass_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_Manufacturer_2() { return static_cast<int32_t>(offsetof(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA, ___m_Manufacturer_2)); }
	inline String_t* get_m_Manufacturer_2() const { return ___m_Manufacturer_2; }
	inline String_t** get_address_of_m_Manufacturer_2() { return &___m_Manufacturer_2; }
	inline void set_m_Manufacturer_2(String_t* value)
	{
		___m_Manufacturer_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Manufacturer_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_Product_3() { return static_cast<int32_t>(offsetof(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA, ___m_Product_3)); }
	inline String_t* get_m_Product_3() const { return ___m_Product_3; }
	inline String_t** get_address_of_m_Product_3() { return &___m_Product_3; }
	inline void set_m_Product_3(String_t* value)
	{
		___m_Product_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Product_3), (void*)value);
	}

	inline static int32_t get_offset_of_m_Serial_4() { return static_cast<int32_t>(offsetof(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA, ___m_Serial_4)); }
	inline String_t* get_m_Serial_4() const { return ___m_Serial_4; }
	inline String_t** get_address_of_m_Serial_4() { return &___m_Serial_4; }
	inline void set_m_Serial_4(String_t* value)
	{
		___m_Serial_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Serial_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_Version_5() { return static_cast<int32_t>(offsetof(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA, ___m_Version_5)); }
	inline String_t* get_m_Version_5() const { return ___m_Version_5; }
	inline String_t** get_address_of_m_Version_5() { return &___m_Version_5; }
	inline void set_m_Version_5(String_t* value)
	{
		___m_Version_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Version_5), (void*)value);
	}

	inline static int32_t get_offset_of_m_Capabilities_6() { return static_cast<int32_t>(offsetof(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA, ___m_Capabilities_6)); }
	inline String_t* get_m_Capabilities_6() const { return ___m_Capabilities_6; }
	inline String_t** get_address_of_m_Capabilities_6() { return &___m_Capabilities_6; }
	inline void set_m_Capabilities_6(String_t* value)
	{
		___m_Capabilities_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Capabilities_6), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputDeviceDescription
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_pinvoke
{
	char* ___m_InterfaceName_0;
	char* ___m_DeviceClass_1;
	char* ___m_Manufacturer_2;
	char* ___m_Product_3;
	char* ___m_Serial_4;
	char* ___m_Version_5;
	char* ___m_Capabilities_6;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputDeviceDescription
struct InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_com
{
	Il2CppChar* ___m_InterfaceName_0;
	Il2CppChar* ___m_DeviceClass_1;
	Il2CppChar* ___m_Manufacturer_2;
	Il2CppChar* ___m_Product_3;
	Il2CppChar* ___m_Serial_4;
	Il2CppChar* ___m_Version_5;
	Il2CppChar* ___m_Capabilities_6;
};

// UnityEngine.InputSystem.LowLevel.InputEventPtr
struct InputEventPtr_tDF9E84E7EAFF138A0A830345C72B2CD5885577B5 
{
public:
	// UnityEngine.InputSystem.LowLevel.InputEvent* UnityEngine.InputSystem.LowLevel.InputEventPtr::m_EventPtr
	InputEvent_t729ADDE8270E3791CB953F0BB7B365B0E726CBA2 * ___m_EventPtr_0;

public:
	inline static int32_t get_offset_of_m_EventPtr_0() { return static_cast<int32_t>(offsetof(InputEventPtr_tDF9E84E7EAFF138A0A830345C72B2CD5885577B5, ___m_EventPtr_0)); }
	inline InputEvent_t729ADDE8270E3791CB953F0BB7B365B0E726CBA2 * get_m_EventPtr_0() const { return ___m_EventPtr_0; }
	inline InputEvent_t729ADDE8270E3791CB953F0BB7B365B0E726CBA2 ** get_address_of_m_EventPtr_0() { return &___m_EventPtr_0; }
	inline void set_m_EventPtr_0(InputEvent_t729ADDE8270E3791CB953F0BB7B365B0E726CBA2 * value)
	{
		___m_EventPtr_0 = value;
	}
};


// System.Int32
struct Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Int64
struct Int64_t378EE0D608BD3107E77238E85F30D2BBD46981F3 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t378EE0D608BD3107E77238E85F30D2BBD46981F3, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// UnityEngine.InputSystem.Utilities.InternedString
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.InternedString::m_StringOriginalCase
	String_t* ___m_StringOriginalCase_0;
	// System.String UnityEngine.InputSystem.Utilities.InternedString::m_StringLowerCase
	String_t* ___m_StringLowerCase_1;

public:
	inline static int32_t get_offset_of_m_StringOriginalCase_0() { return static_cast<int32_t>(offsetof(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4, ___m_StringOriginalCase_0)); }
	inline String_t* get_m_StringOriginalCase_0() const { return ___m_StringOriginalCase_0; }
	inline String_t** get_address_of_m_StringOriginalCase_0() { return &___m_StringOriginalCase_0; }
	inline void set_m_StringOriginalCase_0(String_t* value)
	{
		___m_StringOriginalCase_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_StringOriginalCase_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StringLowerCase_1() { return static_cast<int32_t>(offsetof(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4, ___m_StringLowerCase_1)); }
	inline String_t* get_m_StringLowerCase_1() const { return ___m_StringLowerCase_1; }
	inline String_t** get_address_of_m_StringLowerCase_1() { return &___m_StringLowerCase_1; }
	inline void set_m_StringLowerCase_1(String_t* value)
	{
		___m_StringLowerCase_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_StringLowerCase_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.InternedString
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke
{
	char* ___m_StringOriginalCase_0;
	char* ___m_StringLowerCase_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.InternedString
struct InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com
{
	Il2CppChar* ___m_StringOriginalCase_0;
	Il2CppChar* ___m_StringLowerCase_1;
};

// System.Single
struct Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// UnityEngine.InputSystem.Utilities.Substring
struct Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.Substring::m_String
	String_t* ___m_String_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.Substring::m_Index
	int32_t ___m_Index_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.Substring::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_String_0() { return static_cast<int32_t>(offsetof(Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815, ___m_String_0)); }
	inline String_t* get_m_String_0() const { return ___m_String_0; }
	inline String_t** get_address_of_m_String_0() { return &___m_String_0; }
	inline void set_m_String_0(String_t* value)
	{
		___m_String_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_String_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_Index_1() { return static_cast<int32_t>(offsetof(Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815, ___m_Index_1)); }
	inline int32_t get_m_Index_1() const { return ___m_Index_1; }
	inline int32_t* get_address_of_m_Index_1() { return &___m_Index_1; }
	inline void set_m_Index_1(int32_t value)
	{
		___m_Index_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.Substring
struct Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815_marshaled_pinvoke
{
	char* ___m_String_0;
	int32_t ___m_Index_1;
	int32_t ___m_Length_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.Substring
struct Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815_marshaled_com
{
	Il2CppChar* ___m_String_0;
	int32_t ___m_Index_1;
	int32_t ___m_Length_2;
};

// UnityEngine.InputSystem.EnhancedTouch.TouchHistory
struct TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D 
{
public:
	// UnityEngine.InputSystem.LowLevel.InputStateHistory`1<UnityEngine.InputSystem.LowLevel.TouchState> UnityEngine.InputSystem.EnhancedTouch.TouchHistory::m_History
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___m_History_0;
	// UnityEngine.InputSystem.EnhancedTouch.Finger UnityEngine.InputSystem.EnhancedTouch.TouchHistory::m_Finger
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___m_Finger_1;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.TouchHistory::m_Count
	int32_t ___m_Count_2;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.TouchHistory::m_StartIndex
	int32_t ___m_StartIndex_3;
	// System.UInt32 UnityEngine.InputSystem.EnhancedTouch.TouchHistory::m_Version
	uint32_t ___m_Version_4;

public:
	inline static int32_t get_offset_of_m_History_0() { return static_cast<int32_t>(offsetof(TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D, ___m_History_0)); }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * get_m_History_0() const { return ___m_History_0; }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 ** get_address_of_m_History_0() { return &___m_History_0; }
	inline void set_m_History_0(InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * value)
	{
		___m_History_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_History_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_Finger_1() { return static_cast<int32_t>(offsetof(TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D, ___m_Finger_1)); }
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * get_m_Finger_1() const { return ___m_Finger_1; }
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** get_address_of_m_Finger_1() { return &___m_Finger_1; }
	inline void set_m_Finger_1(Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * value)
	{
		___m_Finger_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Finger_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_Count_2() { return static_cast<int32_t>(offsetof(TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D, ___m_Count_2)); }
	inline int32_t get_m_Count_2() const { return ___m_Count_2; }
	inline int32_t* get_address_of_m_Count_2() { return &___m_Count_2; }
	inline void set_m_Count_2(int32_t value)
	{
		___m_Count_2 = value;
	}

	inline static int32_t get_offset_of_m_StartIndex_3() { return static_cast<int32_t>(offsetof(TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D, ___m_StartIndex_3)); }
	inline int32_t get_m_StartIndex_3() const { return ___m_StartIndex_3; }
	inline int32_t* get_address_of_m_StartIndex_3() { return &___m_StartIndex_3; }
	inline void set_m_StartIndex_3(int32_t value)
	{
		___m_StartIndex_3 = value;
	}

	inline static int32_t get_offset_of_m_Version_4() { return static_cast<int32_t>(offsetof(TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D, ___m_Version_4)); }
	inline uint32_t get_m_Version_4() const { return ___m_Version_4; }
	inline uint32_t* get_address_of_m_Version_4() { return &___m_Version_4; }
	inline void set_m_Version_4(uint32_t value)
	{
		___m_Version_4 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.EnhancedTouch.TouchHistory
struct TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D_marshaled_pinvoke
{
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___m_History_0;
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___m_Finger_1;
	int32_t ___m_Count_2;
	int32_t ___m_StartIndex_3;
	uint32_t ___m_Version_4;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.EnhancedTouch.TouchHistory
struct TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D_marshaled_com
{
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___m_History_0;
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___m_Finger_1;
	int32_t ___m_Count_2;
	int32_t ___m_StartIndex_3;
	uint32_t ___m_Version_4;
};

// System.UInt32
struct UInt32_tE60352A06233E4E69DD198BCC67142159F686B15 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};


// UnityEngine.Vector2
struct Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___zeroVector_2)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___oneVector_3)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___upVector_4)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___downVector_5)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___leftVector_6)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___rightVector_7)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___negativeInfinityVector_9 = value;
	}
};


// UnityEngine.Vector3
struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___zeroVector_5)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___oneVector_6)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___upVector_7)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___downVector_8)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___leftVector_9)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___rightVector_10)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___forwardVector_11)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___backVector_12)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___negativeInfinityVector_14 = value;
	}
};


// UnityEngine.Vector4
struct Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 
{
public:
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}

	inline static int32_t get_offset_of_w_4() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___w_4)); }
	inline float get_w_4() const { return ___w_4; }
	inline float* get_address_of_w_4() { return &___w_4; }
	inline void set_w_4(float value)
	{
		___w_4 = value;
	}
};

struct Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___negativeInfinityVector_8;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___zeroVector_5)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___oneVector_6)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_7() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___positiveInfinityVector_7)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_positiveInfinityVector_7() const { return ___positiveInfinityVector_7; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_positiveInfinityVector_7() { return &___positiveInfinityVector_7; }
	inline void set_positiveInfinityVector_7(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___positiveInfinityVector_7 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___negativeInfinityVector_8)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_negativeInfinityVector_8() const { return ___negativeInfinityVector_8; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_negativeInfinityVector_8() { return &___negativeInfinityVector_8; }
	inline void set_negativeInfinityVector_8(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___negativeInfinityVector_8 = value;
	}
};


// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5__padding[1];
	};

public:
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/Cache
struct Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2 
{
public:
	// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Layouts.InputControlLayout> UnityEngine.InputSystem.Layouts.InputControlLayout/Cache::table
	Dictionary_2_t6CE8857E6EF0C2875C715AE940B95E61532EA296 * ___table_0;

public:
	inline static int32_t get_offset_of_table_0() { return static_cast<int32_t>(offsetof(Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2, ___table_0)); }
	inline Dictionary_2_t6CE8857E6EF0C2875C715AE940B95E61532EA296 * get_table_0() const { return ___table_0; }
	inline Dictionary_2_t6CE8857E6EF0C2875C715AE940B95E61532EA296 ** get_address_of_table_0() { return &___table_0; }
	inline void set_table_0(Dictionary_2_t6CE8857E6EF0C2875C715AE940B95E61532EA296 * value)
	{
		___table_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___table_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Cache
struct Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2_marshaled_pinvoke
{
	Dictionary_2_t6CE8857E6EF0C2875C715AE940B95E61532EA296 * ___table_0;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Cache
struct Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2_marshaled_com
{
	Dictionary_2_t6CE8857E6EF0C2875C715AE940B95E61532EA296 * ___table_0;
};

// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection
struct Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31 
{
public:
	// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,System.Type> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::layoutTypes
	Dictionary_2_tF31B1670D5F3FD89062596A16A6A3F982D3AA2B3 * ___layoutTypes_1;
	// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,System.String> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::layoutStrings
	Dictionary_2_tD1780174E451F0B475D43D8321D854C2B2B07D4C * ___layoutStrings_2;
	// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,System.Func`1<UnityEngine.InputSystem.Layouts.InputControlLayout>> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::layoutBuilders
	Dictionary_2_t83E6A9593BAD78485A83686EF50657E81F026A07 * ___layoutBuilders_3;
	// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::baseLayoutTable
	Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * ___baseLayoutTable_4;
	// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString[]> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::layoutOverrides
	Dictionary_2_tC2734D476B15C1160524848A5921197DCC5AA8F6 * ___layoutOverrides_5;
	// System.Collections.Generic.HashSet`1<UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::layoutOverrideNames
	HashSet_1_t1A7C54D585AA8C377AA954087C08CA6D18F6FA01 * ___layoutOverrideNames_6;
	// System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::precompiledLayouts
	Dictionary_2_tD26AC342FBEBD317D2A4C15C5F6C03CBCBCBA2A6 * ___precompiledLayouts_7;
	// System.Collections.Generic.List`1<UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection::layoutMatchers
	List_1_tA532ACDF821E8BDDBE629683B902A55D9031A2A3 * ___layoutMatchers_8;

public:
	inline static int32_t get_offset_of_layoutTypes_1() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___layoutTypes_1)); }
	inline Dictionary_2_tF31B1670D5F3FD89062596A16A6A3F982D3AA2B3 * get_layoutTypes_1() const { return ___layoutTypes_1; }
	inline Dictionary_2_tF31B1670D5F3FD89062596A16A6A3F982D3AA2B3 ** get_address_of_layoutTypes_1() { return &___layoutTypes_1; }
	inline void set_layoutTypes_1(Dictionary_2_tF31B1670D5F3FD89062596A16A6A3F982D3AA2B3 * value)
	{
		___layoutTypes_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layoutTypes_1), (void*)value);
	}

	inline static int32_t get_offset_of_layoutStrings_2() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___layoutStrings_2)); }
	inline Dictionary_2_tD1780174E451F0B475D43D8321D854C2B2B07D4C * get_layoutStrings_2() const { return ___layoutStrings_2; }
	inline Dictionary_2_tD1780174E451F0B475D43D8321D854C2B2B07D4C ** get_address_of_layoutStrings_2() { return &___layoutStrings_2; }
	inline void set_layoutStrings_2(Dictionary_2_tD1780174E451F0B475D43D8321D854C2B2B07D4C * value)
	{
		___layoutStrings_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layoutStrings_2), (void*)value);
	}

	inline static int32_t get_offset_of_layoutBuilders_3() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___layoutBuilders_3)); }
	inline Dictionary_2_t83E6A9593BAD78485A83686EF50657E81F026A07 * get_layoutBuilders_3() const { return ___layoutBuilders_3; }
	inline Dictionary_2_t83E6A9593BAD78485A83686EF50657E81F026A07 ** get_address_of_layoutBuilders_3() { return &___layoutBuilders_3; }
	inline void set_layoutBuilders_3(Dictionary_2_t83E6A9593BAD78485A83686EF50657E81F026A07 * value)
	{
		___layoutBuilders_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layoutBuilders_3), (void*)value);
	}

	inline static int32_t get_offset_of_baseLayoutTable_4() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___baseLayoutTable_4)); }
	inline Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * get_baseLayoutTable_4() const { return ___baseLayoutTable_4; }
	inline Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B ** get_address_of_baseLayoutTable_4() { return &___baseLayoutTable_4; }
	inline void set_baseLayoutTable_4(Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * value)
	{
		___baseLayoutTable_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___baseLayoutTable_4), (void*)value);
	}

	inline static int32_t get_offset_of_layoutOverrides_5() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___layoutOverrides_5)); }
	inline Dictionary_2_tC2734D476B15C1160524848A5921197DCC5AA8F6 * get_layoutOverrides_5() const { return ___layoutOverrides_5; }
	inline Dictionary_2_tC2734D476B15C1160524848A5921197DCC5AA8F6 ** get_address_of_layoutOverrides_5() { return &___layoutOverrides_5; }
	inline void set_layoutOverrides_5(Dictionary_2_tC2734D476B15C1160524848A5921197DCC5AA8F6 * value)
	{
		___layoutOverrides_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layoutOverrides_5), (void*)value);
	}

	inline static int32_t get_offset_of_layoutOverrideNames_6() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___layoutOverrideNames_6)); }
	inline HashSet_1_t1A7C54D585AA8C377AA954087C08CA6D18F6FA01 * get_layoutOverrideNames_6() const { return ___layoutOverrideNames_6; }
	inline HashSet_1_t1A7C54D585AA8C377AA954087C08CA6D18F6FA01 ** get_address_of_layoutOverrideNames_6() { return &___layoutOverrideNames_6; }
	inline void set_layoutOverrideNames_6(HashSet_1_t1A7C54D585AA8C377AA954087C08CA6D18F6FA01 * value)
	{
		___layoutOverrideNames_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layoutOverrideNames_6), (void*)value);
	}

	inline static int32_t get_offset_of_precompiledLayouts_7() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___precompiledLayouts_7)); }
	inline Dictionary_2_tD26AC342FBEBD317D2A4C15C5F6C03CBCBCBA2A6 * get_precompiledLayouts_7() const { return ___precompiledLayouts_7; }
	inline Dictionary_2_tD26AC342FBEBD317D2A4C15C5F6C03CBCBCBA2A6 ** get_address_of_precompiledLayouts_7() { return &___precompiledLayouts_7; }
	inline void set_precompiledLayouts_7(Dictionary_2_tD26AC342FBEBD317D2A4C15C5F6C03CBCBCBA2A6 * value)
	{
		___precompiledLayouts_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___precompiledLayouts_7), (void*)value);
	}

	inline static int32_t get_offset_of_layoutMatchers_8() { return static_cast<int32_t>(offsetof(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31, ___layoutMatchers_8)); }
	inline List_1_tA532ACDF821E8BDDBE629683B902A55D9031A2A3 * get_layoutMatchers_8() const { return ___layoutMatchers_8; }
	inline List_1_tA532ACDF821E8BDDBE629683B902A55D9031A2A3 ** get_address_of_layoutMatchers_8() { return &___layoutMatchers_8; }
	inline void set_layoutMatchers_8(List_1_tA532ACDF821E8BDDBE629683B902A55D9031A2A3 * value)
	{
		___layoutMatchers_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layoutMatchers_8), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Collection
struct Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31_marshaled_pinvoke
{
	Dictionary_2_tF31B1670D5F3FD89062596A16A6A3F982D3AA2B3 * ___layoutTypes_1;
	Dictionary_2_tD1780174E451F0B475D43D8321D854C2B2B07D4C * ___layoutStrings_2;
	Dictionary_2_t83E6A9593BAD78485A83686EF50657E81F026A07 * ___layoutBuilders_3;
	Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * ___baseLayoutTable_4;
	Dictionary_2_tC2734D476B15C1160524848A5921197DCC5AA8F6 * ___layoutOverrides_5;
	HashSet_1_t1A7C54D585AA8C377AA954087C08CA6D18F6FA01 * ___layoutOverrideNames_6;
	Dictionary_2_tD26AC342FBEBD317D2A4C15C5F6C03CBCBCBA2A6 * ___precompiledLayouts_7;
	List_1_tA532ACDF821E8BDDBE629683B902A55D9031A2A3 * ___layoutMatchers_8;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Collection
struct Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31_marshaled_com
{
	Dictionary_2_tF31B1670D5F3FD89062596A16A6A3F982D3AA2B3 * ___layoutTypes_1;
	Dictionary_2_tD1780174E451F0B475D43D8321D854C2B2B07D4C * ___layoutStrings_2;
	Dictionary_2_t83E6A9593BAD78485A83686EF50657E81F026A07 * ___layoutBuilders_3;
	Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * ___baseLayoutTable_4;
	Dictionary_2_tC2734D476B15C1160524848A5921197DCC5AA8F6 * ___layoutOverrides_5;
	HashSet_1_t1A7C54D585AA8C377AA954087C08CA6D18F6FA01 * ___layoutOverrideNames_6;
	Dictionary_2_tD26AC342FBEBD317D2A4C15C5F6C03CBCBCBA2A6 * ___precompiledLayouts_7;
	List_1_tA532ACDF821E8BDDBE629683B902A55D9031A2A3 * ___layoutMatchers_8;
};

// UnityEngine.InputSystem.LowLevel.InputUpdate/UpdateStepCount
struct UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98 
{
public:
	// System.Boolean UnityEngine.InputSystem.LowLevel.InputUpdate/UpdateStepCount::m_WasUpdated
	bool ___m_WasUpdated_0;
	// System.UInt32 UnityEngine.InputSystem.LowLevel.InputUpdate/UpdateStepCount::<value>k__BackingField
	uint32_t ___U3CvalueU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_m_WasUpdated_0() { return static_cast<int32_t>(offsetof(UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98, ___m_WasUpdated_0)); }
	inline bool get_m_WasUpdated_0() const { return ___m_WasUpdated_0; }
	inline bool* get_address_of_m_WasUpdated_0() { return &___m_WasUpdated_0; }
	inline void set_m_WasUpdated_0(bool value)
	{
		___m_WasUpdated_0 = value;
	}

	inline static int32_t get_offset_of_U3CvalueU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98, ___U3CvalueU3Ek__BackingField_1)); }
	inline uint32_t get_U3CvalueU3Ek__BackingField_1() const { return ___U3CvalueU3Ek__BackingField_1; }
	inline uint32_t* get_address_of_U3CvalueU3Ek__BackingField_1() { return &___U3CvalueU3Ek__BackingField_1; }
	inline void set_U3CvalueU3Ek__BackingField_1(uint32_t value)
	{
		___U3CvalueU3Ek__BackingField_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.LowLevel.InputUpdate/UpdateStepCount
struct UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98_marshaled_pinvoke
{
	int32_t ___m_WasUpdated_0;
	uint32_t ___U3CvalueU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.LowLevel.InputUpdate/UpdateStepCount
struct UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98_marshaled_com
{
	int32_t ___m_WasUpdated_0;
	uint32_t ___U3CvalueU3Ek__BackingField_1;
};

// UnityEngine.InputSystem.LowLevel.QueryKeyNameCommand/<nameBuffer>e__FixedBuffer
struct U3CnameBufferU3Ee__FixedBuffer_tD0C437386CC316974B8F10958E354F9A16933337 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.QueryKeyNameCommand/<nameBuffer>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CnameBufferU3Ee__FixedBuffer_tD0C437386CC316974B8F10958E354F9A16933337__padding[256];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CnameBufferU3Ee__FixedBuffer_tD0C437386CC316974B8F10958E354F9A16933337, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.QueryKeyboardLayoutCommand/<nameBuffer>e__FixedBuffer
struct U3CnameBufferU3Ee__FixedBuffer_t3665DFBAB11CC2C7B13AFE98555658A6DBA897B1 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.QueryKeyboardLayoutCommand/<nameBuffer>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CnameBufferU3Ee__FixedBuffer_t3665DFBAB11CC2C7B13AFE98555658A6DBA897B1__padding[256];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CnameBufferU3Ee__FixedBuffer_t3665DFBAB11CC2C7B13AFE98555658A6DBA897B1, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.QueryPairedUserAccountCommand/<idBuffer>e__FixedBuffer
struct U3CidBufferU3Ee__FixedBuffer_tA564139C32CB5C2D4D0A79C1811D4CDF94CD42E6 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.QueryPairedUserAccountCommand/<idBuffer>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CidBufferU3Ee__FixedBuffer_tA564139C32CB5C2D4D0A79C1811D4CDF94CD42E6__padding[512];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CidBufferU3Ee__FixedBuffer_tA564139C32CB5C2D4D0A79C1811D4CDF94CD42E6, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.QueryPairedUserAccountCommand/<nameBuffer>e__FixedBuffer
struct U3CnameBufferU3Ee__FixedBuffer_t00C333740CDB558E46C8B7870B9A3A7147B0D813 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.QueryPairedUserAccountCommand/<nameBuffer>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CnameBufferU3Ee__FixedBuffer_t00C333740CDB558E46C8B7870B9A3A7147B0D813__padding[512];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CnameBufferU3Ee__FixedBuffer_t00C333740CDB558E46C8B7870B9A3A7147B0D813, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.QueryUserIdCommand/<idBuffer>e__FixedBuffer
struct U3CidBufferU3Ee__FixedBuffer_t19DF6E13240CA248E9495CAB46BD777CE0B7FF32 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.QueryUserIdCommand/<idBuffer>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CidBufferU3Ee__FixedBuffer_t19DF6E13240CA248E9495CAB46BD777CE0B7FF32__padding[512];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CidBufferU3Ee__FixedBuffer_t19DF6E13240CA248E9495CAB46BD777CE0B7FF32, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.XR.Haptics.SendBufferedHapticCommand/<buffer>e__FixedBuffer
struct U3CbufferU3Ee__FixedBuffer_t06DB1F17CA54C59F47CD983576CE731498ED73F7 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.XR.Haptics.SendBufferedHapticCommand/<buffer>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CbufferU3Ee__FixedBuffer_t06DB1F17CA54C59F47CD983576CE731498ED73F7__padding[1024];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CbufferU3Ee__FixedBuffer_t06DB1F17CA54C59F47CD983576CE731498ED73F7, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.StateEvent/<stateData>e__FixedBuffer
struct U3CstateDataU3Ee__FixedBuffer_t0C1082DDCD4C641A8E8703AF7C58B8B685CD1FE8 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.StateEvent/<stateData>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CstateDataU3Ee__FixedBuffer_t0C1082DDCD4C641A8E8703AF7C58B8B685CD1FE8__padding[1];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CstateDataU3Ee__FixedBuffer_t0C1082DDCD4C641A8E8703AF7C58B8B685CD1FE8, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.TouchscreenState/<primaryTouchData>e__FixedBuffer
struct U3CprimaryTouchDataU3Ee__FixedBuffer_t21DA98D2B75AD2DFBAB25B7220868BCB45416029 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.TouchscreenState/<primaryTouchData>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CprimaryTouchDataU3Ee__FixedBuffer_t21DA98D2B75AD2DFBAB25B7220868BCB45416029__padding[56];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CprimaryTouchDataU3Ee__FixedBuffer_t21DA98D2B75AD2DFBAB25B7220868BCB45416029, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.TouchscreenState/<touchData>e__FixedBuffer
struct U3CtouchDataU3Ee__FixedBuffer_tE6D80B909B765994B9EC0D5AFC75A1A1AF21BAC2 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.TouchscreenState/<touchData>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CtouchDataU3Ee__FixedBuffer_tE6D80B909B765994B9EC0D5AFC75A1A1AF21BAC2__padding[560];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CtouchDataU3Ee__FixedBuffer_tE6D80B909B765994B9EC0D5AFC75A1A1AF21BAC2, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder
struct ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 
{
public:
	// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::builder
	Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * ___builder_0;
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::index
	int32_t ___index_1;

public:
	inline static int32_t get_offset_of_builder_0() { return static_cast<int32_t>(offsetof(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37, ___builder_0)); }
	inline Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * get_builder_0() const { return ___builder_0; }
	inline Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E ** get_address_of_builder_0() { return &___builder_0; }
	inline void set_builder_0(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * value)
	{
		___builder_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___builder_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder
struct ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_pinvoke
{
	Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * ___builder_0;
	int32_t ___index_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder
struct ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_com
{
	Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * ___builder_0;
	int32_t ___index_1;
};

// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout
struct PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1 
{
public:
	// System.Func`1<UnityEngine.InputSystem.InputDevice> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout::factoryMethod
	Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548 * ___factoryMethod_0;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout::metadata
	String_t* ___metadata_1;

public:
	inline static int32_t get_offset_of_factoryMethod_0() { return static_cast<int32_t>(offsetof(PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1, ___factoryMethod_0)); }
	inline Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548 * get_factoryMethod_0() const { return ___factoryMethod_0; }
	inline Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548 ** get_address_of_factoryMethod_0() { return &___factoryMethod_0; }
	inline void set_factoryMethod_0(Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548 * value)
	{
		___factoryMethod_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___factoryMethod_0), (void*)value);
	}

	inline static int32_t get_offset_of_metadata_1() { return static_cast<int32_t>(offsetof(PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1, ___metadata_1)); }
	inline String_t* get_metadata_1() const { return ___metadata_1; }
	inline String_t** get_address_of_metadata_1() { return &___metadata_1; }
	inline void set_metadata_1(String_t* value)
	{
		___metadata_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___metadata_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout
struct PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_pinvoke
{
	Il2CppMethodPointer ___factoryMethod_0;
	char* ___metadata_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout
struct PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_com
{
	Il2CppMethodPointer ___factoryMethod_0;
	Il2CppChar* ___metadata_1;
};

// UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson
struct DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB 
{
public:
	// System.String UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson::devicePath
	String_t* ___devicePath_0;
	// System.Boolean UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson::isOptional
	bool ___isOptional_1;
	// System.Boolean UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson::isOR
	bool ___isOR_2;

public:
	inline static int32_t get_offset_of_devicePath_0() { return static_cast<int32_t>(offsetof(DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB, ___devicePath_0)); }
	inline String_t* get_devicePath_0() const { return ___devicePath_0; }
	inline String_t** get_address_of_devicePath_0() { return &___devicePath_0; }
	inline void set_devicePath_0(String_t* value)
	{
		___devicePath_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___devicePath_0), (void*)value);
	}

	inline static int32_t get_offset_of_isOptional_1() { return static_cast<int32_t>(offsetof(DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB, ___isOptional_1)); }
	inline bool get_isOptional_1() const { return ___isOptional_1; }
	inline bool* get_address_of_isOptional_1() { return &___isOptional_1; }
	inline void set_isOptional_1(bool value)
	{
		___isOptional_1 = value;
	}

	inline static int32_t get_offset_of_isOR_2() { return static_cast<int32_t>(offsetof(DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB, ___isOR_2)); }
	inline bool get_isOR_2() const { return ___isOR_2; }
	inline bool* get_address_of_isOR_2() { return &___isOR_2; }
	inline void set_isOR_2(bool value)
	{
		___isOR_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson
struct DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_pinvoke
{
	char* ___devicePath_0;
	int32_t ___isOptional_1;
	int32_t ___isOR_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson
struct DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_com
{
	Il2CppChar* ___devicePath_0;
	int32_t ___isOptional_1;
	int32_t ___isOR_2;
};

// UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability
struct Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0 
{
public:
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability::path
	String_t* ___path_0;
	// System.String UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability::value
	String_t* ___value_1;

public:
	inline static int32_t get_offset_of_path_0() { return static_cast<int32_t>(offsetof(Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0, ___path_0)); }
	inline String_t* get_path_0() const { return ___path_0; }
	inline String_t** get_address_of_path_0() { return &___path_0; }
	inline void set_path_0(String_t* value)
	{
		___path_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___path_0), (void*)value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0, ___value_1)); }
	inline String_t* get_value_1() const { return ___value_1; }
	inline String_t** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(String_t* value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___value_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability
struct Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_pinvoke
{
	char* ___path_0;
	char* ___value_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability
struct Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_com
{
	Il2CppChar* ___path_0;
	Il2CppChar* ___value_1;
};

// UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data
struct Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data::deviceId
	int32_t ___deviceId_0;
	// System.String[] UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data::usages
	StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* ___usages_1;

public:
	inline static int32_t get_offset_of_deviceId_0() { return static_cast<int32_t>(offsetof(Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501, ___deviceId_0)); }
	inline int32_t get_deviceId_0() const { return ___deviceId_0; }
	inline int32_t* get_address_of_deviceId_0() { return &___deviceId_0; }
	inline void set_deviceId_0(int32_t value)
	{
		___deviceId_0 = value;
	}

	inline static int32_t get_offset_of_usages_1() { return static_cast<int32_t>(offsetof(Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501, ___usages_1)); }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* get_usages_1() const { return ___usages_1; }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A** get_address_of_usages_1() { return &___usages_1; }
	inline void set_usages_1(StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* value)
	{
		___usages_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___usages_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data
struct Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_pinvoke
{
	int32_t ___deviceId_0;
	char** ___usages_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data
struct Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_com
{
	int32_t ___deviceId_0;
	Il2CppChar** ___usages_1;
};

// UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data
struct Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C 
{
public:
	// System.String UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data::name
	String_t* ___name_0;
	// System.String UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data::layoutJson
	String_t* ___layoutJson_1;
	// System.Boolean UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data::isOverride
	bool ___isOverride_2;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___name_0), (void*)value);
	}

	inline static int32_t get_offset_of_layoutJson_1() { return static_cast<int32_t>(offsetof(Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C, ___layoutJson_1)); }
	inline String_t* get_layoutJson_1() const { return ___layoutJson_1; }
	inline String_t** get_address_of_layoutJson_1() { return &___layoutJson_1; }
	inline void set_layoutJson_1(String_t* value)
	{
		___layoutJson_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layoutJson_1), (void*)value);
	}

	inline static int32_t get_offset_of_isOverride_2() { return static_cast<int32_t>(offsetof(Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C, ___isOverride_2)); }
	inline bool get_isOverride_2() const { return ___isOverride_2; }
	inline bool* get_address_of_isOverride_2() { return &___isOverride_2; }
	inline void set_isOverride_2(bool value)
	{
		___isOverride_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data
struct Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_pinvoke
{
	char* ___name_0;
	char* ___layoutJson_1;
	int32_t ___isOverride_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data
struct Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_com
{
	Il2CppChar* ___name_0;
	Il2CppChar* ___layoutJson_1;
	int32_t ___isOverride_2;
};

// UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader/<m_StateWithControlIndex>e__FixedBuffer
struct U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader/<m_StateWithControlIndex>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6__padding[1];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader/<m_StateWithoutControlIndex>e__FixedBuffer
struct U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader/<m_StateWithoutControlIndex>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC__padding[1];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.InputSystem/DeltaStateEventBuffer/<data>e__FixedBuffer
struct U3CdataU3Ee__FixedBuffer_t2C576E7A9C44722893A1B090201C1A7BA11DF737 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.InputSystem/DeltaStateEventBuffer/<data>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CdataU3Ee__FixedBuffer_t2C576E7A9C44722893A1B090201C1A7BA11DF737__padding[511];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CdataU3Ee__FixedBuffer_t2C576E7A9C44722893A1B090201C1A7BA11DF737, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.InputSystem/StateEventBuffer/<data>e__FixedBuffer
struct U3CdataU3Ee__FixedBuffer_t2946EC4FF661C25DCA3672CA9F997BC235444D64 
{
public:
	union
	{
		struct
		{
			// System.Byte UnityEngine.InputSystem.InputSystem/StateEventBuffer/<data>e__FixedBuffer::FixedElementField
			uint8_t ___FixedElementField_0;
		};
		uint8_t U3CdataU3Ee__FixedBuffer_t2946EC4FF661C25DCA3672CA9F997BC235444D64__padding[511];
	};

public:
	inline static int32_t get_offset_of_FixedElementField_0() { return static_cast<int32_t>(offsetof(U3CdataU3Ee__FixedBuffer_t2946EC4FF661C25DCA3672CA9F997BC235444D64, ___FixedElementField_0)); }
	inline uint8_t get_FixedElementField_0() const { return ___FixedElementField_0; }
	inline uint8_t* get_address_of_FixedElementField_0() { return &___FixedElementField_0; }
	inline void set_FixedElementField_0(uint8_t value)
	{
		___FixedElementField_0 = value;
	}
};


// UnityEngine.InputSystem.Utilities.CallbackArray`1<System.Action`1<UnityEngine.InputSystem.EnhancedTouch.Finger>>
struct CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F 
{
public:
	// System.Boolean UnityEngine.InputSystem.Utilities.CallbackArray`1::m_CannotMutateCallbacksArray
	bool ___m_CannotMutateCallbacksArray_0;
	// UnityEngine.InputSystem.Utilities.InlinedArray`1<TDelegate> UnityEngine.InputSystem.Utilities.CallbackArray`1::m_Callbacks
	InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  ___m_Callbacks_1;
	// UnityEngine.InputSystem.Utilities.InlinedArray`1<TDelegate> UnityEngine.InputSystem.Utilities.CallbackArray`1::m_CallbacksToAdd
	InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  ___m_CallbacksToAdd_2;
	// UnityEngine.InputSystem.Utilities.InlinedArray`1<TDelegate> UnityEngine.InputSystem.Utilities.CallbackArray`1::m_CallbacksToRemove
	InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  ___m_CallbacksToRemove_3;

public:
	inline static int32_t get_offset_of_m_CannotMutateCallbacksArray_0() { return static_cast<int32_t>(offsetof(CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F, ___m_CannotMutateCallbacksArray_0)); }
	inline bool get_m_CannotMutateCallbacksArray_0() const { return ___m_CannotMutateCallbacksArray_0; }
	inline bool* get_address_of_m_CannotMutateCallbacksArray_0() { return &___m_CannotMutateCallbacksArray_0; }
	inline void set_m_CannotMutateCallbacksArray_0(bool value)
	{
		___m_CannotMutateCallbacksArray_0 = value;
	}

	inline static int32_t get_offset_of_m_Callbacks_1() { return static_cast<int32_t>(offsetof(CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F, ___m_Callbacks_1)); }
	inline InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  get_m_Callbacks_1() const { return ___m_Callbacks_1; }
	inline InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A * get_address_of_m_Callbacks_1() { return &___m_Callbacks_1; }
	inline void set_m_Callbacks_1(InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  value)
	{
		___m_Callbacks_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Callbacks_1))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Callbacks_1))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_CallbacksToAdd_2() { return static_cast<int32_t>(offsetof(CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F, ___m_CallbacksToAdd_2)); }
	inline InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  get_m_CallbacksToAdd_2() const { return ___m_CallbacksToAdd_2; }
	inline InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A * get_address_of_m_CallbacksToAdd_2() { return &___m_CallbacksToAdd_2; }
	inline void set_m_CallbacksToAdd_2(InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  value)
	{
		___m_CallbacksToAdd_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_CallbacksToAdd_2))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_CallbacksToAdd_2))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_CallbacksToRemove_3() { return static_cast<int32_t>(offsetof(CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F, ___m_CallbacksToRemove_3)); }
	inline InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  get_m_CallbacksToRemove_3() const { return ___m_CallbacksToRemove_3; }
	inline InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A * get_address_of_m_CallbacksToRemove_3() { return &___m_CallbacksToRemove_3; }
	inline void set_m_CallbacksToRemove_3(InlinedArray_1_t278861AE8AC0BDDACACEC3517ABA4FC7F534247A  value)
	{
		___m_CallbacksToRemove_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_CallbacksToRemove_3))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_CallbacksToRemove_3))->___additionalValues_2), (void*)NULL);
		#endif
	}
};


// UnityEngine.InputSystem.Utilities.InlinedArray`1<UnityEngine.InputSystem.Utilities.InternedString>
struct InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287 
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.InlinedArray`1::length
	int32_t ___length_0;
	// TValue UnityEngine.InputSystem.Utilities.InlinedArray`1::firstValue
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___firstValue_1;
	// TValue[] UnityEngine.InputSystem.Utilities.InlinedArray`1::additionalValues
	InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___additionalValues_2;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_firstValue_1() { return static_cast<int32_t>(offsetof(InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287, ___firstValue_1)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_firstValue_1() const { return ___firstValue_1; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_firstValue_1() { return &___firstValue_1; }
	inline void set_firstValue_1(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___firstValue_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___firstValue_1))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___firstValue_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_additionalValues_2() { return static_cast<int32_t>(offsetof(InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287, ___additionalValues_2)); }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* get_additionalValues_2() const { return ___additionalValues_2; }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11** get_address_of_additionalValues_2() { return &___additionalValues_2; }
	inline void set_additionalValues_2(InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* value)
	{
		___additionalValues_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___additionalValues_2), (void*)value);
	}
};


// Unity.Collections.Allocator
struct Allocator_t9888223DEF4F46F3419ECFCCD0753599BEE52A05 
{
public:
	// System.Int32 Unity.Collections.Allocator::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Allocator_t9888223DEF4F46F3419ECFCCD0753599BEE52A05, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Delegate
struct Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_target_2), (void*)value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_info_7), (void*)value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___original_method_info_8), (void*)value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * get_data_9() const { return ___data_9; }
	inline DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___data_9), (void*)value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	int32_t ___method_is_virtual_10;
};

// System.Exception
struct Exception_t  : public RuntimeObject
{
public:
	// System.String System.Exception::_className
	String_t* ____className_1;
	// System.String System.Exception::_message
	String_t* ____message_2;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_3;
	// System.Exception System.Exception::_innerException
	Exception_t * ____innerException_4;
	// System.String System.Exception::_helpURL
	String_t* ____helpURL_5;
	// System.Object System.Exception::_stackTrace
	RuntimeObject * ____stackTrace_6;
	// System.String System.Exception::_stackTraceString
	String_t* ____stackTraceString_7;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_8;
	// System.Int32 System.Exception::_remoteStackIndex
	int32_t ____remoteStackIndex_9;
	// System.Object System.Exception::_dynamicMethods
	RuntimeObject * ____dynamicMethods_10;
	// System.Int32 System.Exception::_HResult
	int32_t ____HResult_11;
	// System.String System.Exception::_source
	String_t* ____source_12;
	// System.Runtime.Serialization.SafeSerializationManager System.Exception::_safeSerializationManager
	SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * ____safeSerializationManager_13;
	// System.Diagnostics.StackTrace[] System.Exception::captured_traces
	StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* ___captured_traces_14;
	// System.IntPtr[] System.Exception::native_trace_ips
	IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6* ___native_trace_ips_15;

public:
	inline static int32_t get_offset_of__className_1() { return static_cast<int32_t>(offsetof(Exception_t, ____className_1)); }
	inline String_t* get__className_1() const { return ____className_1; }
	inline String_t** get_address_of__className_1() { return &____className_1; }
	inline void set__className_1(String_t* value)
	{
		____className_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____className_1), (void*)value);
	}

	inline static int32_t get_offset_of__message_2() { return static_cast<int32_t>(offsetof(Exception_t, ____message_2)); }
	inline String_t* get__message_2() const { return ____message_2; }
	inline String_t** get_address_of__message_2() { return &____message_2; }
	inline void set__message_2(String_t* value)
	{
		____message_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____message_2), (void*)value);
	}

	inline static int32_t get_offset_of__data_3() { return static_cast<int32_t>(offsetof(Exception_t, ____data_3)); }
	inline RuntimeObject* get__data_3() const { return ____data_3; }
	inline RuntimeObject** get_address_of__data_3() { return &____data_3; }
	inline void set__data_3(RuntimeObject* value)
	{
		____data_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____data_3), (void*)value);
	}

	inline static int32_t get_offset_of__innerException_4() { return static_cast<int32_t>(offsetof(Exception_t, ____innerException_4)); }
	inline Exception_t * get__innerException_4() const { return ____innerException_4; }
	inline Exception_t ** get_address_of__innerException_4() { return &____innerException_4; }
	inline void set__innerException_4(Exception_t * value)
	{
		____innerException_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____innerException_4), (void*)value);
	}

	inline static int32_t get_offset_of__helpURL_5() { return static_cast<int32_t>(offsetof(Exception_t, ____helpURL_5)); }
	inline String_t* get__helpURL_5() const { return ____helpURL_5; }
	inline String_t** get_address_of__helpURL_5() { return &____helpURL_5; }
	inline void set__helpURL_5(String_t* value)
	{
		____helpURL_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____helpURL_5), (void*)value);
	}

	inline static int32_t get_offset_of__stackTrace_6() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTrace_6)); }
	inline RuntimeObject * get__stackTrace_6() const { return ____stackTrace_6; }
	inline RuntimeObject ** get_address_of__stackTrace_6() { return &____stackTrace_6; }
	inline void set__stackTrace_6(RuntimeObject * value)
	{
		____stackTrace_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____stackTrace_6), (void*)value);
	}

	inline static int32_t get_offset_of__stackTraceString_7() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTraceString_7)); }
	inline String_t* get__stackTraceString_7() const { return ____stackTraceString_7; }
	inline String_t** get_address_of__stackTraceString_7() { return &____stackTraceString_7; }
	inline void set__stackTraceString_7(String_t* value)
	{
		____stackTraceString_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____stackTraceString_7), (void*)value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_8() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_8)); }
	inline String_t* get__remoteStackTraceString_8() const { return ____remoteStackTraceString_8; }
	inline String_t** get_address_of__remoteStackTraceString_8() { return &____remoteStackTraceString_8; }
	inline void set__remoteStackTraceString_8(String_t* value)
	{
		____remoteStackTraceString_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____remoteStackTraceString_8), (void*)value);
	}

	inline static int32_t get_offset_of__remoteStackIndex_9() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackIndex_9)); }
	inline int32_t get__remoteStackIndex_9() const { return ____remoteStackIndex_9; }
	inline int32_t* get_address_of__remoteStackIndex_9() { return &____remoteStackIndex_9; }
	inline void set__remoteStackIndex_9(int32_t value)
	{
		____remoteStackIndex_9 = value;
	}

	inline static int32_t get_offset_of__dynamicMethods_10() { return static_cast<int32_t>(offsetof(Exception_t, ____dynamicMethods_10)); }
	inline RuntimeObject * get__dynamicMethods_10() const { return ____dynamicMethods_10; }
	inline RuntimeObject ** get_address_of__dynamicMethods_10() { return &____dynamicMethods_10; }
	inline void set__dynamicMethods_10(RuntimeObject * value)
	{
		____dynamicMethods_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____dynamicMethods_10), (void*)value);
	}

	inline static int32_t get_offset_of__HResult_11() { return static_cast<int32_t>(offsetof(Exception_t, ____HResult_11)); }
	inline int32_t get__HResult_11() const { return ____HResult_11; }
	inline int32_t* get_address_of__HResult_11() { return &____HResult_11; }
	inline void set__HResult_11(int32_t value)
	{
		____HResult_11 = value;
	}

	inline static int32_t get_offset_of__source_12() { return static_cast<int32_t>(offsetof(Exception_t, ____source_12)); }
	inline String_t* get__source_12() const { return ____source_12; }
	inline String_t** get_address_of__source_12() { return &____source_12; }
	inline void set__source_12(String_t* value)
	{
		____source_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____source_12), (void*)value);
	}

	inline static int32_t get_offset_of__safeSerializationManager_13() { return static_cast<int32_t>(offsetof(Exception_t, ____safeSerializationManager_13)); }
	inline SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * get__safeSerializationManager_13() const { return ____safeSerializationManager_13; }
	inline SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F ** get_address_of__safeSerializationManager_13() { return &____safeSerializationManager_13; }
	inline void set__safeSerializationManager_13(SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * value)
	{
		____safeSerializationManager_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____safeSerializationManager_13), (void*)value);
	}

	inline static int32_t get_offset_of_captured_traces_14() { return static_cast<int32_t>(offsetof(Exception_t, ___captured_traces_14)); }
	inline StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* get_captured_traces_14() const { return ___captured_traces_14; }
	inline StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971** get_address_of_captured_traces_14() { return &___captured_traces_14; }
	inline void set_captured_traces_14(StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* value)
	{
		___captured_traces_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___captured_traces_14), (void*)value);
	}

	inline static int32_t get_offset_of_native_trace_ips_15() { return static_cast<int32_t>(offsetof(Exception_t, ___native_trace_ips_15)); }
	inline IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6* get_native_trace_ips_15() const { return ___native_trace_ips_15; }
	inline IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6** get_address_of_native_trace_ips_15() { return &___native_trace_ips_15; }
	inline void set_native_trace_ips_15(IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6* value)
	{
		___native_trace_ips_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___native_trace_ips_15), (void*)value);
	}
};

struct Exception_t_StaticFields
{
public:
	// System.Object System.Exception::s_EDILock
	RuntimeObject * ___s_EDILock_0;

public:
	inline static int32_t get_offset_of_s_EDILock_0() { return static_cast<int32_t>(offsetof(Exception_t_StaticFields, ___s_EDILock_0)); }
	inline RuntimeObject * get_s_EDILock_0() const { return ___s_EDILock_0; }
	inline RuntimeObject ** get_address_of_s_EDILock_0() { return &___s_EDILock_0; }
	inline void set_s_EDILock_0(RuntimeObject * value)
	{
		___s_EDILock_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_EDILock_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Exception
struct Exception_t_marshaled_pinvoke
{
	char* ____className_1;
	char* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_pinvoke* ____innerException_4;
	char* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	char* ____stackTraceString_7;
	char* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	char* ____source_12;
	SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * ____safeSerializationManager_13;
	StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
};
// Native definition for COM marshalling of System.Exception
struct Exception_t_marshaled_com
{
	Il2CppChar* ____className_1;
	Il2CppChar* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_com* ____innerException_4;
	Il2CppChar* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	Il2CppChar* ____stackTraceString_7;
	Il2CppChar* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	Il2CppChar* ____source_12;
	SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * ____safeSerializationManager_13;
	StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
};

// UnityEngine.InputSystem.Layouts.InputDeviceMatcher
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D 
{
public:
	// System.Collections.Generic.KeyValuePair`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>[] UnityEngine.InputSystem.Layouts.InputDeviceMatcher::m_Patterns
	KeyValuePair_2U5BU5D_t8BAE944D06577C053998DBBC1FF7E54D1D5A2B86* ___m_Patterns_0;

public:
	inline static int32_t get_offset_of_m_Patterns_0() { return static_cast<int32_t>(offsetof(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D, ___m_Patterns_0)); }
	inline KeyValuePair_2U5BU5D_t8BAE944D06577C053998DBBC1FF7E54D1D5A2B86* get_m_Patterns_0() const { return ___m_Patterns_0; }
	inline KeyValuePair_2U5BU5D_t8BAE944D06577C053998DBBC1FF7E54D1D5A2B86** get_address_of_m_Patterns_0() { return &___m_Patterns_0; }
	inline void set_m_Patterns_0(KeyValuePair_2U5BU5D_t8BAE944D06577C053998DBBC1FF7E54D1D5A2B86* value)
	{
		___m_Patterns_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Patterns_0), (void*)value);
	}
};

struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_StaticFields
{
public:
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputDeviceMatcher::kInterfaceKey
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___kInterfaceKey_1;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputDeviceMatcher::kDeviceClassKey
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___kDeviceClassKey_2;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputDeviceMatcher::kManufacturerKey
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___kManufacturerKey_3;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputDeviceMatcher::kProductKey
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___kProductKey_4;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputDeviceMatcher::kVersionKey
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___kVersionKey_5;

public:
	inline static int32_t get_offset_of_kInterfaceKey_1() { return static_cast<int32_t>(offsetof(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_StaticFields, ___kInterfaceKey_1)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_kInterfaceKey_1() const { return ___kInterfaceKey_1; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_kInterfaceKey_1() { return &___kInterfaceKey_1; }
	inline void set_kInterfaceKey_1(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___kInterfaceKey_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___kInterfaceKey_1))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___kInterfaceKey_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_kDeviceClassKey_2() { return static_cast<int32_t>(offsetof(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_StaticFields, ___kDeviceClassKey_2)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_kDeviceClassKey_2() const { return ___kDeviceClassKey_2; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_kDeviceClassKey_2() { return &___kDeviceClassKey_2; }
	inline void set_kDeviceClassKey_2(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___kDeviceClassKey_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___kDeviceClassKey_2))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___kDeviceClassKey_2))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_kManufacturerKey_3() { return static_cast<int32_t>(offsetof(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_StaticFields, ___kManufacturerKey_3)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_kManufacturerKey_3() const { return ___kManufacturerKey_3; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_kManufacturerKey_3() { return &___kManufacturerKey_3; }
	inline void set_kManufacturerKey_3(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___kManufacturerKey_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___kManufacturerKey_3))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___kManufacturerKey_3))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_kProductKey_4() { return static_cast<int32_t>(offsetof(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_StaticFields, ___kProductKey_4)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_kProductKey_4() const { return ___kProductKey_4; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_kProductKey_4() { return &___kProductKey_4; }
	inline void set_kProductKey_4(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___kProductKey_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___kProductKey_4))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___kProductKey_4))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_kVersionKey_5() { return static_cast<int32_t>(offsetof(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_StaticFields, ___kVersionKey_5)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_kVersionKey_5() const { return ___kVersionKey_5; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_kVersionKey_5() { return &___kVersionKey_5; }
	inline void set_kVersionKey_5(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___kVersionKey_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___kVersionKey_5))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___kVersionKey_5))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputDeviceMatcher
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_pinvoke
{
	KeyValuePair_2_t9217F6CF4678FF5176B3DA3A0671CFA8795CFA5B * ___m_Patterns_0;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputDeviceMatcher
struct InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_com
{
	KeyValuePair_2_t9217F6CF4678FF5176B3DA3A0671CFA8795CFA5B * ___m_Patterns_0;
};

// UnityEngine.InputSystem.LowLevel.InputStateBlock
struct InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C 
{
public:
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::<format>k__BackingField
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___U3CformatU3Ek__BackingField_33;
	// System.UInt32 UnityEngine.InputSystem.LowLevel.InputStateBlock::<byteOffset>k__BackingField
	uint32_t ___U3CbyteOffsetU3Ek__BackingField_34;
	// System.UInt32 UnityEngine.InputSystem.LowLevel.InputStateBlock::<bitOffset>k__BackingField
	uint32_t ___U3CbitOffsetU3Ek__BackingField_35;
	// System.UInt32 UnityEngine.InputSystem.LowLevel.InputStateBlock::<sizeInBits>k__BackingField
	uint32_t ___U3CsizeInBitsU3Ek__BackingField_36;

public:
	inline static int32_t get_offset_of_U3CformatU3Ek__BackingField_33() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C, ___U3CformatU3Ek__BackingField_33)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_U3CformatU3Ek__BackingField_33() const { return ___U3CformatU3Ek__BackingField_33; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_U3CformatU3Ek__BackingField_33() { return &___U3CformatU3Ek__BackingField_33; }
	inline void set_U3CformatU3Ek__BackingField_33(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___U3CformatU3Ek__BackingField_33 = value;
	}

	inline static int32_t get_offset_of_U3CbyteOffsetU3Ek__BackingField_34() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C, ___U3CbyteOffsetU3Ek__BackingField_34)); }
	inline uint32_t get_U3CbyteOffsetU3Ek__BackingField_34() const { return ___U3CbyteOffsetU3Ek__BackingField_34; }
	inline uint32_t* get_address_of_U3CbyteOffsetU3Ek__BackingField_34() { return &___U3CbyteOffsetU3Ek__BackingField_34; }
	inline void set_U3CbyteOffsetU3Ek__BackingField_34(uint32_t value)
	{
		___U3CbyteOffsetU3Ek__BackingField_34 = value;
	}

	inline static int32_t get_offset_of_U3CbitOffsetU3Ek__BackingField_35() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C, ___U3CbitOffsetU3Ek__BackingField_35)); }
	inline uint32_t get_U3CbitOffsetU3Ek__BackingField_35() const { return ___U3CbitOffsetU3Ek__BackingField_35; }
	inline uint32_t* get_address_of_U3CbitOffsetU3Ek__BackingField_35() { return &___U3CbitOffsetU3Ek__BackingField_35; }
	inline void set_U3CbitOffsetU3Ek__BackingField_35(uint32_t value)
	{
		___U3CbitOffsetU3Ek__BackingField_35 = value;
	}

	inline static int32_t get_offset_of_U3CsizeInBitsU3Ek__BackingField_36() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C, ___U3CsizeInBitsU3Ek__BackingField_36)); }
	inline uint32_t get_U3CsizeInBitsU3Ek__BackingField_36() const { return ___U3CsizeInBitsU3Ek__BackingField_36; }
	inline uint32_t* get_address_of_U3CsizeInBitsU3Ek__BackingField_36() { return &___U3CsizeInBitsU3Ek__BackingField_36; }
	inline void set_U3CsizeInBitsU3Ek__BackingField_36(uint32_t value)
	{
		___U3CsizeInBitsU3Ek__BackingField_36 = value;
	}
};

struct InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields
{
public:
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatBit
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatBit_2;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatSBit
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatSBit_4;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatInt
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatInt_6;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatUInt
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatUInt_8;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatShort
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatShort_10;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatUShort
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatUShort_12;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatByte
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatByte_14;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatSByte
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatSByte_16;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatLong
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatLong_18;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatULong
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatULong_20;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatFloat
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatFloat_22;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatDouble
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatDouble_24;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatVector2
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatVector2_26;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatVector3
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatVector3_27;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatQuaternion
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatQuaternion_28;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatVector2Short
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatVector2Short_29;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatVector3Short
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatVector3Short_30;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatVector2Byte
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatVector2Byte_31;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputStateBlock::FormatVector3Byte
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___FormatVector3Byte_32;

public:
	inline static int32_t get_offset_of_FormatBit_2() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatBit_2)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatBit_2() const { return ___FormatBit_2; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatBit_2() { return &___FormatBit_2; }
	inline void set_FormatBit_2(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatBit_2 = value;
	}

	inline static int32_t get_offset_of_FormatSBit_4() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatSBit_4)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatSBit_4() const { return ___FormatSBit_4; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatSBit_4() { return &___FormatSBit_4; }
	inline void set_FormatSBit_4(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatSBit_4 = value;
	}

	inline static int32_t get_offset_of_FormatInt_6() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatInt_6)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatInt_6() const { return ___FormatInt_6; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatInt_6() { return &___FormatInt_6; }
	inline void set_FormatInt_6(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatInt_6 = value;
	}

	inline static int32_t get_offset_of_FormatUInt_8() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatUInt_8)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatUInt_8() const { return ___FormatUInt_8; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatUInt_8() { return &___FormatUInt_8; }
	inline void set_FormatUInt_8(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatUInt_8 = value;
	}

	inline static int32_t get_offset_of_FormatShort_10() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatShort_10)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatShort_10() const { return ___FormatShort_10; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatShort_10() { return &___FormatShort_10; }
	inline void set_FormatShort_10(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatShort_10 = value;
	}

	inline static int32_t get_offset_of_FormatUShort_12() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatUShort_12)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatUShort_12() const { return ___FormatUShort_12; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatUShort_12() { return &___FormatUShort_12; }
	inline void set_FormatUShort_12(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatUShort_12 = value;
	}

	inline static int32_t get_offset_of_FormatByte_14() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatByte_14)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatByte_14() const { return ___FormatByte_14; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatByte_14() { return &___FormatByte_14; }
	inline void set_FormatByte_14(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatByte_14 = value;
	}

	inline static int32_t get_offset_of_FormatSByte_16() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatSByte_16)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatSByte_16() const { return ___FormatSByte_16; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatSByte_16() { return &___FormatSByte_16; }
	inline void set_FormatSByte_16(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatSByte_16 = value;
	}

	inline static int32_t get_offset_of_FormatLong_18() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatLong_18)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatLong_18() const { return ___FormatLong_18; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatLong_18() { return &___FormatLong_18; }
	inline void set_FormatLong_18(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatLong_18 = value;
	}

	inline static int32_t get_offset_of_FormatULong_20() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatULong_20)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatULong_20() const { return ___FormatULong_20; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatULong_20() { return &___FormatULong_20; }
	inline void set_FormatULong_20(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatULong_20 = value;
	}

	inline static int32_t get_offset_of_FormatFloat_22() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatFloat_22)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatFloat_22() const { return ___FormatFloat_22; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatFloat_22() { return &___FormatFloat_22; }
	inline void set_FormatFloat_22(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatFloat_22 = value;
	}

	inline static int32_t get_offset_of_FormatDouble_24() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatDouble_24)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatDouble_24() const { return ___FormatDouble_24; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatDouble_24() { return &___FormatDouble_24; }
	inline void set_FormatDouble_24(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatDouble_24 = value;
	}

	inline static int32_t get_offset_of_FormatVector2_26() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatVector2_26)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatVector2_26() const { return ___FormatVector2_26; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatVector2_26() { return &___FormatVector2_26; }
	inline void set_FormatVector2_26(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatVector2_26 = value;
	}

	inline static int32_t get_offset_of_FormatVector3_27() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatVector3_27)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatVector3_27() const { return ___FormatVector3_27; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatVector3_27() { return &___FormatVector3_27; }
	inline void set_FormatVector3_27(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatVector3_27 = value;
	}

	inline static int32_t get_offset_of_FormatQuaternion_28() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatQuaternion_28)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatQuaternion_28() const { return ___FormatQuaternion_28; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatQuaternion_28() { return &___FormatQuaternion_28; }
	inline void set_FormatQuaternion_28(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatQuaternion_28 = value;
	}

	inline static int32_t get_offset_of_FormatVector2Short_29() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatVector2Short_29)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatVector2Short_29() const { return ___FormatVector2Short_29; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatVector2Short_29() { return &___FormatVector2Short_29; }
	inline void set_FormatVector2Short_29(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatVector2Short_29 = value;
	}

	inline static int32_t get_offset_of_FormatVector3Short_30() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatVector3Short_30)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatVector3Short_30() const { return ___FormatVector3Short_30; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatVector3Short_30() { return &___FormatVector3Short_30; }
	inline void set_FormatVector3Short_30(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatVector3Short_30 = value;
	}

	inline static int32_t get_offset_of_FormatVector2Byte_31() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatVector2Byte_31)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatVector2Byte_31() const { return ___FormatVector2Byte_31; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatVector2Byte_31() { return &___FormatVector2Byte_31; }
	inline void set_FormatVector2Byte_31(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatVector2Byte_31 = value;
	}

	inline static int32_t get_offset_of_FormatVector3Byte_32() { return static_cast<int32_t>(offsetof(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C_StaticFields, ___FormatVector3Byte_32)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_FormatVector3Byte_32() const { return ___FormatVector3Byte_32; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_FormatVector3Byte_32() { return &___FormatVector3Byte_32; }
	inline void set_FormatVector3Byte_32(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___FormatVector3Byte_32 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.InputUpdateType
struct InputUpdateType_t47858B05008C63717C1AFE8BA2AD1BB7EBF3712A 
{
public:
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputUpdateType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InputUpdateType_t47858B05008C63717C1AFE8BA2AD1BB7EBF3712A, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.Utilities.NameAndParameters
struct NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.NameAndParameters::<name>k__BackingField
	String_t* ___U3CnameU3Ek__BackingField_0;
	// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue> UnityEngine.InputSystem.Utilities.NameAndParameters::<parameters>k__BackingField
	ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___U3CparametersU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CnameU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76, ___U3CnameU3Ek__BackingField_0)); }
	inline String_t* get_U3CnameU3Ek__BackingField_0() const { return ___U3CnameU3Ek__BackingField_0; }
	inline String_t** get_address_of_U3CnameU3Ek__BackingField_0() { return &___U3CnameU3Ek__BackingField_0; }
	inline void set_U3CnameU3Ek__BackingField_0(String_t* value)
	{
		___U3CnameU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CnameU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CparametersU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76, ___U3CparametersU3Ek__BackingField_1)); }
	inline ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  get_U3CparametersU3Ek__BackingField_1() const { return ___U3CparametersU3Ek__BackingField_1; }
	inline ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8 * get_address_of_U3CparametersU3Ek__BackingField_1() { return &___U3CparametersU3Ek__BackingField_1; }
	inline void set_U3CparametersU3Ek__BackingField_1(ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  value)
	{
		___U3CparametersU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CparametersU3Ek__BackingField_1))->___m_Array_0), (void*)NULL);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.NameAndParameters
struct NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_marshaled_pinvoke
{
	char* ___U3CnameU3Ek__BackingField_0;
	ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___U3CparametersU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.NameAndParameters
struct NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_marshaled_com
{
	Il2CppChar* ___U3CnameU3Ek__BackingField_0;
	ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___U3CparametersU3Ek__BackingField_1;
};

// UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.EventSystems.RaycastResult
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE 
{
public:
	// UnityEngine.GameObject UnityEngine.EventSystems.RaycastResult::m_GameObject
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_GameObject_0;
	// UnityEngine.EventSystems.BaseRaycaster UnityEngine.EventSystems.RaycastResult::module
	BaseRaycaster_tBC0FB2CBE6D3D40991EC20F689C43F76AD82A876 * ___module_1;
	// System.Single UnityEngine.EventSystems.RaycastResult::distance
	float ___distance_2;
	// System.Single UnityEngine.EventSystems.RaycastResult::index
	float ___index_3;
	// System.Int32 UnityEngine.EventSystems.RaycastResult::depth
	int32_t ___depth_4;
	// System.Int32 UnityEngine.EventSystems.RaycastResult::sortingLayer
	int32_t ___sortingLayer_5;
	// System.Int32 UnityEngine.EventSystems.RaycastResult::sortingOrder
	int32_t ___sortingOrder_6;
	// UnityEngine.Vector3 UnityEngine.EventSystems.RaycastResult::worldPosition
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldPosition_7;
	// UnityEngine.Vector3 UnityEngine.EventSystems.RaycastResult::worldNormal
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldNormal_8;
	// UnityEngine.Vector2 UnityEngine.EventSystems.RaycastResult::screenPosition
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___screenPosition_9;
	// System.Int32 UnityEngine.EventSystems.RaycastResult::displayIndex
	int32_t ___displayIndex_10;

public:
	inline static int32_t get_offset_of_m_GameObject_0() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___m_GameObject_0)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_GameObject_0() const { return ___m_GameObject_0; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_GameObject_0() { return &___m_GameObject_0; }
	inline void set_m_GameObject_0(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_GameObject_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_GameObject_0), (void*)value);
	}

	inline static int32_t get_offset_of_module_1() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___module_1)); }
	inline BaseRaycaster_tBC0FB2CBE6D3D40991EC20F689C43F76AD82A876 * get_module_1() const { return ___module_1; }
	inline BaseRaycaster_tBC0FB2CBE6D3D40991EC20F689C43F76AD82A876 ** get_address_of_module_1() { return &___module_1; }
	inline void set_module_1(BaseRaycaster_tBC0FB2CBE6D3D40991EC20F689C43F76AD82A876 * value)
	{
		___module_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___module_1), (void*)value);
	}

	inline static int32_t get_offset_of_distance_2() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___distance_2)); }
	inline float get_distance_2() const { return ___distance_2; }
	inline float* get_address_of_distance_2() { return &___distance_2; }
	inline void set_distance_2(float value)
	{
		___distance_2 = value;
	}

	inline static int32_t get_offset_of_index_3() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___index_3)); }
	inline float get_index_3() const { return ___index_3; }
	inline float* get_address_of_index_3() { return &___index_3; }
	inline void set_index_3(float value)
	{
		___index_3 = value;
	}

	inline static int32_t get_offset_of_depth_4() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___depth_4)); }
	inline int32_t get_depth_4() const { return ___depth_4; }
	inline int32_t* get_address_of_depth_4() { return &___depth_4; }
	inline void set_depth_4(int32_t value)
	{
		___depth_4 = value;
	}

	inline static int32_t get_offset_of_sortingLayer_5() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___sortingLayer_5)); }
	inline int32_t get_sortingLayer_5() const { return ___sortingLayer_5; }
	inline int32_t* get_address_of_sortingLayer_5() { return &___sortingLayer_5; }
	inline void set_sortingLayer_5(int32_t value)
	{
		___sortingLayer_5 = value;
	}

	inline static int32_t get_offset_of_sortingOrder_6() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___sortingOrder_6)); }
	inline int32_t get_sortingOrder_6() const { return ___sortingOrder_6; }
	inline int32_t* get_address_of_sortingOrder_6() { return &___sortingOrder_6; }
	inline void set_sortingOrder_6(int32_t value)
	{
		___sortingOrder_6 = value;
	}

	inline static int32_t get_offset_of_worldPosition_7() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___worldPosition_7)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_worldPosition_7() const { return ___worldPosition_7; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_worldPosition_7() { return &___worldPosition_7; }
	inline void set_worldPosition_7(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___worldPosition_7 = value;
	}

	inline static int32_t get_offset_of_worldNormal_8() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___worldNormal_8)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_worldNormal_8() const { return ___worldNormal_8; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_worldNormal_8() { return &___worldNormal_8; }
	inline void set_worldNormal_8(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___worldNormal_8 = value;
	}

	inline static int32_t get_offset_of_screenPosition_9() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___screenPosition_9)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_screenPosition_9() const { return ___screenPosition_9; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_screenPosition_9() { return &___screenPosition_9; }
	inline void set_screenPosition_9(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___screenPosition_9 = value;
	}

	inline static int32_t get_offset_of_displayIndex_10() { return static_cast<int32_t>(offsetof(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE, ___displayIndex_10)); }
	inline int32_t get_displayIndex_10() const { return ___displayIndex_10; }
	inline int32_t* get_address_of_displayIndex_10() { return &___displayIndex_10; }
	inline void set_displayIndex_10(int32_t value)
	{
		___displayIndex_10 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.EventSystems.RaycastResult
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_pinvoke
{
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_GameObject_0;
	BaseRaycaster_tBC0FB2CBE6D3D40991EC20F689C43F76AD82A876 * ___module_1;
	float ___distance_2;
	float ___index_3;
	int32_t ___depth_4;
	int32_t ___sortingLayer_5;
	int32_t ___sortingOrder_6;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldPosition_7;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldNormal_8;
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___screenPosition_9;
	int32_t ___displayIndex_10;
};
// Native definition for COM marshalling of UnityEngine.EventSystems.RaycastResult
struct RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_com
{
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_GameObject_0;
	BaseRaycaster_tBC0FB2CBE6D3D40991EC20F689C43F76AD82A876 * ___module_1;
	float ___distance_2;
	float ___index_3;
	int32_t ___depth_4;
	int32_t ___sortingLayer_5;
	int32_t ___sortingOrder_6;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldPosition_7;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldNormal_8;
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___screenPosition_9;
	int32_t ___displayIndex_10;
};

// System.StringComparison
struct StringComparison_tCC9F72B9B1E2C3C6D2566DD0D3A61E1621048998 
{
public:
	// System.Int32 System.StringComparison::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(StringComparison_tCC9F72B9B1E2C3C6D2566DD0D3A61E1621048998, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.TouchPhase
struct TouchPhase_tE8F2610A794AA87AC4B5072DEF0BE2D77D4E443D 
{
public:
	// System.Int32 UnityEngine.InputSystem.TouchPhase::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TouchPhase_tE8F2610A794AA87AC4B5072DEF0BE2D77D4E443D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.TouchState
struct TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 
{
public:
	union
	{
		struct
		{
			union
			{
				#pragma pack(push, tp, 1)
				struct
				{
					// System.Int32 UnityEngine.InputSystem.LowLevel.TouchState::touchId
					int32_t ___touchId_1;
				};
				#pragma pack(pop, tp)
				struct
				{
					int32_t ___touchId_1_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___position_2_OffsetPadding[4];
					// UnityEngine.Vector2 UnityEngine.InputSystem.LowLevel.TouchState::position
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___position_2;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___position_2_OffsetPadding_forAlignmentOnly[4];
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___position_2_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___delta_3_OffsetPadding[12];
					// UnityEngine.Vector2 UnityEngine.InputSystem.LowLevel.TouchState::delta
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___delta_3;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___delta_3_OffsetPadding_forAlignmentOnly[12];
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___delta_3_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___pressure_4_OffsetPadding[20];
					// System.Single UnityEngine.InputSystem.LowLevel.TouchState::pressure
					float ___pressure_4;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___pressure_4_OffsetPadding_forAlignmentOnly[20];
					float ___pressure_4_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___radius_5_OffsetPadding[24];
					// UnityEngine.Vector2 UnityEngine.InputSystem.LowLevel.TouchState::radius
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___radius_5;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___radius_5_OffsetPadding_forAlignmentOnly[24];
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___radius_5_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___phaseId_6_OffsetPadding[32];
					// System.Byte UnityEngine.InputSystem.LowLevel.TouchState::phaseId
					uint8_t ___phaseId_6;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___phaseId_6_OffsetPadding_forAlignmentOnly[32];
					uint8_t ___phaseId_6_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___tapCount_7_OffsetPadding[33];
					// System.Byte UnityEngine.InputSystem.LowLevel.TouchState::tapCount
					uint8_t ___tapCount_7;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___tapCount_7_OffsetPadding_forAlignmentOnly[33];
					uint8_t ___tapCount_7_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___displayIndex_8_OffsetPadding[34];
					// System.Byte UnityEngine.InputSystem.LowLevel.TouchState::displayIndex
					uint8_t ___displayIndex_8;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___displayIndex_8_OffsetPadding_forAlignmentOnly[34];
					uint8_t ___displayIndex_8_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___flags_9_OffsetPadding[35];
					// System.Byte UnityEngine.InputSystem.LowLevel.TouchState::flags
					uint8_t ___flags_9;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___flags_9_OffsetPadding_forAlignmentOnly[35];
					uint8_t ___flags_9_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___updateStepCount_10_OffsetPadding[36];
					// System.UInt32 UnityEngine.InputSystem.LowLevel.TouchState::updateStepCount
					uint32_t ___updateStepCount_10;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___updateStepCount_10_OffsetPadding_forAlignmentOnly[36];
					uint32_t ___updateStepCount_10_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___startTime_11_OffsetPadding[40];
					// System.Double UnityEngine.InputSystem.LowLevel.TouchState::startTime
					double ___startTime_11;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___startTime_11_OffsetPadding_forAlignmentOnly[40];
					double ___startTime_11_forAlignmentOnly;
				};
				#pragma pack(push, tp, 1)
				struct
				{
					char ___startPosition_12_OffsetPadding[48];
					// UnityEngine.Vector2 UnityEngine.InputSystem.LowLevel.TouchState::startPosition
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___startPosition_12;
				};
				#pragma pack(pop, tp)
				struct
				{
					char ___startPosition_12_OffsetPadding_forAlignmentOnly[48];
					Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___startPosition_12_forAlignmentOnly;
				};
			};
		};
		uint8_t TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8__padding[56];
	};

public:
	inline static int32_t get_offset_of_touchId_1() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___touchId_1)); }
	inline int32_t get_touchId_1() const { return ___touchId_1; }
	inline int32_t* get_address_of_touchId_1() { return &___touchId_1; }
	inline void set_touchId_1(int32_t value)
	{
		___touchId_1 = value;
	}

	inline static int32_t get_offset_of_position_2() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___position_2)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_position_2() const { return ___position_2; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_position_2() { return &___position_2; }
	inline void set_position_2(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___position_2 = value;
	}

	inline static int32_t get_offset_of_delta_3() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___delta_3)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_delta_3() const { return ___delta_3; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_delta_3() { return &___delta_3; }
	inline void set_delta_3(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___delta_3 = value;
	}

	inline static int32_t get_offset_of_pressure_4() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___pressure_4)); }
	inline float get_pressure_4() const { return ___pressure_4; }
	inline float* get_address_of_pressure_4() { return &___pressure_4; }
	inline void set_pressure_4(float value)
	{
		___pressure_4 = value;
	}

	inline static int32_t get_offset_of_radius_5() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___radius_5)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_radius_5() const { return ___radius_5; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_radius_5() { return &___radius_5; }
	inline void set_radius_5(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___radius_5 = value;
	}

	inline static int32_t get_offset_of_phaseId_6() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___phaseId_6)); }
	inline uint8_t get_phaseId_6() const { return ___phaseId_6; }
	inline uint8_t* get_address_of_phaseId_6() { return &___phaseId_6; }
	inline void set_phaseId_6(uint8_t value)
	{
		___phaseId_6 = value;
	}

	inline static int32_t get_offset_of_tapCount_7() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___tapCount_7)); }
	inline uint8_t get_tapCount_7() const { return ___tapCount_7; }
	inline uint8_t* get_address_of_tapCount_7() { return &___tapCount_7; }
	inline void set_tapCount_7(uint8_t value)
	{
		___tapCount_7 = value;
	}

	inline static int32_t get_offset_of_displayIndex_8() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___displayIndex_8)); }
	inline uint8_t get_displayIndex_8() const { return ___displayIndex_8; }
	inline uint8_t* get_address_of_displayIndex_8() { return &___displayIndex_8; }
	inline void set_displayIndex_8(uint8_t value)
	{
		___displayIndex_8 = value;
	}

	inline static int32_t get_offset_of_flags_9() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___flags_9)); }
	inline uint8_t get_flags_9() const { return ___flags_9; }
	inline uint8_t* get_address_of_flags_9() { return &___flags_9; }
	inline void set_flags_9(uint8_t value)
	{
		___flags_9 = value;
	}

	inline static int32_t get_offset_of_updateStepCount_10() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___updateStepCount_10)); }
	inline uint32_t get_updateStepCount_10() const { return ___updateStepCount_10; }
	inline uint32_t* get_address_of_updateStepCount_10() { return &___updateStepCount_10; }
	inline void set_updateStepCount_10(uint32_t value)
	{
		___updateStepCount_10 = value;
	}

	inline static int32_t get_offset_of_startTime_11() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___startTime_11)); }
	inline double get_startTime_11() const { return ___startTime_11; }
	inline double* get_address_of_startTime_11() { return &___startTime_11; }
	inline void set_startTime_11(double value)
	{
		___startTime_11 = value;
	}

	inline static int32_t get_offset_of_startPosition_12() { return static_cast<int32_t>(offsetof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8, ___startPosition_12)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_startPosition_12() const { return ___startPosition_12; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_startPosition_12() { return &___startPosition_12; }
	inline void set_startPosition_12(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___startPosition_12 = value;
	}
};


// System.TypeCode
struct TypeCode_tCB39BAB5CFB7A1E0BCB521413E3C46B81C31AA7C 
{
public:
	// System.Int32 System.TypeCode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TypeCode_tCB39BAB5CFB7A1E0BCB521413E3C46B81C31AA7C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.HID.HID/HIDElementFlags
struct HIDElementFlags_tCF57DDF8BCB412DAEA2485B8BAB6F9F3C19073AF 
{
public:
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(HIDElementFlags_tCF57DDF8BCB412DAEA2485B8BAB6F9F3C19073AF, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.HID.HID/HIDReportType
struct HIDReportType_tEE7987BF8895E624705C0AAB84BD12BE4687606A 
{
public:
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDReportType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(HIDReportType_tEE7987BF8895E624705C0AAB84BD12BE4687606A, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.HID.HID/UsagePage
struct UsagePage_t22FB7B52BFEF4D35041BEE9DFB9245493D002BA3 
{
public:
	// System.Int32 UnityEngine.InputSystem.HID.HID/UsagePage::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(UsagePage_t22FB7B52BFEF4D35041BEE9DFB9245493D002BA3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputControl/ControlFlags
struct ControlFlags_tC210B095E24C31AC8E07C6E09B02CAA80C2563B6 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputControl/ControlFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ControlFlags_tC210B095E24C31AC8E07C6E09B02CAA80C2563B6, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder
struct Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E  : public RuntimeObject
{
public:
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::<name>k__BackingField
	String_t* ___U3CnameU3Ek__BackingField_0;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::<displayName>k__BackingField
	String_t* ___U3CdisplayNameU3Ek__BackingField_1;
	// System.Type UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::<type>k__BackingField
	Type_t * ___U3CtypeU3Ek__BackingField_2;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::<stateFormat>k__BackingField
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___U3CstateFormatU3Ek__BackingField_3;
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::<stateSizeInBytes>k__BackingField
	int32_t ___U3CstateSizeInBytesU3Ek__BackingField_4;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::m_ExtendsLayout
	String_t* ___m_ExtendsLayout_5;
	// System.Nullable`1<System.Boolean> UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::<updateBeforeRender>k__BackingField
	Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3  ___U3CupdateBeforeRenderU3Ek__BackingField_6;
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::m_ControlCount
	int32_t ___m_ControlCount_7;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem[] UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::m_Controls
	ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* ___m_Controls_8;

public:
	inline static int32_t get_offset_of_U3CnameU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___U3CnameU3Ek__BackingField_0)); }
	inline String_t* get_U3CnameU3Ek__BackingField_0() const { return ___U3CnameU3Ek__BackingField_0; }
	inline String_t** get_address_of_U3CnameU3Ek__BackingField_0() { return &___U3CnameU3Ek__BackingField_0; }
	inline void set_U3CnameU3Ek__BackingField_0(String_t* value)
	{
		___U3CnameU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CnameU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CdisplayNameU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___U3CdisplayNameU3Ek__BackingField_1)); }
	inline String_t* get_U3CdisplayNameU3Ek__BackingField_1() const { return ___U3CdisplayNameU3Ek__BackingField_1; }
	inline String_t** get_address_of_U3CdisplayNameU3Ek__BackingField_1() { return &___U3CdisplayNameU3Ek__BackingField_1; }
	inline void set_U3CdisplayNameU3Ek__BackingField_1(String_t* value)
	{
		___U3CdisplayNameU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CdisplayNameU3Ek__BackingField_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CtypeU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___U3CtypeU3Ek__BackingField_2)); }
	inline Type_t * get_U3CtypeU3Ek__BackingField_2() const { return ___U3CtypeU3Ek__BackingField_2; }
	inline Type_t ** get_address_of_U3CtypeU3Ek__BackingField_2() { return &___U3CtypeU3Ek__BackingField_2; }
	inline void set_U3CtypeU3Ek__BackingField_2(Type_t * value)
	{
		___U3CtypeU3Ek__BackingField_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CtypeU3Ek__BackingField_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CstateFormatU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___U3CstateFormatU3Ek__BackingField_3)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_U3CstateFormatU3Ek__BackingField_3() const { return ___U3CstateFormatU3Ek__BackingField_3; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_U3CstateFormatU3Ek__BackingField_3() { return &___U3CstateFormatU3Ek__BackingField_3; }
	inline void set_U3CstateFormatU3Ek__BackingField_3(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___U3CstateFormatU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CstateSizeInBytesU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___U3CstateSizeInBytesU3Ek__BackingField_4)); }
	inline int32_t get_U3CstateSizeInBytesU3Ek__BackingField_4() const { return ___U3CstateSizeInBytesU3Ek__BackingField_4; }
	inline int32_t* get_address_of_U3CstateSizeInBytesU3Ek__BackingField_4() { return &___U3CstateSizeInBytesU3Ek__BackingField_4; }
	inline void set_U3CstateSizeInBytesU3Ek__BackingField_4(int32_t value)
	{
		___U3CstateSizeInBytesU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of_m_ExtendsLayout_5() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___m_ExtendsLayout_5)); }
	inline String_t* get_m_ExtendsLayout_5() const { return ___m_ExtendsLayout_5; }
	inline String_t** get_address_of_m_ExtendsLayout_5() { return &___m_ExtendsLayout_5; }
	inline void set_m_ExtendsLayout_5(String_t* value)
	{
		___m_ExtendsLayout_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ExtendsLayout_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CupdateBeforeRenderU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___U3CupdateBeforeRenderU3Ek__BackingField_6)); }
	inline Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3  get_U3CupdateBeforeRenderU3Ek__BackingField_6() const { return ___U3CupdateBeforeRenderU3Ek__BackingField_6; }
	inline Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3 * get_address_of_U3CupdateBeforeRenderU3Ek__BackingField_6() { return &___U3CupdateBeforeRenderU3Ek__BackingField_6; }
	inline void set_U3CupdateBeforeRenderU3Ek__BackingField_6(Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3  value)
	{
		___U3CupdateBeforeRenderU3Ek__BackingField_6 = value;
	}

	inline static int32_t get_offset_of_m_ControlCount_7() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___m_ControlCount_7)); }
	inline int32_t get_m_ControlCount_7() const { return ___m_ControlCount_7; }
	inline int32_t* get_address_of_m_ControlCount_7() { return &___m_ControlCount_7; }
	inline void set_m_ControlCount_7(int32_t value)
	{
		___m_ControlCount_7 = value;
	}

	inline static int32_t get_offset_of_m_Controls_8() { return static_cast<int32_t>(offsetof(Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E, ___m_Controls_8)); }
	inline ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* get_m_Controls_8() const { return ___m_Controls_8; }
	inline ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05** get_address_of_m_Controls_8() { return &___m_Controls_8; }
	inline void set_m_Controls_8(ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* value)
	{
		___m_Controls_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Controls_8), (void*)value);
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/Flags
struct Flags_t0D15C077219E78C2FA7A31BEA89734D50E03D73B 
{
public:
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_t0D15C077219E78C2FA7A31BEA89734D50E03D73B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputDevice/DeviceFlags
struct DeviceFlags_tEA83E21B2294D1CFE7395FE7C9455CFC71BBD1F4 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputDevice/DeviceFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(DeviceFlags_tEA83E21B2294D1CFE7395FE7C9455CFC71BBD1F4, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo
struct DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D 
{
public:
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo::m_DeviceId
	int32_t ___m_DeviceId_0;
	// System.String UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo::m_Layout
	String_t* ___m_Layout_1;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo::m_StateFormat
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___m_StateFormat_2;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo::m_StateSizeInBytes
	int32_t ___m_StateSizeInBytes_3;
	// System.String UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo::m_FullLayoutJson
	String_t* ___m_FullLayoutJson_4;

public:
	inline static int32_t get_offset_of_m_DeviceId_0() { return static_cast<int32_t>(offsetof(DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D, ___m_DeviceId_0)); }
	inline int32_t get_m_DeviceId_0() const { return ___m_DeviceId_0; }
	inline int32_t* get_address_of_m_DeviceId_0() { return &___m_DeviceId_0; }
	inline void set_m_DeviceId_0(int32_t value)
	{
		___m_DeviceId_0 = value;
	}

	inline static int32_t get_offset_of_m_Layout_1() { return static_cast<int32_t>(offsetof(DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D, ___m_Layout_1)); }
	inline String_t* get_m_Layout_1() const { return ___m_Layout_1; }
	inline String_t** get_address_of_m_Layout_1() { return &___m_Layout_1; }
	inline void set_m_Layout_1(String_t* value)
	{
		___m_Layout_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Layout_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_StateFormat_2() { return static_cast<int32_t>(offsetof(DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D, ___m_StateFormat_2)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_m_StateFormat_2() const { return ___m_StateFormat_2; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_m_StateFormat_2() { return &___m_StateFormat_2; }
	inline void set_m_StateFormat_2(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___m_StateFormat_2 = value;
	}

	inline static int32_t get_offset_of_m_StateSizeInBytes_3() { return static_cast<int32_t>(offsetof(DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D, ___m_StateSizeInBytes_3)); }
	inline int32_t get_m_StateSizeInBytes_3() const { return ___m_StateSizeInBytes_3; }
	inline int32_t* get_address_of_m_StateSizeInBytes_3() { return &___m_StateSizeInBytes_3; }
	inline void set_m_StateSizeInBytes_3(int32_t value)
	{
		___m_StateSizeInBytes_3 = value;
	}

	inline static int32_t get_offset_of_m_FullLayoutJson_4() { return static_cast<int32_t>(offsetof(DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D, ___m_FullLayoutJson_4)); }
	inline String_t* get_m_FullLayoutJson_4() const { return ___m_FullLayoutJson_4; }
	inline String_t** get_address_of_m_FullLayoutJson_4() { return &___m_FullLayoutJson_4; }
	inline void set_m_FullLayoutJson_4(String_t* value)
	{
		___m_FullLayoutJson_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_FullLayoutJson_4), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo
struct DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D_marshaled_pinvoke
{
	int32_t ___m_DeviceId_0;
	char* ___m_Layout_1;
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___m_StateFormat_2;
	int32_t ___m_StateSizeInBytes_3;
	char* ___m_FullLayoutJson_4;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo
struct DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D_marshaled_com
{
	int32_t ___m_DeviceId_0;
	Il2CppChar* ___m_Layout_1;
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___m_StateFormat_2;
	int32_t ___m_StateSizeInBytes_3;
	Il2CppChar* ___m_FullLayoutJson_4;
};

// UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader
struct RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 
{
public:
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Double UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader::time
			double ___time_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			double ___time_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___version_1_OffsetPadding[8];
			// System.UInt32 UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader::version
			uint32_t ___version_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___version_1_OffsetPadding_forAlignmentOnly[8];
			uint32_t ___version_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___controlIndex_2_OffsetPadding[12];
			// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader::controlIndex
			int32_t ___controlIndex_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___controlIndex_2_OffsetPadding_forAlignmentOnly[12];
			int32_t ___controlIndex_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_StateWithoutControlIndex_3_OffsetPadding[12];
			// UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader/<m_StateWithoutControlIndex>e__FixedBuffer UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader::m_StateWithoutControlIndex
			U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC  ___m_StateWithoutControlIndex_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_StateWithoutControlIndex_3_OffsetPadding_forAlignmentOnly[12];
			U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC  ___m_StateWithoutControlIndex_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_StateWithControlIndex_4_OffsetPadding[16];
			// UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader/<m_StateWithControlIndex>e__FixedBuffer UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader::m_StateWithControlIndex
			U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6  ___m_StateWithControlIndex_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_StateWithControlIndex_4_OffsetPadding_forAlignmentOnly[16];
			U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6  ___m_StateWithControlIndex_4_forAlignmentOnly;
		};
	};

public:
	inline static int32_t get_offset_of_time_0() { return static_cast<int32_t>(offsetof(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768, ___time_0)); }
	inline double get_time_0() const { return ___time_0; }
	inline double* get_address_of_time_0() { return &___time_0; }
	inline void set_time_0(double value)
	{
		___time_0 = value;
	}

	inline static int32_t get_offset_of_version_1() { return static_cast<int32_t>(offsetof(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768, ___version_1)); }
	inline uint32_t get_version_1() const { return ___version_1; }
	inline uint32_t* get_address_of_version_1() { return &___version_1; }
	inline void set_version_1(uint32_t value)
	{
		___version_1 = value;
	}

	inline static int32_t get_offset_of_controlIndex_2() { return static_cast<int32_t>(offsetof(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768, ___controlIndex_2)); }
	inline int32_t get_controlIndex_2() const { return ___controlIndex_2; }
	inline int32_t* get_address_of_controlIndex_2() { return &___controlIndex_2; }
	inline void set_controlIndex_2(int32_t value)
	{
		___controlIndex_2 = value;
	}

	inline static int32_t get_offset_of_m_StateWithoutControlIndex_3() { return static_cast<int32_t>(offsetof(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768, ___m_StateWithoutControlIndex_3)); }
	inline U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC  get_m_StateWithoutControlIndex_3() const { return ___m_StateWithoutControlIndex_3; }
	inline U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC * get_address_of_m_StateWithoutControlIndex_3() { return &___m_StateWithoutControlIndex_3; }
	inline void set_m_StateWithoutControlIndex_3(U3Cm_StateWithoutControlIndexU3Ee__FixedBuffer_tAD4DA1250543CB6FC13235742EEB82788EB513CC  value)
	{
		___m_StateWithoutControlIndex_3 = value;
	}

	inline static int32_t get_offset_of_m_StateWithControlIndex_4() { return static_cast<int32_t>(offsetof(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768, ___m_StateWithControlIndex_4)); }
	inline U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6  get_m_StateWithControlIndex_4() const { return ___m_StateWithControlIndex_4; }
	inline U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6 * get_address_of_m_StateWithControlIndex_4() { return &___m_StateWithControlIndex_4; }
	inline void set_m_StateWithControlIndex_4(U3Cm_StateWithControlIndexU3Ee__FixedBuffer_t48BB82A9F1D1D6733A1B957B6D9AE528E0B4EDF6  value)
	{
		___m_StateWithControlIndex_4 = value;
	}
};


// UnityEngine.InputSystem.Utilities.JsonParser/JsonString
struct JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D 
{
public:
	// UnityEngine.InputSystem.Utilities.Substring UnityEngine.InputSystem.Utilities.JsonParser/JsonString::text
	Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  ___text_0;
	// System.Boolean UnityEngine.InputSystem.Utilities.JsonParser/JsonString::hasEscapes
	bool ___hasEscapes_1;

public:
	inline static int32_t get_offset_of_text_0() { return static_cast<int32_t>(offsetof(JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D, ___text_0)); }
	inline Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  get_text_0() const { return ___text_0; }
	inline Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815 * get_address_of_text_0() { return &___text_0; }
	inline void set_text_0(Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  value)
	{
		___text_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___text_0))->___m_String_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_hasEscapes_1() { return static_cast<int32_t>(offsetof(JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D, ___hasEscapes_1)); }
	inline bool get_hasEscapes_1() const { return ___hasEscapes_1; }
	inline bool* get_address_of_hasEscapes_1() { return &___hasEscapes_1; }
	inline void set_hasEscapes_1(bool value)
	{
		___hasEscapes_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonString
struct JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D_marshaled_pinvoke
{
	Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815_marshaled_pinvoke ___text_0;
	int32_t ___hasEscapes_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonString
struct JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D_marshaled_com
{
	Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815_marshaled_com ___text_0;
	int32_t ___hasEscapes_1;
};

// UnityEngine.InputSystem.Utilities.JsonParser/JsonValueType
struct JsonValueType_tC1693041766D5BCCE3DA251FABD56F8BA8539170 
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.JsonParser/JsonValueType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(JsonValueType_tC1693041766D5BCCE3DA251FABD56F8BA8539170, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.PlayerInputManager/PlayerLeftEvent
struct PlayerLeftEvent_tC4BBBDE1FE743F4EC06251E8554EE4EFF88EF34E  : public UnityEvent_1_tD09E39AD92F90E8B662BC6003C65B108EC9B5EEC
{
public:

public:
};


// UnityEngine.EventSystems.PointerEventData/FramePressState
struct FramePressState_t4BB461B7704D7F72519B36A0C8B3370AB302E7A7 
{
public:
	// System.Int32 UnityEngine.EventSystems.PointerEventData/FramePressState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FramePressState_t4BB461B7704D7F72519B36A0C8B3370AB302E7A7, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.EventSystems.PointerEventData/InputButton
struct InputButton_tA5409FE587ADC841D2BF80835D04074A89C59A9D 
{
public:
	// System.Int32 UnityEngine.EventSystems.PointerEventData/InputButton::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InputButton_tA5409FE587ADC841D2BF80835D04074A89C59A9D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.QueryPairedUserAccountCommand/Result
struct Result_tE6265CA3ACCDE1721E1948D551CBF71779D8EF65 
{
public:
	// System.Int64 UnityEngine.InputSystem.LowLevel.QueryPairedUserAccountCommand/Result::value__
	int64_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Result_tE6265CA3ACCDE1721E1948D551CBF71779D8EF65, ___value___2)); }
	inline int64_t get_value___2() const { return ___value___2; }
	inline int64_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int64_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8
struct U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393  : public RuntimeObject
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::<>1__state
	int32_t ___U3CU3E1__state_0;
	// UnityEngine.InputSystem.Utilities.Substring UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::<>2__current
	Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  ___U3CU3E2__current_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::<>l__initialThreadId
	int32_t ___U3CU3El__initialThreadId_2;
	// System.String UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::str
	String_t* ___str_3;
	// System.String UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::<>3__str
	String_t* ___U3CU3E3__str_4;
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::<length>5__2
	int32_t ___U3ClengthU3E5__2_5;
	// System.Int32 UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::<endPos>5__3
	int32_t ___U3CendPosU3E5__3_6;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393, ___U3CU3E2__current_1)); }
	inline Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815 * get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E2__current_1))->___m_String_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3El__initialThreadId_2() { return static_cast<int32_t>(offsetof(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393, ___U3CU3El__initialThreadId_2)); }
	inline int32_t get_U3CU3El__initialThreadId_2() const { return ___U3CU3El__initialThreadId_2; }
	inline int32_t* get_address_of_U3CU3El__initialThreadId_2() { return &___U3CU3El__initialThreadId_2; }
	inline void set_U3CU3El__initialThreadId_2(int32_t value)
	{
		___U3CU3El__initialThreadId_2 = value;
	}

	inline static int32_t get_offset_of_str_3() { return static_cast<int32_t>(offsetof(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393, ___str_3)); }
	inline String_t* get_str_3() const { return ___str_3; }
	inline String_t** get_address_of_str_3() { return &___str_3; }
	inline void set_str_3(String_t* value)
	{
		___str_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___str_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E3__str_4() { return static_cast<int32_t>(offsetof(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393, ___U3CU3E3__str_4)); }
	inline String_t* get_U3CU3E3__str_4() const { return ___U3CU3E3__str_4; }
	inline String_t** get_address_of_U3CU3E3__str_4() { return &___U3CU3E3__str_4; }
	inline void set_U3CU3E3__str_4(String_t* value)
	{
		___U3CU3E3__str_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E3__str_4), (void*)value);
	}

	inline static int32_t get_offset_of_U3ClengthU3E5__2_5() { return static_cast<int32_t>(offsetof(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393, ___U3ClengthU3E5__2_5)); }
	inline int32_t get_U3ClengthU3E5__2_5() const { return ___U3ClengthU3E5__2_5; }
	inline int32_t* get_address_of_U3ClengthU3E5__2_5() { return &___U3ClengthU3E5__2_5; }
	inline void set_U3ClengthU3E5__2_5(int32_t value)
	{
		___U3ClengthU3E5__2_5 = value;
	}

	inline static int32_t get_offset_of_U3CendPosU3E5__3_6() { return static_cast<int32_t>(offsetof(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393, ___U3CendPosU3E5__3_6)); }
	inline int32_t get_U3CendPosU3E5__3_6() const { return ___U3CendPosU3E5__3_6; }
	inline int32_t* get_address_of_U3CendPosU3E5__3_6() { return &___U3CendPosU3E5__3_6; }
	inline void set_U3CendPosU3E5__3_6(int32_t value)
	{
		___U3CendPosU3E5__3_6 = value;
	}
};


// UnityEngine.InputSystem.Switch.LowLevel.SwitchProControllerHIDInputState/Button
struct Button_t060CD0FC0BF4021C4285BF0FAE67FBA5563DE47B 
{
public:
	// System.Int32 UnityEngine.InputSystem.Switch.LowLevel.SwitchProControllerHIDInputState/Button::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Button_t060CD0FC0BF4021C4285BF0FAE67FBA5563DE47B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.EnhancedTouch.Touch/ExtraDataPerTouchState
struct ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 
{
public:
	// UnityEngine.Vector2 UnityEngine.InputSystem.EnhancedTouch.Touch/ExtraDataPerTouchState::accumulatedDelta
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___accumulatedDelta_0;
	// System.UInt32 UnityEngine.InputSystem.EnhancedTouch.Touch/ExtraDataPerTouchState::uniqueId
	uint32_t ___uniqueId_1;

public:
	inline static int32_t get_offset_of_accumulatedDelta_0() { return static_cast<int32_t>(offsetof(ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6, ___accumulatedDelta_0)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_accumulatedDelta_0() const { return ___accumulatedDelta_0; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_accumulatedDelta_0() { return &___accumulatedDelta_0; }
	inline void set_accumulatedDelta_0(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___accumulatedDelta_0 = value;
	}

	inline static int32_t get_offset_of_uniqueId_1() { return static_cast<int32_t>(offsetof(ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6, ___uniqueId_1)); }
	inline uint32_t get_uniqueId_1() const { return ___uniqueId_1; }
	inline uint32_t* get_address_of_uniqueId_1() { return &___uniqueId_1; }
	inline void set_uniqueId_1(uint32_t value)
	{
		___uniqueId_1 = value;
	}
};


// UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator
struct Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69  : public RuntimeObject
{
public:
	// UnityEngine.InputSystem.EnhancedTouch.TouchHistory UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::m_Owner
	TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  ___m_Owner_0;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::m_Index
	int32_t ___m_Index_1;

public:
	inline static int32_t get_offset_of_m_Owner_0() { return static_cast<int32_t>(offsetof(Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69, ___m_Owner_0)); }
	inline TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  get_m_Owner_0() const { return ___m_Owner_0; }
	inline TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D * get_address_of_m_Owner_0() { return &___m_Owner_0; }
	inline void set_m_Owner_0(TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  value)
	{
		___m_Owner_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Owner_0))->___m_History_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Owner_0))->___m_Finger_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_Index_1() { return static_cast<int32_t>(offsetof(Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69, ___m_Index_1)); }
	inline int32_t get_m_Index_1() const { return ___m_Index_1; }
	inline int32_t* get_address_of_m_Index_1() { return &___m_Index_1; }
	inline void set_m_Index_1(int32_t value)
	{
		___m_Index_1 = value;
	}
};


// UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData
struct RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 
{
public:
	// UnityEngine.UI.Graphic UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::<graphic>k__BackingField
	Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___U3CgraphicU3Ek__BackingField_0;
	// UnityEngine.Vector3 UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::<worldHitPosition>k__BackingField
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___U3CworldHitPositionU3Ek__BackingField_1;
	// UnityEngine.Vector2 UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::<screenPosition>k__BackingField
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___U3CscreenPositionU3Ek__BackingField_2;
	// System.Single UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::<distance>k__BackingField
	float ___U3CdistanceU3Ek__BackingField_3;

public:
	inline static int32_t get_offset_of_U3CgraphicU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1, ___U3CgraphicU3Ek__BackingField_0)); }
	inline Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * get_U3CgraphicU3Ek__BackingField_0() const { return ___U3CgraphicU3Ek__BackingField_0; }
	inline Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 ** get_address_of_U3CgraphicU3Ek__BackingField_0() { return &___U3CgraphicU3Ek__BackingField_0; }
	inline void set_U3CgraphicU3Ek__BackingField_0(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * value)
	{
		___U3CgraphicU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CgraphicU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CworldHitPositionU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1, ___U3CworldHitPositionU3Ek__BackingField_1)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_U3CworldHitPositionU3Ek__BackingField_1() const { return ___U3CworldHitPositionU3Ek__BackingField_1; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_U3CworldHitPositionU3Ek__BackingField_1() { return &___U3CworldHitPositionU3Ek__BackingField_1; }
	inline void set_U3CworldHitPositionU3Ek__BackingField_1(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___U3CworldHitPositionU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CscreenPositionU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1, ___U3CscreenPositionU3Ek__BackingField_2)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_U3CscreenPositionU3Ek__BackingField_2() const { return ___U3CscreenPositionU3Ek__BackingField_2; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_U3CscreenPositionU3Ek__BackingField_2() { return &___U3CscreenPositionU3Ek__BackingField_2; }
	inline void set_U3CscreenPositionU3Ek__BackingField_2(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___U3CscreenPositionU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CdistanceU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1, ___U3CdistanceU3Ek__BackingField_3)); }
	inline float get_U3CdistanceU3Ek__BackingField_3() const { return ___U3CdistanceU3Ek__BackingField_3; }
	inline float* get_address_of_U3CdistanceU3Ek__BackingField_3() { return &___U3CdistanceU3Ek__BackingField_3; }
	inline void set_U3CdistanceU3Ek__BackingField_3(float value)
	{
		___U3CdistanceU3Ek__BackingField_3 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData
struct RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_pinvoke
{
	Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___U3CgraphicU3Ek__BackingField_0;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___U3CworldHitPositionU3Ek__BackingField_1;
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___U3CscreenPositionU3Ek__BackingField_2;
	float ___U3CdistanceU3Ek__BackingField_3;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData
struct RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_com
{
	Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___U3CgraphicU3Ek__BackingField_0;
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___U3CworldHitPositionU3Ek__BackingField_1;
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___U3CscreenPositionU3Ek__BackingField_2;
	float ___U3CdistanceU3Ek__BackingField_3;
};

// UnityEngine.InputSystem.XR.TrackedPoseDriver/TrackingType
struct TrackingType_t319DA637DDBFD6EDAF2D2572DD79B77C7D390EBE 
{
public:
	// System.Int32 UnityEngine.InputSystem.XR.TrackedPoseDriver/TrackingType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TrackingType_t319DA637DDBFD6EDAF2D2572DD79B77C7D390EBE, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.XR.TrackedPoseDriver/UpdateType
struct UpdateType_tEFB33A5F7006040FB2C7AC3D8F4011B102621205 
{
public:
	// System.Int32 UnityEngine.InputSystem.XR.TrackedPoseDriver/UpdateType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(UpdateType_tEFB33A5F7006040FB2C7AC3D8F4011B102621205, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.Composites.Vector2Composite/Mode
struct Mode_tB956BDCC9428A4E2AE6EFD7A2CC9C37B581C1430 
{
public:
	// System.Int32 UnityEngine.InputSystem.Composites.Vector2Composite/Mode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Mode_tB956BDCC9428A4E2AE6EFD7A2CC9C37B581C1430, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.Composites.Vector3Composite/Mode
struct Mode_t80443691A029F0CC526AB96B38FEA9CD372B08E4 
{
public:
	// System.Int32 UnityEngine.InputSystem.Composites.Vector3Composite/Mode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Mode_t80443691A029F0CC526AB96B38FEA9CD372B08E4, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.UI.VirtualMouseInput/CursorMode
struct CursorMode_t88AFE52992D651997C5E4663C79015022F933459 
{
public:
	// System.Int32 UnityEngine.InputSystem.UI.VirtualMouseInput/CursorMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CursorMode_t88AFE52992D651997C5E4663C79015022F933459, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.XInput.XInputController/DeviceFlags
struct DeviceFlags_t40D05E8DB9FFDDD41EE45C5263498A5CB182D89F 
{
public:
	// System.Int32 UnityEngine.InputSystem.XInput.XInputController/DeviceFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(DeviceFlags_t40D05E8DB9FFDDD41EE45C5263498A5CB182D89F, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.XInput.XInputController/DeviceSubType
struct DeviceSubType_t46F1D81BC90E8D1EA279366C9F29B9DEA21DAD60 
{
public:
	// System.Int32 UnityEngine.InputSystem.XInput.XInputController/DeviceSubType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(DeviceSubType_t46F1D81BC90E8D1EA279366C9F29B9DEA21DAD60, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.XInput.XInputController/DeviceType
struct DeviceType_tC8EDF1E7A4CAD3EF74DDBEBD727B5A697FCBA4E4 
{
public:
	// System.Int32 UnityEngine.InputSystem.XInput.XInputController/DeviceType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(DeviceType_tC8EDF1E7A4CAD3EF74DDBEBD727B5A697FCBA4E4, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.XInput.LowLevel.XInputControllerWindowsState/Button
struct Button_tD48D5B3579BC605801BEE999FCD205470B41CAB7 
{
public:
	// System.Int32 UnityEngine.InputSystem.XInput.LowLevel.XInputControllerWindowsState/Button::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Button_tD48D5B3579BC605801BEE999FCD205470B41CAB7, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputActionRebindingExtensions/RebindingOperation/Flags
struct Flags_t56C2BA6778B26893462259E8F0B50041EC8F678D 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputActionRebindingExtensions/RebindingOperation/Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_t56C2BA6778B26893462259E8F0B50041EC8F678D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputActionState/BindingState/Flags
struct Flags_t6D9A69FE16D3A1C3C9EBA6FD4590B1CE558440D3 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputActionState/BindingState/Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_t6D9A69FE16D3A1C3C9EBA6FD4590B1CE558440D3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputActionState/InteractionState/Flags
struct Flags_tCB0634FAC6606D85C8B1A17F23D975EFB3FA14EF 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputActionState/InteractionState/Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_tCB0634FAC6606D85C8B1A17F23D975EFB3FA14EF, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputActionState/TriggerState/Flags
struct Flags_tADFA41097A1B647B40BF95C481A1AA2BD6475D02 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputActionState/TriggerState/Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_tADFA41097A1B647B40BF95C481A1AA2BD6475D02, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24
struct U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C  : public RuntimeObject
{
public:
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::<>1__state
	int32_t ___U3CU3E1__state_0;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::<>2__current
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___U3CU3E2__current_1;
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::<>l__initialThreadId
	int32_t ___U3CU3El__initialThreadId_2;
	// System.Boolean UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::includeSelf
	bool ___includeSelf_3;
	// System.Boolean UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::<>3__includeSelf
	bool ___U3CU3E3__includeSelf_4;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::layout
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___layout_5;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::<>3__layout
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___U3CU3E3__layout_6;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::<>4__this
	Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  ___U3CU3E4__this_7;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::<>3__<>4__this
	Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  ___U3CU3E3__U3CU3E4__this_8;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___U3CU3E2__current_1)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E2__current_1))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E2__current_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3El__initialThreadId_2() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___U3CU3El__initialThreadId_2)); }
	inline int32_t get_U3CU3El__initialThreadId_2() const { return ___U3CU3El__initialThreadId_2; }
	inline int32_t* get_address_of_U3CU3El__initialThreadId_2() { return &___U3CU3El__initialThreadId_2; }
	inline void set_U3CU3El__initialThreadId_2(int32_t value)
	{
		___U3CU3El__initialThreadId_2 = value;
	}

	inline static int32_t get_offset_of_includeSelf_3() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___includeSelf_3)); }
	inline bool get_includeSelf_3() const { return ___includeSelf_3; }
	inline bool* get_address_of_includeSelf_3() { return &___includeSelf_3; }
	inline void set_includeSelf_3(bool value)
	{
		___includeSelf_3 = value;
	}

	inline static int32_t get_offset_of_U3CU3E3__includeSelf_4() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___U3CU3E3__includeSelf_4)); }
	inline bool get_U3CU3E3__includeSelf_4() const { return ___U3CU3E3__includeSelf_4; }
	inline bool* get_address_of_U3CU3E3__includeSelf_4() { return &___U3CU3E3__includeSelf_4; }
	inline void set_U3CU3E3__includeSelf_4(bool value)
	{
		___U3CU3E3__includeSelf_4 = value;
	}

	inline static int32_t get_offset_of_layout_5() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___layout_5)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_layout_5() const { return ___layout_5; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_layout_5() { return &___layout_5; }
	inline void set_layout_5(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___layout_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___layout_5))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___layout_5))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E3__layout_6() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___U3CU3E3__layout_6)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_U3CU3E3__layout_6() const { return ___U3CU3E3__layout_6; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_U3CU3E3__layout_6() { return &___U3CU3E3__layout_6; }
	inline void set_U3CU3E3__layout_6(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___U3CU3E3__layout_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__layout_6))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__layout_6))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_7() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___U3CU3E4__this_7)); }
	inline Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  get_U3CU3E4__this_7() const { return ___U3CU3E4__this_7; }
	inline Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31 * get_address_of_U3CU3E4__this_7() { return &___U3CU3E4__this_7; }
	inline void set_U3CU3E4__this_7(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  value)
	{
		___U3CU3E4__this_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___layoutTypes_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___layoutStrings_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___layoutBuilders_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___baseLayoutTable_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___layoutOverrides_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___layoutOverrideNames_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___precompiledLayouts_7), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E4__this_7))->___layoutMatchers_8), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E3__U3CU3E4__this_8() { return static_cast<int32_t>(offsetof(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C, ___U3CU3E3__U3CU3E4__this_8)); }
	inline Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  get_U3CU3E3__U3CU3E4__this_8() const { return ___U3CU3E3__U3CU3E4__this_8; }
	inline Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31 * get_address_of_U3CU3E3__U3CU3E4__this_8() { return &___U3CU3E3__U3CU3E4__this_8; }
	inline void set_U3CU3E3__U3CU3E4__this_8(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  value)
	{
		___U3CU3E3__U3CU3E4__this_8 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___layoutTypes_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___layoutStrings_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___layoutBuilders_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___baseLayoutTable_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___layoutOverrides_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___layoutOverrideNames_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___precompiledLayouts_7), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3E3__U3CU3E4__this_8))->___layoutMatchers_8), (void*)NULL);
		#endif
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem/Flags
struct Flags_tA463B6113E628C3C75D5BDAFAFAA891080495684 
{
public:
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem/Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_tA463B6113E628C3C75D5BDAFAFAA891080495684, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement/Flags
struct Flags_t396980980AD826EDEE4DB8C5F7E415848599F9E1 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputControlScheme/DeviceRequirement/Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_t396980980AD826EDEE4DB8C5F7E415848599F9E1, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputControlScheme/MatchResult/Result
struct Result_t63EEFE168B001A89A8201C446EFB2A690B94140C 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputControlScheme/MatchResult/Result::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Result_t63EEFE168B001A89A8201C446EFB2A690B94140C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data
struct Data_t41908F253A54212287E75BDC32214CC67A6E46E5 
{
public:
	// System.String UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data::name
	String_t* ___name_0;
	// System.String UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data::layout
	String_t* ___layout_1;
	// System.Int32 UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data::deviceId
	int32_t ___deviceId_2;
	// System.String[] UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data::usages
	StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* ___usages_3;
	// UnityEngine.InputSystem.Layouts.InputDeviceDescription UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data::description
	InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA  ___description_4;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(Data_t41908F253A54212287E75BDC32214CC67A6E46E5, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___name_0), (void*)value);
	}

	inline static int32_t get_offset_of_layout_1() { return static_cast<int32_t>(offsetof(Data_t41908F253A54212287E75BDC32214CC67A6E46E5, ___layout_1)); }
	inline String_t* get_layout_1() const { return ___layout_1; }
	inline String_t** get_address_of_layout_1() { return &___layout_1; }
	inline void set_layout_1(String_t* value)
	{
		___layout_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___layout_1), (void*)value);
	}

	inline static int32_t get_offset_of_deviceId_2() { return static_cast<int32_t>(offsetof(Data_t41908F253A54212287E75BDC32214CC67A6E46E5, ___deviceId_2)); }
	inline int32_t get_deviceId_2() const { return ___deviceId_2; }
	inline int32_t* get_address_of_deviceId_2() { return &___deviceId_2; }
	inline void set_deviceId_2(int32_t value)
	{
		___deviceId_2 = value;
	}

	inline static int32_t get_offset_of_usages_3() { return static_cast<int32_t>(offsetof(Data_t41908F253A54212287E75BDC32214CC67A6E46E5, ___usages_3)); }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* get_usages_3() const { return ___usages_3; }
	inline StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A** get_address_of_usages_3() { return &___usages_3; }
	inline void set_usages_3(StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* value)
	{
		___usages_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___usages_3), (void*)value);
	}

	inline static int32_t get_offset_of_description_4() { return static_cast<int32_t>(offsetof(Data_t41908F253A54212287E75BDC32214CC67A6E46E5, ___description_4)); }
	inline InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA  get_description_4() const { return ___description_4; }
	inline InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA * get_address_of_description_4() { return &___description_4; }
	inline void set_description_4(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA  value)
	{
		___description_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___description_4))->___m_InterfaceName_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___description_4))->___m_DeviceClass_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___description_4))->___m_Manufacturer_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___description_4))->___m_Product_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___description_4))->___m_Serial_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___description_4))->___m_Version_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___description_4))->___m_Capabilities_6), (void*)NULL);
		#endif
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data
struct Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_pinvoke
{
	char* ___name_0;
	char* ___layout_1;
	int32_t ___deviceId_2;
	char** ___usages_3;
	InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_pinvoke ___description_4;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data
struct Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_com
{
	Il2CppChar* ___name_0;
	Il2CppChar* ___layout_1;
	int32_t ___deviceId_2;
	Il2CppChar** ___usages_3;
	InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_com ___description_4;
};

// Unity.Collections.NativeArray`1<System.Byte>
struct NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785 
{
public:
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;

public:
	inline static int32_t get_offset_of_m_Buffer_0() { return static_cast<int32_t>(offsetof(NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785, ___m_Buffer_0)); }
	inline void* get_m_Buffer_0() const { return ___m_Buffer_0; }
	inline void** get_address_of_m_Buffer_0() { return &___m_Buffer_0; }
	inline void set_m_Buffer_0(void* value)
	{
		___m_Buffer_0 = value;
	}

	inline static int32_t get_offset_of_m_Length_1() { return static_cast<int32_t>(offsetof(NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785, ___m_Length_1)); }
	inline int32_t get_m_Length_1() const { return ___m_Length_1; }
	inline int32_t* get_address_of_m_Length_1() { return &___m_Length_1; }
	inline void set_m_Length_1(int32_t value)
	{
		___m_Length_1 = value;
	}

	inline static int32_t get_offset_of_m_AllocatorLabel_2() { return static_cast<int32_t>(offsetof(NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785, ___m_AllocatorLabel_2)); }
	inline int32_t get_m_AllocatorLabel_2() const { return ___m_AllocatorLabel_2; }
	inline int32_t* get_address_of_m_AllocatorLabel_2() { return &___m_AllocatorLabel_2; }
	inline void set_m_AllocatorLabel_2(int32_t value)
	{
		___m_AllocatorLabel_2 = value;
	}
};


// Unity.Collections.NativeArray`1<System.UInt64>
struct NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B 
{
public:
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;

public:
	inline static int32_t get_offset_of_m_Buffer_0() { return static_cast<int32_t>(offsetof(NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B, ___m_Buffer_0)); }
	inline void* get_m_Buffer_0() const { return ___m_Buffer_0; }
	inline void** get_address_of_m_Buffer_0() { return &___m_Buffer_0; }
	inline void set_m_Buffer_0(void* value)
	{
		___m_Buffer_0 = value;
	}

	inline static int32_t get_offset_of_m_Length_1() { return static_cast<int32_t>(offsetof(NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B, ___m_Length_1)); }
	inline int32_t get_m_Length_1() const { return ___m_Length_1; }
	inline int32_t* get_address_of_m_Length_1() { return &___m_Length_1; }
	inline void set_m_Length_1(int32_t value)
	{
		___m_Length_1 = value;
	}

	inline static int32_t get_offset_of_m_AllocatorLabel_2() { return static_cast<int32_t>(offsetof(NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B, ___m_AllocatorLabel_2)); }
	inline int32_t get_m_AllocatorLabel_2() const { return ___m_AllocatorLabel_2; }
	inline int32_t* get_address_of_m_AllocatorLabel_2() { return &___m_AllocatorLabel_2; }
	inline void set_m_AllocatorLabel_2(int32_t value)
	{
		___m_AllocatorLabel_2 = value;
	}
};


// System.Nullable`1<UnityEngine.InputSystem.LowLevel.InputUpdateType>
struct Nullable_1_t6586DF2313941D6CC550CF19432868E82B7CF644 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t6586DF2313941D6CC550CF19432868E82B7CF644, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t6586DF2313941D6CC550CF19432868E82B7CF644, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};


// UnityEngine.Component
struct Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:

public:
};


// UnityEngine.GameObject
struct GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:

public:
};


// UnityEngine.InputSystem.Layouts.InputControlLayout
struct InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491  : public RuntimeObject
{
public:
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout::m_Name
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___m_Name_2;
	// System.Type UnityEngine.InputSystem.Layouts.InputControlLayout::m_Type
	Type_t * ___m_Type_3;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout::m_Variants
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___m_Variants_4;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.Layouts.InputControlLayout::m_StateFormat
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___m_StateFormat_5;
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout::m_StateSizeInBytes
	int32_t ___m_StateSizeInBytes_6;
	// System.Nullable`1<System.Boolean> UnityEngine.InputSystem.Layouts.InputControlLayout::m_UpdateBeforeRender
	Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3  ___m_UpdateBeforeRender_7;
	// UnityEngine.InputSystem.Utilities.InlinedArray`1<UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout::m_BaseLayouts
	InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287  ___m_BaseLayouts_8;
	// UnityEngine.InputSystem.Utilities.InlinedArray`1<UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout::m_AppliedOverrides
	InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287  ___m_AppliedOverrides_9;
	// UnityEngine.InputSystem.Utilities.InternedString[] UnityEngine.InputSystem.Layouts.InputControlLayout::m_CommonUsages
	InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___m_CommonUsages_10;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem[] UnityEngine.InputSystem.Layouts.InputControlLayout::m_Controls
	ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* ___m_Controls_11;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout::m_DisplayName
	String_t* ___m_DisplayName_12;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout::m_Description
	String_t* ___m_Description_13;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/Flags UnityEngine.InputSystem.Layouts.InputControlLayout::m_Flags
	int32_t ___m_Flags_14;

public:
	inline static int32_t get_offset_of_m_Name_2() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_Name_2)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_m_Name_2() const { return ___m_Name_2; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_m_Name_2() { return &___m_Name_2; }
	inline void set_m_Name_2(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___m_Name_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Name_2))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Name_2))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_Type_3() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_Type_3)); }
	inline Type_t * get_m_Type_3() const { return ___m_Type_3; }
	inline Type_t ** get_address_of_m_Type_3() { return &___m_Type_3; }
	inline void set_m_Type_3(Type_t * value)
	{
		___m_Type_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Type_3), (void*)value);
	}

	inline static int32_t get_offset_of_m_Variants_4() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_Variants_4)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_m_Variants_4() const { return ___m_Variants_4; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_m_Variants_4() { return &___m_Variants_4; }
	inline void set_m_Variants_4(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___m_Variants_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Variants_4))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Variants_4))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_StateFormat_5() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_StateFormat_5)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_m_StateFormat_5() const { return ___m_StateFormat_5; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_m_StateFormat_5() { return &___m_StateFormat_5; }
	inline void set_m_StateFormat_5(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___m_StateFormat_5 = value;
	}

	inline static int32_t get_offset_of_m_StateSizeInBytes_6() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_StateSizeInBytes_6)); }
	inline int32_t get_m_StateSizeInBytes_6() const { return ___m_StateSizeInBytes_6; }
	inline int32_t* get_address_of_m_StateSizeInBytes_6() { return &___m_StateSizeInBytes_6; }
	inline void set_m_StateSizeInBytes_6(int32_t value)
	{
		___m_StateSizeInBytes_6 = value;
	}

	inline static int32_t get_offset_of_m_UpdateBeforeRender_7() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_UpdateBeforeRender_7)); }
	inline Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3  get_m_UpdateBeforeRender_7() const { return ___m_UpdateBeforeRender_7; }
	inline Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3 * get_address_of_m_UpdateBeforeRender_7() { return &___m_UpdateBeforeRender_7; }
	inline void set_m_UpdateBeforeRender_7(Nullable_1_t1D1CD146BFCBDC2E53E1F700889F8C5C21063EF3  value)
	{
		___m_UpdateBeforeRender_7 = value;
	}

	inline static int32_t get_offset_of_m_BaseLayouts_8() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_BaseLayouts_8)); }
	inline InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287  get_m_BaseLayouts_8() const { return ___m_BaseLayouts_8; }
	inline InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287 * get_address_of_m_BaseLayouts_8() { return &___m_BaseLayouts_8; }
	inline void set_m_BaseLayouts_8(InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287  value)
	{
		___m_BaseLayouts_8 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_BaseLayouts_8))->___firstValue_1))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_BaseLayouts_8))->___firstValue_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_BaseLayouts_8))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_AppliedOverrides_9() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_AppliedOverrides_9)); }
	inline InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287  get_m_AppliedOverrides_9() const { return ___m_AppliedOverrides_9; }
	inline InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287 * get_address_of_m_AppliedOverrides_9() { return &___m_AppliedOverrides_9; }
	inline void set_m_AppliedOverrides_9(InlinedArray_1_t41F0A254C548513F8F3BC7509CF21C2227019287  value)
	{
		___m_AppliedOverrides_9 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_AppliedOverrides_9))->___firstValue_1))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_AppliedOverrides_9))->___firstValue_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_AppliedOverrides_9))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_CommonUsages_10() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_CommonUsages_10)); }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* get_m_CommonUsages_10() const { return ___m_CommonUsages_10; }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11** get_address_of_m_CommonUsages_10() { return &___m_CommonUsages_10; }
	inline void set_m_CommonUsages_10(InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* value)
	{
		___m_CommonUsages_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CommonUsages_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_Controls_11() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_Controls_11)); }
	inline ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* get_m_Controls_11() const { return ___m_Controls_11; }
	inline ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05** get_address_of_m_Controls_11() { return &___m_Controls_11; }
	inline void set_m_Controls_11(ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* value)
	{
		___m_Controls_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Controls_11), (void*)value);
	}

	inline static int32_t get_offset_of_m_DisplayName_12() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_DisplayName_12)); }
	inline String_t* get_m_DisplayName_12() const { return ___m_DisplayName_12; }
	inline String_t** get_address_of_m_DisplayName_12() { return &___m_DisplayName_12; }
	inline void set_m_DisplayName_12(String_t* value)
	{
		___m_DisplayName_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DisplayName_12), (void*)value);
	}

	inline static int32_t get_offset_of_m_Description_13() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_Description_13)); }
	inline String_t* get_m_Description_13() const { return ___m_Description_13; }
	inline String_t** get_address_of_m_Description_13() { return &___m_Description_13; }
	inline void set_m_Description_13(String_t* value)
	{
		___m_Description_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Description_13), (void*)value);
	}

	inline static int32_t get_offset_of_m_Flags_14() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491, ___m_Flags_14)); }
	inline int32_t get_m_Flags_14() const { return ___m_Flags_14; }
	inline int32_t* get_address_of_m_Flags_14() { return &___m_Flags_14; }
	inline void set_m_Flags_14(int32_t value)
	{
		___m_Flags_14 = value;
	}
};

struct InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491_StaticFields
{
public:
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout::s_DefaultVariant
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___s_DefaultVariant_0;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection UnityEngine.InputSystem.Layouts.InputControlLayout::s_Layouts
	Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  ___s_Layouts_15;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/Cache UnityEngine.InputSystem.Layouts.InputControlLayout::s_CacheInstance
	Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2  ___s_CacheInstance_16;
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout::s_CacheInstanceRef
	int32_t ___s_CacheInstanceRef_17;

public:
	inline static int32_t get_offset_of_s_DefaultVariant_0() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491_StaticFields, ___s_DefaultVariant_0)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_s_DefaultVariant_0() const { return ___s_DefaultVariant_0; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_s_DefaultVariant_0() { return &___s_DefaultVariant_0; }
	inline void set_s_DefaultVariant_0(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___s_DefaultVariant_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_DefaultVariant_0))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_DefaultVariant_0))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_s_Layouts_15() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491_StaticFields, ___s_Layouts_15)); }
	inline Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  get_s_Layouts_15() const { return ___s_Layouts_15; }
	inline Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31 * get_address_of_s_Layouts_15() { return &___s_Layouts_15; }
	inline void set_s_Layouts_15(Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  value)
	{
		___s_Layouts_15 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___layoutTypes_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___layoutStrings_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___layoutBuilders_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___baseLayoutTable_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___layoutOverrides_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___layoutOverrideNames_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___precompiledLayouts_7), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_Layouts_15))->___layoutMatchers_8), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_s_CacheInstance_16() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491_StaticFields, ___s_CacheInstance_16)); }
	inline Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2  get_s_CacheInstance_16() const { return ___s_CacheInstance_16; }
	inline Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2 * get_address_of_s_CacheInstance_16() { return &___s_CacheInstance_16; }
	inline void set_s_CacheInstance_16(Cache_tDBF13B62D0681E4D8D9BD441A0A6502C3A9058D2  value)
	{
		___s_CacheInstance_16 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_CacheInstance_16))->___table_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_s_CacheInstanceRef_17() { return static_cast<int32_t>(offsetof(InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491_StaticFields, ___s_CacheInstanceRef_17)); }
	inline int32_t get_s_CacheInstanceRef_17() const { return ___s_CacheInstanceRef_17; }
	inline int32_t* get_address_of_s_CacheInstanceRef_17() { return &___s_CacheInstanceRef_17; }
	inline void set_s_CacheInstanceRef_17(int32_t value)
	{
		___s_CacheInstanceRef_17 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.InputUpdate
struct InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77  : public RuntimeObject
{
public:

public:
};

struct InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_StaticFields
{
public:
	// System.UInt32 UnityEngine.InputSystem.LowLevel.InputUpdate::s_UpdateStepCount
	uint32_t ___s_UpdateStepCount_0;
	// UnityEngine.InputSystem.LowLevel.InputUpdateType UnityEngine.InputSystem.LowLevel.InputUpdate::s_LatestUpdateType
	int32_t ___s_LatestUpdateType_1;
	// UnityEngine.InputSystem.LowLevel.InputUpdate/UpdateStepCount UnityEngine.InputSystem.LowLevel.InputUpdate::s_PlayerUpdateStepCount
	UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98  ___s_PlayerUpdateStepCount_2;

public:
	inline static int32_t get_offset_of_s_UpdateStepCount_0() { return static_cast<int32_t>(offsetof(InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_StaticFields, ___s_UpdateStepCount_0)); }
	inline uint32_t get_s_UpdateStepCount_0() const { return ___s_UpdateStepCount_0; }
	inline uint32_t* get_address_of_s_UpdateStepCount_0() { return &___s_UpdateStepCount_0; }
	inline void set_s_UpdateStepCount_0(uint32_t value)
	{
		___s_UpdateStepCount_0 = value;
	}

	inline static int32_t get_offset_of_s_LatestUpdateType_1() { return static_cast<int32_t>(offsetof(InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_StaticFields, ___s_LatestUpdateType_1)); }
	inline int32_t get_s_LatestUpdateType_1() const { return ___s_LatestUpdateType_1; }
	inline int32_t* get_address_of_s_LatestUpdateType_1() { return &___s_LatestUpdateType_1; }
	inline void set_s_LatestUpdateType_1(int32_t value)
	{
		___s_LatestUpdateType_1 = value;
	}

	inline static int32_t get_offset_of_s_PlayerUpdateStepCount_2() { return static_cast<int32_t>(offsetof(InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_StaticFields, ___s_PlayerUpdateStepCount_2)); }
	inline UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98  get_s_PlayerUpdateStepCount_2() const { return ___s_PlayerUpdateStepCount_2; }
	inline UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98 * get_address_of_s_PlayerUpdateStepCount_2() { return &___s_PlayerUpdateStepCount_2; }
	inline void set_s_PlayerUpdateStepCount_2(UpdateStepCount_t661EEDB5F977D705225E0713CA8FDC547A95EE98  value)
	{
		___s_PlayerUpdateStepCount_2 = value;
	}
};


// System.MulticastDelegate
struct MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___delegates_11), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};

// UnityEngine.EventSystems.PointerEventData
struct PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954  : public BaseEventData_t722C48843CF21B50E06CC0E2E679415E38A7444E
{
public:
	// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::<pointerEnter>k__BackingField
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___U3CpointerEnterU3Ek__BackingField_2;
	// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::m_PointerPress
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_PointerPress_3;
	// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::<lastPress>k__BackingField
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___U3ClastPressU3Ek__BackingField_4;
	// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::<rawPointerPress>k__BackingField
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___U3CrawPointerPressU3Ek__BackingField_5;
	// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::<pointerDrag>k__BackingField
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___U3CpointerDragU3Ek__BackingField_6;
	// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::<pointerClick>k__BackingField
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___U3CpointerClickU3Ek__BackingField_7;
	// UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::<pointerCurrentRaycast>k__BackingField
	RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  ___U3CpointerCurrentRaycastU3Ek__BackingField_8;
	// UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::<pointerPressRaycast>k__BackingField
	RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  ___U3CpointerPressRaycastU3Ek__BackingField_9;
	// System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.EventSystems.PointerEventData::hovered
	List_1_t6D0A10F47F3440798295D2FFFC6D016477AF38E5 * ___hovered_10;
	// System.Boolean UnityEngine.EventSystems.PointerEventData::<eligibleForClick>k__BackingField
	bool ___U3CeligibleForClickU3Ek__BackingField_11;
	// System.Int32 UnityEngine.EventSystems.PointerEventData::<pointerId>k__BackingField
	int32_t ___U3CpointerIdU3Ek__BackingField_12;
	// UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::<position>k__BackingField
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___U3CpositionU3Ek__BackingField_13;
	// UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::<delta>k__BackingField
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___U3CdeltaU3Ek__BackingField_14;
	// UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::<pressPosition>k__BackingField
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___U3CpressPositionU3Ek__BackingField_15;
	// UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::<worldPosition>k__BackingField
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___U3CworldPositionU3Ek__BackingField_16;
	// UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::<worldNormal>k__BackingField
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___U3CworldNormalU3Ek__BackingField_17;
	// System.Single UnityEngine.EventSystems.PointerEventData::<clickTime>k__BackingField
	float ___U3CclickTimeU3Ek__BackingField_18;
	// System.Int32 UnityEngine.EventSystems.PointerEventData::<clickCount>k__BackingField
	int32_t ___U3CclickCountU3Ek__BackingField_19;
	// UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::<scrollDelta>k__BackingField
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___U3CscrollDeltaU3Ek__BackingField_20;
	// System.Boolean UnityEngine.EventSystems.PointerEventData::<useDragThreshold>k__BackingField
	bool ___U3CuseDragThresholdU3Ek__BackingField_21;
	// System.Boolean UnityEngine.EventSystems.PointerEventData::<dragging>k__BackingField
	bool ___U3CdraggingU3Ek__BackingField_22;
	// UnityEngine.EventSystems.PointerEventData/InputButton UnityEngine.EventSystems.PointerEventData::<button>k__BackingField
	int32_t ___U3CbuttonU3Ek__BackingField_23;

public:
	inline static int32_t get_offset_of_U3CpointerEnterU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpointerEnterU3Ek__BackingField_2)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_U3CpointerEnterU3Ek__BackingField_2() const { return ___U3CpointerEnterU3Ek__BackingField_2; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_U3CpointerEnterU3Ek__BackingField_2() { return &___U3CpointerEnterU3Ek__BackingField_2; }
	inline void set_U3CpointerEnterU3Ek__BackingField_2(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___U3CpointerEnterU3Ek__BackingField_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CpointerEnterU3Ek__BackingField_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_PointerPress_3() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___m_PointerPress_3)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_PointerPress_3() const { return ___m_PointerPress_3; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_PointerPress_3() { return &___m_PointerPress_3; }
	inline void set_m_PointerPress_3(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_PointerPress_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_PointerPress_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3ClastPressU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3ClastPressU3Ek__BackingField_4)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_U3ClastPressU3Ek__BackingField_4() const { return ___U3ClastPressU3Ek__BackingField_4; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_U3ClastPressU3Ek__BackingField_4() { return &___U3ClastPressU3Ek__BackingField_4; }
	inline void set_U3ClastPressU3Ek__BackingField_4(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___U3ClastPressU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3ClastPressU3Ek__BackingField_4), (void*)value);
	}

	inline static int32_t get_offset_of_U3CrawPointerPressU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CrawPointerPressU3Ek__BackingField_5)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_U3CrawPointerPressU3Ek__BackingField_5() const { return ___U3CrawPointerPressU3Ek__BackingField_5; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_U3CrawPointerPressU3Ek__BackingField_5() { return &___U3CrawPointerPressU3Ek__BackingField_5; }
	inline void set_U3CrawPointerPressU3Ek__BackingField_5(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___U3CrawPointerPressU3Ek__BackingField_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CrawPointerPressU3Ek__BackingField_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CpointerDragU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpointerDragU3Ek__BackingField_6)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_U3CpointerDragU3Ek__BackingField_6() const { return ___U3CpointerDragU3Ek__BackingField_6; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_U3CpointerDragU3Ek__BackingField_6() { return &___U3CpointerDragU3Ek__BackingField_6; }
	inline void set_U3CpointerDragU3Ek__BackingField_6(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___U3CpointerDragU3Ek__BackingField_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CpointerDragU3Ek__BackingField_6), (void*)value);
	}

	inline static int32_t get_offset_of_U3CpointerClickU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpointerClickU3Ek__BackingField_7)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_U3CpointerClickU3Ek__BackingField_7() const { return ___U3CpointerClickU3Ek__BackingField_7; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_U3CpointerClickU3Ek__BackingField_7() { return &___U3CpointerClickU3Ek__BackingField_7; }
	inline void set_U3CpointerClickU3Ek__BackingField_7(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___U3CpointerClickU3Ek__BackingField_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CpointerClickU3Ek__BackingField_7), (void*)value);
	}

	inline static int32_t get_offset_of_U3CpointerCurrentRaycastU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpointerCurrentRaycastU3Ek__BackingField_8)); }
	inline RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  get_U3CpointerCurrentRaycastU3Ek__BackingField_8() const { return ___U3CpointerCurrentRaycastU3Ek__BackingField_8; }
	inline RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE * get_address_of_U3CpointerCurrentRaycastU3Ek__BackingField_8() { return &___U3CpointerCurrentRaycastU3Ek__BackingField_8; }
	inline void set_U3CpointerCurrentRaycastU3Ek__BackingField_8(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  value)
	{
		___U3CpointerCurrentRaycastU3Ek__BackingField_8 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CpointerCurrentRaycastU3Ek__BackingField_8))->___m_GameObject_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CpointerCurrentRaycastU3Ek__BackingField_8))->___module_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CpointerPressRaycastU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpointerPressRaycastU3Ek__BackingField_9)); }
	inline RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  get_U3CpointerPressRaycastU3Ek__BackingField_9() const { return ___U3CpointerPressRaycastU3Ek__BackingField_9; }
	inline RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE * get_address_of_U3CpointerPressRaycastU3Ek__BackingField_9() { return &___U3CpointerPressRaycastU3Ek__BackingField_9; }
	inline void set_U3CpointerPressRaycastU3Ek__BackingField_9(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  value)
	{
		___U3CpointerPressRaycastU3Ek__BackingField_9 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CpointerPressRaycastU3Ek__BackingField_9))->___m_GameObject_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CpointerPressRaycastU3Ek__BackingField_9))->___module_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_hovered_10() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___hovered_10)); }
	inline List_1_t6D0A10F47F3440798295D2FFFC6D016477AF38E5 * get_hovered_10() const { return ___hovered_10; }
	inline List_1_t6D0A10F47F3440798295D2FFFC6D016477AF38E5 ** get_address_of_hovered_10() { return &___hovered_10; }
	inline void set_hovered_10(List_1_t6D0A10F47F3440798295D2FFFC6D016477AF38E5 * value)
	{
		___hovered_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___hovered_10), (void*)value);
	}

	inline static int32_t get_offset_of_U3CeligibleForClickU3Ek__BackingField_11() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CeligibleForClickU3Ek__BackingField_11)); }
	inline bool get_U3CeligibleForClickU3Ek__BackingField_11() const { return ___U3CeligibleForClickU3Ek__BackingField_11; }
	inline bool* get_address_of_U3CeligibleForClickU3Ek__BackingField_11() { return &___U3CeligibleForClickU3Ek__BackingField_11; }
	inline void set_U3CeligibleForClickU3Ek__BackingField_11(bool value)
	{
		___U3CeligibleForClickU3Ek__BackingField_11 = value;
	}

	inline static int32_t get_offset_of_U3CpointerIdU3Ek__BackingField_12() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpointerIdU3Ek__BackingField_12)); }
	inline int32_t get_U3CpointerIdU3Ek__BackingField_12() const { return ___U3CpointerIdU3Ek__BackingField_12; }
	inline int32_t* get_address_of_U3CpointerIdU3Ek__BackingField_12() { return &___U3CpointerIdU3Ek__BackingField_12; }
	inline void set_U3CpointerIdU3Ek__BackingField_12(int32_t value)
	{
		___U3CpointerIdU3Ek__BackingField_12 = value;
	}

	inline static int32_t get_offset_of_U3CpositionU3Ek__BackingField_13() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpositionU3Ek__BackingField_13)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_U3CpositionU3Ek__BackingField_13() const { return ___U3CpositionU3Ek__BackingField_13; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_U3CpositionU3Ek__BackingField_13() { return &___U3CpositionU3Ek__BackingField_13; }
	inline void set_U3CpositionU3Ek__BackingField_13(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___U3CpositionU3Ek__BackingField_13 = value;
	}

	inline static int32_t get_offset_of_U3CdeltaU3Ek__BackingField_14() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CdeltaU3Ek__BackingField_14)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_U3CdeltaU3Ek__BackingField_14() const { return ___U3CdeltaU3Ek__BackingField_14; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_U3CdeltaU3Ek__BackingField_14() { return &___U3CdeltaU3Ek__BackingField_14; }
	inline void set_U3CdeltaU3Ek__BackingField_14(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___U3CdeltaU3Ek__BackingField_14 = value;
	}

	inline static int32_t get_offset_of_U3CpressPositionU3Ek__BackingField_15() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CpressPositionU3Ek__BackingField_15)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_U3CpressPositionU3Ek__BackingField_15() const { return ___U3CpressPositionU3Ek__BackingField_15; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_U3CpressPositionU3Ek__BackingField_15() { return &___U3CpressPositionU3Ek__BackingField_15; }
	inline void set_U3CpressPositionU3Ek__BackingField_15(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___U3CpressPositionU3Ek__BackingField_15 = value;
	}

	inline static int32_t get_offset_of_U3CworldPositionU3Ek__BackingField_16() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CworldPositionU3Ek__BackingField_16)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_U3CworldPositionU3Ek__BackingField_16() const { return ___U3CworldPositionU3Ek__BackingField_16; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_U3CworldPositionU3Ek__BackingField_16() { return &___U3CworldPositionU3Ek__BackingField_16; }
	inline void set_U3CworldPositionU3Ek__BackingField_16(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___U3CworldPositionU3Ek__BackingField_16 = value;
	}

	inline static int32_t get_offset_of_U3CworldNormalU3Ek__BackingField_17() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CworldNormalU3Ek__BackingField_17)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_U3CworldNormalU3Ek__BackingField_17() const { return ___U3CworldNormalU3Ek__BackingField_17; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_U3CworldNormalU3Ek__BackingField_17() { return &___U3CworldNormalU3Ek__BackingField_17; }
	inline void set_U3CworldNormalU3Ek__BackingField_17(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___U3CworldNormalU3Ek__BackingField_17 = value;
	}

	inline static int32_t get_offset_of_U3CclickTimeU3Ek__BackingField_18() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CclickTimeU3Ek__BackingField_18)); }
	inline float get_U3CclickTimeU3Ek__BackingField_18() const { return ___U3CclickTimeU3Ek__BackingField_18; }
	inline float* get_address_of_U3CclickTimeU3Ek__BackingField_18() { return &___U3CclickTimeU3Ek__BackingField_18; }
	inline void set_U3CclickTimeU3Ek__BackingField_18(float value)
	{
		___U3CclickTimeU3Ek__BackingField_18 = value;
	}

	inline static int32_t get_offset_of_U3CclickCountU3Ek__BackingField_19() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CclickCountU3Ek__BackingField_19)); }
	inline int32_t get_U3CclickCountU3Ek__BackingField_19() const { return ___U3CclickCountU3Ek__BackingField_19; }
	inline int32_t* get_address_of_U3CclickCountU3Ek__BackingField_19() { return &___U3CclickCountU3Ek__BackingField_19; }
	inline void set_U3CclickCountU3Ek__BackingField_19(int32_t value)
	{
		___U3CclickCountU3Ek__BackingField_19 = value;
	}

	inline static int32_t get_offset_of_U3CscrollDeltaU3Ek__BackingField_20() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CscrollDeltaU3Ek__BackingField_20)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_U3CscrollDeltaU3Ek__BackingField_20() const { return ___U3CscrollDeltaU3Ek__BackingField_20; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_U3CscrollDeltaU3Ek__BackingField_20() { return &___U3CscrollDeltaU3Ek__BackingField_20; }
	inline void set_U3CscrollDeltaU3Ek__BackingField_20(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___U3CscrollDeltaU3Ek__BackingField_20 = value;
	}

	inline static int32_t get_offset_of_U3CuseDragThresholdU3Ek__BackingField_21() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CuseDragThresholdU3Ek__BackingField_21)); }
	inline bool get_U3CuseDragThresholdU3Ek__BackingField_21() const { return ___U3CuseDragThresholdU3Ek__BackingField_21; }
	inline bool* get_address_of_U3CuseDragThresholdU3Ek__BackingField_21() { return &___U3CuseDragThresholdU3Ek__BackingField_21; }
	inline void set_U3CuseDragThresholdU3Ek__BackingField_21(bool value)
	{
		___U3CuseDragThresholdU3Ek__BackingField_21 = value;
	}

	inline static int32_t get_offset_of_U3CdraggingU3Ek__BackingField_22() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CdraggingU3Ek__BackingField_22)); }
	inline bool get_U3CdraggingU3Ek__BackingField_22() const { return ___U3CdraggingU3Ek__BackingField_22; }
	inline bool* get_address_of_U3CdraggingU3Ek__BackingField_22() { return &___U3CdraggingU3Ek__BackingField_22; }
	inline void set_U3CdraggingU3Ek__BackingField_22(bool value)
	{
		___U3CdraggingU3Ek__BackingField_22 = value;
	}

	inline static int32_t get_offset_of_U3CbuttonU3Ek__BackingField_23() { return static_cast<int32_t>(offsetof(PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954, ___U3CbuttonU3Ek__BackingField_23)); }
	inline int32_t get_U3CbuttonU3Ek__BackingField_23() const { return ___U3CbuttonU3Ek__BackingField_23; }
	inline int32_t* get_address_of_U3CbuttonU3Ek__BackingField_23() { return &___U3CbuttonU3Ek__BackingField_23; }
	inline void set_U3CbuttonU3Ek__BackingField_23(int32_t value)
	{
		___U3CbuttonU3Ek__BackingField_23 = value;
	}
};


// UnityEngine.InputSystem.Utilities.PrimitiveValue
struct PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA 
{
public:
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.TypeCode UnityEngine.InputSystem.Utilities.PrimitiveValue::m_Type
			int32_t ___m_Type_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___m_Type_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding[4];
			// System.Boolean UnityEngine.InputSystem.Utilities.PrimitiveValue::m_BoolValue
			bool ___m_BoolValue_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding_forAlignmentOnly[4];
			bool ___m_BoolValue_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_CharValue_2_OffsetPadding[4];
			// System.Char UnityEngine.InputSystem.Utilities.PrimitiveValue::m_CharValue
			Il2CppChar ___m_CharValue_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_CharValue_2_OffsetPadding_forAlignmentOnly[4];
			Il2CppChar ___m_CharValue_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding[4];
			// System.Byte UnityEngine.InputSystem.Utilities.PrimitiveValue::m_ByteValue
			uint8_t ___m_ByteValue_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_ByteValue_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding[4];
			// System.SByte UnityEngine.InputSystem.Utilities.PrimitiveValue::m_SByteValue
			int8_t ___m_SByteValue_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding_forAlignmentOnly[4];
			int8_t ___m_SByteValue_4_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding[4];
			// System.Int16 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_ShortValue
			int16_t ___m_ShortValue_5;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding_forAlignmentOnly[4];
			int16_t ___m_ShortValue_5_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding[4];
			// System.UInt16 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_UShortValue
			uint16_t ___m_UShortValue_6;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding_forAlignmentOnly[4];
			uint16_t ___m_UShortValue_6_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_IntValue_7_OffsetPadding[4];
			// System.Int32 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_IntValue
			int32_t ___m_IntValue_7;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_IntValue_7_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_IntValue_7_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding[4];
			// System.UInt32 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_UIntValue
			uint32_t ___m_UIntValue_8;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding_forAlignmentOnly[4];
			uint32_t ___m_UIntValue_8_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_LongValue_9_OffsetPadding[4];
			// System.Int64 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_LongValue
			int64_t ___m_LongValue_9;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_LongValue_9_OffsetPadding_forAlignmentOnly[4];
			int64_t ___m_LongValue_9_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding[4];
			// System.UInt64 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_ULongValue
			uint64_t ___m_ULongValue_10;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding_forAlignmentOnly[4];
			uint64_t ___m_ULongValue_10_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding[4];
			// System.Single UnityEngine.InputSystem.Utilities.PrimitiveValue::m_FloatValue
			float ___m_FloatValue_11;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding_forAlignmentOnly[4];
			float ___m_FloatValue_11_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding[4];
			// System.Double UnityEngine.InputSystem.Utilities.PrimitiveValue::m_DoubleValue
			double ___m_DoubleValue_12;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding_forAlignmentOnly[4];
			double ___m_DoubleValue_12_forAlignmentOnly;
		};
	};

public:
	inline static int32_t get_offset_of_m_Type_0() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_Type_0)); }
	inline int32_t get_m_Type_0() const { return ___m_Type_0; }
	inline int32_t* get_address_of_m_Type_0() { return &___m_Type_0; }
	inline void set_m_Type_0(int32_t value)
	{
		___m_Type_0 = value;
	}

	inline static int32_t get_offset_of_m_BoolValue_1() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_BoolValue_1)); }
	inline bool get_m_BoolValue_1() const { return ___m_BoolValue_1; }
	inline bool* get_address_of_m_BoolValue_1() { return &___m_BoolValue_1; }
	inline void set_m_BoolValue_1(bool value)
	{
		___m_BoolValue_1 = value;
	}

	inline static int32_t get_offset_of_m_CharValue_2() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_CharValue_2)); }
	inline Il2CppChar get_m_CharValue_2() const { return ___m_CharValue_2; }
	inline Il2CppChar* get_address_of_m_CharValue_2() { return &___m_CharValue_2; }
	inline void set_m_CharValue_2(Il2CppChar value)
	{
		___m_CharValue_2 = value;
	}

	inline static int32_t get_offset_of_m_ByteValue_3() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_ByteValue_3)); }
	inline uint8_t get_m_ByteValue_3() const { return ___m_ByteValue_3; }
	inline uint8_t* get_address_of_m_ByteValue_3() { return &___m_ByteValue_3; }
	inline void set_m_ByteValue_3(uint8_t value)
	{
		___m_ByteValue_3 = value;
	}

	inline static int32_t get_offset_of_m_SByteValue_4() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_SByteValue_4)); }
	inline int8_t get_m_SByteValue_4() const { return ___m_SByteValue_4; }
	inline int8_t* get_address_of_m_SByteValue_4() { return &___m_SByteValue_4; }
	inline void set_m_SByteValue_4(int8_t value)
	{
		___m_SByteValue_4 = value;
	}

	inline static int32_t get_offset_of_m_ShortValue_5() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_ShortValue_5)); }
	inline int16_t get_m_ShortValue_5() const { return ___m_ShortValue_5; }
	inline int16_t* get_address_of_m_ShortValue_5() { return &___m_ShortValue_5; }
	inline void set_m_ShortValue_5(int16_t value)
	{
		___m_ShortValue_5 = value;
	}

	inline static int32_t get_offset_of_m_UShortValue_6() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_UShortValue_6)); }
	inline uint16_t get_m_UShortValue_6() const { return ___m_UShortValue_6; }
	inline uint16_t* get_address_of_m_UShortValue_6() { return &___m_UShortValue_6; }
	inline void set_m_UShortValue_6(uint16_t value)
	{
		___m_UShortValue_6 = value;
	}

	inline static int32_t get_offset_of_m_IntValue_7() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_IntValue_7)); }
	inline int32_t get_m_IntValue_7() const { return ___m_IntValue_7; }
	inline int32_t* get_address_of_m_IntValue_7() { return &___m_IntValue_7; }
	inline void set_m_IntValue_7(int32_t value)
	{
		___m_IntValue_7 = value;
	}

	inline static int32_t get_offset_of_m_UIntValue_8() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_UIntValue_8)); }
	inline uint32_t get_m_UIntValue_8() const { return ___m_UIntValue_8; }
	inline uint32_t* get_address_of_m_UIntValue_8() { return &___m_UIntValue_8; }
	inline void set_m_UIntValue_8(uint32_t value)
	{
		___m_UIntValue_8 = value;
	}

	inline static int32_t get_offset_of_m_LongValue_9() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_LongValue_9)); }
	inline int64_t get_m_LongValue_9() const { return ___m_LongValue_9; }
	inline int64_t* get_address_of_m_LongValue_9() { return &___m_LongValue_9; }
	inline void set_m_LongValue_9(int64_t value)
	{
		___m_LongValue_9 = value;
	}

	inline static int32_t get_offset_of_m_ULongValue_10() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_ULongValue_10)); }
	inline uint64_t get_m_ULongValue_10() const { return ___m_ULongValue_10; }
	inline uint64_t* get_address_of_m_ULongValue_10() { return &___m_ULongValue_10; }
	inline void set_m_ULongValue_10(uint64_t value)
	{
		___m_ULongValue_10 = value;
	}

	inline static int32_t get_offset_of_m_FloatValue_11() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_FloatValue_11)); }
	inline float get_m_FloatValue_11() const { return ___m_FloatValue_11; }
	inline float* get_address_of_m_FloatValue_11() { return &___m_FloatValue_11; }
	inline void set_m_FloatValue_11(float value)
	{
		___m_FloatValue_11 = value;
	}

	inline static int32_t get_offset_of_m_DoubleValue_12() { return static_cast<int32_t>(offsetof(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA, ___m_DoubleValue_12)); }
	inline double get_m_DoubleValue_12() const { return ___m_DoubleValue_12; }
	inline double* get_address_of_m_DoubleValue_12() { return &___m_DoubleValue_12; }
	inline void set_m_DoubleValue_12(double value)
	{
		___m_DoubleValue_12 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.PrimitiveValue
struct PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_pinvoke
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			int32_t ___m_Type_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___m_Type_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding[4];
			int32_t ___m_BoolValue_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_BoolValue_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_CharValue_2_OffsetPadding[4];
			uint8_t ___m_CharValue_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_CharValue_2_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_CharValue_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding[4];
			uint8_t ___m_ByteValue_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_ByteValue_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding[4];
			int8_t ___m_SByteValue_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding_forAlignmentOnly[4];
			int8_t ___m_SByteValue_4_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding[4];
			int16_t ___m_ShortValue_5;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding_forAlignmentOnly[4];
			int16_t ___m_ShortValue_5_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding[4];
			uint16_t ___m_UShortValue_6;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding_forAlignmentOnly[4];
			uint16_t ___m_UShortValue_6_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_IntValue_7_OffsetPadding[4];
			int32_t ___m_IntValue_7;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_IntValue_7_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_IntValue_7_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding[4];
			uint32_t ___m_UIntValue_8;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding_forAlignmentOnly[4];
			uint32_t ___m_UIntValue_8_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_LongValue_9_OffsetPadding[4];
			int64_t ___m_LongValue_9;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_LongValue_9_OffsetPadding_forAlignmentOnly[4];
			int64_t ___m_LongValue_9_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding[4];
			uint64_t ___m_ULongValue_10;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding_forAlignmentOnly[4];
			uint64_t ___m_ULongValue_10_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding[4];
			float ___m_FloatValue_11;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding_forAlignmentOnly[4];
			float ___m_FloatValue_11_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding[4];
			double ___m_DoubleValue_12;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding_forAlignmentOnly[4];
			double ___m_DoubleValue_12_forAlignmentOnly;
		};
	};
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.PrimitiveValue
struct PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_com
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			int32_t ___m_Type_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___m_Type_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding[4];
			int32_t ___m_BoolValue_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_BoolValue_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_CharValue_2_OffsetPadding[4];
			uint8_t ___m_CharValue_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_CharValue_2_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_CharValue_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding[4];
			uint8_t ___m_ByteValue_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_ByteValue_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding[4];
			int8_t ___m_SByteValue_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding_forAlignmentOnly[4];
			int8_t ___m_SByteValue_4_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding[4];
			int16_t ___m_ShortValue_5;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding_forAlignmentOnly[4];
			int16_t ___m_ShortValue_5_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding[4];
			uint16_t ___m_UShortValue_6;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding_forAlignmentOnly[4];
			uint16_t ___m_UShortValue_6_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_IntValue_7_OffsetPadding[4];
			int32_t ___m_IntValue_7;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_IntValue_7_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_IntValue_7_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding[4];
			uint32_t ___m_UIntValue_8;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding_forAlignmentOnly[4];
			uint32_t ___m_UIntValue_8_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_LongValue_9_OffsetPadding[4];
			int64_t ___m_LongValue_9;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_LongValue_9_OffsetPadding_forAlignmentOnly[4];
			int64_t ___m_LongValue_9_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding[4];
			uint64_t ___m_ULongValue_10;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding_forAlignmentOnly[4];
			uint64_t ___m_ULongValue_10_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding[4];
			float ___m_FloatValue_11;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding_forAlignmentOnly[4];
			float ___m_FloatValue_11_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding[4];
			double ___m_DoubleValue_12;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding_forAlignmentOnly[4];
			double ___m_DoubleValue_12_forAlignmentOnly;
		};
	};
};

// UnityEngine.ScriptableObject
struct ScriptableObject_t4361E08CEBF052C650D3666C7CEC37EB31DE116A  : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A
{
public:

public:
};

// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_t4361E08CEBF052C650D3666C7CEC37EB31DE116A_marshaled_pinvoke : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_t4361E08CEBF052C650D3666C7CEC37EB31DE116A_marshaled_com : public Object_tF2F3778131EFF286AF62B7B013A170F95A91571A_marshaled_com
{
};

// System.SystemException
struct SystemException_tC551B4D6EE3772B5F32C71EE8C719F4B43ECCC62  : public Exception_t
{
public:

public:
};


// UnityEngine.InputSystem.HID.HID/HIDElementDescriptor
struct HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48 
{
public:
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::usage
	int32_t ___usage_0;
	// UnityEngine.InputSystem.HID.HID/UsagePage UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::usagePage
	int32_t ___usagePage_1;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::unit
	int32_t ___unit_2;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::unitExponent
	int32_t ___unitExponent_3;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::logicalMin
	int32_t ___logicalMin_4;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::logicalMax
	int32_t ___logicalMax_5;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::physicalMin
	int32_t ___physicalMin_6;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::physicalMax
	int32_t ___physicalMax_7;
	// UnityEngine.InputSystem.HID.HID/HIDReportType UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::reportType
	int32_t ___reportType_8;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::collectionIndex
	int32_t ___collectionIndex_9;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::reportId
	int32_t ___reportId_10;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::reportSizeInBits
	int32_t ___reportSizeInBits_11;
	// System.Int32 UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::reportOffsetInBits
	int32_t ___reportOffsetInBits_12;
	// UnityEngine.InputSystem.HID.HID/HIDElementFlags UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::flags
	int32_t ___flags_13;
	// System.Nullable`1<System.Int32> UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::usageMin
	Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___usageMin_14;
	// System.Nullable`1<System.Int32> UnityEngine.InputSystem.HID.HID/HIDElementDescriptor::usageMax
	Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___usageMax_15;

public:
	inline static int32_t get_offset_of_usage_0() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___usage_0)); }
	inline int32_t get_usage_0() const { return ___usage_0; }
	inline int32_t* get_address_of_usage_0() { return &___usage_0; }
	inline void set_usage_0(int32_t value)
	{
		___usage_0 = value;
	}

	inline static int32_t get_offset_of_usagePage_1() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___usagePage_1)); }
	inline int32_t get_usagePage_1() const { return ___usagePage_1; }
	inline int32_t* get_address_of_usagePage_1() { return &___usagePage_1; }
	inline void set_usagePage_1(int32_t value)
	{
		___usagePage_1 = value;
	}

	inline static int32_t get_offset_of_unit_2() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___unit_2)); }
	inline int32_t get_unit_2() const { return ___unit_2; }
	inline int32_t* get_address_of_unit_2() { return &___unit_2; }
	inline void set_unit_2(int32_t value)
	{
		___unit_2 = value;
	}

	inline static int32_t get_offset_of_unitExponent_3() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___unitExponent_3)); }
	inline int32_t get_unitExponent_3() const { return ___unitExponent_3; }
	inline int32_t* get_address_of_unitExponent_3() { return &___unitExponent_3; }
	inline void set_unitExponent_3(int32_t value)
	{
		___unitExponent_3 = value;
	}

	inline static int32_t get_offset_of_logicalMin_4() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___logicalMin_4)); }
	inline int32_t get_logicalMin_4() const { return ___logicalMin_4; }
	inline int32_t* get_address_of_logicalMin_4() { return &___logicalMin_4; }
	inline void set_logicalMin_4(int32_t value)
	{
		___logicalMin_4 = value;
	}

	inline static int32_t get_offset_of_logicalMax_5() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___logicalMax_5)); }
	inline int32_t get_logicalMax_5() const { return ___logicalMax_5; }
	inline int32_t* get_address_of_logicalMax_5() { return &___logicalMax_5; }
	inline void set_logicalMax_5(int32_t value)
	{
		___logicalMax_5 = value;
	}

	inline static int32_t get_offset_of_physicalMin_6() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___physicalMin_6)); }
	inline int32_t get_physicalMin_6() const { return ___physicalMin_6; }
	inline int32_t* get_address_of_physicalMin_6() { return &___physicalMin_6; }
	inline void set_physicalMin_6(int32_t value)
	{
		___physicalMin_6 = value;
	}

	inline static int32_t get_offset_of_physicalMax_7() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___physicalMax_7)); }
	inline int32_t get_physicalMax_7() const { return ___physicalMax_7; }
	inline int32_t* get_address_of_physicalMax_7() { return &___physicalMax_7; }
	inline void set_physicalMax_7(int32_t value)
	{
		___physicalMax_7 = value;
	}

	inline static int32_t get_offset_of_reportType_8() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___reportType_8)); }
	inline int32_t get_reportType_8() const { return ___reportType_8; }
	inline int32_t* get_address_of_reportType_8() { return &___reportType_8; }
	inline void set_reportType_8(int32_t value)
	{
		___reportType_8 = value;
	}

	inline static int32_t get_offset_of_collectionIndex_9() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___collectionIndex_9)); }
	inline int32_t get_collectionIndex_9() const { return ___collectionIndex_9; }
	inline int32_t* get_address_of_collectionIndex_9() { return &___collectionIndex_9; }
	inline void set_collectionIndex_9(int32_t value)
	{
		___collectionIndex_9 = value;
	}

	inline static int32_t get_offset_of_reportId_10() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___reportId_10)); }
	inline int32_t get_reportId_10() const { return ___reportId_10; }
	inline int32_t* get_address_of_reportId_10() { return &___reportId_10; }
	inline void set_reportId_10(int32_t value)
	{
		___reportId_10 = value;
	}

	inline static int32_t get_offset_of_reportSizeInBits_11() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___reportSizeInBits_11)); }
	inline int32_t get_reportSizeInBits_11() const { return ___reportSizeInBits_11; }
	inline int32_t* get_address_of_reportSizeInBits_11() { return &___reportSizeInBits_11; }
	inline void set_reportSizeInBits_11(int32_t value)
	{
		___reportSizeInBits_11 = value;
	}

	inline static int32_t get_offset_of_reportOffsetInBits_12() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___reportOffsetInBits_12)); }
	inline int32_t get_reportOffsetInBits_12() const { return ___reportOffsetInBits_12; }
	inline int32_t* get_address_of_reportOffsetInBits_12() { return &___reportOffsetInBits_12; }
	inline void set_reportOffsetInBits_12(int32_t value)
	{
		___reportOffsetInBits_12 = value;
	}

	inline static int32_t get_offset_of_flags_13() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___flags_13)); }
	inline int32_t get_flags_13() const { return ___flags_13; }
	inline int32_t* get_address_of_flags_13() { return &___flags_13; }
	inline void set_flags_13(int32_t value)
	{
		___flags_13 = value;
	}

	inline static int32_t get_offset_of_usageMin_14() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___usageMin_14)); }
	inline Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  get_usageMin_14() const { return ___usageMin_14; }
	inline Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103 * get_address_of_usageMin_14() { return &___usageMin_14; }
	inline void set_usageMin_14(Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  value)
	{
		___usageMin_14 = value;
	}

	inline static int32_t get_offset_of_usageMax_15() { return static_cast<int32_t>(offsetof(HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48, ___usageMax_15)); }
	inline Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  get_usageMax_15() const { return ___usageMax_15; }
	inline Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103 * get_address_of_usageMax_15() { return &___usageMax_15; }
	inline void set_usageMax_15(Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  value)
	{
		___usageMax_15 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.HID.HID/HIDElementDescriptor
struct HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48_marshaled_pinvoke
{
	int32_t ___usage_0;
	int32_t ___usagePage_1;
	int32_t ___unit_2;
	int32_t ___unitExponent_3;
	int32_t ___logicalMin_4;
	int32_t ___logicalMax_5;
	int32_t ___physicalMin_6;
	int32_t ___physicalMax_7;
	int32_t ___reportType_8;
	int32_t ___collectionIndex_9;
	int32_t ___reportId_10;
	int32_t ___reportSizeInBits_11;
	int32_t ___reportOffsetInBits_12;
	int32_t ___flags_13;
	Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___usageMin_14;
	Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___usageMax_15;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.HID.HID/HIDElementDescriptor
struct HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48_marshaled_com
{
	int32_t ___usage_0;
	int32_t ___usagePage_1;
	int32_t ___unit_2;
	int32_t ___unitExponent_3;
	int32_t ___logicalMin_4;
	int32_t ___logicalMax_5;
	int32_t ___physicalMin_6;
	int32_t ___physicalMax_7;
	int32_t ___reportType_8;
	int32_t ___collectionIndex_9;
	int32_t ___reportId_10;
	int32_t ___reportSizeInBits_11;
	int32_t ___reportOffsetInBits_12;
	int32_t ___flags_13;
	Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___usageMin_14;
	Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___usageMax_15;
};

// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 
{
public:
	// System.String UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::m_ControlPath
	String_t* ___m_ControlPath_0;
	// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement/Flags UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::m_Flags
	int32_t ___m_Flags_1;

public:
	inline static int32_t get_offset_of_m_ControlPath_0() { return static_cast<int32_t>(offsetof(DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807, ___m_ControlPath_0)); }
	inline String_t* get_m_ControlPath_0() const { return ___m_ControlPath_0; }
	inline String_t** get_address_of_m_ControlPath_0() { return &___m_ControlPath_0; }
	inline void set_m_ControlPath_0(String_t* value)
	{
		___m_ControlPath_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ControlPath_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_Flags_1() { return static_cast<int32_t>(offsetof(DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807, ___m_Flags_1)); }
	inline int32_t get_m_Flags_1() const { return ___m_Flags_1; }
	inline int32_t* get_address_of_m_Flags_1() { return &___m_Flags_1; }
	inline void set_m_Flags_1(int32_t value)
	{
		___m_Flags_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputControlScheme/DeviceRequirement
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke
{
	char* ___m_ControlPath_0;
	int32_t ___m_Flags_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputControlScheme/DeviceRequirement
struct DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com
{
	Il2CppChar* ___m_ControlPath_0;
	int32_t ___m_Flags_1;
};

// UnityEngine.InputSystem.Utilities.JsonParser/JsonValue
struct JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F 
{
public:
	// UnityEngine.InputSystem.Utilities.JsonParser/JsonValueType UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::type
	int32_t ___type_0;
	// System.Boolean UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::boolValue
	bool ___boolValue_1;
	// System.Double UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::realValue
	double ___realValue_2;
	// System.Int64 UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::integerValue
	int64_t ___integerValue_3;
	// UnityEngine.InputSystem.Utilities.JsonParser/JsonString UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::stringValue
	JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D  ___stringValue_4;
	// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue> UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::arrayValue
	List_1_tC2452E93E5B8E31149932C482B9B7286089CB38E * ___arrayValue_5;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue> UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::objectValue
	Dictionary_2_t6559C3595494ACAFACFBD50DF3795F25E9D5FEB1 * ___objectValue_6;
	// System.Object UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::anyValue
	RuntimeObject * ___anyValue_7;

public:
	inline static int32_t get_offset_of_type_0() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___type_0)); }
	inline int32_t get_type_0() const { return ___type_0; }
	inline int32_t* get_address_of_type_0() { return &___type_0; }
	inline void set_type_0(int32_t value)
	{
		___type_0 = value;
	}

	inline static int32_t get_offset_of_boolValue_1() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___boolValue_1)); }
	inline bool get_boolValue_1() const { return ___boolValue_1; }
	inline bool* get_address_of_boolValue_1() { return &___boolValue_1; }
	inline void set_boolValue_1(bool value)
	{
		___boolValue_1 = value;
	}

	inline static int32_t get_offset_of_realValue_2() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___realValue_2)); }
	inline double get_realValue_2() const { return ___realValue_2; }
	inline double* get_address_of_realValue_2() { return &___realValue_2; }
	inline void set_realValue_2(double value)
	{
		___realValue_2 = value;
	}

	inline static int32_t get_offset_of_integerValue_3() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___integerValue_3)); }
	inline int64_t get_integerValue_3() const { return ___integerValue_3; }
	inline int64_t* get_address_of_integerValue_3() { return &___integerValue_3; }
	inline void set_integerValue_3(int64_t value)
	{
		___integerValue_3 = value;
	}

	inline static int32_t get_offset_of_stringValue_4() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___stringValue_4)); }
	inline JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D  get_stringValue_4() const { return ___stringValue_4; }
	inline JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D * get_address_of_stringValue_4() { return &___stringValue_4; }
	inline void set_stringValue_4(JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D  value)
	{
		___stringValue_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_arrayValue_5() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___arrayValue_5)); }
	inline List_1_tC2452E93E5B8E31149932C482B9B7286089CB38E * get_arrayValue_5() const { return ___arrayValue_5; }
	inline List_1_tC2452E93E5B8E31149932C482B9B7286089CB38E ** get_address_of_arrayValue_5() { return &___arrayValue_5; }
	inline void set_arrayValue_5(List_1_tC2452E93E5B8E31149932C482B9B7286089CB38E * value)
	{
		___arrayValue_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___arrayValue_5), (void*)value);
	}

	inline static int32_t get_offset_of_objectValue_6() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___objectValue_6)); }
	inline Dictionary_2_t6559C3595494ACAFACFBD50DF3795F25E9D5FEB1 * get_objectValue_6() const { return ___objectValue_6; }
	inline Dictionary_2_t6559C3595494ACAFACFBD50DF3795F25E9D5FEB1 ** get_address_of_objectValue_6() { return &___objectValue_6; }
	inline void set_objectValue_6(Dictionary_2_t6559C3595494ACAFACFBD50DF3795F25E9D5FEB1 * value)
	{
		___objectValue_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___objectValue_6), (void*)value);
	}

	inline static int32_t get_offset_of_anyValue_7() { return static_cast<int32_t>(offsetof(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F, ___anyValue_7)); }
	inline RuntimeObject * get_anyValue_7() const { return ___anyValue_7; }
	inline RuntimeObject ** get_address_of_anyValue_7() { return &___anyValue_7; }
	inline void set_anyValue_7(RuntimeObject * value)
	{
		___anyValue_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___anyValue_7), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonValue
struct JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F_marshaled_pinvoke
{
	int32_t ___type_0;
	int32_t ___boolValue_1;
	double ___realValue_2;
	int64_t ___integerValue_3;
	JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D_marshaled_pinvoke ___stringValue_4;
	List_1_tC2452E93E5B8E31149932C482B9B7286089CB38E * ___arrayValue_5;
	Dictionary_2_t6559C3595494ACAFACFBD50DF3795F25E9D5FEB1 * ___objectValue_6;
	Il2CppIUnknown* ___anyValue_7;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonValue
struct JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F_marshaled_com
{
	int32_t ___type_0;
	int32_t ___boolValue_1;
	double ___realValue_2;
	int64_t ___integerValue_3;
	JsonString_tE7492E001C8244FE43FD5FE550B2E4471E32364D_marshaled_com ___stringValue_4;
	List_1_tC2452E93E5B8E31149932C482B9B7286089CB38E * ___arrayValue_5;
	Dictionary_2_t6559C3595494ACAFACFBD50DF3795F25E9D5FEB1 * ___objectValue_6;
	Il2CppIUnknown* ___anyValue_7;
};

// UnityEngine.InputSystem.UI.PointerModel/ButtonState
struct ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 
{
public:
	// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_IsPressed
	bool ___m_IsPressed_0;
	// UnityEngine.EventSystems.PointerEventData/FramePressState UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_FramePressState
	int32_t ___m_FramePressState_1;
	// System.Single UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_PressTime
	float ___m_PressTime_2;
	// UnityEngine.EventSystems.RaycastResult UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_PressRaycast
	RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  ___m_PressRaycast_3;
	// UnityEngine.GameObject UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_PressObject
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_PressObject_4;
	// UnityEngine.GameObject UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_RawPressObject
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_RawPressObject_5;
	// UnityEngine.GameObject UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_LastPressObject
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_LastPressObject_6;
	// UnityEngine.GameObject UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_DragObject
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_DragObject_7;
	// UnityEngine.Vector2 UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_PressPosition
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___m_PressPosition_8;
	// System.Single UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_ClickTime
	float ___m_ClickTime_9;
	// System.Int32 UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_ClickCount
	int32_t ___m_ClickCount_10;
	// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_Dragging
	bool ___m_Dragging_11;
	// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_ClickedOnSameGameObject
	bool ___m_ClickedOnSameGameObject_12;
	// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::m_IgnoreNextClick
	bool ___m_IgnoreNextClick_13;

public:
	inline static int32_t get_offset_of_m_IsPressed_0() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_IsPressed_0)); }
	inline bool get_m_IsPressed_0() const { return ___m_IsPressed_0; }
	inline bool* get_address_of_m_IsPressed_0() { return &___m_IsPressed_0; }
	inline void set_m_IsPressed_0(bool value)
	{
		___m_IsPressed_0 = value;
	}

	inline static int32_t get_offset_of_m_FramePressState_1() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_FramePressState_1)); }
	inline int32_t get_m_FramePressState_1() const { return ___m_FramePressState_1; }
	inline int32_t* get_address_of_m_FramePressState_1() { return &___m_FramePressState_1; }
	inline void set_m_FramePressState_1(int32_t value)
	{
		___m_FramePressState_1 = value;
	}

	inline static int32_t get_offset_of_m_PressTime_2() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_PressTime_2)); }
	inline float get_m_PressTime_2() const { return ___m_PressTime_2; }
	inline float* get_address_of_m_PressTime_2() { return &___m_PressTime_2; }
	inline void set_m_PressTime_2(float value)
	{
		___m_PressTime_2 = value;
	}

	inline static int32_t get_offset_of_m_PressRaycast_3() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_PressRaycast_3)); }
	inline RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  get_m_PressRaycast_3() const { return ___m_PressRaycast_3; }
	inline RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE * get_address_of_m_PressRaycast_3() { return &___m_PressRaycast_3; }
	inline void set_m_PressRaycast_3(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  value)
	{
		___m_PressRaycast_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_PressRaycast_3))->___m_GameObject_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_PressRaycast_3))->___module_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_PressObject_4() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_PressObject_4)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_PressObject_4() const { return ___m_PressObject_4; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_PressObject_4() { return &___m_PressObject_4; }
	inline void set_m_PressObject_4(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_PressObject_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_PressObject_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_RawPressObject_5() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_RawPressObject_5)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_RawPressObject_5() const { return ___m_RawPressObject_5; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_RawPressObject_5() { return &___m_RawPressObject_5; }
	inline void set_m_RawPressObject_5(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_RawPressObject_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_RawPressObject_5), (void*)value);
	}

	inline static int32_t get_offset_of_m_LastPressObject_6() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_LastPressObject_6)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_LastPressObject_6() const { return ___m_LastPressObject_6; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_LastPressObject_6() { return &___m_LastPressObject_6; }
	inline void set_m_LastPressObject_6(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_LastPressObject_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_LastPressObject_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_DragObject_7() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_DragObject_7)); }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * get_m_DragObject_7() const { return ___m_DragObject_7; }
	inline GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 ** get_address_of_m_DragObject_7() { return &___m_DragObject_7; }
	inline void set_m_DragObject_7(GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * value)
	{
		___m_DragObject_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DragObject_7), (void*)value);
	}

	inline static int32_t get_offset_of_m_PressPosition_8() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_PressPosition_8)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_m_PressPosition_8() const { return ___m_PressPosition_8; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_m_PressPosition_8() { return &___m_PressPosition_8; }
	inline void set_m_PressPosition_8(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___m_PressPosition_8 = value;
	}

	inline static int32_t get_offset_of_m_ClickTime_9() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_ClickTime_9)); }
	inline float get_m_ClickTime_9() const { return ___m_ClickTime_9; }
	inline float* get_address_of_m_ClickTime_9() { return &___m_ClickTime_9; }
	inline void set_m_ClickTime_9(float value)
	{
		___m_ClickTime_9 = value;
	}

	inline static int32_t get_offset_of_m_ClickCount_10() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_ClickCount_10)); }
	inline int32_t get_m_ClickCount_10() const { return ___m_ClickCount_10; }
	inline int32_t* get_address_of_m_ClickCount_10() { return &___m_ClickCount_10; }
	inline void set_m_ClickCount_10(int32_t value)
	{
		___m_ClickCount_10 = value;
	}

	inline static int32_t get_offset_of_m_Dragging_11() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_Dragging_11)); }
	inline bool get_m_Dragging_11() const { return ___m_Dragging_11; }
	inline bool* get_address_of_m_Dragging_11() { return &___m_Dragging_11; }
	inline void set_m_Dragging_11(bool value)
	{
		___m_Dragging_11 = value;
	}

	inline static int32_t get_offset_of_m_ClickedOnSameGameObject_12() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_ClickedOnSameGameObject_12)); }
	inline bool get_m_ClickedOnSameGameObject_12() const { return ___m_ClickedOnSameGameObject_12; }
	inline bool* get_address_of_m_ClickedOnSameGameObject_12() { return &___m_ClickedOnSameGameObject_12; }
	inline void set_m_ClickedOnSameGameObject_12(bool value)
	{
		___m_ClickedOnSameGameObject_12 = value;
	}

	inline static int32_t get_offset_of_m_IgnoreNextClick_13() { return static_cast<int32_t>(offsetof(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248, ___m_IgnoreNextClick_13)); }
	inline bool get_m_IgnoreNextClick_13() const { return ___m_IgnoreNextClick_13; }
	inline bool* get_address_of_m_IgnoreNextClick_13() { return &___m_IgnoreNextClick_13; }
	inline void set_m_IgnoreNextClick_13(bool value)
	{
		___m_IgnoreNextClick_13 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.UI.PointerModel/ButtonState
struct ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_pinvoke
{
	int32_t ___m_IsPressed_0;
	int32_t ___m_FramePressState_1;
	float ___m_PressTime_2;
	RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_pinvoke ___m_PressRaycast_3;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_PressObject_4;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_RawPressObject_5;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_LastPressObject_6;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_DragObject_7;
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___m_PressPosition_8;
	float ___m_ClickTime_9;
	int32_t ___m_ClickCount_10;
	int32_t ___m_Dragging_11;
	int32_t ___m_ClickedOnSameGameObject_12;
	int32_t ___m_IgnoreNextClick_13;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.UI.PointerModel/ButtonState
struct ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_com
{
	int32_t ___m_IsPressed_0;
	int32_t ___m_FramePressState_1;
	float ___m_PressTime_2;
	RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_com ___m_PressRaycast_3;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_PressObject_4;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_RawPressObject_5;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_LastPressObject_6;
	GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___m_DragObject_7;
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___m_PressPosition_8;
	float ___m_ClickTime_9;
	int32_t ___m_ClickCount_10;
	int32_t ___m_Dragging_11;
	int32_t ___m_ClickedOnSameGameObject_12;
	int32_t ___m_IgnoreNextClick_13;
};

// UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 
{
public:
	// UnityEngine.InputSystem.LowLevel.InputUpdateType UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::updateMask
	int32_t ___updateMask_0;
	// UnityEngine.InputSystem.EnhancedTouch.Finger[] UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::fingers
	FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* ___fingers_1;
	// UnityEngine.InputSystem.EnhancedTouch.Finger[] UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::activeFingers
	FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* ___activeFingers_2;
	// UnityEngine.InputSystem.EnhancedTouch.Touch[] UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::activeTouches
	TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D* ___activeTouches_3;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::activeFingerCount
	int32_t ___activeFingerCount_4;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::activeTouchCount
	int32_t ___activeTouchCount_5;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::totalFingerCount
	int32_t ___totalFingerCount_6;
	// System.UInt32 UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::lastId
	uint32_t ___lastId_7;
	// System.Boolean UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::haveBuiltActiveTouches
	bool ___haveBuiltActiveTouches_8;
	// System.Boolean UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::haveActiveTouchesNeedingRefreshNextUpdate
	bool ___haveActiveTouchesNeedingRefreshNextUpdate_9;
	// UnityEngine.InputSystem.LowLevel.InputStateHistory`1<UnityEngine.InputSystem.LowLevel.TouchState> UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::activeTouchState
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___activeTouchState_10;

public:
	inline static int32_t get_offset_of_updateMask_0() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___updateMask_0)); }
	inline int32_t get_updateMask_0() const { return ___updateMask_0; }
	inline int32_t* get_address_of_updateMask_0() { return &___updateMask_0; }
	inline void set_updateMask_0(int32_t value)
	{
		___updateMask_0 = value;
	}

	inline static int32_t get_offset_of_fingers_1() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___fingers_1)); }
	inline FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* get_fingers_1() const { return ___fingers_1; }
	inline FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** get_address_of_fingers_1() { return &___fingers_1; }
	inline void set_fingers_1(FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* value)
	{
		___fingers_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___fingers_1), (void*)value);
	}

	inline static int32_t get_offset_of_activeFingers_2() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___activeFingers_2)); }
	inline FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* get_activeFingers_2() const { return ___activeFingers_2; }
	inline FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** get_address_of_activeFingers_2() { return &___activeFingers_2; }
	inline void set_activeFingers_2(FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* value)
	{
		___activeFingers_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___activeFingers_2), (void*)value);
	}

	inline static int32_t get_offset_of_activeTouches_3() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___activeTouches_3)); }
	inline TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D* get_activeTouches_3() const { return ___activeTouches_3; }
	inline TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D** get_address_of_activeTouches_3() { return &___activeTouches_3; }
	inline void set_activeTouches_3(TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D* value)
	{
		___activeTouches_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___activeTouches_3), (void*)value);
	}

	inline static int32_t get_offset_of_activeFingerCount_4() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___activeFingerCount_4)); }
	inline int32_t get_activeFingerCount_4() const { return ___activeFingerCount_4; }
	inline int32_t* get_address_of_activeFingerCount_4() { return &___activeFingerCount_4; }
	inline void set_activeFingerCount_4(int32_t value)
	{
		___activeFingerCount_4 = value;
	}

	inline static int32_t get_offset_of_activeTouchCount_5() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___activeTouchCount_5)); }
	inline int32_t get_activeTouchCount_5() const { return ___activeTouchCount_5; }
	inline int32_t* get_address_of_activeTouchCount_5() { return &___activeTouchCount_5; }
	inline void set_activeTouchCount_5(int32_t value)
	{
		___activeTouchCount_5 = value;
	}

	inline static int32_t get_offset_of_totalFingerCount_6() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___totalFingerCount_6)); }
	inline int32_t get_totalFingerCount_6() const { return ___totalFingerCount_6; }
	inline int32_t* get_address_of_totalFingerCount_6() { return &___totalFingerCount_6; }
	inline void set_totalFingerCount_6(int32_t value)
	{
		___totalFingerCount_6 = value;
	}

	inline static int32_t get_offset_of_lastId_7() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___lastId_7)); }
	inline uint32_t get_lastId_7() const { return ___lastId_7; }
	inline uint32_t* get_address_of_lastId_7() { return &___lastId_7; }
	inline void set_lastId_7(uint32_t value)
	{
		___lastId_7 = value;
	}

	inline static int32_t get_offset_of_haveBuiltActiveTouches_8() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___haveBuiltActiveTouches_8)); }
	inline bool get_haveBuiltActiveTouches_8() const { return ___haveBuiltActiveTouches_8; }
	inline bool* get_address_of_haveBuiltActiveTouches_8() { return &___haveBuiltActiveTouches_8; }
	inline void set_haveBuiltActiveTouches_8(bool value)
	{
		___haveBuiltActiveTouches_8 = value;
	}

	inline static int32_t get_offset_of_haveActiveTouchesNeedingRefreshNextUpdate_9() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___haveActiveTouchesNeedingRefreshNextUpdate_9)); }
	inline bool get_haveActiveTouchesNeedingRefreshNextUpdate_9() const { return ___haveActiveTouchesNeedingRefreshNextUpdate_9; }
	inline bool* get_address_of_haveActiveTouchesNeedingRefreshNextUpdate_9() { return &___haveActiveTouchesNeedingRefreshNextUpdate_9; }
	inline void set_haveActiveTouchesNeedingRefreshNextUpdate_9(bool value)
	{
		___haveActiveTouchesNeedingRefreshNextUpdate_9 = value;
	}

	inline static int32_t get_offset_of_activeTouchState_10() { return static_cast<int32_t>(offsetof(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49, ___activeTouchState_10)); }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * get_activeTouchState_10() const { return ___activeTouchState_10; }
	inline InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 ** get_address_of_activeTouchState_10() { return &___activeTouchState_10; }
	inline void set_activeTouchState_10(InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * value)
	{
		___activeTouchState_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___activeTouchState_10), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke
{
	int32_t ___updateMask_0;
	FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* ___fingers_1;
	FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* ___activeFingers_2;
	Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_pinvoke* ___activeTouches_3;
	int32_t ___activeFingerCount_4;
	int32_t ___activeTouchCount_5;
	int32_t ___totalFingerCount_6;
	uint32_t ___lastId_7;
	int32_t ___haveBuiltActiveTouches_8;
	int32_t ___haveActiveTouchesNeedingRefreshNextUpdate_9;
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___activeTouchState_10;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
struct FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com
{
	int32_t ___updateMask_0;
	FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* ___fingers_1;
	FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* ___activeFingers_2;
	Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_com* ___activeTouches_3;
	int32_t ___activeFingerCount_4;
	int32_t ___activeTouchCount_5;
	int32_t ___totalFingerCount_6;
	uint32_t ___lastId_7;
	int32_t ___haveBuiltActiveTouches_8;
	int32_t ___haveActiveTouchesNeedingRefreshNextUpdate_9;
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___activeTouchState_10;
};

// UnityEngine.InputSystem.XInput.XInputController/Capabilities
struct Capabilities_t3A2978B50053810CF9334C2DE7842B91E1FDAA0D 
{
public:
	// UnityEngine.InputSystem.XInput.XInputController/DeviceType UnityEngine.InputSystem.XInput.XInputController/Capabilities::type
	int32_t ___type_0;
	// UnityEngine.InputSystem.XInput.XInputController/DeviceSubType UnityEngine.InputSystem.XInput.XInputController/Capabilities::subType
	int32_t ___subType_1;
	// UnityEngine.InputSystem.XInput.XInputController/DeviceFlags UnityEngine.InputSystem.XInput.XInputController/Capabilities::flags
	int32_t ___flags_2;

public:
	inline static int32_t get_offset_of_type_0() { return static_cast<int32_t>(offsetof(Capabilities_t3A2978B50053810CF9334C2DE7842B91E1FDAA0D, ___type_0)); }
	inline int32_t get_type_0() const { return ___type_0; }
	inline int32_t* get_address_of_type_0() { return &___type_0; }
	inline void set_type_0(int32_t value)
	{
		___type_0 = value;
	}

	inline static int32_t get_offset_of_subType_1() { return static_cast<int32_t>(offsetof(Capabilities_t3A2978B50053810CF9334C2DE7842B91E1FDAA0D, ___subType_1)); }
	inline int32_t get_subType_1() const { return ___subType_1; }
	inline int32_t* get_address_of_subType_1() { return &___subType_1; }
	inline void set_subType_1(int32_t value)
	{
		___subType_1 = value;
	}

	inline static int32_t get_offset_of_flags_2() { return static_cast<int32_t>(offsetof(Capabilities_t3A2978B50053810CF9334C2DE7842B91E1FDAA0D, ___flags_2)); }
	inline int32_t get_flags_2() const { return ___flags_2; }
	inline int32_t* get_address_of_flags_2() { return &___flags_2; }
	inline void set_flags_2(int32_t value)
	{
		___flags_2 = value;
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher
struct LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C 
{
public:
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher::layoutName
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___layoutName_0;
	// UnityEngine.InputSystem.Layouts.InputDeviceMatcher UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher::deviceMatcher
	InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D  ___deviceMatcher_1;

public:
	inline static int32_t get_offset_of_layoutName_0() { return static_cast<int32_t>(offsetof(LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C, ___layoutName_0)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_layoutName_0() const { return ___layoutName_0; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_layoutName_0() { return &___layoutName_0; }
	inline void set_layoutName_0(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___layoutName_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___layoutName_0))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___layoutName_0))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_deviceMatcher_1() { return static_cast<int32_t>(offsetof(LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C, ___deviceMatcher_1)); }
	inline InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D  get_deviceMatcher_1() const { return ___deviceMatcher_1; }
	inline InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D * get_address_of_deviceMatcher_1() { return &___deviceMatcher_1; }
	inline void set_deviceMatcher_1(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D  value)
	{
		___deviceMatcher_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___deviceMatcher_1))->___m_Patterns_0), (void*)NULL);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher
struct LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_pinvoke
{
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke ___layoutName_0;
	InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_pinvoke ___deviceMatcher_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher
struct LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_com
{
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com ___layoutName_0;
	InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_com ___deviceMatcher_1;
};

// System.Func`1<UnityEngine.InputSystem.InputDevice>
struct Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Char,System.Boolean>
struct Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.String,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB  : public MulticastDelegate_t
{
public:

public:
};


// UnityEngine.InputSystem.InputControlList`1<UnityEngine.InputSystem.InputControl>
struct InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputControlList`1::m_Count
	int32_t ___m_Count_0;
	// Unity.Collections.NativeArray`1<System.UInt64> UnityEngine.InputSystem.InputControlList`1::m_Indices
	NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B  ___m_Indices_1;
	// Unity.Collections.Allocator UnityEngine.InputSystem.InputControlList`1::m_Allocator
	int32_t ___m_Allocator_2;

public:
	inline static int32_t get_offset_of_m_Count_0() { return static_cast<int32_t>(offsetof(InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B, ___m_Count_0)); }
	inline int32_t get_m_Count_0() const { return ___m_Count_0; }
	inline int32_t* get_address_of_m_Count_0() { return &___m_Count_0; }
	inline void set_m_Count_0(int32_t value)
	{
		___m_Count_0 = value;
	}

	inline static int32_t get_offset_of_m_Indices_1() { return static_cast<int32_t>(offsetof(InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B, ___m_Indices_1)); }
	inline NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B  get_m_Indices_1() const { return ___m_Indices_1; }
	inline NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B * get_address_of_m_Indices_1() { return &___m_Indices_1; }
	inline void set_m_Indices_1(NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B  value)
	{
		___m_Indices_1 = value;
	}

	inline static int32_t get_offset_of_m_Allocator_2() { return static_cast<int32_t>(offsetof(InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B, ___m_Allocator_2)); }
	inline int32_t get_m_Allocator_2() const { return ___m_Allocator_2; }
	inline int32_t* get_address_of_m_Allocator_2() { return &___m_Allocator_2; }
	inline void set_m_Allocator_2(int32_t value)
	{
		___m_Allocator_2 = value;
	}
};


// UnityEngine.InputSystem.InputControlList`1<System.Object>
struct InputControlList_1_t447EDCA408530F83486DAFD99E11A1CD7F394550 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputControlList`1::m_Count
	int32_t ___m_Count_0;
	// Unity.Collections.NativeArray`1<System.UInt64> UnityEngine.InputSystem.InputControlList`1::m_Indices
	NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B  ___m_Indices_1;
	// Unity.Collections.Allocator UnityEngine.InputSystem.InputControlList`1::m_Allocator
	int32_t ___m_Allocator_2;

public:
	inline static int32_t get_offset_of_m_Count_0() { return static_cast<int32_t>(offsetof(InputControlList_1_t447EDCA408530F83486DAFD99E11A1CD7F394550, ___m_Count_0)); }
	inline int32_t get_m_Count_0() const { return ___m_Count_0; }
	inline int32_t* get_address_of_m_Count_0() { return &___m_Count_0; }
	inline void set_m_Count_0(int32_t value)
	{
		___m_Count_0 = value;
	}

	inline static int32_t get_offset_of_m_Indices_1() { return static_cast<int32_t>(offsetof(InputControlList_1_t447EDCA408530F83486DAFD99E11A1CD7F394550, ___m_Indices_1)); }
	inline NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B  get_m_Indices_1() const { return ___m_Indices_1; }
	inline NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B * get_address_of_m_Indices_1() { return &___m_Indices_1; }
	inline void set_m_Indices_1(NativeArray_1_t9D118727A643E61710D0A4DF5B0C8CD1A918A40B  value)
	{
		___m_Indices_1 = value;
	}

	inline static int32_t get_offset_of_m_Allocator_2() { return static_cast<int32_t>(offsetof(InputControlList_1_t447EDCA408530F83486DAFD99E11A1CD7F394550, ___m_Allocator_2)); }
	inline int32_t get_m_Allocator_2() const { return ___m_Allocator_2; }
	inline int32_t* get_address_of_m_Allocator_2() { return &___m_Allocator_2; }
	inline void set_m_Allocator_2(int32_t value)
	{
		___m_Allocator_2 = value;
	}
};


// System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct KeyValuePair_2_tEE5D23BECC9903E80CE9C9EA17D3C6D530F7987E 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	RuntimeObject * ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_tEE5D23BECC9903E80CE9C9EA17D3C6D530F7987E, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___key_0), (void*)value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_tEE5D23BECC9903E80CE9C9EA17D3C6D530F7987E, ___value_1)); }
	inline JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  get_value_1() const { return ___value_1; }
	inline JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F * get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___value_1))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Collections.Generic.KeyValuePair`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	String_t* ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45, ___key_0)); }
	inline String_t* get_key_0() const { return ___key_0; }
	inline String_t** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(String_t* value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___key_0), (void*)value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45, ___value_1)); }
	inline JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  get_value_1() const { return ___value_1; }
	inline JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F * get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___value_1))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.ArgumentException
struct ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00  : public SystemException_tC551B4D6EE3772B5F32C71EE8C719F4B43ECCC62
{
public:
	// System.String System.ArgumentException::m_paramName
	String_t* ___m_paramName_17;

public:
	inline static int32_t get_offset_of_m_paramName_17() { return static_cast<int32_t>(offsetof(ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00, ___m_paramName_17)); }
	inline String_t* get_m_paramName_17() const { return ___m_paramName_17; }
	inline String_t** get_address_of_m_paramName_17() { return &___m_paramName_17; }
	inline void set_m_paramName_17(String_t* value)
	{
		___m_paramName_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_paramName_17), (void*)value);
	}
};


// UnityEngine.Behaviour
struct Behaviour_t1A3DDDCF73B4627928FBFE02ED52B7251777DBD9  : public Component_t62FBC8D2420DA4BE9037AFE430740F6B3EECA684
{
public:

public:
};


// UnityEngine.InputSystem.InputControl
struct InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713  : public RuntimeObject
{
public:
	// UnityEngine.InputSystem.LowLevel.InputStateBlock UnityEngine.InputSystem.InputControl::m_StateBlock
	InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C  ___m_StateBlock_0;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.InputControl::m_Name
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___m_Name_1;
	// System.String UnityEngine.InputSystem.InputControl::m_Path
	String_t* ___m_Path_2;
	// System.String UnityEngine.InputSystem.InputControl::m_DisplayName
	String_t* ___m_DisplayName_3;
	// System.String UnityEngine.InputSystem.InputControl::m_DisplayNameFromLayout
	String_t* ___m_DisplayNameFromLayout_4;
	// System.String UnityEngine.InputSystem.InputControl::m_ShortDisplayName
	String_t* ___m_ShortDisplayName_5;
	// System.String UnityEngine.InputSystem.InputControl::m_ShortDisplayNameFromLayout
	String_t* ___m_ShortDisplayNameFromLayout_6;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.InputControl::m_Layout
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___m_Layout_7;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.InputControl::m_Variants
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___m_Variants_8;
	// UnityEngine.InputSystem.InputDevice UnityEngine.InputSystem.InputControl::m_Device
	InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * ___m_Device_9;
	// UnityEngine.InputSystem.InputControl UnityEngine.InputSystem.InputControl::m_Parent
	InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * ___m_Parent_10;
	// System.Int32 UnityEngine.InputSystem.InputControl::m_UsageCount
	int32_t ___m_UsageCount_11;
	// System.Int32 UnityEngine.InputSystem.InputControl::m_UsageStartIndex
	int32_t ___m_UsageStartIndex_12;
	// System.Int32 UnityEngine.InputSystem.InputControl::m_AliasCount
	int32_t ___m_AliasCount_13;
	// System.Int32 UnityEngine.InputSystem.InputControl::m_AliasStartIndex
	int32_t ___m_AliasStartIndex_14;
	// System.Int32 UnityEngine.InputSystem.InputControl::m_ChildCount
	int32_t ___m_ChildCount_15;
	// System.Int32 UnityEngine.InputSystem.InputControl::m_ChildStartIndex
	int32_t ___m_ChildStartIndex_16;
	// UnityEngine.InputSystem.InputControl/ControlFlags UnityEngine.InputSystem.InputControl::m_ControlFlags
	int32_t ___m_ControlFlags_17;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.InputControl::m_DefaultState
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___m_DefaultState_18;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.InputControl::m_MinValue
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___m_MinValue_19;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.InputControl::m_MaxValue
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___m_MaxValue_20;

public:
	inline static int32_t get_offset_of_m_StateBlock_0() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_StateBlock_0)); }
	inline InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C  get_m_StateBlock_0() const { return ___m_StateBlock_0; }
	inline InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C * get_address_of_m_StateBlock_0() { return &___m_StateBlock_0; }
	inline void set_m_StateBlock_0(InputStateBlock_t37A383311518FFFA424D1F8F7E355DBFC215624C  value)
	{
		___m_StateBlock_0 = value;
	}

	inline static int32_t get_offset_of_m_Name_1() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_Name_1)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_m_Name_1() const { return ___m_Name_1; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_m_Name_1() { return &___m_Name_1; }
	inline void set_m_Name_1(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___m_Name_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Name_1))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Name_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_Path_2() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_Path_2)); }
	inline String_t* get_m_Path_2() const { return ___m_Path_2; }
	inline String_t** get_address_of_m_Path_2() { return &___m_Path_2; }
	inline void set_m_Path_2(String_t* value)
	{
		___m_Path_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Path_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_DisplayName_3() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_DisplayName_3)); }
	inline String_t* get_m_DisplayName_3() const { return ___m_DisplayName_3; }
	inline String_t** get_address_of_m_DisplayName_3() { return &___m_DisplayName_3; }
	inline void set_m_DisplayName_3(String_t* value)
	{
		___m_DisplayName_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DisplayName_3), (void*)value);
	}

	inline static int32_t get_offset_of_m_DisplayNameFromLayout_4() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_DisplayNameFromLayout_4)); }
	inline String_t* get_m_DisplayNameFromLayout_4() const { return ___m_DisplayNameFromLayout_4; }
	inline String_t** get_address_of_m_DisplayNameFromLayout_4() { return &___m_DisplayNameFromLayout_4; }
	inline void set_m_DisplayNameFromLayout_4(String_t* value)
	{
		___m_DisplayNameFromLayout_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DisplayNameFromLayout_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_ShortDisplayName_5() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_ShortDisplayName_5)); }
	inline String_t* get_m_ShortDisplayName_5() const { return ___m_ShortDisplayName_5; }
	inline String_t** get_address_of_m_ShortDisplayName_5() { return &___m_ShortDisplayName_5; }
	inline void set_m_ShortDisplayName_5(String_t* value)
	{
		___m_ShortDisplayName_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ShortDisplayName_5), (void*)value);
	}

	inline static int32_t get_offset_of_m_ShortDisplayNameFromLayout_6() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_ShortDisplayNameFromLayout_6)); }
	inline String_t* get_m_ShortDisplayNameFromLayout_6() const { return ___m_ShortDisplayNameFromLayout_6; }
	inline String_t** get_address_of_m_ShortDisplayNameFromLayout_6() { return &___m_ShortDisplayNameFromLayout_6; }
	inline void set_m_ShortDisplayNameFromLayout_6(String_t* value)
	{
		___m_ShortDisplayNameFromLayout_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ShortDisplayNameFromLayout_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_Layout_7() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_Layout_7)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_m_Layout_7() const { return ___m_Layout_7; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_m_Layout_7() { return &___m_Layout_7; }
	inline void set_m_Layout_7(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___m_Layout_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Layout_7))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Layout_7))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_Variants_8() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_Variants_8)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_m_Variants_8() const { return ___m_Variants_8; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_m_Variants_8() { return &___m_Variants_8; }
	inline void set_m_Variants_8(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___m_Variants_8 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Variants_8))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Variants_8))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_Device_9() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_Device_9)); }
	inline InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * get_m_Device_9() const { return ___m_Device_9; }
	inline InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 ** get_address_of_m_Device_9() { return &___m_Device_9; }
	inline void set_m_Device_9(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * value)
	{
		___m_Device_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Device_9), (void*)value);
	}

	inline static int32_t get_offset_of_m_Parent_10() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_Parent_10)); }
	inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * get_m_Parent_10() const { return ___m_Parent_10; }
	inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 ** get_address_of_m_Parent_10() { return &___m_Parent_10; }
	inline void set_m_Parent_10(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * value)
	{
		___m_Parent_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Parent_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_UsageCount_11() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_UsageCount_11)); }
	inline int32_t get_m_UsageCount_11() const { return ___m_UsageCount_11; }
	inline int32_t* get_address_of_m_UsageCount_11() { return &___m_UsageCount_11; }
	inline void set_m_UsageCount_11(int32_t value)
	{
		___m_UsageCount_11 = value;
	}

	inline static int32_t get_offset_of_m_UsageStartIndex_12() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_UsageStartIndex_12)); }
	inline int32_t get_m_UsageStartIndex_12() const { return ___m_UsageStartIndex_12; }
	inline int32_t* get_address_of_m_UsageStartIndex_12() { return &___m_UsageStartIndex_12; }
	inline void set_m_UsageStartIndex_12(int32_t value)
	{
		___m_UsageStartIndex_12 = value;
	}

	inline static int32_t get_offset_of_m_AliasCount_13() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_AliasCount_13)); }
	inline int32_t get_m_AliasCount_13() const { return ___m_AliasCount_13; }
	inline int32_t* get_address_of_m_AliasCount_13() { return &___m_AliasCount_13; }
	inline void set_m_AliasCount_13(int32_t value)
	{
		___m_AliasCount_13 = value;
	}

	inline static int32_t get_offset_of_m_AliasStartIndex_14() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_AliasStartIndex_14)); }
	inline int32_t get_m_AliasStartIndex_14() const { return ___m_AliasStartIndex_14; }
	inline int32_t* get_address_of_m_AliasStartIndex_14() { return &___m_AliasStartIndex_14; }
	inline void set_m_AliasStartIndex_14(int32_t value)
	{
		___m_AliasStartIndex_14 = value;
	}

	inline static int32_t get_offset_of_m_ChildCount_15() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_ChildCount_15)); }
	inline int32_t get_m_ChildCount_15() const { return ___m_ChildCount_15; }
	inline int32_t* get_address_of_m_ChildCount_15() { return &___m_ChildCount_15; }
	inline void set_m_ChildCount_15(int32_t value)
	{
		___m_ChildCount_15 = value;
	}

	inline static int32_t get_offset_of_m_ChildStartIndex_16() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_ChildStartIndex_16)); }
	inline int32_t get_m_ChildStartIndex_16() const { return ___m_ChildStartIndex_16; }
	inline int32_t* get_address_of_m_ChildStartIndex_16() { return &___m_ChildStartIndex_16; }
	inline void set_m_ChildStartIndex_16(int32_t value)
	{
		___m_ChildStartIndex_16 = value;
	}

	inline static int32_t get_offset_of_m_ControlFlags_17() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_ControlFlags_17)); }
	inline int32_t get_m_ControlFlags_17() const { return ___m_ControlFlags_17; }
	inline int32_t* get_address_of_m_ControlFlags_17() { return &___m_ControlFlags_17; }
	inline void set_m_ControlFlags_17(int32_t value)
	{
		___m_ControlFlags_17 = value;
	}

	inline static int32_t get_offset_of_m_DefaultState_18() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_DefaultState_18)); }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  get_m_DefaultState_18() const { return ___m_DefaultState_18; }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA * get_address_of_m_DefaultState_18() { return &___m_DefaultState_18; }
	inline void set_m_DefaultState_18(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  value)
	{
		___m_DefaultState_18 = value;
	}

	inline static int32_t get_offset_of_m_MinValue_19() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_MinValue_19)); }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  get_m_MinValue_19() const { return ___m_MinValue_19; }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA * get_address_of_m_MinValue_19() { return &___m_MinValue_19; }
	inline void set_m_MinValue_19(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  value)
	{
		___m_MinValue_19 = value;
	}

	inline static int32_t get_offset_of_m_MaxValue_20() { return static_cast<int32_t>(offsetof(InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713, ___m_MaxValue_20)); }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  get_m_MaxValue_20() const { return ___m_MaxValue_20; }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA * get_address_of_m_MaxValue_20() { return &___m_MaxValue_20; }
	inline void set_m_MaxValue_20(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  value)
	{
		___m_MaxValue_20 = value;
	}
};


// UnityEngine.InputSystem.LowLevel.InputStateHistory
struct InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E  : public RuntimeObject
{
public:
	// System.Action`1<UnityEngine.InputSystem.LowLevel.InputStateHistory/Record> UnityEngine.InputSystem.LowLevel.InputStateHistory::<onRecordAdded>k__BackingField
	Action_1_t50A4778324C38A4406F4AF30FB340C3B0903F628 * ___U3ConRecordAddedU3Ek__BackingField_1;
	// System.Func`4<UnityEngine.InputSystem.InputControl,System.Double,UnityEngine.InputSystem.LowLevel.InputEventPtr,System.Boolean> UnityEngine.InputSystem.LowLevel.InputStateHistory::<onShouldRecordStateChange>k__BackingField
	Func_4_tC181B89FE77E225DD2208DFFF3D3152DD9923199 * ___U3ConShouldRecordStateChangeU3Ek__BackingField_2;
	// UnityEngine.InputSystem.InputControl[] UnityEngine.InputSystem.LowLevel.InputStateHistory::m_Controls
	InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* ___m_Controls_3;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::m_ControlCount
	int32_t ___m_ControlCount_4;
	// Unity.Collections.NativeArray`1<System.Byte> UnityEngine.InputSystem.LowLevel.InputStateHistory::m_RecordBuffer
	NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785  ___m_RecordBuffer_5;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::m_StateSizeInBytes
	int32_t ___m_StateSizeInBytes_6;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::m_RecordCount
	int32_t ___m_RecordCount_7;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::m_HistoryDepth
	int32_t ___m_HistoryDepth_8;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::m_ExtraMemoryPerRecord
	int32_t ___m_ExtraMemoryPerRecord_9;
	// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::m_HeadIndex
	int32_t ___m_HeadIndex_10;
	// System.UInt32 UnityEngine.InputSystem.LowLevel.InputStateHistory::m_CurrentVersion
	uint32_t ___m_CurrentVersion_11;
	// System.Nullable`1<UnityEngine.InputSystem.LowLevel.InputUpdateType> UnityEngine.InputSystem.LowLevel.InputStateHistory::m_UpdateMask
	Nullable_1_t6586DF2313941D6CC550CF19432868E82B7CF644  ___m_UpdateMask_12;
	// System.Boolean UnityEngine.InputSystem.LowLevel.InputStateHistory::m_AddNewControls
	bool ___m_AddNewControls_13;

public:
	inline static int32_t get_offset_of_U3ConRecordAddedU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___U3ConRecordAddedU3Ek__BackingField_1)); }
	inline Action_1_t50A4778324C38A4406F4AF30FB340C3B0903F628 * get_U3ConRecordAddedU3Ek__BackingField_1() const { return ___U3ConRecordAddedU3Ek__BackingField_1; }
	inline Action_1_t50A4778324C38A4406F4AF30FB340C3B0903F628 ** get_address_of_U3ConRecordAddedU3Ek__BackingField_1() { return &___U3ConRecordAddedU3Ek__BackingField_1; }
	inline void set_U3ConRecordAddedU3Ek__BackingField_1(Action_1_t50A4778324C38A4406F4AF30FB340C3B0903F628 * value)
	{
		___U3ConRecordAddedU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3ConRecordAddedU3Ek__BackingField_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3ConShouldRecordStateChangeU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___U3ConShouldRecordStateChangeU3Ek__BackingField_2)); }
	inline Func_4_tC181B89FE77E225DD2208DFFF3D3152DD9923199 * get_U3ConShouldRecordStateChangeU3Ek__BackingField_2() const { return ___U3ConShouldRecordStateChangeU3Ek__BackingField_2; }
	inline Func_4_tC181B89FE77E225DD2208DFFF3D3152DD9923199 ** get_address_of_U3ConShouldRecordStateChangeU3Ek__BackingField_2() { return &___U3ConShouldRecordStateChangeU3Ek__BackingField_2; }
	inline void set_U3ConShouldRecordStateChangeU3Ek__BackingField_2(Func_4_tC181B89FE77E225DD2208DFFF3D3152DD9923199 * value)
	{
		___U3ConShouldRecordStateChangeU3Ek__BackingField_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3ConShouldRecordStateChangeU3Ek__BackingField_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_Controls_3() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_Controls_3)); }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* get_m_Controls_3() const { return ___m_Controls_3; }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F** get_address_of_m_Controls_3() { return &___m_Controls_3; }
	inline void set_m_Controls_3(InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* value)
	{
		___m_Controls_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Controls_3), (void*)value);
	}

	inline static int32_t get_offset_of_m_ControlCount_4() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_ControlCount_4)); }
	inline int32_t get_m_ControlCount_4() const { return ___m_ControlCount_4; }
	inline int32_t* get_address_of_m_ControlCount_4() { return &___m_ControlCount_4; }
	inline void set_m_ControlCount_4(int32_t value)
	{
		___m_ControlCount_4 = value;
	}

	inline static int32_t get_offset_of_m_RecordBuffer_5() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_RecordBuffer_5)); }
	inline NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785  get_m_RecordBuffer_5() const { return ___m_RecordBuffer_5; }
	inline NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785 * get_address_of_m_RecordBuffer_5() { return &___m_RecordBuffer_5; }
	inline void set_m_RecordBuffer_5(NativeArray_1_t3C2855C5B238E8C6739D4C17833F244B95C0F785  value)
	{
		___m_RecordBuffer_5 = value;
	}

	inline static int32_t get_offset_of_m_StateSizeInBytes_6() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_StateSizeInBytes_6)); }
	inline int32_t get_m_StateSizeInBytes_6() const { return ___m_StateSizeInBytes_6; }
	inline int32_t* get_address_of_m_StateSizeInBytes_6() { return &___m_StateSizeInBytes_6; }
	inline void set_m_StateSizeInBytes_6(int32_t value)
	{
		___m_StateSizeInBytes_6 = value;
	}

	inline static int32_t get_offset_of_m_RecordCount_7() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_RecordCount_7)); }
	inline int32_t get_m_RecordCount_7() const { return ___m_RecordCount_7; }
	inline int32_t* get_address_of_m_RecordCount_7() { return &___m_RecordCount_7; }
	inline void set_m_RecordCount_7(int32_t value)
	{
		___m_RecordCount_7 = value;
	}

	inline static int32_t get_offset_of_m_HistoryDepth_8() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_HistoryDepth_8)); }
	inline int32_t get_m_HistoryDepth_8() const { return ___m_HistoryDepth_8; }
	inline int32_t* get_address_of_m_HistoryDepth_8() { return &___m_HistoryDepth_8; }
	inline void set_m_HistoryDepth_8(int32_t value)
	{
		___m_HistoryDepth_8 = value;
	}

	inline static int32_t get_offset_of_m_ExtraMemoryPerRecord_9() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_ExtraMemoryPerRecord_9)); }
	inline int32_t get_m_ExtraMemoryPerRecord_9() const { return ___m_ExtraMemoryPerRecord_9; }
	inline int32_t* get_address_of_m_ExtraMemoryPerRecord_9() { return &___m_ExtraMemoryPerRecord_9; }
	inline void set_m_ExtraMemoryPerRecord_9(int32_t value)
	{
		___m_ExtraMemoryPerRecord_9 = value;
	}

	inline static int32_t get_offset_of_m_HeadIndex_10() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_HeadIndex_10)); }
	inline int32_t get_m_HeadIndex_10() const { return ___m_HeadIndex_10; }
	inline int32_t* get_address_of_m_HeadIndex_10() { return &___m_HeadIndex_10; }
	inline void set_m_HeadIndex_10(int32_t value)
	{
		___m_HeadIndex_10 = value;
	}

	inline static int32_t get_offset_of_m_CurrentVersion_11() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_CurrentVersion_11)); }
	inline uint32_t get_m_CurrentVersion_11() const { return ___m_CurrentVersion_11; }
	inline uint32_t* get_address_of_m_CurrentVersion_11() { return &___m_CurrentVersion_11; }
	inline void set_m_CurrentVersion_11(uint32_t value)
	{
		___m_CurrentVersion_11 = value;
	}

	inline static int32_t get_offset_of_m_UpdateMask_12() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_UpdateMask_12)); }
	inline Nullable_1_t6586DF2313941D6CC550CF19432868E82B7CF644  get_m_UpdateMask_12() const { return ___m_UpdateMask_12; }
	inline Nullable_1_t6586DF2313941D6CC550CF19432868E82B7CF644 * get_address_of_m_UpdateMask_12() { return &___m_UpdateMask_12; }
	inline void set_m_UpdateMask_12(Nullable_1_t6586DF2313941D6CC550CF19432868E82B7CF644  value)
	{
		___m_UpdateMask_12 = value;
	}

	inline static int32_t get_offset_of_m_AddNewControls_13() { return static_cast<int32_t>(offsetof(InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E, ___m_AddNewControls_13)); }
	inline bool get_m_AddNewControls_13() const { return ___m_AddNewControls_13; }
	inline bool* get_address_of_m_AddNewControls_13() { return &___m_AddNewControls_13; }
	inline void set_m_AddNewControls_13(bool value)
	{
		___m_AddNewControls_13 = value;
	}
};


// System.InvalidOperationException
struct InvalidOperationException_t10D3EE59AD28EC641ACEE05BCA4271A527E5ECAB  : public SystemException_tC551B4D6EE3772B5F32C71EE8C719F4B43ECCC62
{
public:

public:
};


// UnityEngine.InputSystem.Utilities.NamedValue
struct NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.NamedValue::<name>k__BackingField
	String_t* ___U3CnameU3Ek__BackingField_1;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.Utilities.NamedValue::<value>k__BackingField
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___U3CvalueU3Ek__BackingField_2;

public:
	inline static int32_t get_offset_of_U3CnameU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94, ___U3CnameU3Ek__BackingField_1)); }
	inline String_t* get_U3CnameU3Ek__BackingField_1() const { return ___U3CnameU3Ek__BackingField_1; }
	inline String_t** get_address_of_U3CnameU3Ek__BackingField_1() { return &___U3CnameU3Ek__BackingField_1; }
	inline void set_U3CnameU3Ek__BackingField_1(String_t* value)
	{
		___U3CnameU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CnameU3Ek__BackingField_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CvalueU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94, ___U3CvalueU3Ek__BackingField_2)); }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  get_U3CvalueU3Ek__BackingField_2() const { return ___U3CvalueU3Ek__BackingField_2; }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA * get_address_of_U3CvalueU3Ek__BackingField_2() { return &___U3CvalueU3Ek__BackingField_2; }
	inline void set_U3CvalueU3Ek__BackingField_2(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  value)
	{
		___U3CvalueU3Ek__BackingField_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.NamedValue
struct NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94_marshaled_pinvoke
{
	char* ___U3CnameU3Ek__BackingField_1;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_pinvoke ___U3CvalueU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.NamedValue
struct NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94_marshaled_com
{
	Il2CppChar* ___U3CnameU3Ek__BackingField_1;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_com ___U3CvalueU3Ek__BackingField_2;
};

// System.NotSupportedException
struct NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339  : public SystemException_tC551B4D6EE3772B5F32C71EE8C719F4B43ECCC62
{
public:

public:
};


// UnityEngine.InputSystem.RemoteInputPlayerConnection
struct RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0  : public ScriptableObject_t4361E08CEBF052C650D3666C7CEC37EB31DE116A
{
public:
	// UnityEngine.Networking.PlayerConnection.IEditorPlayerConnection UnityEngine.InputSystem.RemoteInputPlayerConnection::m_Connection
	RuntimeObject* ___m_Connection_11;
	// UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber[] UnityEngine.InputSystem.RemoteInputPlayerConnection::m_Subscribers
	SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D* ___m_Subscribers_12;
	// System.Int32[] UnityEngine.InputSystem.RemoteInputPlayerConnection::m_ConnectedIds
	Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* ___m_ConnectedIds_13;

public:
	inline static int32_t get_offset_of_m_Connection_11() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0, ___m_Connection_11)); }
	inline RuntimeObject* get_m_Connection_11() const { return ___m_Connection_11; }
	inline RuntimeObject** get_address_of_m_Connection_11() { return &___m_Connection_11; }
	inline void set_m_Connection_11(RuntimeObject* value)
	{
		___m_Connection_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Connection_11), (void*)value);
	}

	inline static int32_t get_offset_of_m_Subscribers_12() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0, ___m_Subscribers_12)); }
	inline SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D* get_m_Subscribers_12() const { return ___m_Subscribers_12; }
	inline SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D** get_address_of_m_Subscribers_12() { return &___m_Subscribers_12; }
	inline void set_m_Subscribers_12(SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D* value)
	{
		___m_Subscribers_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Subscribers_12), (void*)value);
	}

	inline static int32_t get_offset_of_m_ConnectedIds_13() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0, ___m_ConnectedIds_13)); }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* get_m_ConnectedIds_13() const { return ___m_ConnectedIds_13; }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32** get_address_of_m_ConnectedIds_13() { return &___m_ConnectedIds_13; }
	inline void set_m_ConnectedIds_13(Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* value)
	{
		___m_ConnectedIds_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ConnectedIds_13), (void*)value);
	}
};

struct RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields
{
public:
	// System.Guid UnityEngine.InputSystem.RemoteInputPlayerConnection::kNewDeviceMsg
	Guid_t  ___kNewDeviceMsg_4;
	// System.Guid UnityEngine.InputSystem.RemoteInputPlayerConnection::kNewLayoutMsg
	Guid_t  ___kNewLayoutMsg_5;
	// System.Guid UnityEngine.InputSystem.RemoteInputPlayerConnection::kNewEventsMsg
	Guid_t  ___kNewEventsMsg_6;
	// System.Guid UnityEngine.InputSystem.RemoteInputPlayerConnection::kRemoveDeviceMsg
	Guid_t  ___kRemoveDeviceMsg_7;
	// System.Guid UnityEngine.InputSystem.RemoteInputPlayerConnection::kChangeUsagesMsg
	Guid_t  ___kChangeUsagesMsg_8;
	// System.Guid UnityEngine.InputSystem.RemoteInputPlayerConnection::kStartSendingMsg
	Guid_t  ___kStartSendingMsg_9;
	// System.Guid UnityEngine.InputSystem.RemoteInputPlayerConnection::kStopSendingMsg
	Guid_t  ___kStopSendingMsg_10;

public:
	inline static int32_t get_offset_of_kNewDeviceMsg_4() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields, ___kNewDeviceMsg_4)); }
	inline Guid_t  get_kNewDeviceMsg_4() const { return ___kNewDeviceMsg_4; }
	inline Guid_t * get_address_of_kNewDeviceMsg_4() { return &___kNewDeviceMsg_4; }
	inline void set_kNewDeviceMsg_4(Guid_t  value)
	{
		___kNewDeviceMsg_4 = value;
	}

	inline static int32_t get_offset_of_kNewLayoutMsg_5() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields, ___kNewLayoutMsg_5)); }
	inline Guid_t  get_kNewLayoutMsg_5() const { return ___kNewLayoutMsg_5; }
	inline Guid_t * get_address_of_kNewLayoutMsg_5() { return &___kNewLayoutMsg_5; }
	inline void set_kNewLayoutMsg_5(Guid_t  value)
	{
		___kNewLayoutMsg_5 = value;
	}

	inline static int32_t get_offset_of_kNewEventsMsg_6() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields, ___kNewEventsMsg_6)); }
	inline Guid_t  get_kNewEventsMsg_6() const { return ___kNewEventsMsg_6; }
	inline Guid_t * get_address_of_kNewEventsMsg_6() { return &___kNewEventsMsg_6; }
	inline void set_kNewEventsMsg_6(Guid_t  value)
	{
		___kNewEventsMsg_6 = value;
	}

	inline static int32_t get_offset_of_kRemoveDeviceMsg_7() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields, ___kRemoveDeviceMsg_7)); }
	inline Guid_t  get_kRemoveDeviceMsg_7() const { return ___kRemoveDeviceMsg_7; }
	inline Guid_t * get_address_of_kRemoveDeviceMsg_7() { return &___kRemoveDeviceMsg_7; }
	inline void set_kRemoveDeviceMsg_7(Guid_t  value)
	{
		___kRemoveDeviceMsg_7 = value;
	}

	inline static int32_t get_offset_of_kChangeUsagesMsg_8() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields, ___kChangeUsagesMsg_8)); }
	inline Guid_t  get_kChangeUsagesMsg_8() const { return ___kChangeUsagesMsg_8; }
	inline Guid_t * get_address_of_kChangeUsagesMsg_8() { return &___kChangeUsagesMsg_8; }
	inline void set_kChangeUsagesMsg_8(Guid_t  value)
	{
		___kChangeUsagesMsg_8 = value;
	}

	inline static int32_t get_offset_of_kStartSendingMsg_9() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields, ___kStartSendingMsg_9)); }
	inline Guid_t  get_kStartSendingMsg_9() const { return ___kStartSendingMsg_9; }
	inline Guid_t * get_address_of_kStartSendingMsg_9() { return &___kStartSendingMsg_9; }
	inline void set_kStartSendingMsg_9(Guid_t  value)
	{
		___kStartSendingMsg_9 = value;
	}

	inline static int32_t get_offset_of_kStopSendingMsg_10() { return static_cast<int32_t>(offsetof(RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0_StaticFields, ___kStopSendingMsg_10)); }
	inline Guid_t  get_kStopSendingMsg_10() const { return ___kStopSendingMsg_10; }
	inline Guid_t * get_address_of_kStopSendingMsg_10() { return &___kStopSendingMsg_10; }
	inline void set_kStopSendingMsg_10(Guid_t  value)
	{
		___kStopSendingMsg_10 = value;
	}
};


// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem
struct ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D 
{
public:
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<name>k__BackingField
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___U3CnameU3Ek__BackingField_0;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<layout>k__BackingField
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___U3ClayoutU3Ek__BackingField_1;
	// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<variants>k__BackingField
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___U3CvariantsU3Ek__BackingField_2;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<useStateFrom>k__BackingField
	String_t* ___U3CuseStateFromU3Ek__BackingField_3;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<displayName>k__BackingField
	String_t* ___U3CdisplayNameU3Ek__BackingField_4;
	// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<shortDisplayName>k__BackingField
	String_t* ___U3CshortDisplayNameU3Ek__BackingField_5;
	// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<usages>k__BackingField
	ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___U3CusagesU3Ek__BackingField_6;
	// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<aliases>k__BackingField
	ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___U3CaliasesU3Ek__BackingField_7;
	// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<parameters>k__BackingField
	ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___U3CparametersU3Ek__BackingField_8;
	// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NameAndParameters> UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<processors>k__BackingField
	ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  ___U3CprocessorsU3Ek__BackingField_9;
	// System.UInt32 UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<offset>k__BackingField
	uint32_t ___U3CoffsetU3Ek__BackingField_10;
	// System.UInt32 UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<bit>k__BackingField
	uint32_t ___U3CbitU3Ek__BackingField_11;
	// System.UInt32 UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<sizeInBits>k__BackingField
	uint32_t ___U3CsizeInBitsU3Ek__BackingField_12;
	// UnityEngine.InputSystem.Utilities.FourCC UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<format>k__BackingField
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___U3CformatU3Ek__BackingField_13;
	// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem/Flags UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<flags>k__BackingField
	int32_t ___U3CflagsU3Ek__BackingField_14;
	// System.Int32 UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<arraySize>k__BackingField
	int32_t ___U3CarraySizeU3Ek__BackingField_15;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<defaultState>k__BackingField
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___U3CdefaultStateU3Ek__BackingField_16;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<minValue>k__BackingField
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___U3CminValueU3Ek__BackingField_17;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::<maxValue>k__BackingField
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___U3CmaxValueU3Ek__BackingField_18;

public:
	inline static int32_t get_offset_of_U3CnameU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CnameU3Ek__BackingField_0)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_U3CnameU3Ek__BackingField_0() const { return ___U3CnameU3Ek__BackingField_0; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_U3CnameU3Ek__BackingField_0() { return &___U3CnameU3Ek__BackingField_0; }
	inline void set_U3CnameU3Ek__BackingField_0(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___U3CnameU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CnameU3Ek__BackingField_0))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CnameU3Ek__BackingField_0))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3ClayoutU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3ClayoutU3Ek__BackingField_1)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_U3ClayoutU3Ek__BackingField_1() const { return ___U3ClayoutU3Ek__BackingField_1; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_U3ClayoutU3Ek__BackingField_1() { return &___U3ClayoutU3Ek__BackingField_1; }
	inline void set_U3ClayoutU3Ek__BackingField_1(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___U3ClayoutU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3ClayoutU3Ek__BackingField_1))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3ClayoutU3Ek__BackingField_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CvariantsU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CvariantsU3Ek__BackingField_2)); }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  get_U3CvariantsU3Ek__BackingField_2() const { return ___U3CvariantsU3Ek__BackingField_2; }
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * get_address_of_U3CvariantsU3Ek__BackingField_2() { return &___U3CvariantsU3Ek__BackingField_2; }
	inline void set_U3CvariantsU3Ek__BackingField_2(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		___U3CvariantsU3Ek__BackingField_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CvariantsU3Ek__BackingField_2))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CvariantsU3Ek__BackingField_2))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CuseStateFromU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CuseStateFromU3Ek__BackingField_3)); }
	inline String_t* get_U3CuseStateFromU3Ek__BackingField_3() const { return ___U3CuseStateFromU3Ek__BackingField_3; }
	inline String_t** get_address_of_U3CuseStateFromU3Ek__BackingField_3() { return &___U3CuseStateFromU3Ek__BackingField_3; }
	inline void set_U3CuseStateFromU3Ek__BackingField_3(String_t* value)
	{
		___U3CuseStateFromU3Ek__BackingField_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CuseStateFromU3Ek__BackingField_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CdisplayNameU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CdisplayNameU3Ek__BackingField_4)); }
	inline String_t* get_U3CdisplayNameU3Ek__BackingField_4() const { return ___U3CdisplayNameU3Ek__BackingField_4; }
	inline String_t** get_address_of_U3CdisplayNameU3Ek__BackingField_4() { return &___U3CdisplayNameU3Ek__BackingField_4; }
	inline void set_U3CdisplayNameU3Ek__BackingField_4(String_t* value)
	{
		___U3CdisplayNameU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CdisplayNameU3Ek__BackingField_4), (void*)value);
	}

	inline static int32_t get_offset_of_U3CshortDisplayNameU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CshortDisplayNameU3Ek__BackingField_5)); }
	inline String_t* get_U3CshortDisplayNameU3Ek__BackingField_5() const { return ___U3CshortDisplayNameU3Ek__BackingField_5; }
	inline String_t** get_address_of_U3CshortDisplayNameU3Ek__BackingField_5() { return &___U3CshortDisplayNameU3Ek__BackingField_5; }
	inline void set_U3CshortDisplayNameU3Ek__BackingField_5(String_t* value)
	{
		___U3CshortDisplayNameU3Ek__BackingField_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CshortDisplayNameU3Ek__BackingField_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CusagesU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CusagesU3Ek__BackingField_6)); }
	inline ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  get_U3CusagesU3Ek__BackingField_6() const { return ___U3CusagesU3Ek__BackingField_6; }
	inline ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C * get_address_of_U3CusagesU3Ek__BackingField_6() { return &___U3CusagesU3Ek__BackingField_6; }
	inline void set_U3CusagesU3Ek__BackingField_6(ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  value)
	{
		___U3CusagesU3Ek__BackingField_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CusagesU3Ek__BackingField_6))->___m_Array_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CaliasesU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CaliasesU3Ek__BackingField_7)); }
	inline ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  get_U3CaliasesU3Ek__BackingField_7() const { return ___U3CaliasesU3Ek__BackingField_7; }
	inline ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C * get_address_of_U3CaliasesU3Ek__BackingField_7() { return &___U3CaliasesU3Ek__BackingField_7; }
	inline void set_U3CaliasesU3Ek__BackingField_7(ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  value)
	{
		___U3CaliasesU3Ek__BackingField_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CaliasesU3Ek__BackingField_7))->___m_Array_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CparametersU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CparametersU3Ek__BackingField_8)); }
	inline ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  get_U3CparametersU3Ek__BackingField_8() const { return ___U3CparametersU3Ek__BackingField_8; }
	inline ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8 * get_address_of_U3CparametersU3Ek__BackingField_8() { return &___U3CparametersU3Ek__BackingField_8; }
	inline void set_U3CparametersU3Ek__BackingField_8(ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  value)
	{
		___U3CparametersU3Ek__BackingField_8 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CparametersU3Ek__BackingField_8))->___m_Array_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CprocessorsU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CprocessorsU3Ek__BackingField_9)); }
	inline ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  get_U3CprocessorsU3Ek__BackingField_9() const { return ___U3CprocessorsU3Ek__BackingField_9; }
	inline ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F * get_address_of_U3CprocessorsU3Ek__BackingField_9() { return &___U3CprocessorsU3Ek__BackingField_9; }
	inline void set_U3CprocessorsU3Ek__BackingField_9(ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  value)
	{
		___U3CprocessorsU3Ek__BackingField_9 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CprocessorsU3Ek__BackingField_9))->___m_Array_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CoffsetU3Ek__BackingField_10() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CoffsetU3Ek__BackingField_10)); }
	inline uint32_t get_U3CoffsetU3Ek__BackingField_10() const { return ___U3CoffsetU3Ek__BackingField_10; }
	inline uint32_t* get_address_of_U3CoffsetU3Ek__BackingField_10() { return &___U3CoffsetU3Ek__BackingField_10; }
	inline void set_U3CoffsetU3Ek__BackingField_10(uint32_t value)
	{
		___U3CoffsetU3Ek__BackingField_10 = value;
	}

	inline static int32_t get_offset_of_U3CbitU3Ek__BackingField_11() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CbitU3Ek__BackingField_11)); }
	inline uint32_t get_U3CbitU3Ek__BackingField_11() const { return ___U3CbitU3Ek__BackingField_11; }
	inline uint32_t* get_address_of_U3CbitU3Ek__BackingField_11() { return &___U3CbitU3Ek__BackingField_11; }
	inline void set_U3CbitU3Ek__BackingField_11(uint32_t value)
	{
		___U3CbitU3Ek__BackingField_11 = value;
	}

	inline static int32_t get_offset_of_U3CsizeInBitsU3Ek__BackingField_12() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CsizeInBitsU3Ek__BackingField_12)); }
	inline uint32_t get_U3CsizeInBitsU3Ek__BackingField_12() const { return ___U3CsizeInBitsU3Ek__BackingField_12; }
	inline uint32_t* get_address_of_U3CsizeInBitsU3Ek__BackingField_12() { return &___U3CsizeInBitsU3Ek__BackingField_12; }
	inline void set_U3CsizeInBitsU3Ek__BackingField_12(uint32_t value)
	{
		___U3CsizeInBitsU3Ek__BackingField_12 = value;
	}

	inline static int32_t get_offset_of_U3CformatU3Ek__BackingField_13() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CformatU3Ek__BackingField_13)); }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  get_U3CformatU3Ek__BackingField_13() const { return ___U3CformatU3Ek__BackingField_13; }
	inline FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * get_address_of_U3CformatU3Ek__BackingField_13() { return &___U3CformatU3Ek__BackingField_13; }
	inline void set_U3CformatU3Ek__BackingField_13(FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  value)
	{
		___U3CformatU3Ek__BackingField_13 = value;
	}

	inline static int32_t get_offset_of_U3CflagsU3Ek__BackingField_14() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CflagsU3Ek__BackingField_14)); }
	inline int32_t get_U3CflagsU3Ek__BackingField_14() const { return ___U3CflagsU3Ek__BackingField_14; }
	inline int32_t* get_address_of_U3CflagsU3Ek__BackingField_14() { return &___U3CflagsU3Ek__BackingField_14; }
	inline void set_U3CflagsU3Ek__BackingField_14(int32_t value)
	{
		___U3CflagsU3Ek__BackingField_14 = value;
	}

	inline static int32_t get_offset_of_U3CarraySizeU3Ek__BackingField_15() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CarraySizeU3Ek__BackingField_15)); }
	inline int32_t get_U3CarraySizeU3Ek__BackingField_15() const { return ___U3CarraySizeU3Ek__BackingField_15; }
	inline int32_t* get_address_of_U3CarraySizeU3Ek__BackingField_15() { return &___U3CarraySizeU3Ek__BackingField_15; }
	inline void set_U3CarraySizeU3Ek__BackingField_15(int32_t value)
	{
		___U3CarraySizeU3Ek__BackingField_15 = value;
	}

	inline static int32_t get_offset_of_U3CdefaultStateU3Ek__BackingField_16() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CdefaultStateU3Ek__BackingField_16)); }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  get_U3CdefaultStateU3Ek__BackingField_16() const { return ___U3CdefaultStateU3Ek__BackingField_16; }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA * get_address_of_U3CdefaultStateU3Ek__BackingField_16() { return &___U3CdefaultStateU3Ek__BackingField_16; }
	inline void set_U3CdefaultStateU3Ek__BackingField_16(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  value)
	{
		___U3CdefaultStateU3Ek__BackingField_16 = value;
	}

	inline static int32_t get_offset_of_U3CminValueU3Ek__BackingField_17() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CminValueU3Ek__BackingField_17)); }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  get_U3CminValueU3Ek__BackingField_17() const { return ___U3CminValueU3Ek__BackingField_17; }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA * get_address_of_U3CminValueU3Ek__BackingField_17() { return &___U3CminValueU3Ek__BackingField_17; }
	inline void set_U3CminValueU3Ek__BackingField_17(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  value)
	{
		___U3CminValueU3Ek__BackingField_17 = value;
	}

	inline static int32_t get_offset_of_U3CmaxValueU3Ek__BackingField_18() { return static_cast<int32_t>(offsetof(ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D, ___U3CmaxValueU3Ek__BackingField_18)); }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  get_U3CmaxValueU3Ek__BackingField_18() const { return ___U3CmaxValueU3Ek__BackingField_18; }
	inline PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA * get_address_of_U3CmaxValueU3Ek__BackingField_18() { return &___U3CmaxValueU3Ek__BackingField_18; }
	inline void set_U3CmaxValueU3Ek__BackingField_18(PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  value)
	{
		___U3CmaxValueU3Ek__BackingField_18 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem
struct ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D_marshaled_pinvoke
{
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke ___U3CnameU3Ek__BackingField_0;
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke ___U3ClayoutU3Ek__BackingField_1;
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke ___U3CvariantsU3Ek__BackingField_2;
	char* ___U3CuseStateFromU3Ek__BackingField_3;
	char* ___U3CdisplayNameU3Ek__BackingField_4;
	char* ___U3CshortDisplayNameU3Ek__BackingField_5;
	ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___U3CusagesU3Ek__BackingField_6;
	ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___U3CaliasesU3Ek__BackingField_7;
	ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___U3CparametersU3Ek__BackingField_8;
	ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  ___U3CprocessorsU3Ek__BackingField_9;
	uint32_t ___U3CoffsetU3Ek__BackingField_10;
	uint32_t ___U3CbitU3Ek__BackingField_11;
	uint32_t ___U3CsizeInBitsU3Ek__BackingField_12;
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___U3CformatU3Ek__BackingField_13;
	int32_t ___U3CflagsU3Ek__BackingField_14;
	int32_t ___U3CarraySizeU3Ek__BackingField_15;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_pinvoke ___U3CdefaultStateU3Ek__BackingField_16;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_pinvoke ___U3CminValueU3Ek__BackingField_17;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_pinvoke ___U3CmaxValueU3Ek__BackingField_18;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem
struct ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D_marshaled_com
{
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com ___U3CnameU3Ek__BackingField_0;
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com ___U3ClayoutU3Ek__BackingField_1;
	InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com ___U3CvariantsU3Ek__BackingField_2;
	Il2CppChar* ___U3CuseStateFromU3Ek__BackingField_3;
	Il2CppChar* ___U3CdisplayNameU3Ek__BackingField_4;
	Il2CppChar* ___U3CshortDisplayNameU3Ek__BackingField_5;
	ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___U3CusagesU3Ek__BackingField_6;
	ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___U3CaliasesU3Ek__BackingField_7;
	ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___U3CparametersU3Ek__BackingField_8;
	ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  ___U3CprocessorsU3Ek__BackingField_9;
	uint32_t ___U3CoffsetU3Ek__BackingField_10;
	uint32_t ___U3CbitU3Ek__BackingField_11;
	uint32_t ___U3CsizeInBitsU3Ek__BackingField_12;
	FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___U3CformatU3Ek__BackingField_13;
	int32_t ___U3CflagsU3Ek__BackingField_14;
	int32_t ___U3CarraySizeU3Ek__BackingField_15;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_com ___U3CdefaultStateU3Ek__BackingField_16;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_com ___U3CminValueU3Ek__BackingField_17;
	PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA_marshaled_com ___U3CmaxValueU3Ek__BackingField_18;
};

// UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState
struct GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A 
{
public:
	// UnityEngine.InputSystem.Utilities.InlinedArray`1<UnityEngine.InputSystem.Touchscreen> UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState::touchscreens
	InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0  ___touchscreens_0;
	// System.Int32 UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState::historyLengthPerFinger
	int32_t ___historyLengthPerFinger_1;
	// UnityEngine.InputSystem.Utilities.CallbackArray`1<System.Action`1<UnityEngine.InputSystem.EnhancedTouch.Finger>> UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState::onFingerDown
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerDown_2;
	// UnityEngine.InputSystem.Utilities.CallbackArray`1<System.Action`1<UnityEngine.InputSystem.EnhancedTouch.Finger>> UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState::onFingerMove
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerMove_3;
	// UnityEngine.InputSystem.Utilities.CallbackArray`1<System.Action`1<UnityEngine.InputSystem.EnhancedTouch.Finger>> UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState::onFingerUp
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerUp_4;
	// UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState::playerState
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49  ___playerState_5;

public:
	inline static int32_t get_offset_of_touchscreens_0() { return static_cast<int32_t>(offsetof(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A, ___touchscreens_0)); }
	inline InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0  get_touchscreens_0() const { return ___touchscreens_0; }
	inline InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0 * get_address_of_touchscreens_0() { return &___touchscreens_0; }
	inline void set_touchscreens_0(InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0  value)
	{
		___touchscreens_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___touchscreens_0))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___touchscreens_0))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_historyLengthPerFinger_1() { return static_cast<int32_t>(offsetof(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A, ___historyLengthPerFinger_1)); }
	inline int32_t get_historyLengthPerFinger_1() const { return ___historyLengthPerFinger_1; }
	inline int32_t* get_address_of_historyLengthPerFinger_1() { return &___historyLengthPerFinger_1; }
	inline void set_historyLengthPerFinger_1(int32_t value)
	{
		___historyLengthPerFinger_1 = value;
	}

	inline static int32_t get_offset_of_onFingerDown_2() { return static_cast<int32_t>(offsetof(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A, ___onFingerDown_2)); }
	inline CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  get_onFingerDown_2() const { return ___onFingerDown_2; }
	inline CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F * get_address_of_onFingerDown_2() { return &___onFingerDown_2; }
	inline void set_onFingerDown_2(CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  value)
	{
		___onFingerDown_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerDown_2))->___m_Callbacks_1))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerDown_2))->___m_Callbacks_1))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerDown_2))->___m_CallbacksToAdd_2))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerDown_2))->___m_CallbacksToAdd_2))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerDown_2))->___m_CallbacksToRemove_3))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerDown_2))->___m_CallbacksToRemove_3))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_onFingerMove_3() { return static_cast<int32_t>(offsetof(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A, ___onFingerMove_3)); }
	inline CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  get_onFingerMove_3() const { return ___onFingerMove_3; }
	inline CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F * get_address_of_onFingerMove_3() { return &___onFingerMove_3; }
	inline void set_onFingerMove_3(CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  value)
	{
		___onFingerMove_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerMove_3))->___m_Callbacks_1))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerMove_3))->___m_Callbacks_1))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerMove_3))->___m_CallbacksToAdd_2))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerMove_3))->___m_CallbacksToAdd_2))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerMove_3))->___m_CallbacksToRemove_3))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerMove_3))->___m_CallbacksToRemove_3))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_onFingerUp_4() { return static_cast<int32_t>(offsetof(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A, ___onFingerUp_4)); }
	inline CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  get_onFingerUp_4() const { return ___onFingerUp_4; }
	inline CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F * get_address_of_onFingerUp_4() { return &___onFingerUp_4; }
	inline void set_onFingerUp_4(CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  value)
	{
		___onFingerUp_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerUp_4))->___m_Callbacks_1))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerUp_4))->___m_Callbacks_1))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerUp_4))->___m_CallbacksToAdd_2))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerUp_4))->___m_CallbacksToAdd_2))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerUp_4))->___m_CallbacksToRemove_3))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___onFingerUp_4))->___m_CallbacksToRemove_3))->___additionalValues_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_playerState_5() { return static_cast<int32_t>(offsetof(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A, ___playerState_5)); }
	inline FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49  get_playerState_5() const { return ___playerState_5; }
	inline FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * get_address_of_playerState_5() { return &___playerState_5; }
	inline void set_playerState_5(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49  value)
	{
		___playerState_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___playerState_5))->___fingers_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___playerState_5))->___activeFingers_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___playerState_5))->___activeTouches_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___playerState_5))->___activeTouchState_10), (void*)NULL);
		#endif
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState
struct GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_pinvoke
{
	InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0  ___touchscreens_0;
	int32_t ___historyLengthPerFinger_1;
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerDown_2;
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerMove_3;
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerUp_4;
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke ___playerState_5;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState
struct GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_com
{
	InlinedArray_1_t48B62A2FF6AB74D1AFAE1CE22F63985083F64AF0  ___touchscreens_0;
	int32_t ___historyLengthPerFinger_1;
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerDown_2;
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerMove_3;
	CallbackArray_1_tBC8AFBE137A7501ADDBE03CE37E1F2ABEA52A11F  ___onFingerUp_4;
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com ___playerState_5;
};

// UnityEngine.InputSystem.LowLevel.InputStateHistory`1<UnityEngine.InputSystem.LowLevel.TouchState>
struct InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2  : public InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E
{
public:

public:
};


// UnityEngine.InputSystem.InputDevice
struct InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154  : public InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713
{
public:
	// UnityEngine.InputSystem.InputDevice/DeviceFlags UnityEngine.InputSystem.InputDevice::m_DeviceFlags
	int32_t ___m_DeviceFlags_24;
	// System.Int32 UnityEngine.InputSystem.InputDevice::m_DeviceId
	int32_t ___m_DeviceId_25;
	// System.Int32 UnityEngine.InputSystem.InputDevice::m_ParticipantId
	int32_t ___m_ParticipantId_26;
	// System.Int32 UnityEngine.InputSystem.InputDevice::m_DeviceIndex
	int32_t ___m_DeviceIndex_27;
	// UnityEngine.InputSystem.Layouts.InputDeviceDescription UnityEngine.InputSystem.InputDevice::m_Description
	InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA  ___m_Description_28;
	// System.Double UnityEngine.InputSystem.InputDevice::m_LastUpdateTimeInternal
	double ___m_LastUpdateTimeInternal_29;
	// System.UInt32 UnityEngine.InputSystem.InputDevice::m_CurrentUpdateStepCount
	uint32_t ___m_CurrentUpdateStepCount_30;
	// UnityEngine.InputSystem.Utilities.InternedString[] UnityEngine.InputSystem.InputDevice::m_AliasesForEachControl
	InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___m_AliasesForEachControl_31;
	// UnityEngine.InputSystem.Utilities.InternedString[] UnityEngine.InputSystem.InputDevice::m_UsagesForEachControl
	InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___m_UsagesForEachControl_32;
	// UnityEngine.InputSystem.InputControl[] UnityEngine.InputSystem.InputDevice::m_UsageToControl
	InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* ___m_UsageToControl_33;
	// UnityEngine.InputSystem.InputControl[] UnityEngine.InputSystem.InputDevice::m_ChildrenForEachControl
	InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* ___m_ChildrenForEachControl_34;
	// System.UInt32[] UnityEngine.InputSystem.InputDevice::m_StateOffsetToControlMap
	UInt32U5BU5D_tCF06F1E9E72E0302C762578FF5358CC523F2A2CF* ___m_StateOffsetToControlMap_35;

public:
	inline static int32_t get_offset_of_m_DeviceFlags_24() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_DeviceFlags_24)); }
	inline int32_t get_m_DeviceFlags_24() const { return ___m_DeviceFlags_24; }
	inline int32_t* get_address_of_m_DeviceFlags_24() { return &___m_DeviceFlags_24; }
	inline void set_m_DeviceFlags_24(int32_t value)
	{
		___m_DeviceFlags_24 = value;
	}

	inline static int32_t get_offset_of_m_DeviceId_25() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_DeviceId_25)); }
	inline int32_t get_m_DeviceId_25() const { return ___m_DeviceId_25; }
	inline int32_t* get_address_of_m_DeviceId_25() { return &___m_DeviceId_25; }
	inline void set_m_DeviceId_25(int32_t value)
	{
		___m_DeviceId_25 = value;
	}

	inline static int32_t get_offset_of_m_ParticipantId_26() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_ParticipantId_26)); }
	inline int32_t get_m_ParticipantId_26() const { return ___m_ParticipantId_26; }
	inline int32_t* get_address_of_m_ParticipantId_26() { return &___m_ParticipantId_26; }
	inline void set_m_ParticipantId_26(int32_t value)
	{
		___m_ParticipantId_26 = value;
	}

	inline static int32_t get_offset_of_m_DeviceIndex_27() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_DeviceIndex_27)); }
	inline int32_t get_m_DeviceIndex_27() const { return ___m_DeviceIndex_27; }
	inline int32_t* get_address_of_m_DeviceIndex_27() { return &___m_DeviceIndex_27; }
	inline void set_m_DeviceIndex_27(int32_t value)
	{
		___m_DeviceIndex_27 = value;
	}

	inline static int32_t get_offset_of_m_Description_28() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_Description_28)); }
	inline InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA  get_m_Description_28() const { return ___m_Description_28; }
	inline InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA * get_address_of_m_Description_28() { return &___m_Description_28; }
	inline void set_m_Description_28(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA  value)
	{
		___m_Description_28 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Description_28))->___m_InterfaceName_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Description_28))->___m_DeviceClass_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Description_28))->___m_Manufacturer_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Description_28))->___m_Product_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Description_28))->___m_Serial_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Description_28))->___m_Version_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Description_28))->___m_Capabilities_6), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_LastUpdateTimeInternal_29() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_LastUpdateTimeInternal_29)); }
	inline double get_m_LastUpdateTimeInternal_29() const { return ___m_LastUpdateTimeInternal_29; }
	inline double* get_address_of_m_LastUpdateTimeInternal_29() { return &___m_LastUpdateTimeInternal_29; }
	inline void set_m_LastUpdateTimeInternal_29(double value)
	{
		___m_LastUpdateTimeInternal_29 = value;
	}

	inline static int32_t get_offset_of_m_CurrentUpdateStepCount_30() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_CurrentUpdateStepCount_30)); }
	inline uint32_t get_m_CurrentUpdateStepCount_30() const { return ___m_CurrentUpdateStepCount_30; }
	inline uint32_t* get_address_of_m_CurrentUpdateStepCount_30() { return &___m_CurrentUpdateStepCount_30; }
	inline void set_m_CurrentUpdateStepCount_30(uint32_t value)
	{
		___m_CurrentUpdateStepCount_30 = value;
	}

	inline static int32_t get_offset_of_m_AliasesForEachControl_31() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_AliasesForEachControl_31)); }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* get_m_AliasesForEachControl_31() const { return ___m_AliasesForEachControl_31; }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11** get_address_of_m_AliasesForEachControl_31() { return &___m_AliasesForEachControl_31; }
	inline void set_m_AliasesForEachControl_31(InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* value)
	{
		___m_AliasesForEachControl_31 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_AliasesForEachControl_31), (void*)value);
	}

	inline static int32_t get_offset_of_m_UsagesForEachControl_32() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_UsagesForEachControl_32)); }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* get_m_UsagesForEachControl_32() const { return ___m_UsagesForEachControl_32; }
	inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11** get_address_of_m_UsagesForEachControl_32() { return &___m_UsagesForEachControl_32; }
	inline void set_m_UsagesForEachControl_32(InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* value)
	{
		___m_UsagesForEachControl_32 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_UsagesForEachControl_32), (void*)value);
	}

	inline static int32_t get_offset_of_m_UsageToControl_33() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_UsageToControl_33)); }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* get_m_UsageToControl_33() const { return ___m_UsageToControl_33; }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F** get_address_of_m_UsageToControl_33() { return &___m_UsageToControl_33; }
	inline void set_m_UsageToControl_33(InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* value)
	{
		___m_UsageToControl_33 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_UsageToControl_33), (void*)value);
	}

	inline static int32_t get_offset_of_m_ChildrenForEachControl_34() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_ChildrenForEachControl_34)); }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* get_m_ChildrenForEachControl_34() const { return ___m_ChildrenForEachControl_34; }
	inline InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F** get_address_of_m_ChildrenForEachControl_34() { return &___m_ChildrenForEachControl_34; }
	inline void set_m_ChildrenForEachControl_34(InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* value)
	{
		___m_ChildrenForEachControl_34 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ChildrenForEachControl_34), (void*)value);
	}

	inline static int32_t get_offset_of_m_StateOffsetToControlMap_35() { return static_cast<int32_t>(offsetof(InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154, ___m_StateOffsetToControlMap_35)); }
	inline UInt32U5BU5D_tCF06F1E9E72E0302C762578FF5358CC523F2A2CF* get_m_StateOffsetToControlMap_35() const { return ___m_StateOffsetToControlMap_35; }
	inline UInt32U5BU5D_tCF06F1E9E72E0302C762578FF5358CC523F2A2CF** get_address_of_m_StateOffsetToControlMap_35() { return &___m_StateOffsetToControlMap_35; }
	inline void set_m_StateOffsetToControlMap_35(UInt32U5BU5D_tCF06F1E9E72E0302C762578FF5358CC523F2A2CF* value)
	{
		___m_StateOffsetToControlMap_35 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_StateOffsetToControlMap_35), (void*)value);
	}
};


// UnityEngine.MonoBehaviour
struct MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A  : public Behaviour_t1A3DDDCF73B4627928FBFE02ED52B7251777DBD9
{
public:

public:
};


// UnityEngine.InputSystem.EnhancedTouch.Touch
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA 
{
public:
	// UnityEngine.InputSystem.EnhancedTouch.Finger UnityEngine.InputSystem.EnhancedTouch.Touch::m_Finger
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___m_Finger_0;
	// UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record<UnityEngine.InputSystem.LowLevel.TouchState> UnityEngine.InputSystem.EnhancedTouch.Touch::m_TouchRecord
	Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  ___m_TouchRecord_1;

public:
	inline static int32_t get_offset_of_m_Finger_0() { return static_cast<int32_t>(offsetof(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA, ___m_Finger_0)); }
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * get_m_Finger_0() const { return ___m_Finger_0; }
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** get_address_of_m_Finger_0() { return &___m_Finger_0; }
	inline void set_m_Finger_0(Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * value)
	{
		___m_Finger_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Finger_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_TouchRecord_1() { return static_cast<int32_t>(offsetof(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA, ___m_TouchRecord_1)); }
	inline Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  get_m_TouchRecord_1() const { return ___m_TouchRecord_1; }
	inline Record_t6A3403317B951528E7A550FABE9EC42900ABFC48 * get_address_of_m_TouchRecord_1() { return &___m_TouchRecord_1; }
	inline void set_m_TouchRecord_1(Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  value)
	{
		___m_TouchRecord_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_TouchRecord_1))->___m_Owner_0), (void*)NULL);
	}
};

struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_StaticFields
{
public:
	// UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState UnityEngine.InputSystem.EnhancedTouch.Touch::s_GlobalState
	GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A  ___s_GlobalState_2;

public:
	inline static int32_t get_offset_of_s_GlobalState_2() { return static_cast<int32_t>(offsetof(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_StaticFields, ___s_GlobalState_2)); }
	inline GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A  get_s_GlobalState_2() const { return ___s_GlobalState_2; }
	inline GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A * get_address_of_s_GlobalState_2() { return &___s_GlobalState_2; }
	inline void set_s_GlobalState_2(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A  value)
	{
		___s_GlobalState_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___s_GlobalState_2))->___touchscreens_0))->___firstValue_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___s_GlobalState_2))->___touchscreens_0))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerDown_2))->___m_Callbacks_1))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerDown_2))->___m_Callbacks_1))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerDown_2))->___m_CallbacksToAdd_2))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerDown_2))->___m_CallbacksToAdd_2))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerDown_2))->___m_CallbacksToRemove_3))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerDown_2))->___m_CallbacksToRemove_3))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerMove_3))->___m_Callbacks_1))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerMove_3))->___m_Callbacks_1))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerMove_3))->___m_CallbacksToAdd_2))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerMove_3))->___m_CallbacksToAdd_2))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerMove_3))->___m_CallbacksToRemove_3))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerMove_3))->___m_CallbacksToRemove_3))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerUp_4))->___m_Callbacks_1))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerUp_4))->___m_Callbacks_1))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerUp_4))->___m_CallbacksToAdd_2))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerUp_4))->___m_CallbacksToAdd_2))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerUp_4))->___m_CallbacksToRemove_3))->___firstValue_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___s_GlobalState_2))->___onFingerUp_4))->___m_CallbacksToRemove_3))->___additionalValues_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___s_GlobalState_2))->___playerState_5))->___fingers_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___s_GlobalState_2))->___playerState_5))->___activeFingers_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___s_GlobalState_2))->___playerState_5))->___activeTouches_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___s_GlobalState_2))->___playerState_5))->___activeTouchState_10), (void*)NULL);
		#endif
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.EnhancedTouch.Touch
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_pinvoke
{
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___m_Finger_0;
	Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  ___m_TouchRecord_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.EnhancedTouch.Touch
struct Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_com
{
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___m_Finger_0;
	Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  ___m_TouchRecord_1;
};

// UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator
struct Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::m_Index
	int32_t ___m_Index_0;
	// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement[] UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::m_Requirements
	DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* ___m_Requirements_1;
	// UnityEngine.InputSystem.InputControlList`1<UnityEngine.InputSystem.InputControl> UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::m_Controls
	InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  ___m_Controls_2;

public:
	inline static int32_t get_offset_of_m_Index_0() { return static_cast<int32_t>(offsetof(Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98, ___m_Index_0)); }
	inline int32_t get_m_Index_0() const { return ___m_Index_0; }
	inline int32_t* get_address_of_m_Index_0() { return &___m_Index_0; }
	inline void set_m_Index_0(int32_t value)
	{
		___m_Index_0 = value;
	}

	inline static int32_t get_offset_of_m_Requirements_1() { return static_cast<int32_t>(offsetof(Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98, ___m_Requirements_1)); }
	inline DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* get_m_Requirements_1() const { return ___m_Requirements_1; }
	inline DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F** get_address_of_m_Requirements_1() { return &___m_Requirements_1; }
	inline void set_m_Requirements_1(DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* value)
	{
		___m_Requirements_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Requirements_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_Controls_2() { return static_cast<int32_t>(offsetof(Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98, ___m_Controls_2)); }
	inline InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  get_m_Controls_2() const { return ___m_Controls_2; }
	inline InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B * get_address_of_m_Controls_2() { return &___m_Controls_2; }
	inline void set_m_Controls_2(InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  value)
	{
		___m_Controls_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator
struct Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_pinvoke
{
	int32_t ___m_Index_0;
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke* ___m_Requirements_1;
	InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  ___m_Controls_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator
struct Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_com
{
	int32_t ___m_Index_0;
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com* ___m_Requirements_1;
	InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  ___m_Controls_2;
};

// UnityEngine.InputSystem.InputControlScheme/MatchResult/Match
struct Match_tF8E25BC160894A799358F44EB19C42365DAF0828 
{
public:
	// System.Int32 UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::m_RequirementIndex
	int32_t ___m_RequirementIndex_0;
	// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement[] UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::m_Requirements
	DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* ___m_Requirements_1;
	// UnityEngine.InputSystem.InputControlList`1<UnityEngine.InputSystem.InputControl> UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::m_Controls
	InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  ___m_Controls_2;

public:
	inline static int32_t get_offset_of_m_RequirementIndex_0() { return static_cast<int32_t>(offsetof(Match_tF8E25BC160894A799358F44EB19C42365DAF0828, ___m_RequirementIndex_0)); }
	inline int32_t get_m_RequirementIndex_0() const { return ___m_RequirementIndex_0; }
	inline int32_t* get_address_of_m_RequirementIndex_0() { return &___m_RequirementIndex_0; }
	inline void set_m_RequirementIndex_0(int32_t value)
	{
		___m_RequirementIndex_0 = value;
	}

	inline static int32_t get_offset_of_m_Requirements_1() { return static_cast<int32_t>(offsetof(Match_tF8E25BC160894A799358F44EB19C42365DAF0828, ___m_Requirements_1)); }
	inline DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* get_m_Requirements_1() const { return ___m_Requirements_1; }
	inline DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F** get_address_of_m_Requirements_1() { return &___m_Requirements_1; }
	inline void set_m_Requirements_1(DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* value)
	{
		___m_Requirements_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Requirements_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_Controls_2() { return static_cast<int32_t>(offsetof(Match_tF8E25BC160894A799358F44EB19C42365DAF0828, ___m_Controls_2)); }
	inline InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  get_m_Controls_2() const { return ___m_Controls_2; }
	inline InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B * get_address_of_m_Controls_2() { return &___m_Controls_2; }
	inline void set_m_Controls_2(InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  value)
	{
		___m_Controls_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.InputControlScheme/MatchResult/Match
struct Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_pinvoke
{
	int32_t ___m_RequirementIndex_0;
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke* ___m_Requirements_1;
	InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  ___m_Controls_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.InputControlScheme/MatchResult/Match
struct Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_com
{
	int32_t ___m_RequirementIndex_0;
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com* ___m_Requirements_1;
	InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  ___m_Controls_2;
};

// UnityEngine.InputSystem.Pointer
struct Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8  : public InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154
{
public:
	// UnityEngine.InputSystem.Controls.Vector2Control UnityEngine.InputSystem.Pointer::<position>k__BackingField
	Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * ___U3CpositionU3Ek__BackingField_39;
	// UnityEngine.InputSystem.Controls.Vector2Control UnityEngine.InputSystem.Pointer::<delta>k__BackingField
	Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * ___U3CdeltaU3Ek__BackingField_40;
	// UnityEngine.InputSystem.Controls.Vector2Control UnityEngine.InputSystem.Pointer::<radius>k__BackingField
	Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * ___U3CradiusU3Ek__BackingField_41;
	// UnityEngine.InputSystem.Controls.AxisControl UnityEngine.InputSystem.Pointer::<pressure>k__BackingField
	AxisControl_tF6BA6DA28DAB8BBBAD80A596F12BF340EE883B22 * ___U3CpressureU3Ek__BackingField_42;
	// UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.InputSystem.Pointer::<press>k__BackingField
	ButtonControl_t7C71776B1EF54267612446DAC263673FCCA25E6D * ___U3CpressU3Ek__BackingField_43;

public:
	inline static int32_t get_offset_of_U3CpositionU3Ek__BackingField_39() { return static_cast<int32_t>(offsetof(Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8, ___U3CpositionU3Ek__BackingField_39)); }
	inline Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * get_U3CpositionU3Ek__BackingField_39() const { return ___U3CpositionU3Ek__BackingField_39; }
	inline Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 ** get_address_of_U3CpositionU3Ek__BackingField_39() { return &___U3CpositionU3Ek__BackingField_39; }
	inline void set_U3CpositionU3Ek__BackingField_39(Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * value)
	{
		___U3CpositionU3Ek__BackingField_39 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CpositionU3Ek__BackingField_39), (void*)value);
	}

	inline static int32_t get_offset_of_U3CdeltaU3Ek__BackingField_40() { return static_cast<int32_t>(offsetof(Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8, ___U3CdeltaU3Ek__BackingField_40)); }
	inline Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * get_U3CdeltaU3Ek__BackingField_40() const { return ___U3CdeltaU3Ek__BackingField_40; }
	inline Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 ** get_address_of_U3CdeltaU3Ek__BackingField_40() { return &___U3CdeltaU3Ek__BackingField_40; }
	inline void set_U3CdeltaU3Ek__BackingField_40(Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * value)
	{
		___U3CdeltaU3Ek__BackingField_40 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CdeltaU3Ek__BackingField_40), (void*)value);
	}

	inline static int32_t get_offset_of_U3CradiusU3Ek__BackingField_41() { return static_cast<int32_t>(offsetof(Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8, ___U3CradiusU3Ek__BackingField_41)); }
	inline Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * get_U3CradiusU3Ek__BackingField_41() const { return ___U3CradiusU3Ek__BackingField_41; }
	inline Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 ** get_address_of_U3CradiusU3Ek__BackingField_41() { return &___U3CradiusU3Ek__BackingField_41; }
	inline void set_U3CradiusU3Ek__BackingField_41(Vector2Control_t342BA848221108F8818F05BF3CB484934F582935 * value)
	{
		___U3CradiusU3Ek__BackingField_41 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CradiusU3Ek__BackingField_41), (void*)value);
	}

	inline static int32_t get_offset_of_U3CpressureU3Ek__BackingField_42() { return static_cast<int32_t>(offsetof(Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8, ___U3CpressureU3Ek__BackingField_42)); }
	inline AxisControl_tF6BA6DA28DAB8BBBAD80A596F12BF340EE883B22 * get_U3CpressureU3Ek__BackingField_42() const { return ___U3CpressureU3Ek__BackingField_42; }
	inline AxisControl_tF6BA6DA28DAB8BBBAD80A596F12BF340EE883B22 ** get_address_of_U3CpressureU3Ek__BackingField_42() { return &___U3CpressureU3Ek__BackingField_42; }
	inline void set_U3CpressureU3Ek__BackingField_42(AxisControl_tF6BA6DA28DAB8BBBAD80A596F12BF340EE883B22 * value)
	{
		___U3CpressureU3Ek__BackingField_42 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CpressureU3Ek__BackingField_42), (void*)value);
	}

	inline static int32_t get_offset_of_U3CpressU3Ek__BackingField_43() { return static_cast<int32_t>(offsetof(Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8, ___U3CpressU3Ek__BackingField_43)); }
	inline ButtonControl_t7C71776B1EF54267612446DAC263673FCCA25E6D * get_U3CpressU3Ek__BackingField_43() const { return ___U3CpressU3Ek__BackingField_43; }
	inline ButtonControl_t7C71776B1EF54267612446DAC263673FCCA25E6D ** get_address_of_U3CpressU3Ek__BackingField_43() { return &___U3CpressU3Ek__BackingField_43; }
	inline void set_U3CpressU3Ek__BackingField_43(ButtonControl_t7C71776B1EF54267612446DAC263673FCCA25E6D * value)
	{
		___U3CpressU3Ek__BackingField_43 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CpressU3Ek__BackingField_43), (void*)value);
	}
};

struct Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8_StaticFields
{
public:
	// UnityEngine.InputSystem.Pointer UnityEngine.InputSystem.Pointer::<current>k__BackingField
	Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8 * ___U3CcurrentU3Ek__BackingField_44;

public:
	inline static int32_t get_offset_of_U3CcurrentU3Ek__BackingField_44() { return static_cast<int32_t>(offsetof(Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8_StaticFields, ___U3CcurrentU3Ek__BackingField_44)); }
	inline Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8 * get_U3CcurrentU3Ek__BackingField_44() const { return ___U3CcurrentU3Ek__BackingField_44; }
	inline Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8 ** get_address_of_U3CcurrentU3Ek__BackingField_44() { return &___U3CcurrentU3Ek__BackingField_44; }
	inline void set_U3CcurrentU3Ek__BackingField_44(Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8 * value)
	{
		___U3CcurrentU3Ek__BackingField_44 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CcurrentU3Ek__BackingField_44), (void*)value);
	}
};


// UnityEngine.EventSystems.UIBehaviour
struct UIBehaviour_tD1C6E2D542222546D68510ECE74036EFBC3C3B0E  : public MonoBehaviour_t37A501200D970A8257124B0EAE00A0FF3DDC354A
{
public:

public:
};


// UnityEngine.UI.Graphic
struct Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24  : public UIBehaviour_tD1C6E2D542222546D68510ECE74036EFBC3C3B0E
{
public:
	// UnityEngine.Material UnityEngine.UI.Graphic::m_Material
	Material_t8927C00353A72755313F046D0CE85178AE8218EE * ___m_Material_6;
	// UnityEngine.Color UnityEngine.UI.Graphic::m_Color
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___m_Color_7;
	// System.Boolean UnityEngine.UI.Graphic::m_SkipLayoutUpdate
	bool ___m_SkipLayoutUpdate_8;
	// System.Boolean UnityEngine.UI.Graphic::m_SkipMaterialUpdate
	bool ___m_SkipMaterialUpdate_9;
	// System.Boolean UnityEngine.UI.Graphic::m_RaycastTarget
	bool ___m_RaycastTarget_10;
	// UnityEngine.Vector4 UnityEngine.UI.Graphic::m_RaycastPadding
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___m_RaycastPadding_11;
	// UnityEngine.RectTransform UnityEngine.UI.Graphic::m_RectTransform
	RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * ___m_RectTransform_12;
	// UnityEngine.CanvasRenderer UnityEngine.UI.Graphic::m_CanvasRenderer
	CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E * ___m_CanvasRenderer_13;
	// UnityEngine.Canvas UnityEngine.UI.Graphic::m_Canvas
	Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA * ___m_Canvas_14;
	// System.Boolean UnityEngine.UI.Graphic::m_VertsDirty
	bool ___m_VertsDirty_15;
	// System.Boolean UnityEngine.UI.Graphic::m_MaterialDirty
	bool ___m_MaterialDirty_16;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyLayoutCallback
	UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * ___m_OnDirtyLayoutCallback_17;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyVertsCallback
	UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * ___m_OnDirtyVertsCallback_18;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyMaterialCallback
	UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * ___m_OnDirtyMaterialCallback_19;
	// UnityEngine.Mesh UnityEngine.UI.Graphic::m_CachedMesh
	Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * ___m_CachedMesh_22;
	// UnityEngine.Vector2[] UnityEngine.UI.Graphic::m_CachedUvs
	Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA* ___m_CachedUvs_23;
	// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween> UnityEngine.UI.Graphic::m_ColorTweenRunner
	TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 * ___m_ColorTweenRunner_24;
	// System.Boolean UnityEngine.UI.Graphic::<useLegacyMeshGeneration>k__BackingField
	bool ___U3CuseLegacyMeshGenerationU3Ek__BackingField_25;

public:
	inline static int32_t get_offset_of_m_Material_6() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_Material_6)); }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE * get_m_Material_6() const { return ___m_Material_6; }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE ** get_address_of_m_Material_6() { return &___m_Material_6; }
	inline void set_m_Material_6(Material_t8927C00353A72755313F046D0CE85178AE8218EE * value)
	{
		___m_Material_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Material_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_Color_7() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_Color_7)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_m_Color_7() const { return ___m_Color_7; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_m_Color_7() { return &___m_Color_7; }
	inline void set_m_Color_7(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___m_Color_7 = value;
	}

	inline static int32_t get_offset_of_m_SkipLayoutUpdate_8() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_SkipLayoutUpdate_8)); }
	inline bool get_m_SkipLayoutUpdate_8() const { return ___m_SkipLayoutUpdate_8; }
	inline bool* get_address_of_m_SkipLayoutUpdate_8() { return &___m_SkipLayoutUpdate_8; }
	inline void set_m_SkipLayoutUpdate_8(bool value)
	{
		___m_SkipLayoutUpdate_8 = value;
	}

	inline static int32_t get_offset_of_m_SkipMaterialUpdate_9() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_SkipMaterialUpdate_9)); }
	inline bool get_m_SkipMaterialUpdate_9() const { return ___m_SkipMaterialUpdate_9; }
	inline bool* get_address_of_m_SkipMaterialUpdate_9() { return &___m_SkipMaterialUpdate_9; }
	inline void set_m_SkipMaterialUpdate_9(bool value)
	{
		___m_SkipMaterialUpdate_9 = value;
	}

	inline static int32_t get_offset_of_m_RaycastTarget_10() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_RaycastTarget_10)); }
	inline bool get_m_RaycastTarget_10() const { return ___m_RaycastTarget_10; }
	inline bool* get_address_of_m_RaycastTarget_10() { return &___m_RaycastTarget_10; }
	inline void set_m_RaycastTarget_10(bool value)
	{
		___m_RaycastTarget_10 = value;
	}

	inline static int32_t get_offset_of_m_RaycastPadding_11() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_RaycastPadding_11)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_m_RaycastPadding_11() const { return ___m_RaycastPadding_11; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_m_RaycastPadding_11() { return &___m_RaycastPadding_11; }
	inline void set_m_RaycastPadding_11(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___m_RaycastPadding_11 = value;
	}

	inline static int32_t get_offset_of_m_RectTransform_12() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_RectTransform_12)); }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * get_m_RectTransform_12() const { return ___m_RectTransform_12; }
	inline RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 ** get_address_of_m_RectTransform_12() { return &___m_RectTransform_12; }
	inline void set_m_RectTransform_12(RectTransform_t8A6A306FB29A6C8C22010CF9040E319753571072 * value)
	{
		___m_RectTransform_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_RectTransform_12), (void*)value);
	}

	inline static int32_t get_offset_of_m_CanvasRenderer_13() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_CanvasRenderer_13)); }
	inline CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E * get_m_CanvasRenderer_13() const { return ___m_CanvasRenderer_13; }
	inline CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E ** get_address_of_m_CanvasRenderer_13() { return &___m_CanvasRenderer_13; }
	inline void set_m_CanvasRenderer_13(CanvasRenderer_tCF8ABE659F7C3A6ED0D99A988D0BDFB651310F0E * value)
	{
		___m_CanvasRenderer_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CanvasRenderer_13), (void*)value);
	}

	inline static int32_t get_offset_of_m_Canvas_14() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_Canvas_14)); }
	inline Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA * get_m_Canvas_14() const { return ___m_Canvas_14; }
	inline Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA ** get_address_of_m_Canvas_14() { return &___m_Canvas_14; }
	inline void set_m_Canvas_14(Canvas_t2B7E56B7BDC287962E092755372E214ACB6393EA * value)
	{
		___m_Canvas_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Canvas_14), (void*)value);
	}

	inline static int32_t get_offset_of_m_VertsDirty_15() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_VertsDirty_15)); }
	inline bool get_m_VertsDirty_15() const { return ___m_VertsDirty_15; }
	inline bool* get_address_of_m_VertsDirty_15() { return &___m_VertsDirty_15; }
	inline void set_m_VertsDirty_15(bool value)
	{
		___m_VertsDirty_15 = value;
	}

	inline static int32_t get_offset_of_m_MaterialDirty_16() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_MaterialDirty_16)); }
	inline bool get_m_MaterialDirty_16() const { return ___m_MaterialDirty_16; }
	inline bool* get_address_of_m_MaterialDirty_16() { return &___m_MaterialDirty_16; }
	inline void set_m_MaterialDirty_16(bool value)
	{
		___m_MaterialDirty_16 = value;
	}

	inline static int32_t get_offset_of_m_OnDirtyLayoutCallback_17() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_OnDirtyLayoutCallback_17)); }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * get_m_OnDirtyLayoutCallback_17() const { return ___m_OnDirtyLayoutCallback_17; }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 ** get_address_of_m_OnDirtyLayoutCallback_17() { return &___m_OnDirtyLayoutCallback_17; }
	inline void set_m_OnDirtyLayoutCallback_17(UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * value)
	{
		___m_OnDirtyLayoutCallback_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnDirtyLayoutCallback_17), (void*)value);
	}

	inline static int32_t get_offset_of_m_OnDirtyVertsCallback_18() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_OnDirtyVertsCallback_18)); }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * get_m_OnDirtyVertsCallback_18() const { return ___m_OnDirtyVertsCallback_18; }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 ** get_address_of_m_OnDirtyVertsCallback_18() { return &___m_OnDirtyVertsCallback_18; }
	inline void set_m_OnDirtyVertsCallback_18(UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * value)
	{
		___m_OnDirtyVertsCallback_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnDirtyVertsCallback_18), (void*)value);
	}

	inline static int32_t get_offset_of_m_OnDirtyMaterialCallback_19() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_OnDirtyMaterialCallback_19)); }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * get_m_OnDirtyMaterialCallback_19() const { return ___m_OnDirtyMaterialCallback_19; }
	inline UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 ** get_address_of_m_OnDirtyMaterialCallback_19() { return &___m_OnDirtyMaterialCallback_19; }
	inline void set_m_OnDirtyMaterialCallback_19(UnityAction_t22E545F8BE0A62EE051C6A83E209587A0DB1C099 * value)
	{
		___m_OnDirtyMaterialCallback_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_OnDirtyMaterialCallback_19), (void*)value);
	}

	inline static int32_t get_offset_of_m_CachedMesh_22() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_CachedMesh_22)); }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * get_m_CachedMesh_22() const { return ___m_CachedMesh_22; }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 ** get_address_of_m_CachedMesh_22() { return &___m_CachedMesh_22; }
	inline void set_m_CachedMesh_22(Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * value)
	{
		___m_CachedMesh_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CachedMesh_22), (void*)value);
	}

	inline static int32_t get_offset_of_m_CachedUvs_23() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_CachedUvs_23)); }
	inline Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA* get_m_CachedUvs_23() const { return ___m_CachedUvs_23; }
	inline Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA** get_address_of_m_CachedUvs_23() { return &___m_CachedUvs_23; }
	inline void set_m_CachedUvs_23(Vector2U5BU5D_tE0F58A2D6D8592B5EC37D9CDEF09103A02E5D7FA* value)
	{
		___m_CachedUvs_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CachedUvs_23), (void*)value);
	}

	inline static int32_t get_offset_of_m_ColorTweenRunner_24() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___m_ColorTweenRunner_24)); }
	inline TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 * get_m_ColorTweenRunner_24() const { return ___m_ColorTweenRunner_24; }
	inline TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 ** get_address_of_m_ColorTweenRunner_24() { return &___m_ColorTweenRunner_24; }
	inline void set_m_ColorTweenRunner_24(TweenRunner_1_tD84B9953874682FCC36990AF2C54D748293908F3 * value)
	{
		___m_ColorTweenRunner_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ColorTweenRunner_24), (void*)value);
	}

	inline static int32_t get_offset_of_U3CuseLegacyMeshGenerationU3Ek__BackingField_25() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24, ___U3CuseLegacyMeshGenerationU3Ek__BackingField_25)); }
	inline bool get_U3CuseLegacyMeshGenerationU3Ek__BackingField_25() const { return ___U3CuseLegacyMeshGenerationU3Ek__BackingField_25; }
	inline bool* get_address_of_U3CuseLegacyMeshGenerationU3Ek__BackingField_25() { return &___U3CuseLegacyMeshGenerationU3Ek__BackingField_25; }
	inline void set_U3CuseLegacyMeshGenerationU3Ek__BackingField_25(bool value)
	{
		___U3CuseLegacyMeshGenerationU3Ek__BackingField_25 = value;
	}
};

struct Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields
{
public:
	// UnityEngine.Material UnityEngine.UI.Graphic::s_DefaultUI
	Material_t8927C00353A72755313F046D0CE85178AE8218EE * ___s_DefaultUI_4;
	// UnityEngine.Texture2D UnityEngine.UI.Graphic::s_WhiteTexture
	Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * ___s_WhiteTexture_5;
	// UnityEngine.Mesh UnityEngine.UI.Graphic::s_Mesh
	Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * ___s_Mesh_20;
	// UnityEngine.UI.VertexHelper UnityEngine.UI.Graphic::s_VertexHelper
	VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 * ___s_VertexHelper_21;

public:
	inline static int32_t get_offset_of_s_DefaultUI_4() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_DefaultUI_4)); }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE * get_s_DefaultUI_4() const { return ___s_DefaultUI_4; }
	inline Material_t8927C00353A72755313F046D0CE85178AE8218EE ** get_address_of_s_DefaultUI_4() { return &___s_DefaultUI_4; }
	inline void set_s_DefaultUI_4(Material_t8927C00353A72755313F046D0CE85178AE8218EE * value)
	{
		___s_DefaultUI_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_DefaultUI_4), (void*)value);
	}

	inline static int32_t get_offset_of_s_WhiteTexture_5() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_WhiteTexture_5)); }
	inline Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * get_s_WhiteTexture_5() const { return ___s_WhiteTexture_5; }
	inline Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF ** get_address_of_s_WhiteTexture_5() { return &___s_WhiteTexture_5; }
	inline void set_s_WhiteTexture_5(Texture2D_t9B604D0D8E28032123641A7E7338FA872E2698BF * value)
	{
		___s_WhiteTexture_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_WhiteTexture_5), (void*)value);
	}

	inline static int32_t get_offset_of_s_Mesh_20() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_Mesh_20)); }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * get_s_Mesh_20() const { return ___s_Mesh_20; }
	inline Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 ** get_address_of_s_Mesh_20() { return &___s_Mesh_20; }
	inline void set_s_Mesh_20(Mesh_t2F5992DBA650D5862B43D3823ACD997132A57DA6 * value)
	{
		___s_Mesh_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Mesh_20), (void*)value);
	}

	inline static int32_t get_offset_of_s_VertexHelper_21() { return static_cast<int32_t>(offsetof(Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24_StaticFields, ___s_VertexHelper_21)); }
	inline VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 * get_s_VertexHelper_21() const { return ___s_VertexHelper_21; }
	inline VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 ** get_address_of_s_VertexHelper_21() { return &___s_VertexHelper_21; }
	inline void set_s_VertexHelper_21(VertexHelper_tDE8B67D3B076061C4F8DF325B0D63ED2E5367E55 * value)
	{
		___s_VertexHelper_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_VertexHelper_21), (void*)value);
	}
};


// UnityEngine.InputSystem.Touchscreen
struct Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9  : public Pointer_tC3661B26AA286B10B0D9871C329CD5C33CA5D9B8
{
public:
	// UnityEngine.InputSystem.Controls.TouchControl UnityEngine.InputSystem.Touchscreen::<primaryTouch>k__BackingField
	TouchControl_t19F62A1376F68BCD07C64142EEC035FFAF50F798 * ___U3CprimaryTouchU3Ek__BackingField_45;
	// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Controls.TouchControl> UnityEngine.InputSystem.Touchscreen::<touches>k__BackingField
	ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  ___U3CtouchesU3Ek__BackingField_46;

public:
	inline static int32_t get_offset_of_U3CprimaryTouchU3Ek__BackingField_45() { return static_cast<int32_t>(offsetof(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9, ___U3CprimaryTouchU3Ek__BackingField_45)); }
	inline TouchControl_t19F62A1376F68BCD07C64142EEC035FFAF50F798 * get_U3CprimaryTouchU3Ek__BackingField_45() const { return ___U3CprimaryTouchU3Ek__BackingField_45; }
	inline TouchControl_t19F62A1376F68BCD07C64142EEC035FFAF50F798 ** get_address_of_U3CprimaryTouchU3Ek__BackingField_45() { return &___U3CprimaryTouchU3Ek__BackingField_45; }
	inline void set_U3CprimaryTouchU3Ek__BackingField_45(TouchControl_t19F62A1376F68BCD07C64142EEC035FFAF50F798 * value)
	{
		___U3CprimaryTouchU3Ek__BackingField_45 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CprimaryTouchU3Ek__BackingField_45), (void*)value);
	}

	inline static int32_t get_offset_of_U3CtouchesU3Ek__BackingField_46() { return static_cast<int32_t>(offsetof(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9, ___U3CtouchesU3Ek__BackingField_46)); }
	inline ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  get_U3CtouchesU3Ek__BackingField_46() const { return ___U3CtouchesU3Ek__BackingField_46; }
	inline ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3 * get_address_of_U3CtouchesU3Ek__BackingField_46() { return &___U3CtouchesU3Ek__BackingField_46; }
	inline void set_U3CtouchesU3Ek__BackingField_46(ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  value)
	{
		___U3CtouchesU3Ek__BackingField_46 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CtouchesU3Ek__BackingField_46))->___m_Array_0), (void*)NULL);
	}
};

struct Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9_StaticFields
{
public:
	// UnityEngine.InputSystem.Touchscreen UnityEngine.InputSystem.Touchscreen::<current>k__BackingField
	Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___U3CcurrentU3Ek__BackingField_47;
	// System.Single UnityEngine.InputSystem.Touchscreen::s_TapTime
	float ___s_TapTime_48;
	// System.Single UnityEngine.InputSystem.Touchscreen::s_TapDelayTime
	float ___s_TapDelayTime_49;
	// System.Single UnityEngine.InputSystem.Touchscreen::s_TapRadiusSquared
	float ___s_TapRadiusSquared_50;

public:
	inline static int32_t get_offset_of_U3CcurrentU3Ek__BackingField_47() { return static_cast<int32_t>(offsetof(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9_StaticFields, ___U3CcurrentU3Ek__BackingField_47)); }
	inline Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * get_U3CcurrentU3Ek__BackingField_47() const { return ___U3CcurrentU3Ek__BackingField_47; }
	inline Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 ** get_address_of_U3CcurrentU3Ek__BackingField_47() { return &___U3CcurrentU3Ek__BackingField_47; }
	inline void set_U3CcurrentU3Ek__BackingField_47(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * value)
	{
		___U3CcurrentU3Ek__BackingField_47 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CcurrentU3Ek__BackingField_47), (void*)value);
	}

	inline static int32_t get_offset_of_s_TapTime_48() { return static_cast<int32_t>(offsetof(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9_StaticFields, ___s_TapTime_48)); }
	inline float get_s_TapTime_48() const { return ___s_TapTime_48; }
	inline float* get_address_of_s_TapTime_48() { return &___s_TapTime_48; }
	inline void set_s_TapTime_48(float value)
	{
		___s_TapTime_48 = value;
	}

	inline static int32_t get_offset_of_s_TapDelayTime_49() { return static_cast<int32_t>(offsetof(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9_StaticFields, ___s_TapDelayTime_49)); }
	inline float get_s_TapDelayTime_49() const { return ___s_TapDelayTime_49; }
	inline float* get_address_of_s_TapDelayTime_49() { return &___s_TapDelayTime_49; }
	inline void set_s_TapDelayTime_49(float value)
	{
		___s_TapDelayTime_49 = value;
	}

	inline static int32_t get_offset_of_s_TapRadiusSquared_50() { return static_cast<int32_t>(offsetof(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9_StaticFields, ___s_TapRadiusSquared_50)); }
	inline float get_s_TapRadiusSquared_50() const { return ___s_TapRadiusSquared_50; }
	inline float* get_address_of_s_TapRadiusSquared_50() { return &___s_TapRadiusSquared_50; }
	inline void set_s_TapRadiusSquared_50(float value)
	{
		___s_TapRadiusSquared_50 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber[]
struct SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * m_Items[1];

public:
	inline Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// UnityEngine.InputSystem.EnhancedTouch.Finger[]
struct FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * m_Items[1];

public:
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// UnityEngine.InputSystem.EnhancedTouch.Touch[]
struct TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  m_Items[1];

public:
	inline Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_Finger_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___m_TouchRecord_1))->___m_Owner_0), (void*)NULL);
		#endif
	}
	inline Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_Finger_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___m_TouchRecord_1))->___m_Owner_0), (void*)NULL);
		#endif
	}
};
// UnityEngine.InputSystem.InputControl[]
struct InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * m_Items[1];

public:
	inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem[]
struct ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D  m_Items[1];

public:
	inline ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CnameU3Ek__BackingField_0))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CnameU3Ek__BackingField_0))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3ClayoutU3Ek__BackingField_1))->___m_StringOriginalCase_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3ClayoutU3Ek__BackingField_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CvariantsU3Ek__BackingField_2))->___m_StringOriginalCase_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CvariantsU3Ek__BackingField_2))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CuseStateFromU3Ek__BackingField_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CdisplayNameU3Ek__BackingField_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CshortDisplayNameU3Ek__BackingField_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CusagesU3Ek__BackingField_6))->___m_Array_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CaliasesU3Ek__BackingField_7))->___m_Array_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CparametersU3Ek__BackingField_8))->___m_Array_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CprocessorsU3Ek__BackingField_9))->___m_Array_0), (void*)NULL);
		#endif
	}
	inline ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D  value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CnameU3Ek__BackingField_0))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CnameU3Ek__BackingField_0))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3ClayoutU3Ek__BackingField_1))->___m_StringOriginalCase_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3ClayoutU3Ek__BackingField_1))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CvariantsU3Ek__BackingField_2))->___m_StringOriginalCase_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CvariantsU3Ek__BackingField_2))->___m_StringLowerCase_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CuseStateFromU3Ek__BackingField_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CdisplayNameU3Ek__BackingField_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CshortDisplayNameU3Ek__BackingField_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CusagesU3Ek__BackingField_6))->___m_Array_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CaliasesU3Ek__BackingField_7))->___m_Array_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CparametersU3Ek__BackingField_8))->___m_Array_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CprocessorsU3Ek__BackingField_9))->___m_Array_0), (void*)NULL);
		#endif
	}
};
// UnityEngine.InputSystem.Utilities.InternedString[]
struct InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  m_Items[1];

public:
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}
};
// System.String[]
struct StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) String_t* m_Items[1];

public:
	inline String_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline String_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, String_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline String_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline String_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, String_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// UnityEngine.InputSystem.Utilities.NamedValue[]
struct NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94  m_Items[1];

public:
	inline NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CnameU3Ek__BackingField_1), (void*)NULL);
	}
	inline NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94  value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CnameU3Ek__BackingField_1), (void*)NULL);
	}
};
// UnityEngine.InputSystem.Utilities.NameAndParameters[]
struct NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76  m_Items[1];

public:
	inline NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CnameU3Ek__BackingField_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CparametersU3Ek__BackingField_1))->___m_Array_0), (void*)NULL);
		#endif
	}
	inline NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76  value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___U3CnameU3Ek__BackingField_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___U3CparametersU3Ek__BackingField_1))->___m_Array_0), (void*)NULL);
		#endif
	}
};
// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement[]
struct DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  m_Items[1];

public:
	inline DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_ControlPath_0), (void*)NULL);
	}
	inline DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___m_ControlPath_0), (void*)NULL);
	}
};

IL2CPP_EXTERN_C void RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshal_pinvoke(const RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE& unmarshaled, RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshal_pinvoke_back(const RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_pinvoke& marshaled, RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE& unmarshaled);
IL2CPP_EXTERN_C void RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshal_pinvoke_cleanup(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshal_com(const RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE& unmarshaled, RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_com& marshaled);
IL2CPP_EXTERN_C void RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshal_com_back(const RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_com& marshaled, RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE& unmarshaled);
IL2CPP_EXTERN_C void RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshal_com_cleanup(RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE_marshaled_com& marshaled);
IL2CPP_EXTERN_C void Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshal_pinvoke(const Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA& unmarshaled, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshal_pinvoke_back(const Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_pinvoke& marshaled, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA& unmarshaled);
IL2CPP_EXTERN_C void Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshal_pinvoke_cleanup(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshal_com(const Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA& unmarshaled, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_com& marshaled);
IL2CPP_EXTERN_C void Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshal_com_back(const Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_com& marshaled, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA& unmarshaled);
IL2CPP_EXTERN_C void Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshal_com_cleanup(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_marshaled_com& marshaled);
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_pinvoke(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_pinvoke_back(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke& marshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled);
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_pinvoke_cleanup(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_com(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com& marshaled);
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_com_back(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com& marshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled);
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_com_cleanup(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com& marshaled);
IL2CPP_EXTERN_C void InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshal_pinvoke(const InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4& unmarshaled, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshal_pinvoke_back(const InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke& marshaled, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4& unmarshaled);
IL2CPP_EXTERN_C void InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshal_pinvoke_cleanup(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshal_pinvoke(const InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D& unmarshaled, InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshal_pinvoke_back(const InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_pinvoke& marshaled, InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D& unmarshaled);
IL2CPP_EXTERN_C void InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshal_pinvoke_cleanup(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshal_com(const InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4& unmarshaled, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com& marshaled);
IL2CPP_EXTERN_C void InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshal_com_back(const InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com& marshaled, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4& unmarshaled);
IL2CPP_EXTERN_C void InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshal_com_cleanup(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_marshaled_com& marshaled);
IL2CPP_EXTERN_C void InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshal_com(const InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D& unmarshaled, InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_com& marshaled);
IL2CPP_EXTERN_C void InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshal_com_back(const InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_com& marshaled, InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D& unmarshaled);
IL2CPP_EXTERN_C void InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshal_com_cleanup(InputDeviceMatcher_t804477DFDED9A8F10019A02D2CFFE6B14A34156D_marshaled_com& marshaled);
IL2CPP_EXTERN_C void DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshal_pinvoke(const DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807& unmarshaled, DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshal_pinvoke_back(const DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke& marshaled, DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807& unmarshaled);
IL2CPP_EXTERN_C void DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshal_pinvoke_cleanup(DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshal_com(const DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807& unmarshaled, DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com& marshaled);
IL2CPP_EXTERN_C void DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshal_com_back(const DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com& marshaled, DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807& unmarshaled);
IL2CPP_EXTERN_C void DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshal_com_cleanup(DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807_marshaled_com& marshaled);
IL2CPP_EXTERN_C void InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshal_pinvoke(const InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA& unmarshaled, InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshal_pinvoke_back(const InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_pinvoke& marshaled, InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA& unmarshaled);
IL2CPP_EXTERN_C void InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshal_pinvoke_cleanup(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshal_com(const InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA& unmarshaled, InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_com& marshaled);
IL2CPP_EXTERN_C void InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshal_com_back(const InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_com& marshaled, InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA& unmarshaled);
IL2CPP_EXTERN_C void InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshal_com_cleanup(InputDeviceDescription_tA0075FB9BC3E3E130F6A12873960FCCB6D5DEEBA_marshaled_com& marshaled);

// System.Void UnityEngine.Events.UnityEvent`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UnityEvent_1__ctor_mD87552C18A41196B69A62A366C8238FC246B151A_gshared (UnityEvent_1_t32063FE815890FF672DF76288FAC4ABE089B899F * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.Utilities.ArrayHelpers::Erase<System.Object>(TValue[]&,TValue)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ArrayHelpers_Erase_TisRuntimeObject_m37D055EDB7D864A76377A1A356223C8A7966F3DD_gshared (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** ___array0, RuntimeObject * ___value1, const RuntimeMethod* method);
// !1 System.Func`2<System.Char,System.Boolean>::Invoke(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D_gshared (Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * __this, Il2CppChar ___arg0, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<System.Object>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ReadOnlyArray_1_get_Count_mE2A826A6A8EC79EB232A3D5C79208F7F67BDFE21_gshared_inline (ReadOnlyArray_1_t838D76309E9783F02B1E4A7AA7DFD33F97256A03 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::EnsureCapacity<System.Object>(TValue[]&,System.Int32,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayHelpers_EnsureCapacity_TisRuntimeObject_mC65DF5E73A8AAAD6CCF91FBA5F6EF3531A575497_gshared (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** ___array0, int32_t ___count1, int32_t ___capacity2, int32_t ___capacityIncrement3, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.Utilities.ArrayHelpers::AppendWithCapacity<System.Object>(TValue[]&,System.Int32&,TValue,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ArrayHelpers_AppendWithCapacity_TisRuntimeObject_m6D953416FE9A5E6F6DB80358EC3E7DE3A0ADF6E7_gshared (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** ___array0, int32_t* ___count1, RuntimeObject * ___value2, int32_t ___capacityIncrement3, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::EraseSliceWithCapacity<System.Object>(TValue[]&,System.Int32&,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayHelpers_EraseSliceWithCapacity_TisRuntimeObject_mAF130B3CD0EFC9B4917D7BA1789121546FF4B29D_gshared (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** ___array0, int32_t* ___length1, int32_t ___index2, int32_t ___count3, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.InputStateHistory`1<UnityEngine.InputSystem.LowLevel.TouchState>::.ctor(System.Nullable`1<System.Int32>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void InputStateHistory_1__ctor_m4CC173D63A840D058F7D825BB7D7C3A4FDBC1C12_gshared (InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * __this, Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___maxStateSizeInBytes0, const RuntimeMethod* method);
// System.Int32 Unity.Collections.LowLevel.Unsafe.UnsafeUtility::SizeOf<UnityEngine.InputSystem.EnhancedTouch.Touch/ExtraDataPerTouchState>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01_gshared (const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::Clear<System.Object>(TValue[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayHelpers_Clear_TisRuntimeObject_m2282BC55A48509A5DA31510F11B11E4BAD72B4F8_gshared (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ___array0, const RuntimeMethod* method);
// TValue UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<System.Object>::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ReadOnlyArray_1_get_Item_m43A958EC30E969B629E73D3DF57A1F4549F2913B_gshared (ReadOnlyArray_1_t838D76309E9783F02B1E4A7AA7DFD33F97256A03 * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Int32 Unity.Collections.LowLevel.Unsafe.UnsafeUtility::SizeOf<UnityEngine.InputSystem.LowLevel.TouchState>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t UnsafeUtility_SizeOf_TisTouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8_m88C8A28D5EC1B03454E3980C49B61DEEAF2B665B_gshared (const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record<UnityEngine.InputSystem.LowLevel.TouchState>::.ctor(UnityEngine.InputSystem.LowLevel.InputStateHistory`1<TValue>,System.Int32,UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader*)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Record__ctor_mA6E01856DFCAF450BB1AAA06672DBFC8B5061DCC_gshared (Record_t6A3403317B951528E7A550FABE9EC42900ABFC48 * __this, InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___owner0, int32_t ___index1, RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * ___header2, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::InsertAtWithCapacity<UnityEngine.InputSystem.EnhancedTouch.Touch>(TValue[]&,System.Int32&,System.Int32,TValue,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayHelpers_InsertAtWithCapacity_TisTouch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_m86CEA702743AA33B3B395BCEF7202CBA1CBB742C_gshared (TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D** ___array0, int32_t* ___count1, int32_t ___index2, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  ___value3, int32_t ___capacityIncrement4, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.InternedString>::.ctor(TValue[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReadOnlyArray_1__ctor_mEBC958B99E88055B976A48FD29182C367B255013_gshared (ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C * __this, InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___array0, const RuntimeMethod* method);
// System.Void System.Func`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Func_2__ctor_m95BB7160284BF7AB79C08B1FF72F51BCBF6E6BBE_gshared (Func_2_tD58EEB7D030248D39CFED6A2AF6CF7A63FCB6A92 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerable`1<!!1> System.Linq.Enumerable::Select<System.Object,UnityEngine.InputSystem.Utilities.InternedString>(System.Collections.Generic.IEnumerable`1<!!0>,System.Func`2<!!0,!!1>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Enumerable_Select_TisRuntimeObject_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_m2B8D23259A06952B0D0A88F5FF5FCACD087E3430_gshared (RuntimeObject* ___source0, Func_2_tD58EEB7D030248D39CFED6A2AF6CF7A63FCB6A92 * ___selector1, const RuntimeMethod* method);
// !!0[] System.Linq.Enumerable::ToArray<UnityEngine.InputSystem.Utilities.InternedString>(System.Collections.Generic.IEnumerable`1<!!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* Enumerable_ToArray_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_mB81CDBC6648458E775977B0F5B0CD7DFDB092FF8_gshared (RuntimeObject* ___source0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue>::.ctor(TValue[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReadOnlyArray_1__ctor_mAD8348E710A8187038E9A181FF8458AB4FD59447_gshared (ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8 * __this, NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* ___array0, const RuntimeMethod* method);
// !!0[] System.Linq.Enumerable::ToArray<UnityEngine.InputSystem.Utilities.NameAndParameters>(System.Collections.Generic.IEnumerable`1<!!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* Enumerable_ToArray_TisNameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_mDC5522CF62EDFA52EEA4E8F85D7FECD84CFF23AE_gshared (RuntimeObject* ___source0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NameAndParameters>::.ctor(TValue[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReadOnlyArray_1__ctor_m2AEF1D3FB42E7980B7C8F4D40E775EEB1DAD8C8E_gshared (ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F * __this, NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* ___array0, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>::TryGetValue(!0,!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dictionary_2_TryGetValue_m13A59E4AB21B1AFCC1D94C66A2F5689DD3DF7C31_gshared (Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___key0, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * ___value1, const RuntimeMethod* method);
// TControl UnityEngine.InputSystem.InputControlList`1<System.Object>::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * InputControlList_1_get_Item_m384B41A142DD0D1E829F2C1199415EF241786589_gshared (InputControlList_1_t447EDCA408530F83486DAFD99E11A1CD7F394550 * __this, int32_t ___index0, const RuntimeMethod* method);
// !0 System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Key()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject * KeyValuePair_2_get_Key_m4E9ACD2B4E097B0AF5B15D923092D10E257C64E7_gshared_inline (KeyValuePair_2_tEE5D23BECC9903E80CE9C9EA17D3C6D530F7987E * __this, const RuntimeMethod* method);
// !1 System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Value()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  KeyValuePair_2_get_Value_m5D03130FB6F2A36980DDE053BC7BA6EA77FC9ECF_gshared_inline (KeyValuePair_2_tEE5D23BECC9903E80CE9C9EA17D3C6D530F7987E * __this, const RuntimeMethod* method);

// System.Void UnityEngine.Events.UnityEvent`1<UnityEngine.InputSystem.PlayerInput>::.ctor()
inline void UnityEvent_1__ctor_mD8BFEFBF01C2160CFD91DD3E681A92B6D7C9A5B8 (UnityEvent_1_tD09E39AD92F90E8B662BC6003C65B108EC9B5EEC * __this, const RuntimeMethod* method)
{
	((  void (*) (UnityEvent_1_tD09E39AD92F90E8B662BC6003C65B108EC9B5EEC *, const RuntimeMethod*))UnityEvent_1__ctor_mD87552C18A41196B69A62A366C8238FC246B151A_gshared)(__this, method);
}
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_isPressed()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool ButtonState_get_isPressed_mC20A08312DF96CA0D5D6657ADC4FFD4880B28DE0_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_isPressed(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_set_isPressed_m276D75A708B80F7F49771FA5401FDF482F212F9E (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_ignoreNextClick()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool ButtonState_get_ignoreNextClick_m6304EB764807405EF59F964BB0BDA6117F919D45_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_ignoreNextClick(System.Boolean)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ButtonState_set_ignoreNextClick_mE0FE305F262ED710FCFC9DF5A4C7B115476AB26D_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_pressTime()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float ButtonState_get_pressTime_m214D6D781C6F581CBF781A9620A6C10239A096BD_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_pressTime(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ButtonState_set_pressTime_m43CEEA0944E6A2D87CB763FBD333FA8679829E27_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, float ___value0, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_clickedOnSameGameObject()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool ButtonState_get_clickedOnSameGameObject_mE95BA21860C122BD01C8A314CA27381288D015F3_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_clickedOnSameGameObject(System.Boolean)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ButtonState_set_clickedOnSameGameObject_m3F29C95CA8EAECC108C2BF571FFFF5744FBA1A87_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_wasPressedThisFrame()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ButtonState_get_wasPressedThisFrame_m7C0C0C74F0CFA603802C6375B3735CBB87B8D0C6 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_wasReleasedThisFrame()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ButtonState_get_wasReleasedThisFrame_mC2A2CBEAF1776ED64A27ED0C6806B878433D3516 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPressRaycast(UnityEngine.EventSystems.RaycastResult)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_pointerPressRaycast_mAF28B12216468A02DACA9900B0A57FA1BF3B94F4_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_pressPosition(UnityEngine.Vector2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_pressPosition_mE644EE1603DFF2087224FF6364EA0204D04D7939_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_clickCount(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_clickCount_m2EAAB7F43CE26BF505B7FCF7D509C988DCFD7F28_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_clickTime(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_clickTime_m215E254F8585FFC518E3161FAF9137388F64AC58_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, float ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPress(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PointerEventData_set_pointerPress_mF37D23566DDB326EB2CFE59592F8538F23BA0EC0 (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_rawPointerPress(UnityEngine.GameObject)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_rawPointerPress_m0BEEB9CA5E44F570C2C0803553BA9736F4DF58F0_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_pointerDrag(UnityEngine.GameObject)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_pointerDrag_m2E9F059EC1CDF71E0A097A0D3CCBA564E0C463C2_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_dragging(System.Boolean)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_dragging_mEB739C44F1B1848B4B3F4E7FBB9B376587C2C7E1_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.EventSystems.PointerEventData::set_eligibleForClick(System.Boolean)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_eligibleForClick_m5CFAF671C2B33AF8E9153FA4826D93B9308C4C07_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::CopyPressStateTo(UnityEngine.EventSystems.PointerEventData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_CopyPressStateTo_m8DFA367FE2C863DF1A1327B81066E1497AD8AC57 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * ___eventData0, const RuntimeMethod* method);
// UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::get_pointerPressRaycast()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  PointerEventData_get_pointerPressRaycast_m3C5785CD2C31F91C91D6F1084D2EAC31BED56ACB_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerPress()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_pointerPress_mB55C5528AF445DB7B912086E43F0BCD9CDFF409C_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_rawPointerPress()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_rawPointerPress_m0C23DB50BCE28ECC43609CC01E727CCA77FC6473_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_lastPress()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_lastPress_m362C5876B8C9F50BACC27D9026DB3709D6950C0B_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_pressPosition()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  PointerEventData_get_pressPosition_mB8F60EB21F6E6892EC731382614BAB85E29ED642_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// System.Single UnityEngine.EventSystems.PointerEventData::get_clickTime()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float PointerEventData_get_clickTime_m08F7FD164EFE2AE7B47A15C70BC418632B9E5950_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.EventSystems.PointerEventData::get_clickCount()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t PointerEventData_get_clickCount_mB44AAB99335BD7D2BD93E40DAC282A56202E44F2_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerDrag()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_pointerDrag_m5FD1D758CA629D9EBB8BDA3207132BC9BAB91ACE_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.EventSystems.PointerEventData::get_dragging()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool PointerEventData_get_dragging_m7FD3F5D4D8DAC559A57EDB88F2B2B5DEA4B48266_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::CopyPressStateFrom(UnityEngine.EventSystems.PointerEventData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_CopyPressStateFrom_mE72A6AA474EAEAE6D143AD32C64317A4BCF039A5 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * ___eventData0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::OnEndFrame()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_OnEndFrame_m7A59E069FB0C75CB9F6EEFDDAE7FA5D1CEB29FB1 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.Utilities.ArrayHelpers::Erase<UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber>(TValue[]&,TValue)
inline bool ArrayHelpers_Erase_TisSubscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155_mB50873C9A1871E7CB5BFBF691B77D4628B081764 (SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D** ___array0, Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * ___value1, const RuntimeMethod* method)
{
	return ((  bool (*) (SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D**, Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 *, const RuntimeMethod*))ArrayHelpers_Erase_TisRuntimeObject_m37D055EDB7D864A76377A1A356223C8A7966F3DD_gshared)(___array0, ___value1, method);
}
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Int32 System.Environment::get_CurrentManagedThreadId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Environment_get_CurrentManagedThreadId_m09DBD4166BFD399056B2F81C77A3A182339BF92D (const RuntimeMethod* method);
// System.Boolean System.String::IsNullOrEmpty(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_IsNullOrEmpty_m9AFBB5335B441B94E884B8A9D4A27AD60E3D7F7C (String_t* ___value0, const RuntimeMethod* method);
// System.Int32 System.String::get_Length()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m129FC0ADA02FECBED3C0B1A809AE84A5AEE1CF09_inline (String_t* __this, const RuntimeMethod* method);
// System.Char System.String::get_Chars(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70 (String_t* __this, int32_t ___index0, const RuntimeMethod* method);
// !1 System.Func`2<System.Char,System.Boolean>::Invoke(!0)
inline bool Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D (Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * __this, Il2CppChar ___arg0, const RuntimeMethod* method)
{
	return ((  bool (*) (Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A *, Il2CppChar, const RuntimeMethod*))Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D_gshared)(__this, ___arg0, method);
}
// System.String System.String::Substring(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B (String_t* __this, int32_t ___startIndex0, int32_t ___length1, const RuntimeMethod* method);
// System.Void System.NotSupportedException::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NotSupportedException__ctor_m3EA81A5B209A87C3ADA47443F2AFFF735E5256EE (NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSplitU3Ed__9__ctor_m2FD3D68D26219E01C8827B4D14A6B8635AD790D3 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerator`1<System.String> UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::System.Collections.Generic.IEnumerable<System.String>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CSplitU3Ed__9_System_Collections_Generic_IEnumerableU3CSystem_StringU3E_GetEnumerator_mF7CAF7BD420AB028A15C1A61469B2D579921D211 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method);
// System.Boolean System.Char::IsWhiteSpace(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsWhiteSpace_m99A5E1BE1EB9F17EA530A67A607DA8C260BCBF99 (Il2CppChar ___c0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.Substring::.ctor(System.String,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Substring__ctor_mCCE4224E81B04E9292A725BFDF9273449429653D (Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815 * __this, String_t* ___str0, int32_t ___index1, int32_t ___length2, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CTokenizeU3Ed__8__ctor_mA756AE014A5743CE5F81893B1017012FFA90CC95 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.Substring> UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::System.Collections.Generic.IEnumerable<UnityEngine.InputSystem.Utilities.Substring>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CTokenizeU3Ed__8_System_Collections_Generic_IEnumerableU3CUnityEngine_InputSystem_Utilities_SubstringU3E_GetEnumerator_mDEC8DD4FA6ED13993EECF3AF9E5E375E74792F70 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mAD41A398A7F79556455A67F662EAEEC893E09F86 (U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Controls.TouchControl> UnityEngine.InputSystem.Touchscreen::get_touches()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  Touchscreen_get_touches_m67B46B544F3DF685C9571FF2B8DA890C9393D79C_inline (Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Controls.TouchControl>::get_Count()
inline int32_t ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_inline (ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3 *, const RuntimeMethod*))ReadOnlyArray_1_get_Count_mE2A826A6A8EC79EB232A3D5C79208F7F67BDFE21_gshared_inline)(__this, method);
}
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::EnsureCapacity<UnityEngine.InputSystem.EnhancedTouch.Finger>(TValue[]&,System.Int32,System.Int32,System.Int32)
inline void ArrayHelpers_EnsureCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mA18B65BA5322F4F005396C4FCF34BFDD0D6C1C15 (FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** ___array0, int32_t ___count1, int32_t ___capacity2, int32_t ___capacityIncrement3, const RuntimeMethod* method)
{
	((  void (*) (FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD**, int32_t, int32_t, int32_t, const RuntimeMethod*))ArrayHelpers_EnsureCapacity_TisRuntimeObject_mC65DF5E73A8AAAD6CCF91FBA5F6EF3531A575497_gshared)(___array0, ___count1, ___capacity2, ___capacityIncrement3, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Finger::.ctor(UnityEngine.InputSystem.Touchscreen,System.Int32,UnityEngine.InputSystem.LowLevel.InputUpdateType)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Finger__ctor_m8D31BEF6BF108A62AB23DEC1DEC1E5FB216577E8 (Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * __this, Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___screen0, int32_t ___index1, int32_t ___updateMask2, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.Utilities.ArrayHelpers::AppendWithCapacity<UnityEngine.InputSystem.EnhancedTouch.Finger>(TValue[]&,System.Int32&,TValue,System.Int32)
inline int32_t ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68 (FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** ___array0, int32_t* ___count1, Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___value2, int32_t ___capacityIncrement3, const RuntimeMethod* method)
{
	return ((  int32_t (*) (FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD**, int32_t*, Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 *, int32_t, const RuntimeMethod*))ArrayHelpers_AppendWithCapacity_TisRuntimeObject_m6D953416FE9A5E6F6DB80358EC3E7DE3A0ADF6E7_gshared)(___array0, ___count1, ___value2, ___capacityIncrement3, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::AddFingers(UnityEngine.InputSystem.Touchscreen)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_AddFingers_mE2B2CA6DFC89A823AA27B91D202203F5CE6E5941 (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___screen0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Touchscreen UnityEngine.InputSystem.EnhancedTouch.Finger::get_screen()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * Finger_get_screen_mAF59662CC55478F9F668A5E77F1488A346A213B0_inline (Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.InputStateHistory::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void InputStateHistory_Dispose_m2F9781CB0804BDBDF49D37C77B6D1CB21DB78568 (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::EraseSliceWithCapacity<UnityEngine.InputSystem.EnhancedTouch.Finger>(TValue[]&,System.Int32&,System.Int32,System.Int32)
inline void ArrayHelpers_EraseSliceWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_m725E5BB760C8DD2772361E372A579B925CDD99B5 (FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** ___array0, int32_t* ___length1, int32_t ___index2, int32_t ___count3, const RuntimeMethod* method)
{
	((  void (*) (FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD**, int32_t*, int32_t, int32_t, const RuntimeMethod*))ArrayHelpers_EraseSliceWithCapacity_TisRuntimeObject_mAF130B3CD0EFC9B4917D7BA1789121546FF4B29D_gshared)(___array0, ___length1, ___index2, ___count3, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::RemoveFingers(UnityEngine.InputSystem.Touchscreen)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_RemoveFingers_m0F6D384B1F336DD7A4692868A81BF37C7837EA2D (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___screen0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::Destroy()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_Destroy_m3A6FED4F4A62EC291506F042D76A42EA8F292720 (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.EnhancedTouch.Touch UnityEngine.InputSystem.EnhancedTouch.Finger::get_currentTouch()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  Finger_get_currentTouch_m6E82BF6E2EFE0966A8F03EB9EB896FD9BA45CC6D (Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.EnhancedTouch.Touch::get_valid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Touch_get_valid_mA0B2CFA5D11C3767331EB2E23E415E91FBC21533 (Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::UpdateActiveFingers()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_UpdateActiveFingers_m8D96E489660671F2C246BBBDD2380F68FE480F75 (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.InputStateHistory`1<UnityEngine.InputSystem.LowLevel.TouchState>::.ctor(System.Nullable`1<System.Int32>)
inline void InputStateHistory_1__ctor_m4CC173D63A840D058F7D825BB7D7C3A4FDBC1C12 (InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * __this, Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  ___maxStateSizeInBytes0, const RuntimeMethod* method)
{
	((  void (*) (InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 *, Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103 , const RuntimeMethod*))InputStateHistory_1__ctor_m4CC173D63A840D058F7D825BB7D7C3A4FDBC1C12_gshared)(__this, ___maxStateSizeInBytes0, method);
}
// System.Int32 Unity.Collections.LowLevel.Unsafe.UnsafeUtility::SizeOf<UnityEngine.InputSystem.EnhancedTouch.Touch/ExtraDataPerTouchState>()
inline int32_t UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01 (const RuntimeMethod* method)
{
	return ((  int32_t (*) (const RuntimeMethod*))UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01_gshared)(method);
}
// System.Void UnityEngine.InputSystem.LowLevel.InputStateHistory::set_extraMemoryPerRecord(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void InputStateHistory_set_extraMemoryPerRecord_m2B24AC5C2A7A7438DFA6830958A51198F7A847CC (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.InputStateHistory::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void InputStateHistory_Clear_m08FD26FC532376C829F44C058D341C2927C33EF5 (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::Clear<UnityEngine.InputSystem.InputControl>(TValue[])
inline void ArrayHelpers_Clear_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m02E4370667B74A8D105681DEA12E2DBE27F36792 (InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* ___array0, const RuntimeMethod* method)
{
	((  void (*) (InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F*, const RuntimeMethod*))ArrayHelpers_Clear_TisRuntimeObject_m2282BC55A48509A5DA31510F11B11E4BAD72B4F8_gshared)(___array0, method);
}
// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t InputStateHistory_get_Count_m41CC7BFF6BC7537C9F9E04D89DCBB212A445A402_inline (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::UserIndexToRecordIndex(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t InputStateHistory_UserIndexToRecordIndex_mF4A6F8F02CD754777173D27FA5195061BC311E6F (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, int32_t ___index0, const RuntimeMethod* method);
// UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader* UnityEngine.InputSystem.LowLevel.InputStateHistory::GetRecordUnchecked(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * InputStateHistory_GetRecordUnchecked_mF6FB8C28D85F96D0E7DEB2715B36409AA5A111BD (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::get_bytesPerRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t InputStateHistory_get_bytesPerRecord_m92629E1E4E6BD1AC13E8DB7C7062FEAB244E950D (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::get_extraMemoryPerRecord()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t InputStateHistory_get_extraMemoryPerRecord_mD6523D549A81F0C20141E60B706AEE6D12FC4CD0_inline (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.LowLevel.InputStateHistory::get_historyDepth()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t InputStateHistory_get_historyDepth_m232556B5AE37A9388BB37FE3BDA80B6DFF4F94F8_inline (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method);
// System.Byte* UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader::get_statePtrWithoutControlIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t* RecordHeader_get_statePtrWithoutControlIndex_m96348C3EF2B9C5C8EF6F06AA931920C37CCE2D1F (RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.TouchPhase UnityEngine.InputSystem.LowLevel.TouchState::get_phase()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t TouchState_get_phase_mEBFCF4562A1F6A77357D9EEBD2579983B23F713B_inline (TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.InputExtensions::IsEndedOrCanceled(UnityEngine.InputSystem.TouchPhase)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool InputExtensions_IsEndedOrCanceled_mF31E460E4E2EF752099445D3686B54D73B750B25 (int32_t ___phase0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.TouchState::set_phase(UnityEngine.InputSystem.TouchPhase)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TouchState_set_phase_m46F65463E73DE88F54E7E03E1EB6E0336EE96893 (TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.LowLevel.TouchState::get_beganInSameFrame()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TouchState_get_beganInSameFrame_mAFE861824B710FAC981781B5CDDB0544FB523843 (TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader* UnityEngine.InputSystem.LowLevel.InputStateHistory::AllocateRecord(System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * InputStateHistory_AllocateRecord_mD582951B54EE3E4EEDFA22B168074011B7E4F5DF (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, int32_t* ___index0, const RuntimeMethod* method);
// System.Byte* UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader::get_statePtrWithControlIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t* RecordHeader_get_statePtrWithControlIndex_mD985585F516C465246D19A574A028D6C8E6589CD (RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.InputControl> UnityEngine.InputSystem.LowLevel.InputStateHistory::get_controls()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832  InputStateHistory_get_controls_m652D30E8D00AA372BCF00EF63031FE9246D224CD (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method);
// TValue UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.InputControl>::get_Item(System.Int32)
inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * ReadOnlyArray_1_get_Item_m6E99B3BAB50380469478C5CFCD2410E4F64B92F9 (ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * (*) (ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832 *, int32_t, const RuntimeMethod*))ReadOnlyArray_1_get_Item_m43A958EC30E969B629E73D3DF57A1F4549F2913B_gshared)(__this, ___index0, method);
}
// System.Int32 UnityEngine.InputSystem.Utilities.ArrayHelpers::AppendWithCapacity<UnityEngine.InputSystem.InputControl>(TValue[]&,System.Int32&,TValue,System.Int32)
inline int32_t ArrayHelpers_AppendWithCapacity_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m409299335D98E3EE47D99B3651327AFE91780D55 (InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F** ___array0, int32_t* ___count1, InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * ___value2, int32_t ___capacityIncrement3, const RuntimeMethod* method)
{
	return ((  int32_t (*) (InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F**, int32_t*, InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 *, int32_t, const RuntimeMethod*))ArrayHelpers_AppendWithCapacity_TisRuntimeObject_m6D953416FE9A5E6F6DB80358EC3E7DE3A0ADF6E7_gshared)(___array0, ___count1, ___value2, ___capacityIncrement3, method);
}
// System.Int32 Unity.Collections.LowLevel.Unsafe.UnsafeUtility::SizeOf<UnityEngine.InputSystem.LowLevel.TouchState>()
inline int32_t UnsafeUtility_SizeOf_TisTouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8_m88C8A28D5EC1B03454E3980C49B61DEEAF2B665B (const RuntimeMethod* method)
{
	return ((  int32_t (*) (const RuntimeMethod*))UnsafeUtility_SizeOf_TisTouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8_m88C8A28D5EC1B03454E3980C49B61DEEAF2B665B_gshared)(method);
}
// System.Void Unity.Collections.LowLevel.Unsafe.UnsafeUtility::MemCpy(System.Void*,System.Void*,System.Int64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UnsafeUtility_MemCpy_m8E335BAB1C2A8483AF8531CE8464C6A69BB98C1B (void* ___destination0, void* ___source1, int64_t ___size2, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record<UnityEngine.InputSystem.LowLevel.TouchState>::.ctor(UnityEngine.InputSystem.LowLevel.InputStateHistory`1<TValue>,System.Int32,UnityEngine.InputSystem.LowLevel.InputStateHistory/RecordHeader*)
inline void Record__ctor_mA6E01856DFCAF450BB1AAA06672DBFC8B5061DCC (Record_t6A3403317B951528E7A550FABE9EC42900ABFC48 * __this, InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * ___owner0, int32_t ___index1, RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * ___header2, const RuntimeMethod* method)
{
	((  void (*) (Record_t6A3403317B951528E7A550FABE9EC42900ABFC48 *, InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 *, int32_t, RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *, const RuntimeMethod*))Record__ctor_mA6E01856DFCAF450BB1AAA06672DBFC8B5061DCC_gshared)(__this, ___owner0, ___index1, ___header2, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch::.ctor(UnityEngine.InputSystem.EnhancedTouch.Finger,UnityEngine.InputSystem.LowLevel.InputStateHistory`1/Record<UnityEngine.InputSystem.LowLevel.TouchState>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Touch__ctor_mE500D74A20C4959256D6BCF1DDBD92015B2CC4F5 (Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA * __this, Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * ___finger0, Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  ___touchRecord1, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ArrayHelpers::InsertAtWithCapacity<UnityEngine.InputSystem.EnhancedTouch.Touch>(TValue[]&,System.Int32&,System.Int32,TValue,System.Int32)
inline void ArrayHelpers_InsertAtWithCapacity_TisTouch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_m86CEA702743AA33B3B395BCEF7202CBA1CBB742C (TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D** ___array0, int32_t* ___count1, int32_t ___index2, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  ___value3, int32_t ___capacityIncrement4, const RuntimeMethod* method)
{
	((  void (*) (TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D**, int32_t*, int32_t, Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA , int32_t, const RuntimeMethod*))ArrayHelpers_InsertAtWithCapacity_TisTouch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_m86CEA702743AA33B3B395BCEF7202CBA1CBB742C_gshared)(___array0, ___count1, ___index2, ___value3, ___capacityIncrement4, method);
}
// UnityEngine.InputSystem.TouchPhase UnityEngine.InputSystem.EnhancedTouch.Touch::get_phase()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Touch_get_phase_m8246DA777AEA750A87E96E96F38DEFF08C43817F (Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::UpdateActiveTouches()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_UpdateActiveTouches_m51EAB31B9AE121144697D08A0DBB129A9DF71EAA (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.EnhancedTouch.TouchHistory::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t TouchHistory_get_Count_m54E34D6C03893752E6B905F728CAEF691F3FE779_inline (TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.EnhancedTouch.Touch UnityEngine.InputSystem.EnhancedTouch.TouchHistory::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  TouchHistory_get_Item_mDA783592CE8ED5CA149655D0F0CC9A4A878132EF (TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D * __this, int32_t ___index0, const RuntimeMethod* method);
// UnityEngine.InputSystem.EnhancedTouch.Touch UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  Enumerator_get_Current_mFAAFC0193DDE998A96FFFADB0F2DDCB6E5AB34EE (Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mE761A84D3883CD2AFFCC16E0BE6D4AF92E8E8CCE (U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 * __this, const RuntimeMethod* method);
// UnityEngine.UI.Graphic UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_graphic()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * RaycastHitData_get_graphic_m91A6519C0A0B9D40F6FD92744D73814912FB11BC_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.UI.Graphic::get_depth()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Graphic_get_depth_m8AF43A1523D90A3A42A812835D516940E320CD17 (Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * __this, const RuntimeMethod* method);
// System.Int32 System.Int32::CompareTo(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Int32_CompareTo_m2DD1093B956B4D96C3AC3C27FDEE3CA447B044D3 (int32_t* __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::.ctor(UnityEngine.UI.Graphic,UnityEngine.Vector3,UnityEngine.Vector2,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RaycastHitData__ctor_m8F1461FA863FE922484EC142C8B44088741C9B5D (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___graphic0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldHitPosition1, Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___screenPosition2, float ___distance3, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_worldHitPosition()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  RaycastHitData_get_worldHitPosition_mC9C5845797C171788CF76B2CBB32837645157CC2_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method);
// UnityEngine.Vector2 UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_screenPosition()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  RaycastHitData_get_screenPosition_m6645B3B1991CF259946A1EF12953F3FC8CDFA496_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method);
// System.Single UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_distance()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float RaycastHitData_get_distance_m491A785927DD2A56D4735115B9301CF01595112F_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.TypeTable/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mE8CBA0D8755028C9C815A04A86EFC19899D78EE4 (U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.Utilities.InternedString::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC (InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout UnityEngine.InputSystem.XR.XRLayoutBuilder::Build()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491 * XRLayoutBuilder_Build_m31AFDB2D4649937D751A722D79232FE320FDA39D (XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m536EFAB0D8AC660A7178F457D2EA8B23CA03EF87 (U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::get_name()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ControlItem_get_name_mCE0AD0DE297C87588F201396EDA1C92C0120CAD5_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.Utilities.InternedString::op_Implicit(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* InternedString_op_Implicit_m02F9D70EFC8036EBE85DF2019D5AA3B430814EF8 (InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___str0, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.InputControlScheme::get_bindingGroup()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* InputControlScheme_get_bindingGroup_mDBCE86B56691F2942296D6D1AE0D5ADB3194F0ED_inline (InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288 * __this, const RuntimeMethod* method);
// System.Boolean System.String::Equals(System.String,System.StringComparison)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_Equals_m62F0586691097AA2EE48F1596A130170BCFBF7F6 (String_t* __this, String_t* ___value0, int32_t ___comparisonType1, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_displayName(System.String)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_displayName_mB29B2CA5BDF6A4617795C5CD01FD2AD5DA17AE8A_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, String_t* ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithDisplayName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithDisplayName_m1A623A8DF4B7720ECC31835DDBEF3140089EE7A4 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___displayName0, const RuntimeMethod* method);
// System.Void System.ArgumentException::.ctor(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgumentException__ctor_m71044C2110E357B71A1C30D2561C3F861AF1DC0D (ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00 * __this, String_t* ___message0, String_t* ___paramName1, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.InternedString::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void InternedString__ctor_mB41178458180DD7648D91B2F7865A2C5CC1B1192 (InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * __this, String_t* ___text0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_layout(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_layout_m120160AE002A158CA9EDCA62BF8201D27F4E838C_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithLayout(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithLayout_mD3C038067BB92E5A917110E4FBABEA3AB1E253A8 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___layout0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_format(UnityEngine.InputSystem.Utilities.FourCC)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_format_mE749BC629174FFC3153C1A077972A5A796CCB003_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithFormat(UnityEngine.InputSystem.Utilities.FourCC)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithFormat_m4FEE215953366F0D5B9CE14D480BCF2A396446A6 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___format0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.FourCC::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FourCC__ctor_m067FE59969221E1E286A5BA08A93835A50A27BE9 (FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A * __this, String_t* ___str0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithFormat(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithFormat_m8EAB9AD26E96020E18A36BC3A13C1CC4FA537960 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___format0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_offset(System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_offset_m3311619100F27C22CAF2EB2FE8B8E5BD42B4486B_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, uint32_t ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithByteOffset(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithByteOffset_m523C0547DD663078008826E3A81804382E0A0689 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, uint32_t ___offset0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_bit(System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_bit_m18990DBD5680FC858B52DCA931E21C3383809265_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, uint32_t ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithBitOffset(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithBitOffset_m6B537FD254A5BCEDFECDE6A779ADDBA5D34BE695 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, uint32_t ___bit0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_isSynthetic(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ControlItem_set_isSynthetic_mA8F8F5DC079B172B0323CDE7935DCF27976919A2 (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, bool ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::IsSynthetic(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_IsSynthetic_mF1F6C5A150897BA005977285742A0294F00040E9 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_isNoisy(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ControlItem_set_isNoisy_m1F3F63017800F3D868F9D94E5136364C13D263F2 (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, bool ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::IsNoisy(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_IsNoisy_mDDF9673A876A0EEF88337A02E32D64169D4D4729 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_dontReset(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ControlItem_set_dontReset_m5A874442E701E67DAE35578DF99DAB91C5BA031D (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, bool ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::DontReset(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_DontReset_m9D2975378C6E93F2069BF323381791C7F8FAAFF7 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_sizeInBits(System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_sizeInBits_m8F4F28F7ED19B693DE210492DA15EAEE6C8EB543_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, uint32_t ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithSizeInBits(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithSizeInBits_m5D102549835C4325A2A28F769E86CCCC9EBE7A30 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, uint32_t ___sizeInBits0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.Utilities.PrimitiveValue::op_Implicit(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  PrimitiveValue_op_Implicit_m816B423406A5509C5EF837048B425B5091D1F38B (float ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_minValue(UnityEngine.InputSystem.Utilities.PrimitiveValue)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_minValue_mAB7186D561C1E98CBFBAFE17A00A0F177B20171D_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_maxValue(UnityEngine.InputSystem.Utilities.PrimitiveValue)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_maxValue_mBE618291D3CBE215F4ADF8B16D33735618D89E8E_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithRange(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithRange_m145BFDD16FEBCFD69B61FFE1EA4EB18405A18B33 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, float ___minValue0, float ___maxValue1, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.Utilities.InternedString::IsEmpty()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool InternedString_IsEmpty_m78C41407A53828966AC41C95368CFB7EF61A7494 (InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/Builder::get_name()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* Builder_get_name_m0E4ECDC1E4880050B65289CA1ACA6BBFAA279486_inline (Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * __this, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object,System.Object,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6 (String_t* ___format0, RuntimeObject * ___arg01, RuntimeObject * ___arg12, RuntimeObject * ___arg23, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.InternedString>::.ctor(TValue[])
inline void ReadOnlyArray_1__ctor_mEBC958B99E88055B976A48FD29182C367B255013 (ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C * __this, InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___array0, const RuntimeMethod* method)
{
	((  void (*) (ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C *, InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11*, const RuntimeMethod*))ReadOnlyArray_1__ctor_mEBC958B99E88055B976A48FD29182C367B255013_gshared)(__this, ___array0, method);
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_usages(UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.InternedString>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_usages_m565AB9F1578DEA1A853FD37AC283E82838B7F934_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithUsages(UnityEngine.InputSystem.Utilities.InternedString[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_m7766F0A2DE6A8E77E17C4CF777D71A7D2A63ECF6 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___usages0, const RuntimeMethod* method);
// System.Void System.Func`2<System.String,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Object,System.IntPtr)
inline void Func_2__ctor_m244A853C4545AF28ABF654C7F16EAF3B6D52BD7B (Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	((  void (*) (Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB *, RuntimeObject *, intptr_t, const RuntimeMethod*))Func_2__ctor_m95BB7160284BF7AB79C08B1FF72F51BCBF6E6BBE_gshared)(__this, ___object0, ___method1, method);
}
// System.Collections.Generic.IEnumerable`1<!!1> System.Linq.Enumerable::Select<System.String,UnityEngine.InputSystem.Utilities.InternedString>(System.Collections.Generic.IEnumerable`1<!!0>,System.Func`2<!!0,!!1>)
inline RuntimeObject* Enumerable_Select_TisString_t_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_m322E9154E14BE81AD2AAF37A69AC92E6FE3D0E6F (RuntimeObject* ___source0, Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * ___selector1, const RuntimeMethod* method)
{
	return ((  RuntimeObject* (*) (RuntimeObject*, Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB *, const RuntimeMethod*))Enumerable_Select_TisRuntimeObject_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_m2B8D23259A06952B0D0A88F5FF5FCACD087E3430_gshared)(___source0, ___selector1, method);
}
// !!0[] System.Linq.Enumerable::ToArray<UnityEngine.InputSystem.Utilities.InternedString>(System.Collections.Generic.IEnumerable`1<!!0>)
inline InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* Enumerable_ToArray_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_mB81CDBC6648458E775977B0F5B0CD7DFDB092FF8 (RuntimeObject* ___source0, const RuntimeMethod* method)
{
	return ((  InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_ToArray_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_mB81CDBC6648458E775977B0F5B0CD7DFDB092FF8_gshared)(___source0, method);
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithUsages(System.Collections.Generic.IEnumerable`1<System.String>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_mC6770F32E20A5F1C57BD18A556A52EE176113F35 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, RuntimeObject* ___usages0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithUsages(System.String[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_mD84AACB822B051C4B90BF627DEE0D6226F546767 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* ___usages0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Utilities.NamedValue[] UnityEngine.InputSystem.Utilities.NamedValue::ParseMultiple(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* NamedValue_ParseMultiple_m102A3FEB344FC4CD41D094A637106B47B5FE6B40 (String_t* ___parameterString0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue>::.ctor(TValue[])
inline void ReadOnlyArray_1__ctor_mAD8348E710A8187038E9A181FF8458AB4FD59447 (ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8 * __this, NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* ___array0, const RuntimeMethod* method)
{
	((  void (*) (ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8 *, NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B*, const RuntimeMethod*))ReadOnlyArray_1__ctor_mAD8348E710A8187038E9A181FF8458AB4FD59447_gshared)(__this, ___array0, method);
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_parameters(UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_parameters_m70663F346869784CF8C4E6C5BADDE822F98B8B24_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithParameters(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithParameters_m8042DDA5517A5EC2428ED502651674EE9BF46AB2 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___parameters0, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerable`1<UnityEngine.InputSystem.Utilities.NameAndParameters> UnityEngine.InputSystem.Utilities.NameAndParameters::ParseMultiple(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* NameAndParameters_ParseMultiple_mF1A7222A513A114B1AB2E58FE747F54965A35C53 (String_t* ___text0, const RuntimeMethod* method);
// !!0[] System.Linq.Enumerable::ToArray<UnityEngine.InputSystem.Utilities.NameAndParameters>(System.Collections.Generic.IEnumerable`1<!!0>)
inline NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* Enumerable_ToArray_TisNameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_mDC5522CF62EDFA52EEA4E8F85D7FECD84CFF23AE (RuntimeObject* ___source0, const RuntimeMethod* method)
{
	return ((  NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_ToArray_TisNameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_mDC5522CF62EDFA52EEA4E8F85D7FECD84CFF23AE_gshared)(___source0, method);
}
// System.Void UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NameAndParameters>::.ctor(TValue[])
inline void ReadOnlyArray_1__ctor_m2AEF1D3FB42E7980B7C8F4D40E775EEB1DAD8C8E (ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F * __this, NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* ___array0, const RuntimeMethod* method)
{
	((  void (*) (ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F *, NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83*, const RuntimeMethod*))ReadOnlyArray_1__ctor_m2AEF1D3FB42E7980B7C8F4D40E775EEB1DAD8C8E_gshared)(__this, ___array0, method);
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_processors(UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NameAndParameters>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_processors_m9A9EF453FBB41590F5DC79775533A7DB5781B8C9_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithProcessors(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithProcessors_m7711FE6714EA57F0356AE3076D72508F5C9275F7 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___processors0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_defaultState(UnityEngine.InputSystem.Utilities.PrimitiveValue)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_defaultState_mB9603018DBC8D71A72B9E74B0179AD2E4965D681_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithDefaultState(UnityEngine.InputSystem.Utilities.PrimitiveValue)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithDefaultState_m028E2C3DAB7D1FBE5E5019088971F980825933C4 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_useStateFrom(System.String)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_useStateFrom_m2483939EAAD5950014A020C5A056DE99484CAF86_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, String_t* ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::UsingStateFrom(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_UsingStateFrom_m47B51350F5935A5B9216C129D48B46DF9C6C9C71 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___path0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem::set_arraySize(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_arraySize_mB8DE5DE08FBE9A89D6878878D0DF5618EA24ECFB_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, int32_t ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::AsArrayOfControlsWithSize(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_AsArrayOfControlsWithSize_m92B1A2C880BBB1FA09A64A421BEB952DBB9F829E (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, int32_t ___arraySize0, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>::TryGetValue(!0,!1&)
inline bool Dictionary_2_TryGetValue_m13A59E4AB21B1AFCC1D94C66A2F5689DD3DF7C31 (Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___key0, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * ___value1, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B *, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 , InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *, const RuntimeMethod*))Dictionary_2_TryGetValue_m13A59E4AB21B1AFCC1D94C66A2F5689DD3DF7C31_gshared)(__this, ___key0, ___value1, method);
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CGetBaseLayoutsU3Ed__24__ctor_m1FC80EA631C9A11728DC11205F1C4E2FC6ECE022 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::System.Collections.Generic.IEnumerable<UnityEngine.InputSystem.Utilities.InternedString>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CGetBaseLayoutsU3Ed__24_System_Collections_Generic_IEnumerableU3CUnityEngine_InputSystem_Utilities_InternedStringU3E_GetEnumerator_m9254F2D4D1437C7746A0CC2C60F0B340D73A2AD3 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mFE18172684237870F6DD9CC60FD94D624C0E99D4 (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.Utilities.NamedValue::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* NamedValue_ToString_mEE65DA4CA646BCC2F772F24A446983008CECA098 (NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94 * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.Utilities.NameAndParameters::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* NameAndParameters_ToString_m69852A95F27B6F0593D56932ADD47AA08FD7F775 (NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mCF1CD4BDB1326CE26CD97C6B1F504983FAF18B97 (U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m0887F13BD9B7E5DA9527DB853D4FD6C6F82A52E4 (U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.Utilities.Substring::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Substring_ToString_m937D6E75F4C022340ED2DEDAD848028B3BC9FD2F (Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m69D0FB3FEB02C8B1D1C42A8595BD2D9943156F3D (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator_Reset_mB34C8934D0B76650C0CAF3E338E76EBCBAA2DCD9 (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method);
// System.Void System.InvalidOperationException::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void InvalidOperationException__ctor_mC012CE552988309733C896F3FEA8249171E4402E (InvalidOperationException_t10D3EE59AD28EC641ACEE05BCA4271A527E5ECAB * __this, String_t* ___message0, const RuntimeMethod* method);
// UnityEngine.InputSystem.InputControlScheme/MatchResult/Match UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Match_tF8E25BC160894A799358F44EB19C42365DAF0828  Enumerator_get_Current_m89A82ED8B3FAEF6771859606DADC26A56149B8B2 (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method);
// System.Object UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * Enumerator_System_Collections_IEnumerator_get_Current_m4FF1A3117FCFFC22B6CB53138F563F4E58073499 (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator_Dispose_mD6FB640B4C4F656F1D7F0235C4AC4B378681F99B (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method);
// TControl UnityEngine.InputSystem.InputControlList`1<UnityEngine.InputSystem.InputControl>::get_Item(System.Int32)
inline InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * InputControlList_1_get_Item_mB3D2AEA475656D4495707F32D001D2192024A108 (InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B * __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * (*) (InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B *, int32_t, const RuntimeMethod*))InputControlList_1_get_Item_m384B41A142DD0D1E829F2C1199415EF241786589_gshared)(__this, ___index0, method);
}
// UnityEngine.InputSystem.InputControl UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_control()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * Match_get_control_m741951B4E84AD0E6C303FA8D51D43742918E830B (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.InputDevice UnityEngine.InputSystem.InputControl::get_device()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * InputControl_get_device_m238E9124B28FCDD64BCB24DD187503F3621B1B03_inline (InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.InputDevice UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_device()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * Match_get_device_mFFC18BE3B6939104A5828EE6C57B7EB62B5B8F0A (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_requirementIndex()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Match_get_requirementIndex_mD05676A71BCB0583CDC59F9E20C31341048D2519_inline (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method);
// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_requirement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  Match_get_requirement_mDEEE98468DF83D46E3ACF11434B8AE6BEC64ED92 (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::get_isOptional()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DeviceRequirement_get_isOptional_mEA1639502FEB610CE88F05491A1B1F0FD06CDB55 (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_isOptional()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Match_get_isOptional_mDC63A63D9D82238E9BD8B3784E05BAACF03F9905 (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::set_controlPath(System.String)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void DeviceRequirement_set_controlPath_mAE0850C485197021FD454C20922F00322370908E_inline (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, String_t* ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::set_isOptional(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DeviceRequirement_set_isOptional_mE5FA29C2E76F1922119F087C72FA8B9772A44CFE (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::set_isOR(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DeviceRequirement_set_isOR_m367881FA1B119F181ED68BDBF34A8148C79C7BC6 (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, bool ___value0, const RuntimeMethod* method);
// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson::ToDeviceEntry()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  DeviceJson_ToDeviceEntry_m3274EB04F6EB5F9A70A918B51FCFBC3B6A206416 (DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::get_controlPath()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* DeviceRequirement_get_controlPath_m30D76119C4E712E3177B17FF34359FD3426601DC_inline (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.InputSystem.InputControlScheme/DeviceRequirement::get_isOR()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DeviceRequirement_get_isOR_m2B8AA0404E45B881E709118077376043762DEE36 (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m8D6B5CDB7AB6575EF56554F078F4B67254D974A1 (U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD * __this, const RuntimeMethod* method);
// System.Double UnityEngine.InputSystem.LowLevel.InputEventPtr::get_time()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double InputEventPtr_get_time_m05F48852D2AD3907919F7B3931F195F1AEB62F06 (InputEventPtr_tDF9E84E7EAFF138A0A830345C72B2CD5885577B5 * __this, const RuntimeMethod* method);
// System.Int32 System.Double::CompareTo(System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Double_CompareTo_m93107F1616A67C9CDB540738E0115A5E668FBBBE (double* __this, double ___value0, const RuntimeMethod* method);
// System.Int32 UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo::get_deviceId()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t DeviceInfo_get_deviceId_m2B26439F4A8C1BAAECA5DFFC538B6F675F877988_inline (DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m64EE0F8705120CC7B1EDB9801FFE4774B7A6A625 (U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m6F681E0D4BEAA97DBC3AC40A8C282FE61FEE0BC6 (U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mE375B98801D8D5A008F73076C87EB9FFEBD7408F (U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * __this, const RuntimeMethod* method);
// System.String UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* JsonValue_ToString_mFC3514B762B6CB76975CD44B57E4EBC3850A055E (JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.KeyValuePair`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Key()
inline String_t* KeyValuePair_2_get_Key_m0981E567B61168C690B6342E523A320D15BC6949_inline (KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45 * __this, const RuntimeMethod* method)
{
	return ((  String_t* (*) (KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45 *, const RuntimeMethod*))KeyValuePair_2_get_Key_m4E9ACD2B4E097B0AF5B15D923092D10E257C64E7_gshared_inline)(__this, method);
}
// !1 System.Collections.Generic.KeyValuePair`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Value()
inline JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  KeyValuePair_2_get_Value_mBBA0D76AE55EE865EADCB26991005D244E481AFF_inline (KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45 * __this, const RuntimeMethod* method)
{
	return ((  JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  (*) (KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45 *, const RuntimeMethod*))KeyValuePair_2_get_Value_m5D03130FB6F2A36980DDE053BC7BA6EA77FC9ECF_gshared_inline)(__this, method);
}
// System.String System.String::Format(System.String,System.Object,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66 (String_t* ___format0, RuntimeObject * ___arg01, RuntimeObject * ___arg12, const RuntimeMethod* method);
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mBF2B08D9F34A2B44F8CD488BBAD9C35257282B39 (U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * __this, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.PlayerInputManager/PlayerLeftEvent::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayerLeftEvent__ctor_mC3818A4364BB369C7984DE82554CA3EC18A02838 (PlayerLeftEvent_tC4BBBDE1FE743F4EC06251E8554EE4EFF88EF34E * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UnityEvent_1__ctor_mD8BFEFBF01C2160CFD91DD3E681A92B6D7C9A5B8_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		UnityEvent_1__ctor_mD8BFEFBF01C2160CFD91DD3E681A92B6D7C9A5B8(__this, /*hidden argument*/UnityEvent_1__ctor_mD8BFEFBF01C2160CFD91DD3E681A92B6D7C9A5B8_RuntimeMethod_var);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: UnityEngine.InputSystem.UI.PointerModel/ButtonState
IL2CPP_EXTERN_C void ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshal_pinvoke(const ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248& unmarshaled, ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_PressRaycast_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_PressRaycast' of type 'ButtonState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_PressRaycast_3Exception, NULL);
}
IL2CPP_EXTERN_C void ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshal_pinvoke_back(const ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_pinvoke& marshaled, ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248& unmarshaled)
{
	Exception_t* ___m_PressRaycast_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_PressRaycast' of type 'ButtonState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_PressRaycast_3Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.UI.PointerModel/ButtonState
IL2CPP_EXTERN_C void ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshal_pinvoke_cleanup(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: UnityEngine.InputSystem.UI.PointerModel/ButtonState
IL2CPP_EXTERN_C void ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshal_com(const ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248& unmarshaled, ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_com& marshaled)
{
	Exception_t* ___m_PressRaycast_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_PressRaycast' of type 'ButtonState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_PressRaycast_3Exception, NULL);
}
IL2CPP_EXTERN_C void ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshal_com_back(const ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_com& marshaled, ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248& unmarshaled)
{
	Exception_t* ___m_PressRaycast_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_PressRaycast' of type 'ButtonState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_PressRaycast_3Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.UI.PointerModel/ButtonState
IL2CPP_EXTERN_C void ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshal_com_cleanup(ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248_marshaled_com& marshaled)
{
}
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_isPressed()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ButtonState_get_isPressed_mC20A08312DF96CA0D5D6657ADC4FFD4880B28DE0 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_IsPressed;
		bool L_0 = __this->get_m_IsPressed_0();
		return L_0;
	}
}
IL2CPP_EXTERN_C  bool ButtonState_get_isPressed_mC20A08312DF96CA0D5D6657ADC4FFD4880B28DE0_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	bool _returnValue;
	_returnValue = ButtonState_get_isPressed_mC20A08312DF96CA0D5D6657ADC4FFD4880B28DE0_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_isPressed(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_set_isPressed_m276D75A708B80F7F49771FA5401FDF482F212F9E (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// if (m_IsPressed != value)
		bool L_0 = __this->get_m_IsPressed_0();
		bool L_1 = ___value0;
		if ((((int32_t)L_0) == ((int32_t)L_1)))
		{
			goto IL_004b;
		}
	}
	{
		// m_IsPressed = value;
		bool L_2 = ___value0;
		__this->set_m_IsPressed_0(L_2);
		// if (m_FramePressState == PointerEventData.FramePressState.NotChanged && value)
		int32_t L_3 = __this->get_m_FramePressState_1();
		bool L_4 = ___value0;
		if (!((int32_t)((int32_t)((((int32_t)L_3) == ((int32_t)3))? 1 : 0)&(int32_t)L_4)))
		{
			goto IL_0025;
		}
	}
	{
		// m_FramePressState = PointerEventData.FramePressState.Pressed;
		__this->set_m_FramePressState_1(0);
		return;
	}

IL_0025:
	{
		// else if (m_FramePressState == PointerEventData.FramePressState.NotChanged && !value)
		int32_t L_5 = __this->get_m_FramePressState_1();
		if ((!(((uint32_t)L_5) == ((uint32_t)3))))
		{
			goto IL_0039;
		}
	}
	{
		bool L_6 = ___value0;
		if (L_6)
		{
			goto IL_0039;
		}
	}
	{
		// m_FramePressState = PointerEventData.FramePressState.Released;
		__this->set_m_FramePressState_1(1);
		return;
	}

IL_0039:
	{
		// else if (m_FramePressState == PointerEventData.FramePressState.Pressed && !value)
		int32_t L_7 = __this->get_m_FramePressState_1();
		if (L_7)
		{
			goto IL_004b;
		}
	}
	{
		bool L_8 = ___value0;
		if (L_8)
		{
			goto IL_004b;
		}
	}
	{
		// m_FramePressState = PointerEventData.FramePressState.PressedAndReleased;
		__this->set_m_FramePressState_1(2);
	}

IL_004b:
	{
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void ButtonState_set_isPressed_m276D75A708B80F7F49771FA5401FDF482F212F9E_AdjustorThunk (RuntimeObject * __this, bool ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	ButtonState_set_isPressed_m276D75A708B80F7F49771FA5401FDF482F212F9E(_thisAdjusted, ___value0, method);
}
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_ignoreNextClick()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ButtonState_get_ignoreNextClick_m6304EB764807405EF59F964BB0BDA6117F919D45 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_IgnoreNextClick;
		bool L_0 = __this->get_m_IgnoreNextClick_13();
		return L_0;
	}
}
IL2CPP_EXTERN_C  bool ButtonState_get_ignoreNextClick_m6304EB764807405EF59F964BB0BDA6117F919D45_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	bool _returnValue;
	_returnValue = ButtonState_get_ignoreNextClick_m6304EB764807405EF59F964BB0BDA6117F919D45_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_ignoreNextClick(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_set_ignoreNextClick_mE0FE305F262ED710FCFC9DF5A4C7B115476AB26D (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// set => m_IgnoreNextClick = value;
		bool L_0 = ___value0;
		__this->set_m_IgnoreNextClick_13(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void ButtonState_set_ignoreNextClick_mE0FE305F262ED710FCFC9DF5A4C7B115476AB26D_AdjustorThunk (RuntimeObject * __this, bool ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	ButtonState_set_ignoreNextClick_mE0FE305F262ED710FCFC9DF5A4C7B115476AB26D_inline(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_pressTime()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float ButtonState_get_pressTime_m214D6D781C6F581CBF781A9620A6C10239A096BD (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_PressTime;
		float L_0 = __this->get_m_PressTime_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C  float ButtonState_get_pressTime_m214D6D781C6F581CBF781A9620A6C10239A096BD_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	float _returnValue;
	_returnValue = ButtonState_get_pressTime_m214D6D781C6F581CBF781A9620A6C10239A096BD_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_pressTime(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_set_pressTime_m43CEEA0944E6A2D87CB763FBD333FA8679829E27 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		// set => m_PressTime = value;
		float L_0 = ___value0;
		__this->set_m_PressTime_2(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void ButtonState_set_pressTime_m43CEEA0944E6A2D87CB763FBD333FA8679829E27_AdjustorThunk (RuntimeObject * __this, float ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	ButtonState_set_pressTime_m43CEEA0944E6A2D87CB763FBD333FA8679829E27_inline(_thisAdjusted, ___value0, method);
}
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_clickedOnSameGameObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ButtonState_get_clickedOnSameGameObject_mE95BA21860C122BD01C8A314CA27381288D015F3 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_ClickedOnSameGameObject;
		bool L_0 = __this->get_m_ClickedOnSameGameObject_12();
		return L_0;
	}
}
IL2CPP_EXTERN_C  bool ButtonState_get_clickedOnSameGameObject_mE95BA21860C122BD01C8A314CA27381288D015F3_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	bool _returnValue;
	_returnValue = ButtonState_get_clickedOnSameGameObject_mE95BA21860C122BD01C8A314CA27381288D015F3_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::set_clickedOnSameGameObject(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_set_clickedOnSameGameObject_m3F29C95CA8EAECC108C2BF571FFFF5744FBA1A87 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// set => m_ClickedOnSameGameObject = value;
		bool L_0 = ___value0;
		__this->set_m_ClickedOnSameGameObject_12(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void ButtonState_set_clickedOnSameGameObject_m3F29C95CA8EAECC108C2BF571FFFF5744FBA1A87_AdjustorThunk (RuntimeObject * __this, bool ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	ButtonState_set_clickedOnSameGameObject_m3F29C95CA8EAECC108C2BF571FFFF5744FBA1A87_inline(_thisAdjusted, ___value0, method);
}
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_wasPressedThisFrame()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ButtonState_get_wasPressedThisFrame_m7C0C0C74F0CFA603802C6375B3735CBB87B8D0C6 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// public bool wasPressedThisFrame => m_FramePressState == PointerEventData.FramePressState.Pressed ||
		// m_FramePressState == PointerEventData.FramePressState.PressedAndReleased;
		int32_t L_0 = __this->get_m_FramePressState_1();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		int32_t L_1 = __this->get_m_FramePressState_1();
		return (bool)((((int32_t)L_1) == ((int32_t)2))? 1 : 0);
	}

IL_0012:
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C  bool ButtonState_get_wasPressedThisFrame_m7C0C0C74F0CFA603802C6375B3735CBB87B8D0C6_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	bool _returnValue;
	_returnValue = ButtonState_get_wasPressedThisFrame_m7C0C0C74F0CFA603802C6375B3735CBB87B8D0C6(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean UnityEngine.InputSystem.UI.PointerModel/ButtonState::get_wasReleasedThisFrame()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ButtonState_get_wasReleasedThisFrame_mC2A2CBEAF1776ED64A27ED0C6806B878433D3516 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// public bool wasReleasedThisFrame => m_FramePressState == PointerEventData.FramePressState.Released ||
		// m_FramePressState == PointerEventData.FramePressState.PressedAndReleased;
		int32_t L_0 = __this->get_m_FramePressState_1();
		if ((((int32_t)L_0) == ((int32_t)1)))
		{
			goto IL_0013;
		}
	}
	{
		int32_t L_1 = __this->get_m_FramePressState_1();
		return (bool)((((int32_t)L_1) == ((int32_t)2))? 1 : 0);
	}

IL_0013:
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C  bool ButtonState_get_wasReleasedThisFrame_mC2A2CBEAF1776ED64A27ED0C6806B878433D3516_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	bool _returnValue;
	_returnValue = ButtonState_get_wasReleasedThisFrame_mC2A2CBEAF1776ED64A27ED0C6806B878433D3516(_thisAdjusted, method);
	return _returnValue;
}
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::CopyPressStateTo(UnityEngine.EventSystems.PointerEventData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_CopyPressStateTo_m8DFA367FE2C863DF1A1327B81066E1497AD8AC57 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * ___eventData0, const RuntimeMethod* method)
{
	{
		// eventData.pointerPressRaycast = m_PressRaycast;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_0 = ___eventData0;
		RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  L_1 = __this->get_m_PressRaycast_3();
		NullCheck(L_0);
		PointerEventData_set_pointerPressRaycast_mAF28B12216468A02DACA9900B0A57FA1BF3B94F4_inline(L_0, L_1, /*hidden argument*/NULL);
		// eventData.pressPosition = m_PressPosition;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_2 = ___eventData0;
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_3 = __this->get_m_PressPosition_8();
		NullCheck(L_2);
		PointerEventData_set_pressPosition_mE644EE1603DFF2087224FF6364EA0204D04D7939_inline(L_2, L_3, /*hidden argument*/NULL);
		// eventData.clickCount = m_ClickCount;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_4 = ___eventData0;
		int32_t L_5 = __this->get_m_ClickCount_10();
		NullCheck(L_4);
		PointerEventData_set_clickCount_m2EAAB7F43CE26BF505B7FCF7D509C988DCFD7F28_inline(L_4, L_5, /*hidden argument*/NULL);
		// eventData.clickTime = m_ClickTime;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_6 = ___eventData0;
		float L_7 = __this->get_m_ClickTime_9();
		NullCheck(L_6);
		PointerEventData_set_clickTime_m215E254F8585FFC518E3161FAF9137388F64AC58_inline(L_6, L_7, /*hidden argument*/NULL);
		// eventData.pointerPress = m_LastPressObject;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_8 = ___eventData0;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_9 = __this->get_m_LastPressObject_6();
		NullCheck(L_8);
		PointerEventData_set_pointerPress_mF37D23566DDB326EB2CFE59592F8538F23BA0EC0(L_8, L_9, /*hidden argument*/NULL);
		// eventData.pointerPress = m_PressObject;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_10 = ___eventData0;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_11 = __this->get_m_PressObject_4();
		NullCheck(L_10);
		PointerEventData_set_pointerPress_mF37D23566DDB326EB2CFE59592F8538F23BA0EC0(L_10, L_11, /*hidden argument*/NULL);
		// eventData.rawPointerPress = m_RawPressObject;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_12 = ___eventData0;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_13 = __this->get_m_RawPressObject_5();
		NullCheck(L_12);
		PointerEventData_set_rawPointerPress_m0BEEB9CA5E44F570C2C0803553BA9736F4DF58F0_inline(L_12, L_13, /*hidden argument*/NULL);
		// eventData.pointerDrag = m_DragObject;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_14 = ___eventData0;
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_15 = __this->get_m_DragObject_7();
		NullCheck(L_14);
		PointerEventData_set_pointerDrag_m2E9F059EC1CDF71E0A097A0D3CCBA564E0C463C2_inline(L_14, L_15, /*hidden argument*/NULL);
		// eventData.dragging = m_Dragging;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_16 = ___eventData0;
		bool L_17 = __this->get_m_Dragging_11();
		NullCheck(L_16);
		PointerEventData_set_dragging_mEB739C44F1B1848B4B3F4E7FBB9B376587C2C7E1_inline(L_16, L_17, /*hidden argument*/NULL);
		// if (ignoreNextClick)
		bool L_18;
		L_18 = ButtonState_get_ignoreNextClick_m6304EB764807405EF59F964BB0BDA6117F919D45_inline((ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *)__this, /*hidden argument*/NULL);
		if (!L_18)
		{
			goto IL_007b;
		}
	}
	{
		// eventData.eligibleForClick = false;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_19 = ___eventData0;
		NullCheck(L_19);
		PointerEventData_set_eligibleForClick_m5CFAF671C2B33AF8E9153FA4826D93B9308C4C07_inline(L_19, (bool)0, /*hidden argument*/NULL);
	}

IL_007b:
	{
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void ButtonState_CopyPressStateTo_m8DFA367FE2C863DF1A1327B81066E1497AD8AC57_AdjustorThunk (RuntimeObject * __this, PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * ___eventData0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	ButtonState_CopyPressStateTo_m8DFA367FE2C863DF1A1327B81066E1497AD8AC57(_thisAdjusted, ___eventData0, method);
}
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::CopyPressStateFrom(UnityEngine.EventSystems.PointerEventData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_CopyPressStateFrom_mE72A6AA474EAEAE6D143AD32C64317A4BCF039A5 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * ___eventData0, const RuntimeMethod* method)
{
	{
		// m_PressRaycast = eventData.pointerPressRaycast;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_0 = ___eventData0;
		NullCheck(L_0);
		RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  L_1;
		L_1 = PointerEventData_get_pointerPressRaycast_m3C5785CD2C31F91C91D6F1084D2EAC31BED56ACB_inline(L_0, /*hidden argument*/NULL);
		__this->set_m_PressRaycast_3(L_1);
		// m_PressObject = eventData.pointerPress;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_2 = ___eventData0;
		NullCheck(L_2);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_3;
		L_3 = PointerEventData_get_pointerPress_mB55C5528AF445DB7B912086E43F0BCD9CDFF409C_inline(L_2, /*hidden argument*/NULL);
		__this->set_m_PressObject_4(L_3);
		// m_RawPressObject = eventData.rawPointerPress;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_4 = ___eventData0;
		NullCheck(L_4);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_5;
		L_5 = PointerEventData_get_rawPointerPress_m0C23DB50BCE28ECC43609CC01E727CCA77FC6473_inline(L_4, /*hidden argument*/NULL);
		__this->set_m_RawPressObject_5(L_5);
		// m_LastPressObject = eventData.lastPress;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_6 = ___eventData0;
		NullCheck(L_6);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_7;
		L_7 = PointerEventData_get_lastPress_m362C5876B8C9F50BACC27D9026DB3709D6950C0B_inline(L_6, /*hidden argument*/NULL);
		__this->set_m_LastPressObject_6(L_7);
		// m_PressPosition = eventData.pressPosition;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_8 = ___eventData0;
		NullCheck(L_8);
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_9;
		L_9 = PointerEventData_get_pressPosition_mB8F60EB21F6E6892EC731382614BAB85E29ED642_inline(L_8, /*hidden argument*/NULL);
		__this->set_m_PressPosition_8(L_9);
		// m_ClickTime = eventData.clickTime;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_10 = ___eventData0;
		NullCheck(L_10);
		float L_11;
		L_11 = PointerEventData_get_clickTime_m08F7FD164EFE2AE7B47A15C70BC418632B9E5950_inline(L_10, /*hidden argument*/NULL);
		__this->set_m_ClickTime_9(L_11);
		// m_ClickCount = eventData.clickCount;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_12 = ___eventData0;
		NullCheck(L_12);
		int32_t L_13;
		L_13 = PointerEventData_get_clickCount_mB44AAB99335BD7D2BD93E40DAC282A56202E44F2_inline(L_12, /*hidden argument*/NULL);
		__this->set_m_ClickCount_10(L_13);
		// m_DragObject = eventData.pointerDrag;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_14 = ___eventData0;
		NullCheck(L_14);
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_15;
		L_15 = PointerEventData_get_pointerDrag_m5FD1D758CA629D9EBB8BDA3207132BC9BAB91ACE_inline(L_14, /*hidden argument*/NULL);
		__this->set_m_DragObject_7(L_15);
		// m_Dragging = eventData.dragging;
		PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * L_16 = ___eventData0;
		NullCheck(L_16);
		bool L_17;
		L_17 = PointerEventData_get_dragging_m7FD3F5D4D8DAC559A57EDB88F2B2B5DEA4B48266_inline(L_16, /*hidden argument*/NULL);
		__this->set_m_Dragging_11(L_17);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void ButtonState_CopyPressStateFrom_mE72A6AA474EAEAE6D143AD32C64317A4BCF039A5_AdjustorThunk (RuntimeObject * __this, PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * ___eventData0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	ButtonState_CopyPressStateFrom_mE72A6AA474EAEAE6D143AD32C64317A4BCF039A5(_thisAdjusted, ___eventData0, method);
}
// System.Void UnityEngine.InputSystem.UI.PointerModel/ButtonState::OnEndFrame()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ButtonState_OnEndFrame_m7A59E069FB0C75CB9F6EEFDDAE7FA5D1CEB29FB1 (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// m_FramePressState = PointerEventData.FramePressState.NotChanged;
		__this->set_m_FramePressState_1(3);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void ButtonState_OnEndFrame_m7A59E069FB0C75CB9F6EEFDDAE7FA5D1CEB29FB1_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * _thisAdjusted = reinterpret_cast<ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 *>(__this + _offset);
	ButtonState_OnEndFrame_m7A59E069FB0C75CB9F6EEFDDAE7FA5D1CEB29FB1(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Subscriber_Dispose_m71146815BE41528B23995203AC4C056FBD5BCE01 (Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_Erase_TisSubscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155_mB50873C9A1871E7CB5BFBF691B77D4628B081764_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// ArrayHelpers.Erase(ref owner.m_Subscribers, this);
		RemoteInputPlayerConnection_tFC6AA5385F0CCB0C526B4163D962AD2F3BFEA1C0 * L_0 = __this->get_owner_0();
		NullCheck(L_0);
		SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D** L_1 = L_0->get_address_of_m_Subscribers_12();
		bool L_2;
		L_2 = ArrayHelpers_Erase_TisSubscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155_mB50873C9A1871E7CB5BFBF691B77D4628B081764((SubscriberU5BU5D_t99EEE2465686AB5E5A241510F998CC15DB2AA52D**)L_1, __this, /*hidden argument*/ArrayHelpers_Erase_TisSubscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155_mB50873C9A1871E7CB5BFBF691B77D4628B081764_RuntimeMethod_var);
		// }
		return;
	}
}
// System.Void UnityEngine.InputSystem.RemoteInputPlayerConnection/Subscriber::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Subscriber__ctor_m9B34B3E92AC274410C3E3DADD1D3630FC6744B72 (Subscriber_t369E10EE5DBCFEC1704981F2C00904F1EF36B155 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSplitU3Ed__9__ctor_m2FD3D68D26219E01C8827B4D14A6B8635AD790D3 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___U3CU3E1__state0;
		__this->set_U3CU3E1__state_0(L_0);
		int32_t L_1;
		L_1 = Environment_get_CurrentManagedThreadId_m09DBD4166BFD399056B2F81C77A3A182339BF92D(/*hidden argument*/NULL);
		__this->set_U3CU3El__initialThreadId_2(L_1);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::System.IDisposable.Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSplitU3Ed__9_System_IDisposable_Dispose_m6AC5B596D033F62983078C9CED233C7413C51A1B (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method)
{
	{
		return;
	}
}
// System.Boolean UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CSplitU3Ed__9_MoveNext_mFEC25B236D571606C1E544A0E4FB1F47BF0BEC38 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Il2CppChar V_1 = 0x0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		int32_t L_1 = V_0;
		if (!L_1)
		{
			goto IL_0013;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)1)))
		{
			goto IL_00fd;
		}
	}
	{
		return (bool)0;
	}

IL_0013:
	{
		__this->set_U3CU3E1__state_0((-1));
		// if (string.IsNullOrEmpty(str))
		String_t* L_3 = __this->get_str_3();
		bool L_4;
		L_4 = String_IsNullOrEmpty_m9AFBB5335B441B94E884B8A9D4A27AD60E3D7F7C(L_3, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_0029;
		}
	}
	{
		// yield break;
		return (bool)0;
	}

IL_0029:
	{
		// var length = str.Length;
		String_t* L_5 = __this->get_str_3();
		NullCheck(L_5);
		int32_t L_6;
		L_6 = String_get_Length_m129FC0ADA02FECBED3C0B1A809AE84A5AEE1CF09_inline(L_5, /*hidden argument*/NULL);
		__this->set_U3ClengthU3E5__2_7(L_6);
		// var position = 0;
		__this->set_U3CpositionU3E5__3_8(0);
		goto IL_0104;
	}

IL_0046:
	{
		// var ch = str[position];
		String_t* L_7 = __this->get_str_3();
		int32_t L_8 = __this->get_U3CpositionU3E5__3_8();
		NullCheck(L_7);
		Il2CppChar L_9;
		L_9 = String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70(L_7, L_8, /*hidden argument*/NULL);
		V_1 = L_9;
		// if (predicate(ch))
		Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * L_10 = __this->get_predicate_5();
		Il2CppChar L_11 = V_1;
		NullCheck(L_10);
		bool L_12;
		L_12 = Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D(L_10, L_11, /*hidden argument*/Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D_RuntimeMethod_var);
		if (!L_12)
		{
			goto IL_007d;
		}
	}
	{
		// ++position;
		int32_t L_13 = __this->get_U3CpositionU3E5__3_8();
		V_4 = ((int32_t)il2cpp_codegen_add((int32_t)L_13, (int32_t)1));
		int32_t L_14 = V_4;
		__this->set_U3CpositionU3E5__3_8(L_14);
		// continue;
		goto IL_0104;
	}

IL_007d:
	{
		// var startPosition = position;
		int32_t L_15 = __this->get_U3CpositionU3E5__3_8();
		V_2 = L_15;
		// ++position;
		int32_t L_16 = __this->get_U3CpositionU3E5__3_8();
		V_4 = ((int32_t)il2cpp_codegen_add((int32_t)L_16, (int32_t)1));
		int32_t L_17 = V_4;
		__this->set_U3CpositionU3E5__3_8(L_17);
		goto IL_00ca;
	}

IL_0098:
	{
		// ch = str[position];
		String_t* L_18 = __this->get_str_3();
		int32_t L_19 = __this->get_U3CpositionU3E5__3_8();
		NullCheck(L_18);
		Il2CppChar L_20;
		L_20 = String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70(L_18, L_19, /*hidden argument*/NULL);
		V_1 = L_20;
		// if (predicate(ch))
		Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * L_21 = __this->get_predicate_5();
		Il2CppChar L_22 = V_1;
		NullCheck(L_21);
		bool L_23;
		L_23 = Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D(L_21, L_22, /*hidden argument*/Func_2_Invoke_m4E2E052C8F2A506D1CD8407AD66BF83758FBF59D_RuntimeMethod_var);
		if (L_23)
		{
			goto IL_00d8;
		}
	}
	{
		// ++position;
		int32_t L_24 = __this->get_U3CpositionU3E5__3_8();
		V_4 = ((int32_t)il2cpp_codegen_add((int32_t)L_24, (int32_t)1));
		int32_t L_25 = V_4;
		__this->set_U3CpositionU3E5__3_8(L_25);
	}

IL_00ca:
	{
		// while (position < length)
		int32_t L_26 = __this->get_U3CpositionU3E5__3_8();
		int32_t L_27 = __this->get_U3ClengthU3E5__2_7();
		if ((((int32_t)L_26) < ((int32_t)L_27)))
		{
			goto IL_0098;
		}
	}

IL_00d8:
	{
		// var endPosition = position;
		int32_t L_28 = __this->get_U3CpositionU3E5__3_8();
		V_3 = L_28;
		// yield return str.Substring(startPosition, endPosition - startPosition);
		String_t* L_29 = __this->get_str_3();
		int32_t L_30 = V_2;
		int32_t L_31 = V_3;
		int32_t L_32 = V_2;
		NullCheck(L_29);
		String_t* L_33;
		L_33 = String_Substring_m7A39A2AC0893AE940CF4CEC841326D56FFB9D86B(L_29, L_30, ((int32_t)il2cpp_codegen_subtract((int32_t)L_31, (int32_t)L_32)), /*hidden argument*/NULL);
		__this->set_U3CU3E2__current_1(L_33);
		__this->set_U3CU3E1__state_0(1);
		return (bool)1;
	}

IL_00fd:
	{
		__this->set_U3CU3E1__state_0((-1));
	}

IL_0104:
	{
		// while (position < length)
		int32_t L_34 = __this->get_U3CpositionU3E5__3_8();
		int32_t L_35 = __this->get_U3ClengthU3E5__2_7();
		if ((((int32_t)L_34) < ((int32_t)L_35)))
		{
			goto IL_0046;
		}
	}
	{
		// }
		return (bool)0;
	}
}
// System.String UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::System.Collections.Generic.IEnumerator<System.String>.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CSplitU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_StringU3E_get_Current_mF8D302A25131714F3BDD6DBB00CF74CFD3297A13 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_U3CU3E2__current_1();
		return L_0;
	}
}
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::System.Collections.IEnumerator.Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSplitU3Ed__9_System_Collections_IEnumerator_Reset_m39D8804A07E4F16DC701F7614415743F7AA2F943 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method)
{
	{
		NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339 * L_0 = (NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339 *)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339_il2cpp_TypeInfo_var)));
		NotSupportedException__ctor_m3EA81A5B209A87C3ADA47443F2AFFF735E5256EE(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CSplitU3Ed__9_System_Collections_IEnumerator_Reset_m39D8804A07E4F16DC701F7614415743F7AA2F943_RuntimeMethod_var)));
	}
}
// System.Object UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * U3CSplitU3Ed__9_System_Collections_IEnumerator_get_Current_m964629051692ED225148325B857158A178793370 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_U3CU3E2__current_1();
		return L_0;
	}
}
// System.Collections.Generic.IEnumerator`1<System.String> UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::System.Collections.Generic.IEnumerable<System.String>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CSplitU3Ed__9_System_Collections_Generic_IEnumerableU3CSystem_StringU3E_GetEnumerator_mF7CAF7BD420AB028A15C1A61469B2D579921D211 (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * V_0 = NULL;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)((int32_t)-2)))))
		{
			goto IL_0022;
		}
	}
	{
		int32_t L_1 = __this->get_U3CU3El__initialThreadId_2();
		int32_t L_2;
		L_2 = Environment_get_CurrentManagedThreadId_m09DBD4166BFD399056B2F81C77A3A182339BF92D(/*hidden argument*/NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)L_2))))
		{
			goto IL_0022;
		}
	}
	{
		__this->set_U3CU3E1__state_0(0);
		V_0 = __this;
		goto IL_0029;
	}

IL_0022:
	{
		U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * L_3 = (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E *)il2cpp_codegen_object_new(U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E_il2cpp_TypeInfo_var);
		U3CSplitU3Ed__9__ctor_m2FD3D68D26219E01C8827B4D14A6B8635AD790D3(L_3, 0, /*hidden argument*/NULL);
		V_0 = L_3;
	}

IL_0029:
	{
		U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * L_4 = V_0;
		String_t* L_5 = __this->get_U3CU3E3__str_4();
		NullCheck(L_4);
		L_4->set_str_3(L_5);
		U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * L_6 = V_0;
		Func_2_t12237805D7B3E966E36DB4327BA1F80B724C4B9A * L_7 = __this->get_U3CU3E3__predicate_6();
		NullCheck(L_6);
		L_6->set_predicate_5(L_7);
		U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * L_8 = V_0;
		return L_8;
	}
}
// System.Collections.IEnumerator UnityEngine.InputSystem.Utilities.StringHelpers/<Split>d__9::System.Collections.IEnumerable.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CSplitU3Ed__9_System_Collections_IEnumerable_GetEnumerator_m3D53AF210403295F582D5DD1C288CB7365F944BE (U3CSplitU3Ed__9_tB960B24DDD5E408B40913A232E74DAD1CFC8049E * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0;
		L_0 = U3CSplitU3Ed__9_System_Collections_Generic_IEnumerableU3CSystem_StringU3E_GetEnumerator_mF7CAF7BD420AB028A15C1A61469B2D579921D211(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CTokenizeU3Ed__8__ctor_mA756AE014A5743CE5F81893B1017012FFA90CC95 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___U3CU3E1__state0;
		__this->set_U3CU3E1__state_0(L_0);
		int32_t L_1;
		L_1 = Environment_get_CurrentManagedThreadId_m09DBD4166BFD399056B2F81C77A3A182339BF92D(/*hidden argument*/NULL);
		__this->set_U3CU3El__initialThreadId_2(L_1);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::System.IDisposable.Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CTokenizeU3Ed__8_System_IDisposable_Dispose_mB073E590682ABBFA13D22B4EF1CCAD9A8C6BDDF2 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method)
{
	{
		return;
	}
}
// System.Boolean UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CTokenizeU3Ed__8_MoveNext_m743D838A58D61971D33E7D151FAF51118A0D723E (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		int32_t L_1 = V_0;
		switch (L_1)
		{
			case 0:
			{
				goto IL_001b;
			}
			case 1:
			{
				goto IL_0111;
			}
			case 2:
			{
				goto IL_0185;
			}
		}
	}
	{
		return (bool)0;
	}

IL_001b:
	{
		__this->set_U3CU3E1__state_0((-1));
		// var pos = 0;
		V_1 = 0;
		// var length = str.Length;
		String_t* L_2 = __this->get_str_3();
		NullCheck(L_2);
		int32_t L_3;
		L_3 = String_get_Length_m129FC0ADA02FECBED3C0B1A809AE84A5AEE1CF09_inline(L_2, /*hidden argument*/NULL);
		__this->set_U3ClengthU3E5__2_5(L_3);
		goto IL_0193;
	}

IL_003a:
	{
		// ++pos;
		int32_t L_4 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)1));
	}

IL_003e:
	{
		// while (pos < length && char.IsWhiteSpace(str[pos]))
		int32_t L_5 = V_1;
		int32_t L_6 = __this->get_U3ClengthU3E5__2_5();
		if ((((int32_t)L_5) >= ((int32_t)L_6)))
		{
			goto IL_005a;
		}
	}
	{
		String_t* L_7 = __this->get_str_3();
		int32_t L_8 = V_1;
		NullCheck(L_7);
		Il2CppChar L_9;
		L_9 = String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70(L_7, L_8, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_il2cpp_TypeInfo_var);
		bool L_10;
		L_10 = Char_IsWhiteSpace_m99A5E1BE1EB9F17EA530A67A607DA8C260BCBF99(L_9, /*hidden argument*/NULL);
		if (L_10)
		{
			goto IL_003a;
		}
	}

IL_005a:
	{
		// if (pos == length)
		int32_t L_11 = V_1;
		int32_t L_12 = __this->get_U3ClengthU3E5__2_5();
		if ((((int32_t)L_11) == ((int32_t)L_12)))
		{
			goto IL_019f;
		}
	}
	{
		// if (str[pos] == '"')
		String_t* L_13 = __this->get_str_3();
		int32_t L_14 = V_1;
		NullCheck(L_13);
		Il2CppChar L_15;
		L_15 = String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70(L_13, L_14, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_15) == ((uint32_t)((int32_t)34)))))
		{
			goto IL_0123;
		}
	}
	{
		// ++pos;
		int32_t L_16 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_16, (int32_t)1));
		// var endPos = pos;
		int32_t L_17 = V_1;
		__this->set_U3CendPosU3E5__3_6(L_17);
		goto IL_00cb;
	}

IL_0086:
	{
		// if (str[endPos] == '\\' && endPos < length - 1)
		String_t* L_18 = __this->get_str_3();
		int32_t L_19 = __this->get_U3CendPosU3E5__3_6();
		NullCheck(L_18);
		Il2CppChar L_20;
		L_20 = String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70(L_18, L_19, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_20) == ((uint32_t)((int32_t)92)))))
		{
			goto IL_00bb;
		}
	}
	{
		int32_t L_21 = __this->get_U3CendPosU3E5__3_6();
		int32_t L_22 = __this->get_U3ClengthU3E5__2_5();
		if ((((int32_t)L_21) >= ((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_22, (int32_t)1)))))
		{
			goto IL_00bb;
		}
	}
	{
		// ++endPos;
		int32_t L_23 = __this->get_U3CendPosU3E5__3_6();
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_23, (int32_t)1));
		int32_t L_24 = V_2;
		__this->set_U3CendPosU3E5__3_6(L_24);
	}

IL_00bb:
	{
		// ++endPos;
		int32_t L_25 = __this->get_U3CendPosU3E5__3_6();
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_25, (int32_t)1));
		int32_t L_26 = V_2;
		__this->set_U3CendPosU3E5__3_6(L_26);
	}

IL_00cb:
	{
		// while (endPos < length && str[endPos] != '\"')
		int32_t L_27 = __this->get_U3CendPosU3E5__3_6();
		int32_t L_28 = __this->get_U3ClengthU3E5__2_5();
		if ((((int32_t)L_27) >= ((int32_t)L_28)))
		{
			goto IL_00ee;
		}
	}
	{
		String_t* L_29 = __this->get_str_3();
		int32_t L_30 = __this->get_U3CendPosU3E5__3_6();
		NullCheck(L_29);
		Il2CppChar L_31;
		L_31 = String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70(L_29, L_30, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_31) == ((uint32_t)((int32_t)34)))))
		{
			goto IL_0086;
		}
	}

IL_00ee:
	{
		// yield return new Substring(str, pos, endPos - pos);
		String_t* L_32 = __this->get_str_3();
		int32_t L_33 = V_1;
		int32_t L_34 = __this->get_U3CendPosU3E5__3_6();
		int32_t L_35 = V_1;
		Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  L_36;
		memset((&L_36), 0, sizeof(L_36));
		Substring__ctor_mCCE4224E81B04E9292A725BFDF9273449429653D((&L_36), L_32, L_33, ((int32_t)il2cpp_codegen_subtract((int32_t)L_34, (int32_t)L_35)), /*hidden argument*/NULL);
		__this->set_U3CU3E2__current_1(L_36);
		__this->set_U3CU3E1__state_0(1);
		return (bool)1;
	}

IL_0111:
	{
		__this->set_U3CU3E1__state_0((-1));
		// pos = endPos + 1;
		int32_t L_37 = __this->get_U3CendPosU3E5__3_6();
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_37, (int32_t)1));
		// }
		goto IL_0193;
	}

IL_0123:
	{
		// var endPos = pos;
		int32_t L_38 = V_1;
		__this->set_U3CendPosU3E5__3_6(L_38);
		goto IL_013c;
	}

IL_012c:
	{
		// ++endPos;
		int32_t L_39 = __this->get_U3CendPosU3E5__3_6();
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_39, (int32_t)1));
		int32_t L_40 = V_2;
		__this->set_U3CendPosU3E5__3_6(L_40);
	}

IL_013c:
	{
		// while (endPos < length && !char.IsWhiteSpace(str[endPos]))
		int32_t L_41 = __this->get_U3CendPosU3E5__3_6();
		int32_t L_42 = __this->get_U3ClengthU3E5__2_5();
		if ((((int32_t)L_41) >= ((int32_t)L_42)))
		{
			goto IL_0162;
		}
	}
	{
		String_t* L_43 = __this->get_str_3();
		int32_t L_44 = __this->get_U3CendPosU3E5__3_6();
		NullCheck(L_43);
		Il2CppChar L_45;
		L_45 = String_get_Chars_m9B1A5E4C8D70AA33A60F03735AF7B77AB9DBBA70(L_43, L_44, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_il2cpp_TypeInfo_var);
		bool L_46;
		L_46 = Char_IsWhiteSpace_m99A5E1BE1EB9F17EA530A67A607DA8C260BCBF99(L_45, /*hidden argument*/NULL);
		if (!L_46)
		{
			goto IL_012c;
		}
	}

IL_0162:
	{
		// yield return new Substring(str, pos, endPos - pos);
		String_t* L_47 = __this->get_str_3();
		int32_t L_48 = V_1;
		int32_t L_49 = __this->get_U3CendPosU3E5__3_6();
		int32_t L_50 = V_1;
		Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  L_51;
		memset((&L_51), 0, sizeof(L_51));
		Substring__ctor_mCCE4224E81B04E9292A725BFDF9273449429653D((&L_51), L_47, L_48, ((int32_t)il2cpp_codegen_subtract((int32_t)L_49, (int32_t)L_50)), /*hidden argument*/NULL);
		__this->set_U3CU3E2__current_1(L_51);
		__this->set_U3CU3E1__state_0(2);
		return (bool)1;
	}

IL_0185:
	{
		__this->set_U3CU3E1__state_0((-1));
		// pos = endPos;
		int32_t L_52 = __this->get_U3CendPosU3E5__3_6();
		V_1 = L_52;
	}

IL_0193:
	{
		// while (pos < length)
		int32_t L_53 = V_1;
		int32_t L_54 = __this->get_U3ClengthU3E5__2_5();
		if ((((int32_t)L_53) < ((int32_t)L_54)))
		{
			goto IL_003e;
		}
	}

IL_019f:
	{
		// }
		return (bool)0;
	}
}
// UnityEngine.InputSystem.Utilities.Substring UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::System.Collections.Generic.IEnumerator<UnityEngine.InputSystem.Utilities.Substring>.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  U3CTokenizeU3Ed__8_System_Collections_Generic_IEnumeratorU3CUnityEngine_InputSystem_Utilities_SubstringU3E_get_Current_m61BCF191AEACE02A67FDA6972CC0C04366878909 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method)
{
	{
		Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  L_0 = __this->get_U3CU3E2__current_1();
		return L_0;
	}
}
// System.Void UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::System.Collections.IEnumerator.Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CTokenizeU3Ed__8_System_Collections_IEnumerator_Reset_m08B687E0418382B35AB74491FD953B5C591AF183 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method)
{
	{
		NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339 * L_0 = (NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339 *)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339_il2cpp_TypeInfo_var)));
		NotSupportedException__ctor_m3EA81A5B209A87C3ADA47443F2AFFF735E5256EE(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CTokenizeU3Ed__8_System_Collections_IEnumerator_Reset_m08B687E0418382B35AB74491FD953B5C591AF183_RuntimeMethod_var)));
	}
}
// System.Object UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * U3CTokenizeU3Ed__8_System_Collections_IEnumerator_get_Current_mF0C85AE4E05CF039515796CA6C843D38B938A993 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  L_0 = __this->get_U3CU3E2__current_1();
		Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  L_1 = L_0;
		RuntimeObject * L_2 = Box(Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815_il2cpp_TypeInfo_var, &L_1);
		return L_2;
	}
}
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.Substring> UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::System.Collections.Generic.IEnumerable<UnityEngine.InputSystem.Utilities.Substring>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CTokenizeU3Ed__8_System_Collections_Generic_IEnumerableU3CUnityEngine_InputSystem_Utilities_SubstringU3E_GetEnumerator_mDEC8DD4FA6ED13993EECF3AF9E5E375E74792F70 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * V_0 = NULL;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)((int32_t)-2)))))
		{
			goto IL_0022;
		}
	}
	{
		int32_t L_1 = __this->get_U3CU3El__initialThreadId_2();
		int32_t L_2;
		L_2 = Environment_get_CurrentManagedThreadId_m09DBD4166BFD399056B2F81C77A3A182339BF92D(/*hidden argument*/NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)L_2))))
		{
			goto IL_0022;
		}
	}
	{
		__this->set_U3CU3E1__state_0(0);
		V_0 = __this;
		goto IL_0029;
	}

IL_0022:
	{
		U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * L_3 = (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 *)il2cpp_codegen_object_new(U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393_il2cpp_TypeInfo_var);
		U3CTokenizeU3Ed__8__ctor_mA756AE014A5743CE5F81893B1017012FFA90CC95(L_3, 0, /*hidden argument*/NULL);
		V_0 = L_3;
	}

IL_0029:
	{
		U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * L_4 = V_0;
		String_t* L_5 = __this->get_U3CU3E3__str_4();
		NullCheck(L_4);
		L_4->set_str_3(L_5);
		U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * L_6 = V_0;
		return L_6;
	}
}
// System.Collections.IEnumerator UnityEngine.InputSystem.Utilities.StringHelpers/<Tokenize>d__8::System.Collections.IEnumerable.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CTokenizeU3Ed__8_System_Collections_IEnumerable_GetEnumerator_mCE3A2E83473860F7C61972E5CEACD15CEA1BF710 (U3CTokenizeU3Ed__8_tB31121C1A9AE608190BC03E3BAD1DC92DC748393 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0;
		L_0 = U3CTokenizeU3Ed__8_System_Collections_Generic_IEnumerableU3CUnityEngine_InputSystem_Utilities_SubstringU3E_GetEnumerator_mDEC8DD4FA6ED13993EECF3AF9E5E375E74792F70(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m7BAE632EA2AF295E4D1E28306831C8B9DEB6C247 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * L_0 = (U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 *)il2cpp_codegen_object_new(U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mAD41A398A7F79556455A67F662EAEEC893E09F86(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mAD41A398A7F79556455A67F662EAEEC893E09F86 (U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::<SaveAndResetState>b__78_0(UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec_U3CSaveAndResetStateU3Eb__78_0_m269A91F456A60EFE88F604377C24F361D4891BA3 (U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * __this, GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A * ___state0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// (ref GlobalState state) => s_GlobalState = state,
		GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A * L_0 = ___state0;
		GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A  L_1 = (*(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A *)L_0);
		IL2CPP_RUNTIME_CLASS_INIT(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_il2cpp_TypeInfo_var);
		((Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_StaticFields*)il2cpp_codegen_static_fields_for(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_il2cpp_TypeInfo_var))->set_s_GlobalState_2(L_1);
		return;
	}
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/<>c::<SaveAndResetState>b__78_1()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec_U3CSaveAndResetStateU3Eb__78_1_m079B2339EF7A9DBC0C672E2309F74DEB38C2F0F1 (U3CU3Ec_t8C7CD7025391DD6967BEF967207AFA5641B08690 * __this, const RuntimeMethod* method)
{
	{
		// () => { /* currently nothing to dispose */ });
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_pinvoke(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke& marshaled)
{
	Exception_t* ___fingers_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'fingers' of type 'FingerAndTouchState': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___fingers_1Exception, NULL);
}
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_pinvoke_back(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke& marshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled)
{
	Exception_t* ___fingers_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'fingers' of type 'FingerAndTouchState': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___fingers_1Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_pinvoke_cleanup(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_com(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com& marshaled)
{
	Exception_t* ___fingers_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'fingers' of type 'FingerAndTouchState': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___fingers_1Exception, NULL);
}
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_com_back(const FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com& marshaled, FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49& unmarshaled)
{
	Exception_t* ___fingers_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'fingers' of type 'FingerAndTouchState': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___fingers_1Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState
IL2CPP_EXTERN_C void FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshal_com_cleanup(FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49_marshaled_com& marshaled)
{
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::AddFingers(UnityEngine.InputSystem.Touchscreen)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_AddFingers_mE2B2CA6DFC89A823AA27B91D202203F5CE6E5941 (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___screen0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_EnsureCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mA18B65BA5322F4F005396C4FCF34BFDD0D6C1C15_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * V_3 = NULL;
	{
		// var touchCount = screen.touches.Count;
		Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * L_0 = ___screen0;
		NullCheck(L_0);
		ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  L_1;
		L_1 = Touchscreen_get_touches_m67B46B544F3DF685C9571FF2B8DA890C9393D79C_inline(L_0, /*hidden argument*/NULL);
		V_1 = L_1;
		int32_t L_2;
		L_2 = ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_inline((ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3 *)(&V_1), /*hidden argument*/ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_RuntimeMethod_var);
		V_0 = L_2;
		// ArrayHelpers.EnsureCapacity(ref fingers, totalFingerCount, touchCount);
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** L_3 = __this->get_address_of_fingers_1();
		int32_t L_4 = __this->get_totalFingerCount_6();
		int32_t L_5 = V_0;
		ArrayHelpers_EnsureCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mA18B65BA5322F4F005396C4FCF34BFDD0D6C1C15((FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD**)L_3, L_4, L_5, ((int32_t)10), /*hidden argument*/ArrayHelpers_EnsureCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mA18B65BA5322F4F005396C4FCF34BFDD0D6C1C15_RuntimeMethod_var);
		// for (var i = 0; i < touchCount; ++i)
		V_2 = 0;
		goto IL_004e;
	}

IL_0027:
	{
		// var finger = new Finger(screen, i, updateMask);
		Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * L_6 = ___screen0;
		int32_t L_7 = V_2;
		int32_t L_8 = __this->get_updateMask_0();
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_9 = (Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 *)il2cpp_codegen_object_new(Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_il2cpp_TypeInfo_var);
		Finger__ctor_m8D31BEF6BF108A62AB23DEC1DEC1E5FB216577E8(L_9, L_6, L_7, L_8, /*hidden argument*/NULL);
		V_3 = L_9;
		// ArrayHelpers.AppendWithCapacity(ref fingers, ref totalFingerCount, finger);
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** L_10 = __this->get_address_of_fingers_1();
		int32_t* L_11 = __this->get_address_of_totalFingerCount_6();
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_12 = V_3;
		int32_t L_13;
		L_13 = ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68((FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD**)L_10, (int32_t*)L_11, L_12, ((int32_t)10), /*hidden argument*/ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68_RuntimeMethod_var);
		// for (var i = 0; i < touchCount; ++i)
		int32_t L_14 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_14, (int32_t)1));
	}

IL_004e:
	{
		// for (var i = 0; i < touchCount; ++i)
		int32_t L_15 = V_2;
		int32_t L_16 = V_0;
		if ((((int32_t)L_15) < ((int32_t)L_16)))
		{
			goto IL_0027;
		}
	}
	{
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void FingerAndTouchState_AddFingers_mE2B2CA6DFC89A823AA27B91D202203F5CE6E5941_AdjustorThunk (RuntimeObject * __this, Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___screen0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * _thisAdjusted = reinterpret_cast<FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 *>(__this + _offset);
	FingerAndTouchState_AddFingers_mE2B2CA6DFC89A823AA27B91D202203F5CE6E5941(_thisAdjusted, ___screen0, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::RemoveFingers(UnityEngine.InputSystem.Touchscreen)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_RemoveFingers_m0F6D384B1F336DD7A4692868A81BF37C7837EA2D (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___screen0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_EraseSliceWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_m725E5BB760C8DD2772361E372A579B925CDD99B5_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		// var touchCount = screen.touches.Count;
		Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * L_0 = ___screen0;
		NullCheck(L_0);
		ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  L_1;
		L_1 = Touchscreen_get_touches_m67B46B544F3DF685C9571FF2B8DA890C9393D79C_inline(L_0, /*hidden argument*/NULL);
		V_1 = L_1;
		int32_t L_2;
		L_2 = ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_inline((ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3 *)(&V_1), /*hidden argument*/ReadOnlyArray_1_get_Count_mF3560652B39AFB359F81C2CE5BDC8B57F7358AD1_RuntimeMethod_var);
		V_0 = L_2;
		// for (var i = 0; i < fingers.Length; ++i)
		V_2 = 0;
		goto IL_005c;
	}

IL_0013:
	{
		// if (fingers[i].screen != screen)
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* L_3 = __this->get_fingers_1();
		int32_t L_4 = V_2;
		NullCheck(L_3);
		int32_t L_5 = L_4;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_6 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		NullCheck(L_6);
		Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * L_7;
		L_7 = Finger_get_screen_mAF59662CC55478F9F668A5E77F1488A346A213B0_inline(L_6, /*hidden argument*/NULL);
		Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * L_8 = ___screen0;
		if ((!(((RuntimeObject*)(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 *)L_7) == ((RuntimeObject*)(Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 *)L_8))))
		{
			goto IL_0058;
		}
	}
	{
		// for (var n = 0; n < touchCount; ++n)
		V_3 = 0;
		goto IL_003f;
	}

IL_0027:
	{
		// fingers[i + n].m_StateHistory.Dispose();
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* L_9 = __this->get_fingers_1();
		int32_t L_10 = V_2;
		int32_t L_11 = V_3;
		NullCheck(L_9);
		int32_t L_12 = ((int32_t)il2cpp_codegen_add((int32_t)L_10, (int32_t)L_11));
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_13 = (L_9)->GetAt(static_cast<il2cpp_array_size_t>(L_12));
		NullCheck(L_13);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_14 = L_13->get_m_StateHistory_2();
		NullCheck(L_14);
		InputStateHistory_Dispose_m2F9781CB0804BDBDF49D37C77B6D1CB21DB78568(L_14, /*hidden argument*/NULL);
		// for (var n = 0; n < touchCount; ++n)
		int32_t L_15 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_15, (int32_t)1));
	}

IL_003f:
	{
		// for (var n = 0; n < touchCount; ++n)
		int32_t L_16 = V_3;
		int32_t L_17 = V_0;
		if ((((int32_t)L_16) < ((int32_t)L_17)))
		{
			goto IL_0027;
		}
	}
	{
		// ArrayHelpers.EraseSliceWithCapacity(ref fingers, ref totalFingerCount, i, touchCount);
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** L_18 = __this->get_address_of_fingers_1();
		int32_t* L_19 = __this->get_address_of_totalFingerCount_6();
		int32_t L_20 = V_2;
		int32_t L_21 = V_0;
		ArrayHelpers_EraseSliceWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_m725E5BB760C8DD2772361E372A579B925CDD99B5((FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD**)L_18, (int32_t*)L_19, L_20, L_21, /*hidden argument*/ArrayHelpers_EraseSliceWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_m725E5BB760C8DD2772361E372A579B925CDD99B5_RuntimeMethod_var);
		// break;
		goto IL_0067;
	}

IL_0058:
	{
		// for (var i = 0; i < fingers.Length; ++i)
		int32_t L_22 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_22, (int32_t)1));
	}

IL_005c:
	{
		// for (var i = 0; i < fingers.Length; ++i)
		int32_t L_23 = V_2;
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* L_24 = __this->get_fingers_1();
		NullCheck(L_24);
		if ((((int32_t)L_23) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_24)->max_length))))))
		{
			goto IL_0013;
		}
	}

IL_0067:
	{
		// haveBuiltActiveTouches = false;
		__this->set_haveBuiltActiveTouches_8((bool)0);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void FingerAndTouchState_RemoveFingers_m0F6D384B1F336DD7A4692868A81BF37C7837EA2D_AdjustorThunk (RuntimeObject * __this, Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * ___screen0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * _thisAdjusted = reinterpret_cast<FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 *>(__this + _offset);
	FingerAndTouchState_RemoveFingers_m0F6D384B1F336DD7A4692868A81BF37C7837EA2D(_thisAdjusted, ___screen0, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::Destroy()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_Destroy_m3A6FED4F4A62EC291506F042D76A42EA8F292720 (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * G_B5_0 = NULL;
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * G_B4_0 = NULL;
	{
		// for (var i = 0; i < totalFingerCount; ++i)
		V_0 = 0;
		goto IL_001a;
	}

IL_0004:
	{
		// fingers[i].m_StateHistory.Dispose();
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* L_0 = __this->get_fingers_1();
		int32_t L_1 = V_0;
		NullCheck(L_0);
		int32_t L_2 = L_1;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_3 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_2));
		NullCheck(L_3);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_4 = L_3->get_m_StateHistory_2();
		NullCheck(L_4);
		InputStateHistory_Dispose_m2F9781CB0804BDBDF49D37C77B6D1CB21DB78568(L_4, /*hidden argument*/NULL);
		// for (var i = 0; i < totalFingerCount; ++i)
		int32_t L_5 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_5, (int32_t)1));
	}

IL_001a:
	{
		// for (var i = 0; i < totalFingerCount; ++i)
		int32_t L_6 = V_0;
		int32_t L_7 = __this->get_totalFingerCount_6();
		if ((((int32_t)L_6) < ((int32_t)L_7)))
		{
			goto IL_0004;
		}
	}
	{
		// activeTouchState?.Dispose();
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_8 = __this->get_activeTouchState_10();
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_9 = L_8;
		G_B4_0 = L_9;
		if (L_9)
		{
			G_B5_0 = L_9;
			goto IL_002f;
		}
	}
	{
		goto IL_0034;
	}

IL_002f:
	{
		NullCheck(G_B5_0);
		InputStateHistory_Dispose_m2F9781CB0804BDBDF49D37C77B6D1CB21DB78568(G_B5_0, /*hidden argument*/NULL);
	}

IL_0034:
	{
		// activeTouchState = null;
		__this->set_activeTouchState_10((InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 *)NULL);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void FingerAndTouchState_Destroy_m3A6FED4F4A62EC291506F042D76A42EA8F292720_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * _thisAdjusted = reinterpret_cast<FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 *>(__this + _offset);
	FingerAndTouchState_Destroy_m3A6FED4F4A62EC291506F042D76A42EA8F292720(_thisAdjusted, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::UpdateActiveFingers()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_UpdateActiveFingers_m8D96E489660671F2C246BBBDD2380F68FE480F75 (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * V_1 = NULL;
	Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  V_2;
	memset((&V_2), 0, sizeof(V_2));
	{
		// activeFingerCount = 0;
		__this->set_activeFingerCount_4(0);
		// for (var i = 0; i < totalFingerCount; ++i)
		V_0 = 0;
		goto IL_003d;
	}

IL_000b:
	{
		// var finger = fingers[i];
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* L_0 = __this->get_fingers_1();
		int32_t L_1 = V_0;
		NullCheck(L_0);
		int32_t L_2 = L_1;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_3 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_2));
		V_1 = L_3;
		// var lastTouch = finger.currentTouch;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_4 = V_1;
		NullCheck(L_4);
		Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  L_5;
		L_5 = Finger_get_currentTouch_m6E82BF6E2EFE0966A8F03EB9EB896FD9BA45CC6D(L_4, /*hidden argument*/NULL);
		V_2 = L_5;
		// if (lastTouch.valid)
		bool L_6;
		L_6 = Touch_get_valid_mA0B2CFA5D11C3767331EB2E23E415E91FBC21533((Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA *)(&V_2), /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0039;
		}
	}
	{
		// ArrayHelpers.AppendWithCapacity(ref activeFingers, ref activeFingerCount, finger);
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD** L_7 = __this->get_address_of_activeFingers_2();
		int32_t* L_8 = __this->get_address_of_activeFingerCount_4();
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_9 = V_1;
		int32_t L_10;
		L_10 = ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68((FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD**)L_7, (int32_t*)L_8, L_9, ((int32_t)10), /*hidden argument*/ArrayHelpers_AppendWithCapacity_TisFinger_t8C3F95C202B41127D4B0C5953AE1814681413DE2_mDB1E365D704AD764CD8CBA9F7F9A63293958AC68_RuntimeMethod_var);
	}

IL_0039:
	{
		// for (var i = 0; i < totalFingerCount; ++i)
		int32_t L_11 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_11, (int32_t)1));
	}

IL_003d:
	{
		// for (var i = 0; i < totalFingerCount; ++i)
		int32_t L_12 = V_0;
		int32_t L_13 = __this->get_totalFingerCount_6();
		if ((((int32_t)L_12) < ((int32_t)L_13)))
		{
			goto IL_000b;
		}
	}
	{
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void FingerAndTouchState_UpdateActiveFingers_m8D96E489660671F2C246BBBDD2380F68FE480F75_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * _thisAdjusted = reinterpret_cast<FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 *>(__this + _offset);
	FingerAndTouchState_UpdateActiveFingers_m8D96E489660671F2C246BBBDD2380F68FE480F75(_thisAdjusted, method);
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.Touch/FingerAndTouchState::UpdateActiveTouches()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FingerAndTouchState_UpdateActiveTouches_m51EAB31B9AE121144697D08A0DBB129A9DF71EAA (FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_AppendWithCapacity_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m409299335D98E3EE47D99B3651327AFE91780D55_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_Clear_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m02E4370667B74A8D105681DEA12E2DBE27F36792_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayHelpers_InsertAtWithCapacity_TisTouch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_m86CEA702743AA33B3B395BCEF7202CBA1CBB742C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&InputStateHistory_1__ctor_m4CC173D63A840D058F7D825BB7D7C3A4FDBC1C12_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlyArray_1_get_Item_m6E99B3BAB50380469478C5CFCD2410E4F64B92F9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Record__ctor_mA6E01856DFCAF450BB1AAA06672DBFC8B5061DCC_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UnsafeUtility_SizeOf_TisTouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8_m88C8A28D5EC1B03454E3980C49B61DEEAF2B665B_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** V_3 = NULL;
	InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * V_4 = NULL;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * V_8 = NULL;
	int32_t V_9 = 0;
	RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * V_10 = NULL;
	int32_t V_11 = 0;
	int32_t V_12 = 0;
	int32_t V_13 = 0;
	TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * V_14 = NULL;
	bool V_15 = false;
	ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 * V_16 = NULL;
	RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * V_17 = NULL;
	int32_t V_18 = 0;
	TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * V_19 = NULL;
	ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 * V_20 = NULL;
	int32_t V_21 = 0;
	Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  V_22;
	memset((&V_22), 0, sizeof(V_22));
	Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  V_23;
	memset((&V_23), 0, sizeof(V_23));
	ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832  V_24;
	memset((&V_24), 0, sizeof(V_24));
	{
		// if (haveBuiltActiveTouches)
		bool L_0 = __this->get_haveBuiltActiveTouches_8();
		if (!L_0)
		{
			goto IL_0009;
		}
	}
	{
		// return;
		return;
	}

IL_0009:
	{
		// if (activeTouchState == null)
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_1 = __this->get_activeTouchState_10();
		if (L_1)
		{
			goto IL_0032;
		}
	}
	{
		// activeTouchState = new InputStateHistory<TouchState>
		// {
		//     extraMemoryPerRecord = UnsafeUtility.SizeOf<ExtraDataPerTouchState>()
		// };
		il2cpp_codegen_initobj((&V_1), sizeof(Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103 ));
		Nullable_1_t864FD0051A05D37F91C857AB496BFCB3FE756103  L_2 = V_1;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_3 = (InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 *)il2cpp_codegen_object_new(InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2_il2cpp_TypeInfo_var);
		InputStateHistory_1__ctor_m4CC173D63A840D058F7D825BB7D7C3A4FDBC1C12(L_3, L_2, /*hidden argument*/InputStateHistory_1__ctor_m4CC173D63A840D058F7D825BB7D7C3A4FDBC1C12_RuntimeMethod_var);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_4 = L_3;
		int32_t L_5;
		L_5 = UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01(/*hidden argument*/UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01_RuntimeMethod_var);
		NullCheck(L_4);
		InputStateHistory_set_extraMemoryPerRecord_m2B24AC5C2A7A7438DFA6830958A51198F7A847CC(L_4, L_5, /*hidden argument*/NULL);
		__this->set_activeTouchState_10(L_4);
		// }
		goto IL_0059;
	}

IL_0032:
	{
		// activeTouchState.Clear();
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_6 = __this->get_activeTouchState_10();
		NullCheck(L_6);
		InputStateHistory_Clear_m08FD26FC532376C829F44C058D341C2927C33EF5(L_6, /*hidden argument*/NULL);
		// activeTouchState.m_ControlCount = 0;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_7 = __this->get_activeTouchState_10();
		NullCheck(L_7);
		((InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E *)L_7)->set_m_ControlCount_4(0);
		// activeTouchState.m_Controls.Clear();
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_8 = __this->get_activeTouchState_10();
		NullCheck(L_8);
		InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F* L_9 = ((InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E *)L_8)->get_m_Controls_3();
		ArrayHelpers_Clear_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m02E4370667B74A8D105681DEA12E2DBE27F36792(L_9, /*hidden argument*/ArrayHelpers_Clear_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m02E4370667B74A8D105681DEA12E2DBE27F36792_RuntimeMethod_var);
	}

IL_0059:
	{
		// activeTouchCount = 0;
		__this->set_activeTouchCount_5(0);
		// haveActiveTouchesNeedingRefreshNextUpdate = false;
		__this->set_haveActiveTouchesNeedingRefreshNextUpdate_9((bool)0);
		// var currentUpdateStepCount = InputUpdate.s_UpdateStepCount;
		uint32_t L_10 = ((InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_StaticFields*)il2cpp_codegen_static_fields_for(InputUpdate_t236541F23C2DD63ECDBF9A0403B073AEDE21CA77_il2cpp_TypeInfo_var))->get_s_UpdateStepCount_0();
		V_0 = L_10;
		// for (var i = 0; i < totalFingerCount; ++i)
		V_2 = 0;
		goto IL_031c;
	}

IL_0074:
	{
		// ref var finger = ref fingers[i];
		FingerU5BU5D_tA69A346ECB512F4D4A5D9AFA1B4FF15B1383BBAD* L_11 = __this->get_fingers_1();
		int32_t L_12 = V_2;
		NullCheck(L_11);
		V_3 = (Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 **)((L_11)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_12)));
		// var history = finger.m_StateHistory;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** L_13 = V_3;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_14 = *((Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 **)L_13);
		NullCheck(L_14);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_15 = L_14->get_m_StateHistory_2();
		V_4 = L_15;
		// var touchRecordCount = history.Count;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_16 = V_4;
		NullCheck(L_16);
		int32_t L_17;
		L_17 = InputStateHistory_get_Count_m41CC7BFF6BC7537C9F9E04D89DCBB212A445A402_inline(L_16, /*hidden argument*/NULL);
		V_5 = L_17;
		// if (touchRecordCount == 0)
		int32_t L_18 = V_5;
		if (!L_18)
		{
			goto IL_0318;
		}
	}
	{
		// var insertAt = activeTouchCount;
		int32_t L_19 = __this->get_activeTouchCount_5();
		V_6 = L_19;
		// var currentTouchId = 0;
		V_7 = 0;
		// var currentTouchState = default(TouchState*);
		il2cpp_codegen_initobj((&V_8), sizeof(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *));
		// var touchRecordIndex = history.UserIndexToRecordIndex(touchRecordCount - 1); // Start with last record.
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_20 = V_4;
		int32_t L_21 = V_5;
		NullCheck(L_20);
		int32_t L_22;
		L_22 = InputStateHistory_UserIndexToRecordIndex_mF4A6F8F02CD754777173D27FA5195061BC311E6F(L_20, ((int32_t)il2cpp_codegen_subtract((int32_t)L_21, (int32_t)1)), /*hidden argument*/NULL);
		V_9 = L_22;
		// var touchRecordHeader = history.GetRecordUnchecked(touchRecordIndex);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_23 = V_4;
		int32_t L_24 = V_9;
		NullCheck(L_23);
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_25;
		L_25 = InputStateHistory_GetRecordUnchecked_mF6FB8C28D85F96D0E7DEB2715B36409AA5A111BD(L_23, L_24, /*hidden argument*/NULL);
		V_10 = (RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)L_25;
		// var touchRecordSize = history.bytesPerRecord;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_26 = V_4;
		NullCheck(L_26);
		int32_t L_27;
		L_27 = InputStateHistory_get_bytesPerRecord_m92629E1E4E6BD1AC13E8DB7C7062FEAB244E950D(L_26, /*hidden argument*/NULL);
		V_11 = L_27;
		// var extraMemoryOffset = touchRecordSize - history.extraMemoryPerRecord;
		int32_t L_28 = V_11;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_29 = V_4;
		NullCheck(L_29);
		int32_t L_30;
		L_30 = InputStateHistory_get_extraMemoryPerRecord_mD6523D549A81F0C20141E60B706AEE6D12FC4CD0_inline(L_29, /*hidden argument*/NULL);
		V_12 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_28, (int32_t)L_30));
		// for (var n = 0; n < touchRecordCount; ++n)
		V_13 = 0;
		goto IL_030f;
	}

IL_00e2:
	{
		// if (n != 0)
		int32_t L_31 = V_13;
		if (!L_31)
		{
			goto IL_0110;
		}
	}
	{
		// --touchRecordIndex;
		int32_t L_32 = V_9;
		V_9 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_32, (int32_t)1));
		// if (touchRecordIndex < 0)
		int32_t L_33 = V_9;
		if ((((int32_t)L_33) >= ((int32_t)0)))
		{
			goto IL_0109;
		}
	}
	{
		// touchRecordIndex = history.historyDepth - 1;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_34 = V_4;
		NullCheck(L_34);
		int32_t L_35;
		L_35 = InputStateHistory_get_historyDepth_m232556B5AE37A9388BB37FE3BDA80B6DFF4F94F8_inline(L_34, /*hidden argument*/NULL);
		V_9 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_35, (int32_t)1));
		// touchRecordHeader = history.GetRecordUnchecked(touchRecordIndex);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_36 = V_4;
		int32_t L_37 = V_9;
		NullCheck(L_36);
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_38;
		L_38 = InputStateHistory_GetRecordUnchecked_mF6FB8C28D85F96D0E7DEB2715B36409AA5A111BD(L_36, L_37, /*hidden argument*/NULL);
		V_10 = (RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)L_38;
		// }
		goto IL_0110;
	}

IL_0109:
	{
		// touchRecordHeader = (InputStateHistory.RecordHeader*)((byte*)touchRecordHeader - touchRecordSize);
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_39 = V_10;
		int32_t L_40 = V_11;
		V_10 = (RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)((RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)il2cpp_codegen_subtract((intptr_t)L_39, (int32_t)L_40));
	}

IL_0110:
	{
		// var touchState = (TouchState*)touchRecordHeader->statePtrWithoutControlIndex; // History is tied to a single TouchControl.
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_41 = V_10;
		uint8_t* L_42;
		L_42 = RecordHeader_get_statePtrWithoutControlIndex_m96348C3EF2B9C5C8EF6F06AA931920C37CCE2D1F((RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)L_41, /*hidden argument*/NULL);
		V_14 = (TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_42;
		// var wasUpdatedThisFrame = touchState->updateStepCount == currentUpdateStepCount;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_43 = V_14;
		NullCheck(L_43);
		uint32_t L_44 = L_43->get_updateStepCount_10();
		uint32_t L_45 = V_0;
		V_15 = (bool)((((int32_t)L_44) == ((int32_t)L_45))? 1 : 0);
		// if (touchState->touchId == currentTouchId && !touchState->phase.IsEndedOrCanceled())
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_46 = V_14;
		NullCheck(L_46);
		int32_t L_47 = L_46->get_touchId_1();
		int32_t L_48 = V_7;
		if ((!(((uint32_t)L_47) == ((uint32_t)L_48))))
		{
			goto IL_0181;
		}
	}
	{
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_49 = V_14;
		int32_t L_50;
		L_50 = TouchState_get_phase_mEBFCF4562A1F6A77357D9EEBD2579983B23F713B_inline((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_49, /*hidden argument*/NULL);
		bool L_51;
		L_51 = InputExtensions_IsEndedOrCanceled_mF31E460E4E2EF752099445D3686B54D73B750B25(L_50, /*hidden argument*/NULL);
		if (L_51)
		{
			goto IL_0181;
		}
	}
	{
		// if (wasUpdatedThisFrame && touchState->phase == TouchPhase.Began)
		bool L_52 = V_15;
		if (!L_52)
		{
			goto IL_0309;
		}
	}
	{
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_53 = V_14;
		int32_t L_54;
		L_54 = TouchState_get_phase_mEBFCF4562A1F6A77357D9EEBD2579983B23F713B_inline((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_53, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_54) == ((uint32_t)1))))
		{
			goto IL_0309;
		}
	}
	{
		// currentTouchState->phase = TouchPhase.Began;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_55 = V_8;
		TouchState_set_phase_m46F65463E73DE88F54E7E03E1EB6E0336EE96893((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_55, 1, /*hidden argument*/NULL);
		// currentTouchState->position = touchState->position;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_56 = V_8;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_57 = V_14;
		NullCheck(L_57);
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_58 = L_57->get_position_2();
		NullCheck(L_56);
		L_56->set_position_2(L_58);
		// currentTouchState->delta = default;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_59 = V_8;
		NullCheck(L_59);
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * L_60 = L_59->get_address_of_delta_3();
		il2cpp_codegen_initobj(L_60, sizeof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 ));
		// haveActiveTouchesNeedingRefreshNextUpdate = true;
		__this->set_haveActiveTouchesNeedingRefreshNextUpdate_9((bool)1);
		// continue;
		goto IL_0309;
	}

IL_0181:
	{
		// if (touchState->phase.IsEndedOrCanceled())
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_61 = V_14;
		int32_t L_62;
		L_62 = TouchState_get_phase_mEBFCF4562A1F6A77357D9EEBD2579983B23F713B_inline((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_61, /*hidden argument*/NULL);
		bool L_63;
		L_63 = InputExtensions_IsEndedOrCanceled_mF31E460E4E2EF752099445D3686B54D73B750B25(L_62, /*hidden argument*/NULL);
		if (!L_63)
		{
			goto IL_01ab;
		}
	}
	{
		// if (!(touchState->beganInSameFrame && touchState->updateStepCount == currentUpdateStepCount - 1) &&
		//     !wasUpdatedThisFrame)
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_64 = V_14;
		bool L_65;
		L_65 = TouchState_get_beganInSameFrame_mAFE861824B710FAC981781B5CDDB0544FB523843((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_64, /*hidden argument*/NULL);
		if (!L_65)
		{
			goto IL_01a4;
		}
	}
	{
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_66 = V_14;
		NullCheck(L_66);
		uint32_t L_67 = L_66->get_updateStepCount_10();
		uint32_t L_68 = V_0;
		if ((((int32_t)L_67) == ((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_68, (int32_t)1)))))
		{
			goto IL_01ab;
		}
	}

IL_01a4:
	{
		bool L_69 = V_15;
		if (!L_69)
		{
			goto IL_0318;
		}
	}

IL_01ab:
	{
		// var touchExtraState = (ExtraDataPerTouchState*)((byte*)touchRecordHeader + extraMemoryOffset);
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_70 = V_10;
		int32_t L_71 = V_12;
		V_16 = (ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 *)((RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)il2cpp_codegen_add((intptr_t)L_70, (int32_t)L_71));
		// var newRecordHeader = activeTouchState.AllocateRecord(out var newRecordIndex);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_72 = __this->get_activeTouchState_10();
		NullCheck(L_72);
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_73;
		L_73 = InputStateHistory_AllocateRecord_mD582951B54EE3E4EEDFA22B168074011B7E4F5DF(L_72, (int32_t*)(&V_18), /*hidden argument*/NULL);
		V_17 = (RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)L_73;
		// var newRecordState = (TouchState*)newRecordHeader->statePtrWithControlIndex;
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_74 = V_17;
		uint8_t* L_75;
		L_75 = RecordHeader_get_statePtrWithControlIndex_mD985585F516C465246D19A574A028D6C8E6589CD((RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)L_74, /*hidden argument*/NULL);
		V_19 = (TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_75;
		// var newRecordExtraState = (ExtraDataPerTouchState*)((byte*)newRecordHeader + activeTouchState.bytesPerRecord - UnsafeUtility.SizeOf<ExtraDataPerTouchState>());
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_76 = V_17;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_77 = __this->get_activeTouchState_10();
		NullCheck(L_77);
		int32_t L_78;
		L_78 = InputStateHistory_get_bytesPerRecord_m92629E1E4E6BD1AC13E8DB7C7062FEAB244E950D(L_77, /*hidden argument*/NULL);
		int32_t L_79;
		L_79 = UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01(/*hidden argument*/UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01_RuntimeMethod_var);
		V_20 = (ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 *)((RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)il2cpp_codegen_subtract((intptr_t)((RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)il2cpp_codegen_add((intptr_t)L_76, (int32_t)L_78)), (int32_t)L_79));
		// newRecordHeader->time = touchRecordHeader->time;
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_80 = V_17;
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_81 = V_10;
		NullCheck(L_81);
		double L_82 = L_81->get_time_0();
		NullCheck(L_80);
		L_80->set_time_0(L_82);
		// newRecordHeader->controlIndex = ArrayHelpers.AppendWithCapacity(ref activeTouchState.m_Controls,
		//     ref activeTouchState.m_ControlCount, finger.m_StateHistory.controls[0]);
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_83 = V_17;
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_84 = __this->get_activeTouchState_10();
		NullCheck(L_84);
		InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F** L_85 = ((InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E *)L_84)->get_address_of_m_Controls_3();
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_86 = __this->get_activeTouchState_10();
		NullCheck(L_86);
		int32_t* L_87 = ((InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E *)L_86)->get_address_of_m_ControlCount_4();
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** L_88 = V_3;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_89 = *((Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 **)L_88);
		NullCheck(L_89);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_90 = L_89->get_m_StateHistory_2();
		NullCheck(L_90);
		ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832  L_91;
		L_91 = InputStateHistory_get_controls_m652D30E8D00AA372BCF00EF63031FE9246D224CD(L_90, /*hidden argument*/NULL);
		V_24 = L_91;
		InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * L_92;
		L_92 = ReadOnlyArray_1_get_Item_m6E99B3BAB50380469478C5CFCD2410E4F64B92F9((ReadOnlyArray_1_tAF9B0648418AA0E5E23239BB78647C13D881F832 *)(&V_24), 0, /*hidden argument*/ReadOnlyArray_1_get_Item_m6E99B3BAB50380469478C5CFCD2410E4F64B92F9_RuntimeMethod_var);
		int32_t L_93;
		L_93 = ArrayHelpers_AppendWithCapacity_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m409299335D98E3EE47D99B3651327AFE91780D55((InputControlU5BU5D_t70A3E35F91F44D7B9476D69090DA050EE0B7418F**)L_85, (int32_t*)L_87, L_92, ((int32_t)10), /*hidden argument*/ArrayHelpers_AppendWithCapacity_TisInputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713_m409299335D98E3EE47D99B3651327AFE91780D55_RuntimeMethod_var);
		NullCheck(L_83);
		L_83->set_controlIndex_2(L_93);
		// UnsafeUtility.MemCpy(newRecordState, touchState, UnsafeUtility.SizeOf<TouchState>());
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_94 = V_19;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_95 = V_14;
		int32_t L_96;
		L_96 = UnsafeUtility_SizeOf_TisTouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8_m88C8A28D5EC1B03454E3980C49B61DEEAF2B665B(/*hidden argument*/UnsafeUtility_SizeOf_TisTouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8_m88C8A28D5EC1B03454E3980C49B61DEEAF2B665B_RuntimeMethod_var);
		UnsafeUtility_MemCpy_m8E335BAB1C2A8483AF8531CE8464C6A69BB98C1B((void*)(void*)L_94, (void*)(void*)L_95, ((int64_t)((int64_t)L_96)), /*hidden argument*/NULL);
		// UnsafeUtility.MemCpy(newRecordExtraState, touchExtraState, UnsafeUtility.SizeOf<ExtraDataPerTouchState>());
		ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 * L_97 = V_20;
		ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 * L_98 = V_16;
		int32_t L_99;
		L_99 = UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01(/*hidden argument*/UnsafeUtility_SizeOf_TisExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6_m6713DA0E96DB8315A0618F7960640FB25E7BDB01_RuntimeMethod_var);
		UnsafeUtility_MemCpy_m8E335BAB1C2A8483AF8531CE8464C6A69BB98C1B((void*)(void*)L_97, (void*)(void*)L_98, ((int64_t)((int64_t)L_99)), /*hidden argument*/NULL);
		// var phase = touchState->phase;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_100 = V_14;
		int32_t L_101;
		L_101 = TouchState_get_phase_mEBFCF4562A1F6A77357D9EEBD2579983B23F713B_inline((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_100, /*hidden argument*/NULL);
		V_21 = L_101;
		// if ((phase == TouchPhase.Moved || phase == TouchPhase.Began) &&
		//     !wasUpdatedThisFrame && !(phase == TouchPhase.Moved && touchState->beganInSameFrame && touchState->updateStepCount == currentUpdateStepCount - 1))
		int32_t L_102 = V_21;
		if ((((int32_t)L_102) == ((int32_t)2)))
		{
			goto IL_0259;
		}
	}
	{
		int32_t L_103 = V_21;
		if ((!(((uint32_t)L_103) == ((uint32_t)1))))
		{
			goto IL_028e;
		}
	}

IL_0259:
	{
		bool L_104 = V_15;
		if (L_104)
		{
			goto IL_028e;
		}
	}
	{
		int32_t L_105 = V_21;
		if ((!(((uint32_t)L_105) == ((uint32_t)2))))
		{
			goto IL_0277;
		}
	}
	{
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_106 = V_14;
		bool L_107;
		L_107 = TouchState_get_beganInSameFrame_mAFE861824B710FAC981781B5CDDB0544FB523843((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_106, /*hidden argument*/NULL);
		if (!L_107)
		{
			goto IL_0277;
		}
	}
	{
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_108 = V_14;
		NullCheck(L_108);
		uint32_t L_109 = L_108->get_updateStepCount_10();
		uint32_t L_110 = V_0;
		if ((((int32_t)L_109) == ((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_110, (int32_t)1)))))
		{
			goto IL_028e;
		}
	}

IL_0277:
	{
		// newRecordState->phase = TouchPhase.Stationary;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_111 = V_19;
		TouchState_set_phase_m46F65463E73DE88F54E7E03E1EB6E0336EE96893((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_111, 5, /*hidden argument*/NULL);
		// newRecordState->delta = default;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_112 = V_19;
		NullCheck(L_112);
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * L_113 = L_112->get_address_of_delta_3();
		il2cpp_codegen_initobj(L_113, sizeof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 ));
		// }
		goto IL_02b8;
	}

IL_028e:
	{
		// else if (!wasUpdatedThisFrame && !touchState->beganInSameFrame)
		bool L_114 = V_15;
		if (L_114)
		{
			goto IL_02aa;
		}
	}
	{
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_115 = V_14;
		bool L_116;
		L_116 = TouchState_get_beganInSameFrame_mAFE861824B710FAC981781B5CDDB0544FB523843((TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)(TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_115, /*hidden argument*/NULL);
		if (L_116)
		{
			goto IL_02aa;
		}
	}
	{
		// newRecordState->delta = default;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_117 = V_19;
		NullCheck(L_117);
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * L_118 = L_117->get_address_of_delta_3();
		il2cpp_codegen_initobj(L_118, sizeof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 ));
		// }
		goto IL_02b8;
	}

IL_02aa:
	{
		// newRecordState->delta = newRecordExtraState->accumulatedDelta;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_119 = V_19;
		ExtraDataPerTouchState_tD50C1FEC1E9FBD28A9C67A8559BFD3F40DAA8EC6 * L_120 = V_20;
		NullCheck(L_120);
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_121 = L_120->get_accumulatedDelta_0();
		NullCheck(L_119);
		L_119->set_delta_3(L_121);
	}

IL_02b8:
	{
		// var newRecord = new InputStateHistory<TouchState>.Record(activeTouchState, newRecordIndex, newRecordHeader);
		InputStateHistory_1_t2D7FE8B7F5F77BD08802BB74C100F494170CDCB2 * L_122 = __this->get_activeTouchState_10();
		int32_t L_123 = V_18;
		RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 * L_124 = V_17;
		Record__ctor_mA6E01856DFCAF450BB1AAA06672DBFC8B5061DCC((Record_t6A3403317B951528E7A550FABE9EC42900ABFC48 *)(&V_22), L_122, L_123, (RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)(RecordHeader_t8E12835411602B94F3AD136329C9B066F45E7768 *)L_124, /*hidden argument*/Record__ctor_mA6E01856DFCAF450BB1AAA06672DBFC8B5061DCC_RuntimeMethod_var);
		// var newTouch = new Touch(finger, newRecord);
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 ** L_125 = V_3;
		Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * L_126 = *((Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 **)L_125);
		Record_t6A3403317B951528E7A550FABE9EC42900ABFC48  L_127 = V_22;
		Touch__ctor_mE500D74A20C4959256D6BCF1DDBD92015B2CC4F5((Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA *)(&V_23), L_126, L_127, /*hidden argument*/NULL);
		// ArrayHelpers.InsertAtWithCapacity(ref activeTouches, ref activeTouchCount, insertAt, newTouch);
		TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D** L_128 = __this->get_address_of_activeTouches_3();
		int32_t* L_129 = __this->get_address_of_activeTouchCount_5();
		int32_t L_130 = V_6;
		Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  L_131 = V_23;
		ArrayHelpers_InsertAtWithCapacity_TisTouch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_m86CEA702743AA33B3B395BCEF7202CBA1CBB742C((TouchU5BU5D_tB5E4EADAEACE597F5E184ACC771E7E84830F275D**)L_128, (int32_t*)L_129, L_130, L_131, ((int32_t)10), /*hidden argument*/ArrayHelpers_InsertAtWithCapacity_TisTouch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_m86CEA702743AA33B3B395BCEF7202CBA1CBB742C_RuntimeMethod_var);
		// currentTouchId = touchState->touchId;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_132 = V_14;
		NullCheck(L_132);
		int32_t L_133 = L_132->get_touchId_1();
		V_7 = L_133;
		// currentTouchState = newRecordState;
		TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * L_134 = V_19;
		V_8 = (TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 *)L_134;
		// if (newTouch.phase != TouchPhase.Stationary)
		int32_t L_135;
		L_135 = Touch_get_phase_m8246DA777AEA750A87E96E96F38DEFF08C43817F((Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA *)(&V_23), /*hidden argument*/NULL);
		if ((((int32_t)L_135) == ((int32_t)5)))
		{
			goto IL_0309;
		}
	}
	{
		// haveActiveTouchesNeedingRefreshNextUpdate = true;
		__this->set_haveActiveTouchesNeedingRefreshNextUpdate_9((bool)1);
	}

IL_0309:
	{
		// for (var n = 0; n < touchRecordCount; ++n)
		int32_t L_136 = V_13;
		V_13 = ((int32_t)il2cpp_codegen_add((int32_t)L_136, (int32_t)1));
	}

IL_030f:
	{
		// for (var n = 0; n < touchRecordCount; ++n)
		int32_t L_137 = V_13;
		int32_t L_138 = V_5;
		if ((((int32_t)L_137) < ((int32_t)L_138)))
		{
			goto IL_00e2;
		}
	}

IL_0318:
	{
		// for (var i = 0; i < totalFingerCount; ++i)
		int32_t L_139 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_139, (int32_t)1));
	}

IL_031c:
	{
		// for (var i = 0; i < totalFingerCount; ++i)
		int32_t L_140 = V_2;
		int32_t L_141 = __this->get_totalFingerCount_6();
		if ((((int32_t)L_140) < ((int32_t)L_141)))
		{
			goto IL_0074;
		}
	}
	{
		// haveBuiltActiveTouches = true;
		__this->set_haveBuiltActiveTouches_8((bool)1);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void FingerAndTouchState_UpdateActiveTouches_m51EAB31B9AE121144697D08A0DBB129A9DF71EAA_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 * _thisAdjusted = reinterpret_cast<FingerAndTouchState_t7D608ED3346F58E32CF5BDE238C441E104093D49 *>(__this + _offset);
	FingerAndTouchState_UpdateActiveTouches_m51EAB31B9AE121144697D08A0DBB129A9DF71EAA(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState
IL2CPP_EXTERN_C void GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshal_pinvoke(const GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A& unmarshaled, GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_pinvoke& marshaled)
{
	Exception_t* ___touchscreens_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'touchscreens' of type 'GlobalState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___touchscreens_0Exception, NULL);
}
IL2CPP_EXTERN_C void GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshal_pinvoke_back(const GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_pinvoke& marshaled, GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A& unmarshaled)
{
	Exception_t* ___touchscreens_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'touchscreens' of type 'GlobalState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___touchscreens_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState
IL2CPP_EXTERN_C void GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshal_pinvoke_cleanup(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState
IL2CPP_EXTERN_C void GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshal_com(const GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A& unmarshaled, GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_com& marshaled)
{
	Exception_t* ___touchscreens_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'touchscreens' of type 'GlobalState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___touchscreens_0Exception, NULL);
}
IL2CPP_EXTERN_C void GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshal_com_back(const GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_com& marshaled, GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A& unmarshaled)
{
	Exception_t* ___touchscreens_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'touchscreens' of type 'GlobalState'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___touchscreens_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.EnhancedTouch.Touch/GlobalState
IL2CPP_EXTERN_C void GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshal_com_cleanup(GlobalState_tB844B328DFFEE9FED985169019BDFA6104BC919A_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::.ctor(UnityEngine.InputSystem.EnhancedTouch.TouchHistory)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator__ctor_mEAA4F00826A64417B165D1F4535511DF777A295C (Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69 * __this, TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  ___owner0, const RuntimeMethod* method)
{
	{
		// internal Enumerator(TouchHistory owner)
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		// m_Owner = owner;
		TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  L_0 = ___owner0;
		__this->set_m_Owner_0(L_0);
		// m_Index = -1;
		__this->set_m_Index_1((-1));
		// }
		return;
	}
}
// System.Boolean UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m04B010CE6BF9BE50F802E0161C97E853EC707580 (Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69 * __this, const RuntimeMethod* method)
{
	TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// if (m_Index >= m_Owner.Count - 1)
		int32_t L_0 = __this->get_m_Index_1();
		TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  L_1 = __this->get_m_Owner_0();
		V_0 = L_1;
		int32_t L_2;
		L_2 = TouchHistory_get_Count_m54E34D6C03893752E6B905F728CAEF691F3FE779_inline((TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D *)(&V_0), /*hidden argument*/NULL);
		if ((((int32_t)L_0) < ((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_2, (int32_t)1)))))
		{
			goto IL_001a;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_001a:
	{
		// ++m_Index;
		int32_t L_3 = __this->get_m_Index_1();
		__this->set_m_Index_1(((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)1)));
		// return true;
		return (bool)1;
	}
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator_Reset_m603EBE2CEE12884E4C97232B9EFE13560FC2131E (Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69 * __this, const RuntimeMethod* method)
{
	{
		// m_Index = -1;
		__this->set_m_Index_1((-1));
		// }
		return;
	}
}
// UnityEngine.InputSystem.EnhancedTouch.Touch UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  Enumerator_get_Current_mFAAFC0193DDE998A96FFFADB0F2DDCB6E5AB34EE (Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69 * __this, const RuntimeMethod* method)
{
	TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// public Touch Current => m_Owner[m_Index];
		TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D  L_0 = __this->get_m_Owner_0();
		V_0 = L_0;
		int32_t L_1 = __this->get_m_Index_1();
		Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  L_2;
		L_2 = TouchHistory_get_Item_mDA783592CE8ED5CA149655D0F0CC9A4A878132EF((TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D *)(&V_0), L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * Enumerator_System_Collections_IEnumerator_get_Current_m971A8D2DB16AD4A3F8A0C7FB0C60B92121D46C16 (Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// object IEnumerator.Current => Current;
		Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  L_0;
		L_0 = Enumerator_get_Current_mFAAFC0193DDE998A96FFFADB0F2DDCB6E5AB34EE(__this, /*hidden argument*/NULL);
		Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA  L_1 = L_0;
		RuntimeObject * L_2 = Box(Touch_tD7416E6D52EC6FF0E8A241A8F8522D63AB7D73FA_il2cpp_TypeInfo_var, &L_1);
		return L_2;
	}
}
// System.Void UnityEngine.InputSystem.EnhancedTouch.TouchHistory/Enumerator::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator_Dispose_m8DD012BBABB4333E59A0DAD4D33199BF3B63CE9B (Enumerator_tC4E5CF973721402CEEFB59CFDD97B29D8AC65E69 * __this, const RuntimeMethod* method)
{
	{
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_mDD8F98F2D2756700BAE5B04486F09A6709D7EA3A (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 * L_0 = (U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 *)il2cpp_codegen_object_new(U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mE761A84D3883CD2AFFCC16E0BE6D4AF92E8E8CCE(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mE761A84D3883CD2AFFCC16E0BE6D4AF92E8E8CCE (U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Int32 UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/<>c::<SortedRaycastGraphics>b__25_0(UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData,UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t U3CU3Ec_U3CSortedRaycastGraphicsU3Eb__25_0_mD01188106F3CD6EC9DF893090778202A9FECF8D5 (U3CU3Ec_t8EB959CCD7DF0CF896BE180C4F1A8366BD6C62A5 * __this, RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1  ___g10, RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1  ___g21, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		// s_SortedGraphics.Sort((g1, g2) => g2.graphic.depth.CompareTo(g1.graphic.depth));
		Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * L_0;
		L_0 = RaycastHitData_get_graphic_m91A6519C0A0B9D40F6FD92744D73814912FB11BC_inline((RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 *)(&___g21), /*hidden argument*/NULL);
		NullCheck(L_0);
		int32_t L_1;
		L_1 = Graphic_get_depth_m8AF43A1523D90A3A42A812835D516940E320CD17(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * L_2;
		L_2 = RaycastHitData_get_graphic_m91A6519C0A0B9D40F6FD92744D73814912FB11BC_inline((RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 *)(&___g10), /*hidden argument*/NULL);
		NullCheck(L_2);
		int32_t L_3;
		L_3 = Graphic_get_depth_m8AF43A1523D90A3A42A812835D516940E320CD17(L_2, /*hidden argument*/NULL);
		int32_t L_4;
		L_4 = Int32_CompareTo_m2DD1093B956B4D96C3AC3C27FDEE3CA447B044D3((int32_t*)(&V_0), L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData
IL2CPP_EXTERN_C void RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshal_pinvoke(const RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1& unmarshaled, RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_pinvoke& marshaled)
{
	Exception_t* ___U3CgraphicU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<graphic>k__BackingField' of type 'RaycastHitData': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CgraphicU3Ek__BackingField_0Exception, NULL);
}
IL2CPP_EXTERN_C void RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshal_pinvoke_back(const RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_pinvoke& marshaled, RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1& unmarshaled)
{
	Exception_t* ___U3CgraphicU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<graphic>k__BackingField' of type 'RaycastHitData': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CgraphicU3Ek__BackingField_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData
IL2CPP_EXTERN_C void RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshal_pinvoke_cleanup(RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData
IL2CPP_EXTERN_C void RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshal_com(const RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1& unmarshaled, RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_com& marshaled)
{
	Exception_t* ___U3CgraphicU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<graphic>k__BackingField' of type 'RaycastHitData': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CgraphicU3Ek__BackingField_0Exception, NULL);
}
IL2CPP_EXTERN_C void RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshal_com_back(const RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_com& marshaled, RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1& unmarshaled)
{
	Exception_t* ___U3CgraphicU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<graphic>k__BackingField' of type 'RaycastHitData': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CgraphicU3Ek__BackingField_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData
IL2CPP_EXTERN_C void RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshal_com_cleanup(RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1_marshaled_com& marshaled)
{
}
// System.Void UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::.ctor(UnityEngine.UI.Graphic,UnityEngine.Vector3,UnityEngine.Vector2,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RaycastHitData__ctor_m8F1461FA863FE922484EC142C8B44088741C9B5D (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___graphic0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldHitPosition1, Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___screenPosition2, float ___distance3, const RuntimeMethod* method)
{
	{
		// this.graphic = graphic;
		Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * L_0 = ___graphic0;
		__this->set_U3CgraphicU3Ek__BackingField_0(L_0);
		// this.worldHitPosition = worldHitPosition;
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_1 = ___worldHitPosition1;
		__this->set_U3CworldHitPositionU3Ek__BackingField_1(L_1);
		// this.screenPosition = screenPosition;
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_2 = ___screenPosition2;
		__this->set_U3CscreenPositionU3Ek__BackingField_2(L_2);
		// this.distance = distance;
		float L_3 = ___distance3;
		__this->set_U3CdistanceU3Ek__BackingField_3(L_3);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void RaycastHitData__ctor_m8F1461FA863FE922484EC142C8B44088741C9B5D_AdjustorThunk (RuntimeObject * __this, Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * ___graphic0, Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___worldHitPosition1, Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___screenPosition2, float ___distance3, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * _thisAdjusted = reinterpret_cast<RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 *>(__this + _offset);
	RaycastHitData__ctor_m8F1461FA863FE922484EC142C8B44088741C9B5D(_thisAdjusted, ___graphic0, ___worldHitPosition1, ___screenPosition2, ___distance3, method);
}
// UnityEngine.UI.Graphic UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_graphic()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * RaycastHitData_get_graphic_m91A6519C0A0B9D40F6FD92744D73814912FB11BC (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public Graphic graphic { get; }
		Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * L_0 = __this->get_U3CgraphicU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_EXTERN_C  Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * RaycastHitData_get_graphic_m91A6519C0A0B9D40F6FD92744D73814912FB11BC_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * _thisAdjusted = reinterpret_cast<RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 *>(__this + _offset);
	Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * _returnValue;
	_returnValue = RaycastHitData_get_graphic_m91A6519C0A0B9D40F6FD92744D73814912FB11BC_inline(_thisAdjusted, method);
	return _returnValue;
}
// UnityEngine.Vector3 UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_worldHitPosition()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  RaycastHitData_get_worldHitPosition_mC9C5845797C171788CF76B2CBB32837645157CC2 (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public Vector3 worldHitPosition { get; }
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0 = __this->get_U3CworldHitPositionU3Ek__BackingField_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C  Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  RaycastHitData_get_worldHitPosition_mC9C5845797C171788CF76B2CBB32837645157CC2_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * _thisAdjusted = reinterpret_cast<RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 *>(__this + _offset);
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  _returnValue;
	_returnValue = RaycastHitData_get_worldHitPosition_mC9C5845797C171788CF76B2CBB32837645157CC2_inline(_thisAdjusted, method);
	return _returnValue;
}
// UnityEngine.Vector2 UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_screenPosition()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  RaycastHitData_get_screenPosition_m6645B3B1991CF259946A1EF12953F3FC8CDFA496 (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public Vector2 screenPosition { get; }
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_0 = __this->get_U3CscreenPositionU3Ek__BackingField_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C  Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  RaycastHitData_get_screenPosition_m6645B3B1991CF259946A1EF12953F3FC8CDFA496_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * _thisAdjusted = reinterpret_cast<RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 *>(__this + _offset);
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  _returnValue;
	_returnValue = RaycastHitData_get_screenPosition_m6645B3B1991CF259946A1EF12953F3FC8CDFA496_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Single UnityEngine.InputSystem.UI.TrackedDeviceRaycaster/RaycastHitData::get_distance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float RaycastHitData_get_distance_m491A785927DD2A56D4735115B9301CF01595112F (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public float distance { get; }
		float L_0 = __this->get_U3CdistanceU3Ek__BackingField_3();
		return L_0;
	}
}
IL2CPP_EXTERN_C  float RaycastHitData_get_distance_m491A785927DD2A56D4735115B9301CF01595112F_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * _thisAdjusted = reinterpret_cast<RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 *>(__this + _offset);
	float _returnValue;
	_returnValue = RaycastHitData_get_distance_m491A785927DD2A56D4735115B9301CF01595112F_inline(_thisAdjusted, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Utilities.TypeTable/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m7AA72A217DA715C6697D53E4B25F1934DCD4E0DF (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 * L_0 = (U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 *)il2cpp_codegen_object_new(U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mE8CBA0D8755028C9C815A04A86EFC19899D78EE4(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Utilities.TypeTable/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mE8CBA0D8755028C9C815A04A86EFC19899D78EE4 (U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.String UnityEngine.InputSystem.Utilities.TypeTable/<>c::<get_names>b__2_0(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3Cget_namesU3Eb__2_0_mED64344211423281C11348D9A8C6A22F797BD42C (U3CU3Ec_tF3B179A6D5C9B2684299CC840938D0BF05475F16 * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___x0, const RuntimeMethod* method)
{
	{
		// public IEnumerable<string> names => table.Keys.Select(x => x.ToString());
		String_t* L_0;
		L_0 = InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.XR.XRLayoutBuilder/<>c__DisplayClass5_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass5_0__ctor_m5F3B31A4DC3CE219AD210F924C2B17D8DDD3F16C (U3CU3Ec__DisplayClass5_0_t61B431287C870188CE58D7B356636FD26AA4A34F * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// UnityEngine.InputSystem.Layouts.InputControlLayout UnityEngine.InputSystem.XR.XRLayoutBuilder/<>c__DisplayClass5_0::<OnFindLayoutForDevice>b__0()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491 * U3CU3Ec__DisplayClass5_0_U3COnFindLayoutForDeviceU3Eb__0_m96A8DF1143739D0B1085CD41C0F1A0F96DAE528A (U3CU3Ec__DisplayClass5_0_t61B431287C870188CE58D7B356636FD26AA4A34F * __this, const RuntimeMethod* method)
{
	{
		// InputSystem.RegisterLayoutBuilder(() => layout.Build(), layoutName, matchedLayout);
		XRLayoutBuilder_t87FD014CF9A3CF74ADE95C0D5117DBE89AC68EB6 * L_0 = __this->get_layout_0();
		NullCheck(L_0);
		InputControlLayout_t140BFB108735BF4A39F07286474E67317902B491 * L_1;
		L_1 = XRLayoutBuilder_Build_m31AFDB2D4649937D751A722D79232FE320FDA39D(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m7A4671AA3794F1FEE347F9217D5851BC0401945E (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * L_0 = (U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 *)il2cpp_codegen_object_new(U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_m536EFAB0D8AC660A7178F457D2EA8B23CA03EF87(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m536EFAB0D8AC660A7178F457D2EA8B23CA03EF87 (U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::<Build>b__4_0(UnityEngine.InputSystem.HID.HID/HIDElementDescriptor)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CBuildU3Eb__4_0_m3FA0A62A7C253F1D8230D3A5E9EC0F07C2E43131 (U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * __this, HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48  ___element0, const RuntimeMethod* method)
{
	{
		// element => element.usagePage == UsagePage.GenericDesktop &&
		// element.usage == (int)GenericDesktop.X);
		HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48  L_0 = ___element0;
		int32_t L_1 = L_0.get_usagePage_1();
		if ((!(((uint32_t)L_1) == ((uint32_t)1))))
		{
			goto IL_0014;
		}
	}
	{
		HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48  L_2 = ___element0;
		int32_t L_3 = L_2.get_usage_0();
		return (bool)((((int32_t)L_3) == ((int32_t)((int32_t)48)))? 1 : 0);
	}

IL_0014:
	{
		return (bool)0;
	}
}
// System.Boolean UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::<Build>b__4_1(UnityEngine.InputSystem.HID.HID/HIDElementDescriptor)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CBuildU3Eb__4_1_m7CD65A8362A0DC9D0179849DC496BB04504878F5 (U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * __this, HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48  ___element0, const RuntimeMethod* method)
{
	{
		// element => element.usagePage == UsagePage.GenericDesktop &&
		// element.usage == (int)GenericDesktop.Y);
		HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48  L_0 = ___element0;
		int32_t L_1 = L_0.get_usagePage_1();
		if ((!(((uint32_t)L_1) == ((uint32_t)1))))
		{
			goto IL_0014;
		}
	}
	{
		HIDElementDescriptor_tABBE6D909D333DBC426B5CED2F7DDD53FAC9EB48  L_2 = ___element0;
		int32_t L_3 = L_2.get_usage_0();
		return (bool)((((int32_t)L_3) == ((int32_t)((int32_t)49)))? 1 : 0);
	}

IL_0014:
	{
		return (bool)0;
	}
}
// System.String UnityEngine.InputSystem.HID.HID/HIDLayoutBuilder/<>c::<Build>b__4_2(UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CBuildU3Eb__4_2_m4FEF30ADDC83F24959A14110D3D82A18937C1613 (U3CU3Ec_tCA18C758763B958693A2DE4435D18CB5EE568419 * __this, ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D  ___x0, const RuntimeMethod* method)
{
	{
		// name = StringHelpers.MakeUniqueName(name, builder.controls, x => x.name);
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_0;
		L_0 = ControlItem_get_name_mCE0AD0DE297C87588F201396EDA1C92C0120CAD5_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)(&___x0), /*hidden argument*/NULL);
		String_t* L_1;
		L_1 = InternedString_op_Implicit_m02F9D70EFC8036EBE85DF2019D5AA3B430814EF8(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.InputActionRebindingExtensions/RebindingOperation/<>c__DisplayClass32_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass32_0__ctor_m786504C0C980B2845A7B1E95C4A77D87974F25AF (U3CU3Ec__DisplayClass32_0_tA271F31E878C96B5240F88C220A943476FA04921 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean UnityEngine.InputSystem.InputActionRebindingExtensions/RebindingOperation/<>c__DisplayClass32_0::<WithTargetBinding>b__0(UnityEngine.InputSystem.InputControlScheme)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass32_0_U3CWithTargetBindingU3Eb__0_mCC830755E2EF76AA3BB3589F57E59E589463A5B8 (U3CU3Ec__DisplayClass32_0_tA271F31E878C96B5240F88C220A943476FA04921 * __this, InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288  ___x0, const RuntimeMethod* method)
{
	{
		// asset.controlSchemes.IndexOf(x => group.Equals(x.bindingGroup, StringComparison.InvariantCultureIgnoreCase));
		String_t* L_0 = __this->get_group_0();
		String_t* L_1;
		L_1 = InputControlScheme_get_bindingGroup_mDBCE86B56691F2942296D6D1AE0D5ADB3194F0ED_inline((InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288 *)(&___x0), /*hidden argument*/NULL);
		NullCheck(L_0);
		bool L_2;
		L_2 = String_Equals_m62F0586691097AA2EE48F1596A130170BCFBF7F6(L_0, L_1, 3, /*hidden argument*/NULL);
		return L_2;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder
IL2CPP_EXTERN_C void ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshal_pinvoke(const ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37& unmarshaled, ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_pinvoke& marshaled)
{
	Exception_t* ___builder_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'builder' of type 'ControlBuilder': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___builder_0Exception, NULL);
}
IL2CPP_EXTERN_C void ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshal_pinvoke_back(const ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_pinvoke& marshaled, ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37& unmarshaled)
{
	Exception_t* ___builder_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'builder' of type 'ControlBuilder': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___builder_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder
IL2CPP_EXTERN_C void ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshal_pinvoke_cleanup(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder
IL2CPP_EXTERN_C void ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshal_com(const ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37& unmarshaled, ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_com& marshaled)
{
	Exception_t* ___builder_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'builder' of type 'ControlBuilder': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___builder_0Exception, NULL);
}
IL2CPP_EXTERN_C void ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshal_com_back(const ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_com& marshaled, ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37& unmarshaled)
{
	Exception_t* ___builder_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'builder' of type 'ControlBuilder': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___builder_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder
IL2CPP_EXTERN_C void ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshal_com_cleanup(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37_marshaled_com& marshaled)
{
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithDisplayName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithDisplayName_m1A623A8DF4B7720ECC31835DDBEF3140089EE7A4 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___displayName0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].displayName = displayName;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		String_t* L_3 = ___displayName0;
		ControlItem_set_displayName_mB29B2CA5BDF6A4617795C5CD01FD2AD5DA17AE8A_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithDisplayName_m1A623A8DF4B7720ECC31835DDBEF3140089EE7A4_AdjustorThunk (RuntimeObject * __this, String_t* ___displayName0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithDisplayName_m1A623A8DF4B7720ECC31835DDBEF3140089EE7A4(_thisAdjusted, ___displayName0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithLayout(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithLayout_mD3C038067BB92E5A917110E4FBABEA3AB1E253A8 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___layout0, const RuntimeMethod* method)
{
	{
		// if (string.IsNullOrEmpty(layout))
		String_t* L_0 = ___layout0;
		bool L_1;
		L_1 = String_IsNullOrEmpty_m9AFBB5335B441B94E884B8A9D4A27AD60E3D7F7C(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0018;
		}
	}
	{
		// throw new ArgumentException("Layout name cannot be null or empty", nameof(layout));
		ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00 * L_2 = (ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00 *)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00_il2cpp_TypeInfo_var)));
		ArgumentException__ctor_m71044C2110E357B71A1C30D2561C3F861AF1DC0D(L_2, ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral546E64419B7FFEA645697C61A9E3845E8244EB14)), ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral73F1C0DB7E67894BD0991354AA6CB2DA4A3A5D88)), /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ControlBuilder_WithLayout_mD3C038067BB92E5A917110E4FBABEA3AB1E253A8_RuntimeMethod_var)));
	}

IL_0018:
	{
		// builder.m_Controls[index].layout = new InternedString(layout);
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_3 = __this->get_builder_0();
		NullCheck(L_3);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_4 = L_3->get_m_Controls_8();
		int32_t L_5 = __this->get_index_1();
		NullCheck(L_4);
		String_t* L_6 = ___layout0;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_7;
		memset((&L_7), 0, sizeof(L_7));
		InternedString__ctor_mB41178458180DD7648D91B2F7865A2C5CC1B1192((&L_7), L_6, /*hidden argument*/NULL);
		ControlItem_set_layout_m120160AE002A158CA9EDCA62BF8201D27F4E838C_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_4)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_5))), L_7, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_8 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_8;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithLayout_mD3C038067BB92E5A917110E4FBABEA3AB1E253A8_AdjustorThunk (RuntimeObject * __this, String_t* ___layout0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithLayout_mD3C038067BB92E5A917110E4FBABEA3AB1E253A8(_thisAdjusted, ___layout0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithFormat(UnityEngine.InputSystem.Utilities.FourCC)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithFormat_m4FEE215953366F0D5B9CE14D480BCF2A396446A6 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___format0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].format = format;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  L_3 = ___format0;
		ControlItem_set_format_mE749BC629174FFC3153C1A077972A5A796CCB003_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithFormat_m4FEE215953366F0D5B9CE14D480BCF2A396446A6_AdjustorThunk (RuntimeObject * __this, FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___format0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithFormat_m4FEE215953366F0D5B9CE14D480BCF2A396446A6(_thisAdjusted, ___format0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithFormat(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithFormat_m8EAB9AD26E96020E18A36BC3A13C1CC4FA537960 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___format0, const RuntimeMethod* method)
{
	{
		// return WithFormat(new FourCC(format));
		String_t* L_0 = ___format0;
		FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  L_1;
		memset((&L_1), 0, sizeof(L_1));
		FourCC__ctor_m067FE59969221E1E286A5BA08A93835A50A27BE9((&L_1), L_0, /*hidden argument*/NULL);
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_2;
		L_2 = ControlBuilder_WithFormat_m4FEE215953366F0D5B9CE14D480BCF2A396446A6((ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithFormat_m8EAB9AD26E96020E18A36BC3A13C1CC4FA537960_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithFormat_m8EAB9AD26E96020E18A36BC3A13C1CC4FA537960(_thisAdjusted, ___format0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithByteOffset(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithByteOffset_m523C0547DD663078008826E3A81804382E0A0689 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, uint32_t ___offset0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].offset = offset;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		uint32_t L_3 = ___offset0;
		ControlItem_set_offset_m3311619100F27C22CAF2EB2FE8B8E5BD42B4486B_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithByteOffset_m523C0547DD663078008826E3A81804382E0A0689_AdjustorThunk (RuntimeObject * __this, uint32_t ___offset0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithByteOffset_m523C0547DD663078008826E3A81804382E0A0689(_thisAdjusted, ___offset0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithBitOffset(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithBitOffset_m6B537FD254A5BCEDFECDE6A779ADDBA5D34BE695 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, uint32_t ___bit0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].bit = bit;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		uint32_t L_3 = ___bit0;
		ControlItem_set_bit_m18990DBD5680FC858B52DCA931E21C3383809265_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithBitOffset_m6B537FD254A5BCEDFECDE6A779ADDBA5D34BE695_AdjustorThunk (RuntimeObject * __this, uint32_t ___bit0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithBitOffset_m6B537FD254A5BCEDFECDE6A779ADDBA5D34BE695(_thisAdjusted, ___bit0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::IsSynthetic(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_IsSynthetic_mF1F6C5A150897BA005977285742A0294F00040E9 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].isSynthetic = value;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		bool L_3 = ___value0;
		ControlItem_set_isSynthetic_mA8F8F5DC079B172B0323CDE7935DCF27976919A2((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_IsSynthetic_mF1F6C5A150897BA005977285742A0294F00040E9_AdjustorThunk (RuntimeObject * __this, bool ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_IsSynthetic_mF1F6C5A150897BA005977285742A0294F00040E9(_thisAdjusted, ___value0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::IsNoisy(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_IsNoisy_mDDF9673A876A0EEF88337A02E32D64169D4D4729 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].isNoisy = value;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		bool L_3 = ___value0;
		ControlItem_set_isNoisy_m1F3F63017800F3D868F9D94E5136364C13D263F2((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_IsNoisy_mDDF9673A876A0EEF88337A02E32D64169D4D4729_AdjustorThunk (RuntimeObject * __this, bool ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_IsNoisy_mDDF9673A876A0EEF88337A02E32D64169D4D4729(_thisAdjusted, ___value0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::DontReset(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_DontReset_m9D2975378C6E93F2069BF323381791C7F8FAAFF7 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].dontReset = value;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		bool L_3 = ___value0;
		ControlItem_set_dontReset_m5A874442E701E67DAE35578DF99DAB91C5BA031D((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_DontReset_m9D2975378C6E93F2069BF323381791C7F8FAAFF7_AdjustorThunk (RuntimeObject * __this, bool ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_DontReset_m9D2975378C6E93F2069BF323381791C7F8FAAFF7(_thisAdjusted, ___value0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithSizeInBits(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithSizeInBits_m5D102549835C4325A2A28F769E86CCCC9EBE7A30 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, uint32_t ___sizeInBits0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].sizeInBits = sizeInBits;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		uint32_t L_3 = ___sizeInBits0;
		ControlItem_set_sizeInBits_m8F4F28F7ED19B693DE210492DA15EAEE6C8EB543_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithSizeInBits_m5D102549835C4325A2A28F769E86CCCC9EBE7A30_AdjustorThunk (RuntimeObject * __this, uint32_t ___sizeInBits0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithSizeInBits_m5D102549835C4325A2A28F769E86CCCC9EBE7A30(_thisAdjusted, ___sizeInBits0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithRange(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithRange_m145BFDD16FEBCFD69B61FFE1EA4EB18405A18B33 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, float ___minValue0, float ___maxValue1, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].minValue = minValue;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		float L_3 = ___minValue0;
		PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  L_4;
		L_4 = PrimitiveValue_op_Implicit_m816B423406A5509C5EF837048B425B5091D1F38B(L_3, /*hidden argument*/NULL);
		ControlItem_set_minValue_mAB7186D561C1E98CBFBAFE17A00A0F177B20171D_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_4, /*hidden argument*/NULL);
		// builder.m_Controls[index].maxValue = maxValue;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_5 = __this->get_builder_0();
		NullCheck(L_5);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_6 = L_5->get_m_Controls_8();
		int32_t L_7 = __this->get_index_1();
		NullCheck(L_6);
		float L_8 = ___maxValue1;
		PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  L_9;
		L_9 = PrimitiveValue_op_Implicit_m816B423406A5509C5EF837048B425B5091D1F38B(L_8, /*hidden argument*/NULL);
		ControlItem_set_maxValue_mBE618291D3CBE215F4ADF8B16D33735618D89E8E_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_6)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_7))), L_9, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_10 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_10;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithRange_m145BFDD16FEBCFD69B61FFE1EA4EB18405A18B33_AdjustorThunk (RuntimeObject * __this, float ___minValue0, float ___maxValue1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithRange_m145BFDD16FEBCFD69B61FFE1EA4EB18405A18B33(_thisAdjusted, ___minValue0, ___maxValue1, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithUsages(UnityEngine.InputSystem.Utilities.InternedString[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_m7766F0A2DE6A8E77E17C4CF777D71A7D2A63ECF6 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___usages0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlyArray_1__ctor_mEBC958B99E88055B976A48FD29182C367B255013_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (usages == null || usages.Length == 0)
		InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* L_0 = ___usages0;
		if (!L_0)
		{
			goto IL_0007;
		}
	}
	{
		InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* L_1 = ___usages0;
		NullCheck(L_1);
		if ((((RuntimeArray*)L_1)->max_length))
		{
			goto IL_000e;
		}
	}

IL_0007:
	{
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_2 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_2;
	}

IL_000e:
	{
		// for (var i = 0; i < usages.Length; ++i)
		V_0 = 0;
		goto IL_006a;
	}

IL_0012:
	{
		// if (usages[i].IsEmpty())
		InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* L_3 = ___usages0;
		int32_t L_4 = V_0;
		NullCheck(L_3);
		bool L_5;
		L_5 = InternedString_IsEmpty_m78C41407A53828966AC41C95368CFB7EF61A7494((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)((L_3)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4))), /*hidden argument*/NULL);
		if (!L_5)
		{
			goto IL_0066;
		}
	}
	{
		// throw new ArgumentException(
		//     $"Empty usage entry at index {i} for control '{builder.m_Controls[index].name}' in layout '{builder.name}'",
		//     nameof(usages));
		int32_t L_6 = V_0;
		int32_t L_7 = L_6;
		RuntimeObject * L_8 = Box(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var)), &L_7);
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_9 = __this->get_builder_0();
		NullCheck(L_9);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_10 = L_9->get_m_Controls_8();
		int32_t L_11 = __this->get_index_1();
		NullCheck(L_10);
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_12;
		L_12 = ControlItem_get_name_mCE0AD0DE297C87588F201396EDA1C92C0120CAD5_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_10)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_11))), /*hidden argument*/NULL);
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_13 = L_12;
		RuntimeObject * L_14 = Box(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_il2cpp_TypeInfo_var)), &L_13);
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_15 = __this->get_builder_0();
		NullCheck(L_15);
		String_t* L_16;
		L_16 = Builder_get_name_m0E4ECDC1E4880050B65289CA1ACA6BBFAA279486_inline(L_15, /*hidden argument*/NULL);
		String_t* L_17;
		L_17 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral8AA175FF4B1ED47D26B7A4841279300DE227A679)), L_8, L_14, L_16, /*hidden argument*/NULL);
		ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00 * L_18 = (ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00 *)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ArgumentException_t505FA8C11E883F2D96C797AD9D396490794DEE00_il2cpp_TypeInfo_var)));
		ArgumentException__ctor_m71044C2110E357B71A1C30D2561C3F861AF1DC0D(L_18, L_17, ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral8E2BEC23B4BAF8EC6CCD9A01B38260B8517E930F)), /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_18, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ControlBuilder_WithUsages_m7766F0A2DE6A8E77E17C4CF777D71A7D2A63ECF6_RuntimeMethod_var)));
	}

IL_0066:
	{
		// for (var i = 0; i < usages.Length; ++i)
		int32_t L_19 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_19, (int32_t)1));
	}

IL_006a:
	{
		// for (var i = 0; i < usages.Length; ++i)
		int32_t L_20 = V_0;
		InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* L_21 = ___usages0;
		NullCheck(L_21);
		if ((((int32_t)L_20) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_21)->max_length))))))
		{
			goto IL_0012;
		}
	}
	{
		// builder.m_Controls[index].usages = new ReadOnlyArray<InternedString>(usages);
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_22 = __this->get_builder_0();
		NullCheck(L_22);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_23 = L_22->get_m_Controls_8();
		int32_t L_24 = __this->get_index_1();
		NullCheck(L_23);
		InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* L_25 = ___usages0;
		ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  L_26;
		memset((&L_26), 0, sizeof(L_26));
		ReadOnlyArray_1__ctor_mEBC958B99E88055B976A48FD29182C367B255013((&L_26), L_25, /*hidden argument*/ReadOnlyArray_1__ctor_mEBC958B99E88055B976A48FD29182C367B255013_RuntimeMethod_var);
		ControlItem_set_usages_m565AB9F1578DEA1A853FD37AC283E82838B7F934_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_23)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_24))), L_26, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_27 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_27;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_m7766F0A2DE6A8E77E17C4CF777D71A7D2A63ECF6_AdjustorThunk (RuntimeObject * __this, InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* ___usages0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithUsages_m7766F0A2DE6A8E77E17C4CF777D71A7D2A63ECF6(_thisAdjusted, ___usages0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithUsages(System.Collections.Generic.IEnumerable`1<System.String>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_mC6770F32E20A5F1C57BD18A556A52EE176113F35 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, RuntimeObject* ___usages0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_Select_TisString_t_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_m322E9154E14BE81AD2AAF37A69AC92E6FE3D0E6F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_ToArray_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_mB81CDBC6648458E775977B0F5B0CD7DFDB092FF8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_2__ctor_m244A853C4545AF28ABF654C7F16EAF3B6D52BD7B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_U3CWithUsagesU3Eb__14_0_m8ED6A0DFF67848D3FB546D919E9B8987D9D7DB78_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* V_0 = NULL;
	Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * G_B2_0 = NULL;
	RuntimeObject* G_B2_1 = NULL;
	Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * G_B1_0 = NULL;
	RuntimeObject* G_B1_1 = NULL;
	{
		// var usagesArray = usages.Select(x => new InternedString(x)).ToArray();
		RuntimeObject* L_0 = ___usages0;
		IL2CPP_RUNTIME_CLASS_INIT(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var);
		Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * L_1 = ((U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var))->get_U3CU3E9__14_0_1();
		Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * L_2 = L_1;
		G_B1_0 = L_2;
		G_B1_1 = L_0;
		if (L_2)
		{
			G_B2_0 = L_2;
			G_B2_1 = L_0;
			goto IL_0020;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var);
		U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * L_3 = ((U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var))->get_U3CU3E9_0();
		Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * L_4 = (Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB *)il2cpp_codegen_object_new(Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB_il2cpp_TypeInfo_var);
		Func_2__ctor_m244A853C4545AF28ABF654C7F16EAF3B6D52BD7B(L_4, L_3, (intptr_t)((intptr_t)U3CU3Ec_U3CWithUsagesU3Eb__14_0_m8ED6A0DFF67848D3FB546D919E9B8987D9D7DB78_RuntimeMethod_var), /*hidden argument*/Func_2__ctor_m244A853C4545AF28ABF654C7F16EAF3B6D52BD7B_RuntimeMethod_var);
		Func_2_tB5E9ACFD062EBB78C074076FD098FD2655C607FB * L_5 = L_4;
		((U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var))->set_U3CU3E9__14_0_1(L_5);
		G_B2_0 = L_5;
		G_B2_1 = G_B1_1;
	}

IL_0020:
	{
		RuntimeObject* L_6;
		L_6 = Enumerable_Select_TisString_t_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_m322E9154E14BE81AD2AAF37A69AC92E6FE3D0E6F(G_B2_1, G_B2_0, /*hidden argument*/Enumerable_Select_TisString_t_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_m322E9154E14BE81AD2AAF37A69AC92E6FE3D0E6F_RuntimeMethod_var);
		InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* L_7;
		L_7 = Enumerable_ToArray_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_mB81CDBC6648458E775977B0F5B0CD7DFDB092FF8(L_6, /*hidden argument*/Enumerable_ToArray_TisInternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_mB81CDBC6648458E775977B0F5B0CD7DFDB092FF8_RuntimeMethod_var);
		V_0 = L_7;
		// return WithUsages(usagesArray);
		InternedStringU5BU5D_t157EC3FD5EC6C17780128E7E48FC136DB6E27D11* L_8 = V_0;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_9;
		L_9 = ControlBuilder_WithUsages_m7766F0A2DE6A8E77E17C4CF777D71A7D2A63ECF6((ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_mC6770F32E20A5F1C57BD18A556A52EE176113F35_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___usages0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithUsages_mC6770F32E20A5F1C57BD18A556A52EE176113F35(_thisAdjusted, ___usages0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithUsages(System.String[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_mD84AACB822B051C4B90BF627DEE0D6226F546767 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* ___usages0, const RuntimeMethod* method)
{
	{
		// return WithUsages((IEnumerable<string>)usages);
		StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* L_0 = ___usages0;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_1;
		L_1 = ControlBuilder_WithUsages_mC6770F32E20A5F1C57BD18A556A52EE176113F35((ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this, (RuntimeObject*)(RuntimeObject*)L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithUsages_mD84AACB822B051C4B90BF627DEE0D6226F546767_AdjustorThunk (RuntimeObject * __this, StringU5BU5D_tACEBFEDE350025B554CD507C9AE8FFE49359549A* ___usages0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithUsages_mD84AACB822B051C4B90BF627DEE0D6226F546767(_thisAdjusted, ___usages0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithParameters(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithParameters_m8042DDA5517A5EC2428ED502651674EE9BF46AB2 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___parameters0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlyArray_1__ctor_mAD8348E710A8187038E9A181FF8458AB4FD59447_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* V_0 = NULL;
	{
		// if (string.IsNullOrEmpty(parameters))
		String_t* L_0 = ___parameters0;
		bool L_1;
		L_1 = String_IsNullOrEmpty_m9AFBB5335B441B94E884B8A9D4A27AD60E3D7F7C(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_000f;
		}
	}
	{
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_2 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_2;
	}

IL_000f:
	{
		// var parsed = NamedValue.ParseMultiple(parameters);
		String_t* L_3 = ___parameters0;
		NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* L_4;
		L_4 = NamedValue_ParseMultiple_m102A3FEB344FC4CD41D094A637106B47B5FE6B40(L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		// builder.m_Controls[index].parameters = new ReadOnlyArray<NamedValue>(parsed);
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_5 = __this->get_builder_0();
		NullCheck(L_5);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_6 = L_5->get_m_Controls_8();
		int32_t L_7 = __this->get_index_1();
		NullCheck(L_6);
		NamedValueU5BU5D_t3BC95F20A3983C313F80AF3BD283FDB060EA959B* L_8 = V_0;
		ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  L_9;
		memset((&L_9), 0, sizeof(L_9));
		ReadOnlyArray_1__ctor_mAD8348E710A8187038E9A181FF8458AB4FD59447((&L_9), L_8, /*hidden argument*/ReadOnlyArray_1__ctor_mAD8348E710A8187038E9A181FF8458AB4FD59447_RuntimeMethod_var);
		ControlItem_set_parameters_m70663F346869784CF8C4E6C5BADDE822F98B8B24_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_6)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_7))), L_9, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_10 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_10;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithParameters_m8042DDA5517A5EC2428ED502651674EE9BF46AB2_AdjustorThunk (RuntimeObject * __this, String_t* ___parameters0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithParameters_m8042DDA5517A5EC2428ED502651674EE9BF46AB2(_thisAdjusted, ___parameters0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithProcessors(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithProcessors_m7711FE6714EA57F0356AE3076D72508F5C9275F7 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___processors0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_ToArray_TisNameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_mDC5522CF62EDFA52EEA4E8F85D7FECD84CFF23AE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlyArray_1__ctor_m2AEF1D3FB42E7980B7C8F4D40E775EEB1DAD8C8E_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* V_0 = NULL;
	{
		// if (string.IsNullOrEmpty(processors))
		String_t* L_0 = ___processors0;
		bool L_1;
		L_1 = String_IsNullOrEmpty_m9AFBB5335B441B94E884B8A9D4A27AD60E3D7F7C(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_000f;
		}
	}
	{
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_2 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_2;
	}

IL_000f:
	{
		// var parsed = NameAndParameters.ParseMultiple(processors).ToArray();
		String_t* L_3 = ___processors0;
		RuntimeObject* L_4;
		L_4 = NameAndParameters_ParseMultiple_mF1A7222A513A114B1AB2E58FE747F54965A35C53(L_3, /*hidden argument*/NULL);
		NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* L_5;
		L_5 = Enumerable_ToArray_TisNameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_mDC5522CF62EDFA52EEA4E8F85D7FECD84CFF23AE(L_4, /*hidden argument*/Enumerable_ToArray_TisNameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76_mDC5522CF62EDFA52EEA4E8F85D7FECD84CFF23AE_RuntimeMethod_var);
		V_0 = L_5;
		// builder.m_Controls[index].processors = new ReadOnlyArray<NameAndParameters>(parsed);
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_6 = __this->get_builder_0();
		NullCheck(L_6);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_7 = L_6->get_m_Controls_8();
		int32_t L_8 = __this->get_index_1();
		NullCheck(L_7);
		NameAndParametersU5BU5D_t8313AFC154803B78FB2182249118FA823500EE83* L_9 = V_0;
		ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  L_10;
		memset((&L_10), 0, sizeof(L_10));
		ReadOnlyArray_1__ctor_m2AEF1D3FB42E7980B7C8F4D40E775EEB1DAD8C8E((&L_10), L_9, /*hidden argument*/ReadOnlyArray_1__ctor_m2AEF1D3FB42E7980B7C8F4D40E775EEB1DAD8C8E_RuntimeMethod_var);
		ControlItem_set_processors_m9A9EF453FBB41590F5DC79775533A7DB5781B8C9_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_7)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_8))), L_10, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_11 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_11;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithProcessors_m7711FE6714EA57F0356AE3076D72508F5C9275F7_AdjustorThunk (RuntimeObject * __this, String_t* ___processors0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithProcessors_m7711FE6714EA57F0356AE3076D72508F5C9275F7(_thisAdjusted, ___processors0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::WithDefaultState(UnityEngine.InputSystem.Utilities.PrimitiveValue)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithDefaultState_m028E2C3DAB7D1FBE5E5019088971F980825933C4 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].defaultState = value;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  L_3 = ___value0;
		ControlItem_set_defaultState_mB9603018DBC8D71A72B9E74B0179AD2E4965D681_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_WithDefaultState_m028E2C3DAB7D1FBE5E5019088971F980825933C4_AdjustorThunk (RuntimeObject * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_WithDefaultState_m028E2C3DAB7D1FBE5E5019088971F980825933C4(_thisAdjusted, ___value0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::UsingStateFrom(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_UsingStateFrom_m47B51350F5935A5B9216C129D48B46DF9C6C9C71 (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, String_t* ___path0, const RuntimeMethod* method)
{
	{
		// if (string.IsNullOrEmpty(path))
		String_t* L_0 = ___path0;
		bool L_1;
		L_1 = String_IsNullOrEmpty_m9AFBB5335B441B94E884B8A9D4A27AD60E3D7F7C(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_000f;
		}
	}
	{
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_2 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_2;
	}

IL_000f:
	{
		// builder.m_Controls[index].useStateFrom = path;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_3 = __this->get_builder_0();
		NullCheck(L_3);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_4 = L_3->get_m_Controls_8();
		int32_t L_5 = __this->get_index_1();
		NullCheck(L_4);
		String_t* L_6 = ___path0;
		ControlItem_set_useStateFrom_m2483939EAAD5950014A020C5A056DE99484CAF86_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_4)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_5))), L_6, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_7 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_7;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_UsingStateFrom_m47B51350F5935A5B9216C129D48B46DF9C6C9C71_AdjustorThunk (RuntimeObject * __this, String_t* ___path0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_UsingStateFrom_m47B51350F5935A5B9216C129D48B46DF9C6C9C71(_thisAdjusted, ___path0, method);
	return _returnValue;
}
// UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder::AsArrayOfControlsWithSize(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_AsArrayOfControlsWithSize_m92B1A2C880BBB1FA09A64A421BEB952DBB9F829E (ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * __this, int32_t ___arraySize0, const RuntimeMethod* method)
{
	{
		// builder.m_Controls[index].arraySize = arraySize;
		Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		ControlItemU5BU5D_tD4F83FB5898E170E9E3D0933D354C3F167C14C05* L_1 = L_0->get_m_Controls_8();
		int32_t L_2 = __this->get_index_1();
		NullCheck(L_1);
		int32_t L_3 = ___arraySize0;
		ControlItem_set_arraySize_mB8DE5DE08FBE9A89D6878878D0DF5618EA24ECFB_inline((ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D *)((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2))), L_3, /*hidden argument*/NULL);
		// return this;
		ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  L_4 = (*(ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *)__this);
		return L_4;
	}
}
IL2CPP_EXTERN_C  ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  ControlBuilder_AsArrayOfControlsWithSize_m92B1A2C880BBB1FA09A64A421BEB952DBB9F829E_AdjustorThunk (RuntimeObject * __this, int32_t ___arraySize0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 * _thisAdjusted = reinterpret_cast<ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37 *>(__this + _offset);
	ControlBuilder_t04691F57503AD4046234AB524641AA9B42461A37  _returnValue;
	_returnValue = ControlBuilder_AsArrayOfControlsWithSize_m92B1A2C880BBB1FA09A64A421BEB952DBB9F829E(_thisAdjusted, ___arraySize0, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CGetBaseLayoutsU3Ed__24__ctor_m1FC80EA631C9A11728DC11205F1C4E2FC6ECE022 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___U3CU3E1__state0;
		__this->set_U3CU3E1__state_0(L_0);
		int32_t L_1;
		L_1 = Environment_get_CurrentManagedThreadId_m09DBD4166BFD399056B2F81C77A3A182339BF92D(/*hidden argument*/NULL);
		__this->set_U3CU3El__initialThreadId_2(L_1);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::System.IDisposable.Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CGetBaseLayoutsU3Ed__24_System_IDisposable_Dispose_mF8CCD48730187E4AD892642D34F082B40861E856 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method)
{
	{
		return;
	}
}
// System.Boolean UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CGetBaseLayoutsU3Ed__24_MoveNext_m3440C6CC85A9614B4234FF8A421A04C8C01B3B08 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_TryGetValue_m13A59E4AB21B1AFCC1D94C66A2F5689DD3DF7C31_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		int32_t L_1 = V_0;
		switch (L_1)
		{
			case 0:
			{
				goto IL_001b;
			}
			case 1:
			{
				goto IL_003f;
			}
			case 2:
			{
				goto IL_005d;
			}
		}
	}
	{
		return (bool)0;
	}

IL_001b:
	{
		__this->set_U3CU3E1__state_0((-1));
		// if (includeSelf)
		bool L_2 = __this->get_includeSelf_3();
		if (!L_2)
		{
			goto IL_0064;
		}
	}
	{
		// yield return layout;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_3 = __this->get_layout_5();
		__this->set_U3CU3E2__current_1(L_3);
		__this->set_U3CU3E1__state_0(1);
		return (bool)1;
	}

IL_003f:
	{
		__this->set_U3CU3E1__state_0((-1));
		goto IL_0064;
	}

IL_0048:
	{
		// yield return layout;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_4 = __this->get_layout_5();
		__this->set_U3CU3E2__current_1(L_4);
		__this->set_U3CU3E1__state_0(2);
		return (bool)1;
	}

IL_005d:
	{
		__this->set_U3CU3E1__state_0((-1));
	}

IL_0064:
	{
		// while (baseLayoutTable.TryGetValue(layout, out layout))
		Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31 * L_5 = __this->get_address_of_U3CU3E4__this_7();
		Dictionary_2_t73978FA6F22330645B7B1FE8A70FFC186726390B * L_6 = L_5->get_baseLayoutTable_4();
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_7 = __this->get_layout_5();
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 * L_8 = __this->get_address_of_layout_5();
		NullCheck(L_6);
		bool L_9;
		L_9 = Dictionary_2_TryGetValue_m13A59E4AB21B1AFCC1D94C66A2F5689DD3DF7C31(L_6, L_7, (InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)L_8, /*hidden argument*/Dictionary_2_TryGetValue_m13A59E4AB21B1AFCC1D94C66A2F5689DD3DF7C31_RuntimeMethod_var);
		if (L_9)
		{
			goto IL_0048;
		}
	}
	{
		// }
		return (bool)0;
	}
}
// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::System.Collections.Generic.IEnumerator<UnityEngine.InputSystem.Utilities.InternedString>.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  U3CGetBaseLayoutsU3Ed__24_System_Collections_Generic_IEnumeratorU3CUnityEngine_InputSystem_Utilities_InternedStringU3E_get_Current_m846A6415F9410B8042B484A77182710EEE3AF42C (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method)
{
	{
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_0 = __this->get_U3CU3E2__current_1();
		return L_0;
	}
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::System.Collections.IEnumerator.Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CGetBaseLayoutsU3Ed__24_System_Collections_IEnumerator_Reset_mEB1025F01E1CDA75A0CD2954359454D42E774E2E (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method)
{
	{
		NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339 * L_0 = (NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339 *)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&NotSupportedException_tB9D89F0E9470A2C423D239D7C68EE0CFD77F9339_il2cpp_TypeInfo_var)));
		NotSupportedException__ctor_m3EA81A5B209A87C3ADA47443F2AFFF735E5256EE(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CGetBaseLayoutsU3Ed__24_System_Collections_IEnumerator_Reset_mEB1025F01E1CDA75A0CD2954359454D42E774E2E_RuntimeMethod_var)));
	}
}
// System.Object UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * U3CGetBaseLayoutsU3Ed__24_System_Collections_IEnumerator_get_Current_mF40676B32D679EEDDC1063A68C7D349E8304DCD8 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_0 = __this->get_U3CU3E2__current_1();
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_1 = L_0;
		RuntimeObject * L_2 = Box(InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4_il2cpp_TypeInfo_var, &L_1);
		return L_2;
	}
}
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.InternedString> UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::System.Collections.Generic.IEnumerable<UnityEngine.InputSystem.Utilities.InternedString>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CGetBaseLayoutsU3Ed__24_System_Collections_Generic_IEnumerableU3CUnityEngine_InputSystem_Utilities_InternedStringU3E_GetEnumerator_m9254F2D4D1437C7746A0CC2C60F0B340D73A2AD3 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * V_0 = NULL;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)((int32_t)-2)))))
		{
			goto IL_0022;
		}
	}
	{
		int32_t L_1 = __this->get_U3CU3El__initialThreadId_2();
		int32_t L_2;
		L_2 = Environment_get_CurrentManagedThreadId_m09DBD4166BFD399056B2F81C77A3A182339BF92D(/*hidden argument*/NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)L_2))))
		{
			goto IL_0022;
		}
	}
	{
		__this->set_U3CU3E1__state_0(0);
		V_0 = __this;
		goto IL_0029;
	}

IL_0022:
	{
		U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * L_3 = (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C *)il2cpp_codegen_object_new(U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C_il2cpp_TypeInfo_var);
		U3CGetBaseLayoutsU3Ed__24__ctor_m1FC80EA631C9A11728DC11205F1C4E2FC6ECE022(L_3, 0, /*hidden argument*/NULL);
		V_0 = L_3;
	}

IL_0029:
	{
		U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * L_4 = V_0;
		Collection_t67F06AF0205E48B75E185C85BE5C7E622D58CE31  L_5 = __this->get_U3CU3E3__U3CU3E4__this_8();
		NullCheck(L_4);
		L_4->set_U3CU3E4__this_7(L_5);
		U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * L_6 = V_0;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_7 = __this->get_U3CU3E3__layout_6();
		NullCheck(L_6);
		L_6->set_layout_5(L_7);
		U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * L_8 = V_0;
		bool L_9 = __this->get_U3CU3E3__includeSelf_4();
		NullCheck(L_8);
		L_8->set_includeSelf_3(L_9);
		U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * L_10 = V_0;
		return L_10;
	}
}
// System.Collections.IEnumerator UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/<GetBaseLayouts>d__24::System.Collections.IEnumerable.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CGetBaseLayoutsU3Ed__24_System_Collections_IEnumerable_GetEnumerator_mD9114DDD9CD3A6B082F7CFA5BDE4A07CCC285381 (U3CGetBaseLayoutsU3Ed__24_t4969BA226D8727B5920F6117694E0E2DC4F7CE8C * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0;
		L_0 = U3CGetBaseLayoutsU3Ed__24_System_Collections_Generic_IEnumerableU3CUnityEngine_InputSystem_Utilities_InternedStringU3E_GetEnumerator_m9254F2D4D1437C7746A0CC2C60F0B340D73A2AD3(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif




// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher
IL2CPP_EXTERN_C void LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshal_pinvoke(const LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C& unmarshaled, LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_pinvoke& marshaled)
{
	Exception_t* ___deviceMatcher_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'deviceMatcher' of type 'LayoutMatcher'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___deviceMatcher_1Exception, NULL);
}
IL2CPP_EXTERN_C void LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshal_pinvoke_back(const LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_pinvoke& marshaled, LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C& unmarshaled)
{
	Exception_t* ___deviceMatcher_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'deviceMatcher' of type 'LayoutMatcher'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___deviceMatcher_1Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher
IL2CPP_EXTERN_C void LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshal_pinvoke_cleanup(LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_pinvoke& marshaled)
{
}




// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher
IL2CPP_EXTERN_C void LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshal_com(const LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C& unmarshaled, LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_com& marshaled)
{
	Exception_t* ___deviceMatcher_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'deviceMatcher' of type 'LayoutMatcher'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___deviceMatcher_1Exception, NULL);
}
IL2CPP_EXTERN_C void LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshal_com_back(const LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_com& marshaled, LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C& unmarshaled)
{
	Exception_t* ___deviceMatcher_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'deviceMatcher' of type 'LayoutMatcher'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___deviceMatcher_1Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/LayoutMatcher
IL2CPP_EXTERN_C void LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshal_com_cleanup(LayoutMatcher_t3D6F641561519AA1AC5B55B372A5228F5795D49C_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout
IL2CPP_EXTERN_C void PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshal_pinvoke(const PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1& unmarshaled, PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_pinvoke& marshaled)
{
	marshaled.___factoryMethod_0 = il2cpp_codegen_marshal_delegate(reinterpret_cast<MulticastDelegate_t*>(unmarshaled.get_factoryMethod_0()));
	marshaled.___metadata_1 = il2cpp_codegen_marshal_string(unmarshaled.get_metadata_1());
}
IL2CPP_EXTERN_C void PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshal_pinvoke_back(const PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_pinvoke& marshaled, PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	unmarshaled.set_factoryMethod_0(il2cpp_codegen_marshal_function_ptr_to_delegate<Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548>(marshaled.___factoryMethod_0, Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548_il2cpp_TypeInfo_var));
	unmarshaled.set_metadata_1(il2cpp_codegen_marshal_string_result(marshaled.___metadata_1));
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout
IL2CPP_EXTERN_C void PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshal_pinvoke_cleanup(PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_marshal_free(marshaled.___metadata_1);
	marshaled.___metadata_1 = NULL;
}
// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout
IL2CPP_EXTERN_C void PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshal_com(const PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1& unmarshaled, PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_com& marshaled)
{
	marshaled.___factoryMethod_0 = il2cpp_codegen_marshal_delegate(reinterpret_cast<MulticastDelegate_t*>(unmarshaled.get_factoryMethod_0()));
	marshaled.___metadata_1 = il2cpp_codegen_marshal_bstring(unmarshaled.get_metadata_1());
}
IL2CPP_EXTERN_C void PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshal_com_back(const PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_com& marshaled, PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	unmarshaled.set_factoryMethod_0(il2cpp_codegen_marshal_function_ptr_to_delegate<Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548>(marshaled.___factoryMethod_0, Func_1_t3787BAF919966A790AF7BC0DF7945FDDFA00F548_il2cpp_TypeInfo_var));
	unmarshaled.set_metadata_1(il2cpp_codegen_marshal_bstring_result(marshaled.___metadata_1));
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputControlLayout/Collection/PrecompiledLayout
IL2CPP_EXTERN_C void PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshal_com_cleanup(PrecompiledLayout_t17F1AC2B93D72A64B9040D908C745B88E21187C1_marshaled_com& marshaled)
{
	il2cpp_codegen_marshal_free_bstring(marshaled.___metadata_1);
	marshaled.___metadata_1 = NULL;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m37EE437E4AF825E96655E031B2B5ACA78D8F8C1D (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * L_0 = (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 *)il2cpp_codegen_object_new(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mFE18172684237870F6DD9CC60FD94D624C0E99D4(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mFE18172684237870F6DD9CC60FD94D624C0E99D4 (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<ToLayout>b__24_0(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  U3CU3Ec_U3CToLayoutU3Eb__24_0_m9E2CBCA16373B68DF4DDD39FCA710E2A53D56092 (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, String_t* ___x0, const RuntimeMethod* method)
{
	{
		// layout.usages = new ReadOnlyArray<InternedString>(usagesList.Select(x => new InternedString(x)).ToArray());
		String_t* L_0 = ___x0;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_1;
		memset((&L_1), 0, sizeof(L_1));
		InternedString__ctor_mB41178458180DD7648D91B2F7865A2C5CC1B1192((&L_1), L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<ToLayout>b__24_1(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  U3CU3Ec_U3CToLayoutU3Eb__24_1_m3CAB935098E97A555DFB5ED9BD7019473B932A6F (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, String_t* ___x0, const RuntimeMethod* method)
{
	{
		// layout.aliases = new ReadOnlyArray<InternedString>(aliasesList.Select(x => new InternedString(x)).ToArray());
		String_t* L_0 = ___x0;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_1;
		memset((&L_1), 0, sizeof(L_1));
		InternedString__ctor_mB41178458180DD7648D91B2F7865A2C5CC1B1192((&L_1), L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<FromControlItems>b__25_0(UnityEngine.InputSystem.Utilities.NamedValue)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CFromControlItemsU3Eb__25_0_mF9DC80421F2CC55CD27D1A837EC7811A9746D1EE (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94  ___x0, const RuntimeMethod* method)
{
	{
		// parameters = string.Join(",", item.parameters.Select(x => x.ToString()).ToArray()),
		String_t* L_0;
		L_0 = NamedValue_ToString_mEE65DA4CA646BCC2F772F24A446983008CECA098((NamedValue_tE0B0EA747A0E5B3A8B18EA5AD69BB7F7F91D1B94 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<FromControlItems>b__25_1(UnityEngine.InputSystem.Utilities.NameAndParameters)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CFromControlItemsU3Eb__25_1_mA27B846BDA5F02E0DDEEF48F127A050B9B79500D (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76  ___x0, const RuntimeMethod* method)
{
	{
		// processors = string.Join(",", item.processors.Select(x => x.ToString()).ToArray()),
		String_t* L_0;
		L_0 = NameAndParameters_ToString_m69852A95F27B6F0593D56932ADD47AA08FD7F775((NameAndParameters_tEBC11C9D51435C0932FBCF5076DE970B4A71EC76 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<FromControlItems>b__25_2(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CFromControlItemsU3Eb__25_2_m3C3D8AB537DAC02FCC18CC34F67B13507DEC8BEE (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___x0, const RuntimeMethod* method)
{
	{
		// usages = item.usages.Select(x => x.ToString()).ToArray(),
		String_t* L_0;
		L_0 = InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItemJson/<>c::<FromControlItems>b__25_3(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CFromControlItemsU3Eb__25_3_m0CC73C7D155D3AD856568F3403318586F6424146 (U3CU3Ec_tB40AD41A6ECE0DD73805B88F483599AB505AE707 * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___x0, const RuntimeMethod* method)
{
	{
		// aliases = item.aliases.Select(x => x.ToString()).ToArray(),
		String_t* L_0;
		L_0 = InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_mA87238172C859B533A38A060A640B2F558C09404 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * L_0 = (U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 *)il2cpp_codegen_object_new(U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mCF1CD4BDB1326CE26CD97C6B1F504983FAF18B97(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mCF1CD4BDB1326CE26CD97C6B1F504983FAF18B97 (U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::<ToLayout>b__14_0(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  U3CU3Ec_U3CToLayoutU3Eb__14_0_mAE08AD229592DF4485AAECB1F2D92CDEDE295856 (U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * __this, String_t* ___x0, const RuntimeMethod* method)
{
	{
		// m_CommonUsages = ArrayHelpers.Select(commonUsages, x => new InternedString(x)),
		String_t* L_0 = ___x0;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_1;
		memset((&L_1), 0, sizeof(L_1));
		InternedString__ctor_mB41178458180DD7648D91B2F7865A2C5CC1B1192((&L_1), L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::<FromLayout>b__15_0(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CFromLayoutU3Eb__15_0_m9F3CC52ABB88DA5E9B3DB083B58D277AF5B3AB4C (U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___x0, const RuntimeMethod* method)
{
	{
		// extendMultiple = layout.m_BaseLayouts.length > 1 ? layout.m_BaseLayouts.ToArray(x => x.ToString()) : null,
		String_t* L_0;
		L_0 = InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String UnityEngine.InputSystem.Layouts.InputControlLayout/LayoutJson/<>c::<FromLayout>b__15_1(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CFromLayoutU3Eb__15_1_m0B5AC753779B946E24144416FAD63E9C8F6CA6D2 (U3CU3Ec_t29E7AD64ADEF14F82C2EF1F5F055AB9D9DA87404 * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___x0, const RuntimeMethod* method)
{
	{
		// commonUsages = ArrayHelpers.Select(layout.m_CommonUsages, x => x.ToString()),
		String_t* L_0;
		L_0 = InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_mD7ACA6959748C6C79FD0CA698C7F6BE751ADE024 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 * L_0 = (U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 *)il2cpp_codegen_object_new(U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_m0887F13BD9B7E5DA9527DB853D4FD6C6F82A52E4(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m0887F13BD9B7E5DA9527DB853D4FD6C6F82A52E4 (U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.String UnityEngine.InputSystem.InputControlPath/ParsedPathComponent/<>c::<get_usages>b__7_0(UnityEngine.InputSystem.Utilities.Substring)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3Cget_usagesU3Eb__7_0_m7F4D64F173C17756936A2E2DDB6D9B9247694A58 (U3CU3Ec_t65EAFFC07AA9A4FDF56B94747ADF0B9F435A7B47 * __this, Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815  ___x0, const RuntimeMethod* method)
{
	{
		// public IEnumerable<string> usages => m_Usages.Select(x => x.ToString());
		String_t* L_0;
		L_0 = Substring_ToString_m937D6E75F4C022340ED2DEDAD848028B3BC9FD2F((Substring_t9AD8D12A00743C9AF2A3E122F51B06CCE4615815 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator
IL2CPP_EXTERN_C void Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshal_pinvoke(const Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98& unmarshaled, Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Enumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
IL2CPP_EXTERN_C void Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshal_pinvoke_back(const Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_pinvoke& marshaled, Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98& unmarshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Enumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator
IL2CPP_EXTERN_C void Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshal_pinvoke_cleanup(Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator
IL2CPP_EXTERN_C void Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshal_com(const Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98& unmarshaled, Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_com& marshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Enumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
IL2CPP_EXTERN_C void Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshal_com_back(const Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_com& marshaled, Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98& unmarshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Enumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator
IL2CPP_EXTERN_C void Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshal_com_cleanup(Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98_marshaled_com& marshaled)
{
}
// System.Boolean UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m69D0FB3FEB02C8B1D1C42A8595BD2D9943156F3D (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method)
{
	{
		// ++m_Index;
		int32_t L_0 = __this->get_m_Index_0();
		__this->set_m_Index_0(((int32_t)il2cpp_codegen_add((int32_t)L_0, (int32_t)1)));
		// return m_Requirements != null && m_Index < m_Requirements.Length;
		DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* L_1 = __this->get_m_Requirements_1();
		if (!L_1)
		{
			goto IL_0027;
		}
	}
	{
		int32_t L_2 = __this->get_m_Index_0();
		DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* L_3 = __this->get_m_Requirements_1();
		NullCheck(L_3);
		return (bool)((((int32_t)L_2) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_3)->max_length)))))? 1 : 0);
	}

IL_0027:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool Enumerator_MoveNext_m69D0FB3FEB02C8B1D1C42A8595BD2D9943156F3D_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * _thisAdjusted = reinterpret_cast<Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 *>(__this + _offset);
	bool _returnValue;
	_returnValue = Enumerator_MoveNext_m69D0FB3FEB02C8B1D1C42A8595BD2D9943156F3D(_thisAdjusted, method);
	return _returnValue;
}
// System.Void UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator_Reset_mB34C8934D0B76650C0CAF3E338E76EBCBAA2DCD9 (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method)
{
	{
		// m_Index = -1;
		__this->set_m_Index_0((-1));
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void Enumerator_Reset_mB34C8934D0B76650C0CAF3E338E76EBCBAA2DCD9_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * _thisAdjusted = reinterpret_cast<Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 *>(__this + _offset);
	Enumerator_Reset_mB34C8934D0B76650C0CAF3E338E76EBCBAA2DCD9(_thisAdjusted, method);
}
// UnityEngine.InputSystem.InputControlScheme/MatchResult/Match UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Match_tF8E25BC160894A799358F44EB19C42365DAF0828  Enumerator_get_Current_m89A82ED8B3FAEF6771859606DADC26A56149B8B2 (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method)
{
	Match_tF8E25BC160894A799358F44EB19C42365DAF0828  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// if (m_Requirements == null || m_Index < 0 || m_Index >= m_Requirements.Length)
		DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* L_0 = __this->get_m_Requirements_1();
		if (!L_0)
		{
			goto IL_0021;
		}
	}
	{
		int32_t L_1 = __this->get_m_Index_0();
		if ((((int32_t)L_1) < ((int32_t)0)))
		{
			goto IL_0021;
		}
	}
	{
		int32_t L_2 = __this->get_m_Index_0();
		DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* L_3 = __this->get_m_Requirements_1();
		NullCheck(L_3);
		if ((((int32_t)L_2) < ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_3)->max_length))))))
		{
			goto IL_002c;
		}
	}

IL_0021:
	{
		// throw new InvalidOperationException("Enumerator is not valid");
		InvalidOperationException_t10D3EE59AD28EC641ACEE05BCA4271A527E5ECAB * L_4 = (InvalidOperationException_t10D3EE59AD28EC641ACEE05BCA4271A527E5ECAB *)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&InvalidOperationException_t10D3EE59AD28EC641ACEE05BCA4271A527E5ECAB_il2cpp_TypeInfo_var)));
		InvalidOperationException__ctor_mC012CE552988309733C896F3FEA8249171E4402E(L_4, ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral670CBAB5C8A30A4C8DC68337B78F13CC30BC704D)), /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Enumerator_get_Current_m89A82ED8B3FAEF6771859606DADC26A56149B8B2_RuntimeMethod_var)));
	}

IL_002c:
	{
		// return new Match
		// {
		//     m_RequirementIndex = m_Index,
		//     m_Requirements = m_Requirements,
		//     m_Controls = m_Controls,
		// };
		il2cpp_codegen_initobj((&V_0), sizeof(Match_tF8E25BC160894A799358F44EB19C42365DAF0828 ));
		int32_t L_5 = __this->get_m_Index_0();
		(&V_0)->set_m_RequirementIndex_0(L_5);
		DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* L_6 = __this->get_m_Requirements_1();
		(&V_0)->set_m_Requirements_1(L_6);
		InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B  L_7 = __this->get_m_Controls_2();
		(&V_0)->set_m_Controls_2(L_7);
		Match_tF8E25BC160894A799358F44EB19C42365DAF0828  L_8 = V_0;
		return L_8;
	}
}
IL2CPP_EXTERN_C  Match_tF8E25BC160894A799358F44EB19C42365DAF0828  Enumerator_get_Current_m89A82ED8B3FAEF6771859606DADC26A56149B8B2_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * _thisAdjusted = reinterpret_cast<Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 *>(__this + _offset);
	Match_tF8E25BC160894A799358F44EB19C42365DAF0828  _returnValue;
	_returnValue = Enumerator_get_Current_m89A82ED8B3FAEF6771859606DADC26A56149B8B2(_thisAdjusted, method);
	return _returnValue;
}
// System.Object UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * Enumerator_System_Collections_IEnumerator_get_Current_m4FF1A3117FCFFC22B6CB53138F563F4E58073499 (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Match_tF8E25BC160894A799358F44EB19C42365DAF0828_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// object IEnumerator.Current => Current;
		Match_tF8E25BC160894A799358F44EB19C42365DAF0828  L_0;
		L_0 = Enumerator_get_Current_m89A82ED8B3FAEF6771859606DADC26A56149B8B2((Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 *)__this, /*hidden argument*/NULL);
		Match_tF8E25BC160894A799358F44EB19C42365DAF0828  L_1 = L_0;
		RuntimeObject * L_2 = Box(Match_tF8E25BC160894A799358F44EB19C42365DAF0828_il2cpp_TypeInfo_var, &L_1);
		return L_2;
	}
}
IL2CPP_EXTERN_C  RuntimeObject * Enumerator_System_Collections_IEnumerator_get_Current_m4FF1A3117FCFFC22B6CB53138F563F4E58073499_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * _thisAdjusted = reinterpret_cast<Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 *>(__this + _offset);
	RuntimeObject * _returnValue;
	_returnValue = Enumerator_System_Collections_IEnumerator_get_Current_m4FF1A3117FCFFC22B6CB53138F563F4E58073499(_thisAdjusted, method);
	return _returnValue;
}
// System.Void UnityEngine.InputSystem.InputControlScheme/MatchResult/Enumerator::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator_Dispose_mD6FB640B4C4F656F1D7F0235C4AC4B378681F99B (Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * __this, const RuntimeMethod* method)
{
	{
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void Enumerator_Dispose_mD6FB640B4C4F656F1D7F0235C4AC4B378681F99B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 * _thisAdjusted = reinterpret_cast<Enumerator_tF23097815E3B61674F14B59DD45351C1E0D78B98 *>(__this + _offset);
	Enumerator_Dispose_mD6FB640B4C4F656F1D7F0235C4AC4B378681F99B(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Match
IL2CPP_EXTERN_C void Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshal_pinvoke(const Match_tF8E25BC160894A799358F44EB19C42365DAF0828& unmarshaled, Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Match'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
IL2CPP_EXTERN_C void Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshal_pinvoke_back(const Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_pinvoke& marshaled, Match_tF8E25BC160894A799358F44EB19C42365DAF0828& unmarshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Match'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Match
IL2CPP_EXTERN_C void Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshal_pinvoke_cleanup(Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Match
IL2CPP_EXTERN_C void Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshal_com(const Match_tF8E25BC160894A799358F44EB19C42365DAF0828& unmarshaled, Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_com& marshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Match'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
IL2CPP_EXTERN_C void Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshal_com_back(const Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_com& marshaled, Match_tF8E25BC160894A799358F44EB19C42365DAF0828& unmarshaled)
{
	Exception_t* ___m_Controls_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Controls' of type 'Match'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Controls_2Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputControlScheme/MatchResult/Match
IL2CPP_EXTERN_C void Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshal_com_cleanup(Match_tF8E25BC160894A799358F44EB19C42365DAF0828_marshaled_com& marshaled)
{
}
// UnityEngine.InputSystem.InputControl UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_control()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * Match_get_control_m741951B4E84AD0E6C303FA8D51D43742918E830B (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&InputControlList_1_get_Item_mB3D2AEA475656D4495707F32D001D2192024A108_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public InputControl control => m_Controls[m_RequirementIndex];
		InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B * L_0 = __this->get_address_of_m_Controls_2();
		int32_t L_1 = __this->get_m_RequirementIndex_0();
		InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * L_2;
		L_2 = InputControlList_1_get_Item_mB3D2AEA475656D4495707F32D001D2192024A108((InputControlList_1_tB75F31059C7CA1C52C28A1270458825F2776428B *)L_0, L_1, /*hidden argument*/InputControlList_1_get_Item_mB3D2AEA475656D4495707F32D001D2192024A108_RuntimeMethod_var);
		return L_2;
	}
}
IL2CPP_EXTERN_C  InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * Match_get_control_m741951B4E84AD0E6C303FA8D51D43742918E830B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * _thisAdjusted = reinterpret_cast<Match_tF8E25BC160894A799358F44EB19C42365DAF0828 *>(__this + _offset);
	InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * _returnValue;
	_returnValue = Match_get_control_m741951B4E84AD0E6C303FA8D51D43742918E830B(_thisAdjusted, method);
	return _returnValue;
}
// UnityEngine.InputSystem.InputDevice UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_device()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * Match_get_device_mFFC18BE3B6939104A5828EE6C57B7EB62B5B8F0A (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method)
{
	InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * G_B2_0 = NULL;
	InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * G_B1_0 = NULL;
	{
		// var control = this.control;
		InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * L_0;
		L_0 = Match_get_control_m741951B4E84AD0E6C303FA8D51D43742918E830B((Match_tF8E25BC160894A799358F44EB19C42365DAF0828 *)__this, /*hidden argument*/NULL);
		// return control?.device;
		InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * L_1 = L_0;
		G_B1_0 = L_1;
		if (L_1)
		{
			G_B2_0 = L_1;
			goto IL_000c;
		}
	}
	{
		return (InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 *)NULL;
	}

IL_000c:
	{
		NullCheck(G_B2_0);
		InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * L_2;
		L_2 = InputControl_get_device_m238E9124B28FCDD64BCB24DD187503F3621B1B03_inline(G_B2_0, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_EXTERN_C  InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * Match_get_device_mFFC18BE3B6939104A5828EE6C57B7EB62B5B8F0A_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * _thisAdjusted = reinterpret_cast<Match_tF8E25BC160894A799358F44EB19C42365DAF0828 *>(__this + _offset);
	InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * _returnValue;
	_returnValue = Match_get_device_mFFC18BE3B6939104A5828EE6C57B7EB62B5B8F0A(_thisAdjusted, method);
	return _returnValue;
}
// System.Int32 UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_requirementIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Match_get_requirementIndex_mD05676A71BCB0583CDC59F9E20C31341048D2519 (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method)
{
	{
		// public int requirementIndex => m_RequirementIndex;
		int32_t L_0 = __this->get_m_RequirementIndex_0();
		return L_0;
	}
}
IL2CPP_EXTERN_C  int32_t Match_get_requirementIndex_mD05676A71BCB0583CDC59F9E20C31341048D2519_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * _thisAdjusted = reinterpret_cast<Match_tF8E25BC160894A799358F44EB19C42365DAF0828 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = Match_get_requirementIndex_mD05676A71BCB0583CDC59F9E20C31341048D2519_inline(_thisAdjusted, method);
	return _returnValue;
}
// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_requirement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  Match_get_requirement_mDEEE98468DF83D46E3ACF11434B8AE6BEC64ED92 (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method)
{
	{
		// public DeviceRequirement requirement => m_Requirements[m_RequirementIndex];
		DeviceRequirementU5BU5D_tBEFA5CADFC07A3A326E46B22E1D3A630F022511F* L_0 = __this->get_m_Requirements_1();
		int32_t L_1 = __this->get_m_RequirementIndex_0();
		NullCheck(L_0);
		int32_t L_2 = L_1;
		DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  L_3 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_2));
		return L_3;
	}
}
IL2CPP_EXTERN_C  DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  Match_get_requirement_mDEEE98468DF83D46E3ACF11434B8AE6BEC64ED92_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * _thisAdjusted = reinterpret_cast<Match_tF8E25BC160894A799358F44EB19C42365DAF0828 *>(__this + _offset);
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  _returnValue;
	_returnValue = Match_get_requirement_mDEEE98468DF83D46E3ACF11434B8AE6BEC64ED92(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean UnityEngine.InputSystem.InputControlScheme/MatchResult/Match::get_isOptional()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Match_get_isOptional_mDC63A63D9D82238E9BD8B3784E05BAACF03F9905 (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method)
{
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// public bool isOptional => requirement.isOptional;
		DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  L_0;
		L_0 = Match_get_requirement_mDEEE98468DF83D46E3ACF11434B8AE6BEC64ED92((Match_tF8E25BC160894A799358F44EB19C42365DAF0828 *)__this, /*hidden argument*/NULL);
		V_0 = L_0;
		bool L_1;
		L_1 = DeviceRequirement_get_isOptional_mEA1639502FEB610CE88F05491A1B1F0FD06CDB55((DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 *)(&V_0), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool Match_get_isOptional_mDC63A63D9D82238E9BD8B3784E05BAACF03F9905_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * _thisAdjusted = reinterpret_cast<Match_tF8E25BC160894A799358F44EB19C42365DAF0828 *>(__this + _offset);
	bool _returnValue;
	_returnValue = Match_get_isOptional_mDC63A63D9D82238E9BD8B3784E05BAACF03F9905(_thisAdjusted, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson
IL2CPP_EXTERN_C void DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshal_pinvoke(const DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB& unmarshaled, DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_pinvoke& marshaled)
{
	marshaled.___devicePath_0 = il2cpp_codegen_marshal_string(unmarshaled.get_devicePath_0());
	marshaled.___isOptional_1 = static_cast<int32_t>(unmarshaled.get_isOptional_1());
	marshaled.___isOR_2 = static_cast<int32_t>(unmarshaled.get_isOR_2());
}
IL2CPP_EXTERN_C void DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshal_pinvoke_back(const DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_pinvoke& marshaled, DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB& unmarshaled)
{
	unmarshaled.set_devicePath_0(il2cpp_codegen_marshal_string_result(marshaled.___devicePath_0));
	bool unmarshaled_isOptional_temp_1 = false;
	unmarshaled_isOptional_temp_1 = static_cast<bool>(marshaled.___isOptional_1);
	unmarshaled.set_isOptional_1(unmarshaled_isOptional_temp_1);
	bool unmarshaled_isOR_temp_2 = false;
	unmarshaled_isOR_temp_2 = static_cast<bool>(marshaled.___isOR_2);
	unmarshaled.set_isOR_2(unmarshaled_isOR_temp_2);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson
IL2CPP_EXTERN_C void DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshal_pinvoke_cleanup(DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_marshal_free(marshaled.___devicePath_0);
	marshaled.___devicePath_0 = NULL;
}
// Conversion methods for marshalling of: UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson
IL2CPP_EXTERN_C void DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshal_com(const DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB& unmarshaled, DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_com& marshaled)
{
	marshaled.___devicePath_0 = il2cpp_codegen_marshal_bstring(unmarshaled.get_devicePath_0());
	marshaled.___isOptional_1 = static_cast<int32_t>(unmarshaled.get_isOptional_1());
	marshaled.___isOR_2 = static_cast<int32_t>(unmarshaled.get_isOR_2());
}
IL2CPP_EXTERN_C void DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshal_com_back(const DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_com& marshaled, DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB& unmarshaled)
{
	unmarshaled.set_devicePath_0(il2cpp_codegen_marshal_bstring_result(marshaled.___devicePath_0));
	bool unmarshaled_isOptional_temp_1 = false;
	unmarshaled_isOptional_temp_1 = static_cast<bool>(marshaled.___isOptional_1);
	unmarshaled.set_isOptional_1(unmarshaled_isOptional_temp_1);
	bool unmarshaled_isOR_temp_2 = false;
	unmarshaled_isOR_temp_2 = static_cast<bool>(marshaled.___isOR_2);
	unmarshaled.set_isOR_2(unmarshaled_isOR_temp_2);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson
IL2CPP_EXTERN_C void DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshal_com_cleanup(DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB_marshaled_com& marshaled)
{
	il2cpp_codegen_marshal_free_bstring(marshaled.___devicePath_0);
	marshaled.___devicePath_0 = NULL;
}
// UnityEngine.InputSystem.InputControlScheme/DeviceRequirement UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson::ToDeviceEntry()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  DeviceJson_ToDeviceEntry_m3274EB04F6EB5F9A70A918B51FCFBC3B6A206416 (DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB * __this, const RuntimeMethod* method)
{
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// return new DeviceRequirement
		// {
		//     controlPath = devicePath,
		//     isOptional = isOptional,
		//     isOR = isOR,
		// };
		il2cpp_codegen_initobj((&V_0), sizeof(DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 ));
		String_t* L_0 = __this->get_devicePath_0();
		DeviceRequirement_set_controlPath_mAE0850C485197021FD454C20922F00322370908E_inline((DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 *)(&V_0), L_0, /*hidden argument*/NULL);
		bool L_1 = __this->get_isOptional_1();
		DeviceRequirement_set_isOptional_mE5FA29C2E76F1922119F087C72FA8B9772A44CFE((DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 *)(&V_0), L_1, /*hidden argument*/NULL);
		bool L_2 = __this->get_isOR_2();
		DeviceRequirement_set_isOR_m367881FA1B119F181ED68BDBF34A8148C79C7BC6((DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 *)(&V_0), L_2, /*hidden argument*/NULL);
		DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  L_3 = V_0;
		return L_3;
	}
}
IL2CPP_EXTERN_C  DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  DeviceJson_ToDeviceEntry_m3274EB04F6EB5F9A70A918B51FCFBC3B6A206416_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB * _thisAdjusted = reinterpret_cast<DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB *>(__this + _offset);
	DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  _returnValue;
	_returnValue = DeviceJson_ToDeviceEntry_m3274EB04F6EB5F9A70A918B51FCFBC3B6A206416(_thisAdjusted, method);
	return _returnValue;
}
// UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson UnityEngine.InputSystem.InputControlScheme/SchemeJson/DeviceJson::From(UnityEngine.InputSystem.InputControlScheme/DeviceRequirement)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB  DeviceJson_From_mE7DAC914B38ACA350DBDAADA6B9F372B1ABBC21E (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807  ___requirement0, const RuntimeMethod* method)
{
	DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// return new DeviceJson
		// {
		//     devicePath = requirement.controlPath,
		//     isOptional = requirement.isOptional,
		//     isOR = requirement.isOR,
		// };
		il2cpp_codegen_initobj((&V_0), sizeof(DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB ));
		String_t* L_0;
		L_0 = DeviceRequirement_get_controlPath_m30D76119C4E712E3177B17FF34359FD3426601DC_inline((DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 *)(&___requirement0), /*hidden argument*/NULL);
		(&V_0)->set_devicePath_0(L_0);
		bool L_1;
		L_1 = DeviceRequirement_get_isOptional_mEA1639502FEB610CE88F05491A1B1F0FD06CDB55((DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 *)(&___requirement0), /*hidden argument*/NULL);
		(&V_0)->set_isOptional_1(L_1);
		bool L_2;
		L_2 = DeviceRequirement_get_isOR_m2B8AA0404E45B881E709118077376043762DEE36((DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 *)(&___requirement0), /*hidden argument*/NULL);
		(&V_0)->set_isOR_2(L_2);
		DeviceJson_t8FCA05F72BA4628BB8EF910ECACD22AD8288AAAB  L_3 = V_0;
		return L_3;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability
IL2CPP_EXTERN_C void Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshal_pinvoke(const Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0& unmarshaled, Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_pinvoke& marshaled)
{
	marshaled.___path_0 = il2cpp_codegen_marshal_string(unmarshaled.get_path_0());
	marshaled.___value_1 = il2cpp_codegen_marshal_string(unmarshaled.get_value_1());
}
IL2CPP_EXTERN_C void Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshal_pinvoke_back(const Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_pinvoke& marshaled, Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0& unmarshaled)
{
	unmarshaled.set_path_0(il2cpp_codegen_marshal_string_result(marshaled.___path_0));
	unmarshaled.set_value_1(il2cpp_codegen_marshal_string_result(marshaled.___value_1));
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability
IL2CPP_EXTERN_C void Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshal_pinvoke_cleanup(Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_marshal_free(marshaled.___path_0);
	marshaled.___path_0 = NULL;
	il2cpp_codegen_marshal_free(marshaled.___value_1);
	marshaled.___value_1 = NULL;
}
// Conversion methods for marshalling of: UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability
IL2CPP_EXTERN_C void Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshal_com(const Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0& unmarshaled, Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_com& marshaled)
{
	marshaled.___path_0 = il2cpp_codegen_marshal_bstring(unmarshaled.get_path_0());
	marshaled.___value_1 = il2cpp_codegen_marshal_bstring(unmarshaled.get_value_1());
}
IL2CPP_EXTERN_C void Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshal_com_back(const Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_com& marshaled, Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0& unmarshaled)
{
	unmarshaled.set_path_0(il2cpp_codegen_marshal_bstring_result(marshaled.___path_0));
	unmarshaled.set_value_1(il2cpp_codegen_marshal_bstring_result(marshaled.___value_1));
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.Layouts.InputDeviceMatcher/MatcherJson/Capability
IL2CPP_EXTERN_C void Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshal_com_cleanup(Capability_t92A3914CC1920EA279F50DCEC2F84B67C79AFDF0_marshaled_com& marshaled)
{
	il2cpp_codegen_marshal_free_bstring(marshaled.___path_0);
	marshaled.___path_0 = NULL;
	il2cpp_codegen_marshal_free_bstring(marshaled.___value_1);
	marshaled.___value_1 = NULL;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_mCDCDD2844BDABE99A9A561773F20CA69FDFD5803 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD * L_0 = (U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD *)il2cpp_codegen_object_new(U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_m8D6B5CDB7AB6575EF56554F078F4B67254D974A1(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m8D6B5CDB7AB6575EF56554F078F4B67254D974A1 (U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Int32 UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c::<PlayAllEventsAccordingToTimestamps>b__38_0(UnityEngine.InputSystem.LowLevel.InputEventPtr,UnityEngine.InputSystem.LowLevel.InputEventPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t U3CU3Ec_U3CPlayAllEventsAccordingToTimestampsU3Eb__38_0_mB503C0ADF0AF7341A139547C6FABF43EB069DA01 (U3CU3Ec_tC2508F22F5AD40EC6BF0031F7495A145831ACCAD * __this, InputEventPtr_tDF9E84E7EAFF138A0A830345C72B2CD5885577B5  ___a0, InputEventPtr_tDF9E84E7EAFF138A0A830345C72B2CD5885577B5  ___b1, const RuntimeMethod* method)
{
	double V_0 = 0.0;
	{
		// eventsByTime.Sort((a, b) => a.time.CompareTo(b.time));
		double L_0;
		L_0 = InputEventPtr_get_time_m05F48852D2AD3907919F7B3931F195F1AEB62F06((InputEventPtr_tDF9E84E7EAFF138A0A830345C72B2CD5885577B5 *)(&___a0), /*hidden argument*/NULL);
		V_0 = L_0;
		double L_1;
		L_1 = InputEventPtr_get_time_m05F48852D2AD3907919F7B3931F195F1AEB62F06((InputEventPtr_tDF9E84E7EAFF138A0A830345C72B2CD5885577B5 *)(&___b1), /*hidden argument*/NULL);
		int32_t L_2;
		L_2 = Double_CompareTo_m93107F1616A67C9CDB540738E0115A5E668FBBBE((double*)(&V_0), L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c__DisplayClass43_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass43_0__ctor_mA2B2F482F64C07330E21AE9DABF6A16C3B9A4CE4 (U3CU3Ec__DisplayClass43_0_tD15BBA4A7D46373705B077359CCBC1214B7E4D70 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean UnityEngine.InputSystem.LowLevel.InputEventTrace/ReplayController/<>c__DisplayClass43_0::<ApplyDeviceMapping>b__0(UnityEngine.InputSystem.LowLevel.InputEventTrace/DeviceInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass43_0_U3CApplyDeviceMappingU3Eb__0_mAF4CAC0A251424472517815EA3790B7CDC5F996C (U3CU3Ec__DisplayClass43_0_tD15BBA4A7D46373705B077359CCBC1214B7E4D70 * __this, DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D  ___x0, const RuntimeMethod* method)
{
	{
		// var deviceIndex = m_EventTrace.deviceInfos.IndexOf(x => x.deviceId == originalDeviceId);
		int32_t L_0;
		L_0 = DeviceInfo_get_deviceId_m2B26439F4A8C1BAAECA5DFFC538B6F675F877988_inline((DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D *)(&___x0), /*hidden argument*/NULL);
		int32_t L_1 = __this->get_originalDeviceId_0();
		return (bool)((((int32_t)L_0) == ((int32_t)L_1))? 1 : 0);
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m7D4CE624B396AA61A00BEDBACEB1605CBD50A934 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A * L_0 = (U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A *)il2cpp_codegen_object_new(U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_m64EE0F8705120CC7B1EDB9801FFE4774B7A6A625(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m64EE0F8705120CC7B1EDB9801FFE4774B7A6A625 (U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.String UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/<>c::<Create>b__1_0(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CCreateU3Eb__1_0_m40AFE999DA4023EE666C96D870269159C627B92C (U3CU3Ec_t44E3A06027AFBCADE6CBAD1EEEFD58E9E292BB5A * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___x0, const RuntimeMethod* method)
{
	{
		// usages = device.usages.Select(x => x.ToString()).ToArray()
		String_t* L_0;
		L_0 = InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data
IL2CPP_EXTERN_C void Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshal_pinvoke(const Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501& unmarshaled, Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_pinvoke& marshaled)
{
	Exception_t* ___usages_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_1Exception, NULL);
}
IL2CPP_EXTERN_C void Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshal_pinvoke_back(const Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_pinvoke& marshaled, Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501& unmarshaled)
{
	Exception_t* ___usages_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_1Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data
IL2CPP_EXTERN_C void Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshal_pinvoke_cleanup(Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data
IL2CPP_EXTERN_C void Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshal_com(const Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501& unmarshaled, Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_com& marshaled)
{
	Exception_t* ___usages_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_1Exception, NULL);
}
IL2CPP_EXTERN_C void Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshal_com_back(const Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_com& marshaled, Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501& unmarshaled)
{
	Exception_t* ___usages_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_1Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputRemoting/ChangeUsageMsg/Data
IL2CPP_EXTERN_C void Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshal_com_cleanup(Data_t72B75C4AEC8570678159F5B0E87DD223F97A5501_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_mD47745319D302770F9E853E1D39341A2CCFEB47B (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 * L_0 = (U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 *)il2cpp_codegen_object_new(U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_m6F681E0D4BEAA97DBC3AC40A8C282FE61FEE0BC6(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m6F681E0D4BEAA97DBC3AC40A8C282FE61FEE0BC6 (U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.String UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/<>c::<Create>b__1_0(UnityEngine.InputSystem.Utilities.InternedString)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CCreateU3Eb__1_0_m723C2C03C4BAE49B30653BEA2D9175737C42803B (U3CU3Ec_tEA17A6DE2D52094E510B56FB026696C65F59F5F8 * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___x0, const RuntimeMethod* method)
{
	{
		// usages = device.usages.Select(x => x.ToString()).ToArray()
		String_t* L_0;
		L_0 = InternedString_ToString_m30B19358C5535B59AE379ACEFCF5F9B706B0BCAC((InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4 *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data
IL2CPP_EXTERN_C void Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshal_pinvoke(const Data_t41908F253A54212287E75BDC32214CC67A6E46E5& unmarshaled, Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_pinvoke& marshaled)
{
	Exception_t* ___usages_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_3Exception, NULL);
}
IL2CPP_EXTERN_C void Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshal_pinvoke_back(const Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_pinvoke& marshaled, Data_t41908F253A54212287E75BDC32214CC67A6E46E5& unmarshaled)
{
	Exception_t* ___usages_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_3Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data
IL2CPP_EXTERN_C void Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshal_pinvoke_cleanup(Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data
IL2CPP_EXTERN_C void Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshal_com(const Data_t41908F253A54212287E75BDC32214CC67A6E46E5& unmarshaled, Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_com& marshaled)
{
	Exception_t* ___usages_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_3Exception, NULL);
}
IL2CPP_EXTERN_C void Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshal_com_back(const Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_com& marshaled, Data_t41908F253A54212287E75BDC32214CC67A6E46E5& unmarshaled)
{
	Exception_t* ___usages_3Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'usages' of type 'Data'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___usages_3Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputRemoting/NewDeviceMsg/Data
IL2CPP_EXTERN_C void Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshal_com_cleanup(Data_t41908F253A54212287E75BDC32214CC67A6E46E5_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data
IL2CPP_EXTERN_C void Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshal_pinvoke(const Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C& unmarshaled, Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_pinvoke& marshaled)
{
	marshaled.___name_0 = il2cpp_codegen_marshal_string(unmarshaled.get_name_0());
	marshaled.___layoutJson_1 = il2cpp_codegen_marshal_string(unmarshaled.get_layoutJson_1());
	marshaled.___isOverride_2 = static_cast<int32_t>(unmarshaled.get_isOverride_2());
}
IL2CPP_EXTERN_C void Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshal_pinvoke_back(const Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_pinvoke& marshaled, Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C& unmarshaled)
{
	unmarshaled.set_name_0(il2cpp_codegen_marshal_string_result(marshaled.___name_0));
	unmarshaled.set_layoutJson_1(il2cpp_codegen_marshal_string_result(marshaled.___layoutJson_1));
	bool unmarshaled_isOverride_temp_2 = false;
	unmarshaled_isOverride_temp_2 = static_cast<bool>(marshaled.___isOverride_2);
	unmarshaled.set_isOverride_2(unmarshaled_isOverride_temp_2);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data
IL2CPP_EXTERN_C void Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshal_pinvoke_cleanup(Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_marshal_free(marshaled.___name_0);
	marshaled.___name_0 = NULL;
	il2cpp_codegen_marshal_free(marshaled.___layoutJson_1);
	marshaled.___layoutJson_1 = NULL;
}
// Conversion methods for marshalling of: UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data
IL2CPP_EXTERN_C void Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshal_com(const Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C& unmarshaled, Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_com& marshaled)
{
	marshaled.___name_0 = il2cpp_codegen_marshal_bstring(unmarshaled.get_name_0());
	marshaled.___layoutJson_1 = il2cpp_codegen_marshal_bstring(unmarshaled.get_layoutJson_1());
	marshaled.___isOverride_2 = static_cast<int32_t>(unmarshaled.get_isOverride_2());
}
IL2CPP_EXTERN_C void Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshal_com_back(const Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_com& marshaled, Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C& unmarshaled)
{
	unmarshaled.set_name_0(il2cpp_codegen_marshal_bstring_result(marshaled.___name_0));
	unmarshaled.set_layoutJson_1(il2cpp_codegen_marshal_bstring_result(marshaled.___layoutJson_1));
	bool unmarshaled_isOverride_temp_2 = false;
	unmarshaled_isOverride_temp_2 = static_cast<bool>(marshaled.___isOverride_2);
	unmarshaled.set_isOverride_2(unmarshaled_isOverride_temp_2);
}
// Conversion method for clean up from marshalling of: UnityEngine.InputSystem.InputRemoting/NewLayoutMsg/Data
IL2CPP_EXTERN_C void Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshal_com_cleanup(Data_t303CFBB2174C3D2691359B89C75913696C0F7F9C_marshaled_com& marshaled)
{
	il2cpp_codegen_marshal_free_bstring(marshaled.___name_0);
	marshaled.___name_0 = NULL;
	il2cpp_codegen_marshal_free_bstring(marshaled.___layoutJson_1);
	marshaled.___layoutJson_1 = NULL;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m48338E6A8D0BBD50F5D36FB152054E6A2D52F447 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * L_0 = (U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB *)il2cpp_codegen_object_new(U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mE375B98801D8D5A008F73076C87EB9FFEBD7408F(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mE375B98801D8D5A008F73076C87EB9FFEBD7408F (U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.String UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::<ToString>b__11_0(UnityEngine.InputSystem.Utilities.JsonParser/JsonValue)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CToStringU3Eb__11_0_mF53035C86AC93893E270BDAE6D84B655EFBB8F77 (U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * __this, JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  ___x0, const RuntimeMethod* method)
{
	{
		// return $"[{string.Join(",", arrayValue.Select(x => x.ToString()))}]";
		String_t* L_0;
		L_0 = JsonValue_ToString_mFC3514B762B6CB76975CD44B57E4EBC3850A055E((JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F *)(&___x0), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String UnityEngine.InputSystem.Utilities.JsonParser/JsonValue/<>c::<ToString>b__11_1(System.Collections.Generic.KeyValuePair`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* U3CU3Ec_U3CToStringU3Eb__11_1_mEF2846F2AB93F5EE8F7B871FD126D60540E78B53 (U3CU3Ec_t93814AC1EFFB8FE3F25E56FECD0DA0A332FAF2EB * __this, KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45  ___pair0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&KeyValuePair_2_get_Key_m0981E567B61168C690B6342E523A320D15BC6949_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&KeyValuePair_2_get_Value_mBBA0D76AE55EE865EADCB26991005D244E481AFF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral987DBAD62F58327E403CC7854409712A13BD33B8);
		s_Il2CppMethodInitialized = true;
	}
	{
		// var elements = objectValue.Select(pair => $"\"{pair.Key}\" : \"{pair.Value}\"");
		String_t* L_0;
		L_0 = KeyValuePair_2_get_Key_m0981E567B61168C690B6342E523A320D15BC6949_inline((KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45 *)(&___pair0), /*hidden argument*/KeyValuePair_2_get_Key_m0981E567B61168C690B6342E523A320D15BC6949_RuntimeMethod_var);
		JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  L_1;
		L_1 = KeyValuePair_2_get_Value_mBBA0D76AE55EE865EADCB26991005D244E481AFF_inline((KeyValuePair_2_t2BC9E76B947C237AE5C3075FA4B848A2A8BA3E45 *)(&___pair0), /*hidden argument*/KeyValuePair_2_get_Value_mBBA0D76AE55EE865EADCB26991005D244E481AFF_RuntimeMethod_var);
		JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  L_2 = L_1;
		RuntimeObject * L_3 = Box(JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F_il2cpp_TypeInfo_var, &L_2);
		String_t* L_4;
		L_4 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral987DBAD62F58327E403CC7854409712A13BD33B8, L_0, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m46B55D78D97DAB7BC5CC08904035EAB358336022 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * L_0 = (U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 *)il2cpp_codegen_object_new(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mBF2B08D9F34A2B44F8CD488BBAD9C35257282B39(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mBF2B08D9F34A2B44F8CD488BBAD9C35257282B39 (U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// UnityEngine.InputSystem.Utilities.InternedString UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder/<>c::<WithUsages>b__14_0(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  U3CU3Ec_U3CWithUsagesU3Eb__14_0_m8ED6A0DFF67848D3FB546D919E9B8987D9D7DB78 (U3CU3Ec_tAAD27CE7D90EC934343E962EB8E26F9AE62531E3 * __this, String_t* ___x0, const RuntimeMethod* method)
{
	{
		// var usagesArray = usages.Select(x => new InternedString(x)).ToArray();
		String_t* L_0 = ___x0;
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_1;
		memset((&L_1), 0, sizeof(L_1));
		InternedString__ctor_mB41178458180DD7648D91B2F7865A2C5CC1B1192((&L_1), L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool ButtonState_get_isPressed_mC20A08312DF96CA0D5D6657ADC4FFD4880B28DE0_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_IsPressed;
		bool L_0 = __this->get_m_IsPressed_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool ButtonState_get_ignoreNextClick_m6304EB764807405EF59F964BB0BDA6117F919D45_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_IgnoreNextClick;
		bool L_0 = __this->get_m_IgnoreNextClick_13();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ButtonState_set_ignoreNextClick_mE0FE305F262ED710FCFC9DF5A4C7B115476AB26D_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// set => m_IgnoreNextClick = value;
		bool L_0 = ___value0;
		__this->set_m_IgnoreNextClick_13(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float ButtonState_get_pressTime_m214D6D781C6F581CBF781A9620A6C10239A096BD_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_PressTime;
		float L_0 = __this->get_m_PressTime_2();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ButtonState_set_pressTime_m43CEEA0944E6A2D87CB763FBD333FA8679829E27_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		// set => m_PressTime = value;
		float L_0 = ___value0;
		__this->set_m_PressTime_2(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool ButtonState_get_clickedOnSameGameObject_mE95BA21860C122BD01C8A314CA27381288D015F3_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, const RuntimeMethod* method)
{
	{
		// get => m_ClickedOnSameGameObject;
		bool L_0 = __this->get_m_ClickedOnSameGameObject_12();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ButtonState_set_clickedOnSameGameObject_m3F29C95CA8EAECC108C2BF571FFFF5744FBA1A87_inline (ButtonState_t4727048C78E1FF3FB94DC6DBF701752D9B592248 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// set => m_ClickedOnSameGameObject = value;
		bool L_0 = ___value0;
		__this->set_m_ClickedOnSameGameObject_12(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_pointerPressRaycast_mAF28B12216468A02DACA9900B0A57FA1BF3B94F4_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  ___value0, const RuntimeMethod* method)
{
	{
		// public RaycastResult pointerPressRaycast { get; set; }
		RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  L_0 = ___value0;
		__this->set_U3CpointerPressRaycastU3Ek__BackingField_9(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_pressPosition_mE644EE1603DFF2087224FF6364EA0204D04D7939_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___value0, const RuntimeMethod* method)
{
	{
		// public Vector2 pressPosition { get; set; }
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_0 = ___value0;
		__this->set_U3CpressPositionU3Ek__BackingField_15(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_clickCount_m2EAAB7F43CE26BF505B7FCF7D509C988DCFD7F28_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public int clickCount { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CclickCountU3Ek__BackingField_19(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_clickTime_m215E254F8585FFC518E3161FAF9137388F64AC58_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, float ___value0, const RuntimeMethod* method)
{
	{
		// public float clickTime { get; set; }
		float L_0 = ___value0;
		__this->set_U3CclickTimeU3Ek__BackingField_18(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_rawPointerPress_m0BEEB9CA5E44F570C2C0803553BA9736F4DF58F0_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___value0, const RuntimeMethod* method)
{
	{
		// public GameObject rawPointerPress { get; set; }
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = ___value0;
		__this->set_U3CrawPointerPressU3Ek__BackingField_5(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_pointerDrag_m2E9F059EC1CDF71E0A097A0D3CCBA564E0C463C2_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * ___value0, const RuntimeMethod* method)
{
	{
		// public GameObject pointerDrag { get; set; }
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = ___value0;
		__this->set_U3CpointerDragU3Ek__BackingField_6(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_dragging_mEB739C44F1B1848B4B3F4E7FBB9B376587C2C7E1_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool dragging { get; set; }
		bool L_0 = ___value0;
		__this->set_U3CdraggingU3Ek__BackingField_22(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void PointerEventData_set_eligibleForClick_m5CFAF671C2B33AF8E9153FA4826D93B9308C4C07_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool eligibleForClick { get; set; }
		bool L_0 = ___value0;
		__this->set_U3CeligibleForClickU3Ek__BackingField_11(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  PointerEventData_get_pointerPressRaycast_m3C5785CD2C31F91C91D6F1084D2EAC31BED56ACB_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public RaycastResult pointerPressRaycast { get; set; }
		RaycastResult_t9EFDE24B29650BD6DC8A49D954A3769E17146BCE  L_0 = __this->get_U3CpointerPressRaycastU3Ek__BackingField_9();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_pointerPress_mB55C5528AF445DB7B912086E43F0BCD9CDFF409C_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// get { return m_PointerPress; }
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = __this->get_m_PointerPress_3();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_rawPointerPress_m0C23DB50BCE28ECC43609CC01E727CCA77FC6473_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public GameObject rawPointerPress { get; set; }
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = __this->get_U3CrawPointerPressU3Ek__BackingField_5();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_lastPress_m362C5876B8C9F50BACC27D9026DB3709D6950C0B_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public GameObject lastPress { get; private set; }
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = __this->get_U3ClastPressU3Ek__BackingField_4();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  PointerEventData_get_pressPosition_mB8F60EB21F6E6892EC731382614BAB85E29ED642_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public Vector2 pressPosition { get; set; }
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_0 = __this->get_U3CpressPositionU3Ek__BackingField_15();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float PointerEventData_get_clickTime_m08F7FD164EFE2AE7B47A15C70BC418632B9E5950_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public float clickTime { get; set; }
		float L_0 = __this->get_U3CclickTimeU3Ek__BackingField_18();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t PointerEventData_get_clickCount_mB44AAB99335BD7D2BD93E40DAC282A56202E44F2_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public int clickCount { get; set; }
		int32_t L_0 = __this->get_U3CclickCountU3Ek__BackingField_19();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * PointerEventData_get_pointerDrag_m5FD1D758CA629D9EBB8BDA3207132BC9BAB91ACE_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public GameObject pointerDrag { get; set; }
		GameObject_tC000A2E1A7CF1E10FD7BA08863287C072207C319 * L_0 = __this->get_U3CpointerDragU3Ek__BackingField_6();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool PointerEventData_get_dragging_m7FD3F5D4D8DAC559A57EDB88F2B2B5DEA4B48266_inline (PointerEventData_tC6C1BEE9D4C8755A31DA7FC0C9A1F28A36456954 * __this, const RuntimeMethod* method)
{
	{
		// public bool dragging { get; set; }
		bool L_0 = __this->get_U3CdraggingU3Ek__BackingField_22();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m129FC0ADA02FECBED3C0B1A809AE84A5AEE1CF09_inline (String_t* __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_m_stringLength_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  Touchscreen_get_touches_m67B46B544F3DF685C9571FF2B8DA890C9393D79C_inline (Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * __this, const RuntimeMethod* method)
{
	{
		// public ReadOnlyArray<TouchControl> touches { get; protected set; }
		ReadOnlyArray_1_tEE51974BFAB2F16B8BA1FB827AD085BAA18D89B3  L_0 = __this->get_U3CtouchesU3Ek__BackingField_46();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * Finger_get_screen_mAF59662CC55478F9F668A5E77F1488A346A213B0_inline (Finger_t8C3F95C202B41127D4B0C5953AE1814681413DE2 * __this, const RuntimeMethod* method)
{
	{
		// public Touchscreen screen { get; }
		Touchscreen_t433AC261149F9B791183C983B061A2CB7CF7C0B9 * L_0 = __this->get_U3CscreenU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t InputStateHistory_get_Count_m41CC7BFF6BC7537C9F9E04D89DCBB212A445A402_inline (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method)
{
	{
		// public int Count => m_RecordCount;
		int32_t L_0 = __this->get_m_RecordCount_7();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t InputStateHistory_get_extraMemoryPerRecord_mD6523D549A81F0C20141E60B706AEE6D12FC4CD0_inline (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method)
{
	{
		// get => m_ExtraMemoryPerRecord;
		int32_t L_0 = __this->get_m_ExtraMemoryPerRecord_9();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t InputStateHistory_get_historyDepth_m232556B5AE37A9388BB37FE3BDA80B6DFF4F94F8_inline (InputStateHistory_tDE8523D6B1A763393B633A707620864ADA09B05E * __this, const RuntimeMethod* method)
{
	{
		// get => m_HistoryDepth;
		int32_t L_0 = __this->get_m_HistoryDepth_8();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t TouchState_get_phase_mEBFCF4562A1F6A77357D9EEBD2579983B23F713B_inline (TouchState_tDCCE90D9D69C89BF4DE60A86BFBDEFFA7063B2E8 * __this, const RuntimeMethod* method)
{
	{
		// get => (TouchPhase)phaseId;
		uint8_t L_0 = __this->get_phaseId_6();
		return (int32_t)(L_0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t TouchHistory_get_Count_m54E34D6C03893752E6B905F728CAEF691F3FE779_inline (TouchHistory_tE5E862D47C21907055788C897D691061F2256F0D * __this, const RuntimeMethod* method)
{
	{
		// public int Count => m_Count;
		int32_t L_0 = __this->get_m_Count_2();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * RaycastHitData_get_graphic_m91A6519C0A0B9D40F6FD92744D73814912FB11BC_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public Graphic graphic { get; }
		Graphic_tF07D777035055CF93BA5F46F77ED5EDFEFF9AE24 * L_0 = __this->get_U3CgraphicU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  RaycastHitData_get_worldHitPosition_mC9C5845797C171788CF76B2CBB32837645157CC2_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public Vector3 worldHitPosition { get; }
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0 = __this->get_U3CworldHitPositionU3Ek__BackingField_1();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  RaycastHitData_get_screenPosition_m6645B3B1991CF259946A1EF12953F3FC8CDFA496_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public Vector2 screenPosition { get; }
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_0 = __this->get_U3CscreenPositionU3Ek__BackingField_2();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float RaycastHitData_get_distance_m491A785927DD2A56D4735115B9301CF01595112F_inline (RaycastHitData_tF9901BAC4938F45BF4E7DCC9DBA48673B8B27AB1 * __this, const RuntimeMethod* method)
{
	{
		// public float distance { get; }
		float L_0 = __this->get_U3CdistanceU3Ek__BackingField_3();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ControlItem_get_name_mCE0AD0DE297C87588F201396EDA1C92C0120CAD5_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, const RuntimeMethod* method)
{
	{
		// public InternedString name { get; internal set; }
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_0 = __this->get_U3CnameU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* InputControlScheme_get_bindingGroup_mDBCE86B56691F2942296D6D1AE0D5ADB3194F0ED_inline (InputControlScheme_tEC3828C076819E78DC5620AC154211EE72F08288 * __this, const RuntimeMethod* method)
{
	{
		// get => m_BindingGroup;
		String_t* L_0 = __this->get_m_BindingGroup_1();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_displayName_mB29B2CA5BDF6A4617795C5CD01FD2AD5DA17AE8A_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// public string displayName { get; internal set; }
		String_t* L_0 = ___value0;
		__this->set_U3CdisplayNameU3Ek__BackingField_4(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_layout_m120160AE002A158CA9EDCA62BF8201D27F4E838C_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  ___value0, const RuntimeMethod* method)
{
	{
		// public InternedString layout { get; internal set; }
		InternedString_t01D20018001F1112F6D24F765D888CA7E8DCF0B4  L_0 = ___value0;
		__this->set_U3ClayoutU3Ek__BackingField_1(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_format_mE749BC629174FFC3153C1A077972A5A796CCB003_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  ___value0, const RuntimeMethod* method)
{
	{
		// public FourCC format { get; internal set; }
		FourCC_tBEC8228886DFE3C6BC4C72B4500954E34FB99D5A  L_0 = ___value0;
		__this->set_U3CformatU3Ek__BackingField_13(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_offset_m3311619100F27C22CAF2EB2FE8B8E5BD42B4486B_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, uint32_t ___value0, const RuntimeMethod* method)
{
	{
		// public uint offset { get; internal set; }
		uint32_t L_0 = ___value0;
		__this->set_U3CoffsetU3Ek__BackingField_10(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_bit_m18990DBD5680FC858B52DCA931E21C3383809265_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, uint32_t ___value0, const RuntimeMethod* method)
{
	{
		// public uint bit { get; internal set; }
		uint32_t L_0 = ___value0;
		__this->set_U3CbitU3Ek__BackingField_11(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_sizeInBits_m8F4F28F7ED19B693DE210492DA15EAEE6C8EB543_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, uint32_t ___value0, const RuntimeMethod* method)
{
	{
		// public uint sizeInBits { get; internal set; }
		uint32_t L_0 = ___value0;
		__this->set_U3CsizeInBitsU3Ek__BackingField_12(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_minValue_mAB7186D561C1E98CBFBAFE17A00A0F177B20171D_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method)
{
	{
		// public PrimitiveValue minValue { get; internal set; }
		PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  L_0 = ___value0;
		__this->set_U3CminValueU3Ek__BackingField_17(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_maxValue_mBE618291D3CBE215F4ADF8B16D33735618D89E8E_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method)
{
	{
		// public PrimitiveValue maxValue { get; internal set; }
		PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  L_0 = ___value0;
		__this->set_U3CmaxValueU3Ek__BackingField_18(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* Builder_get_name_m0E4ECDC1E4880050B65289CA1ACA6BBFAA279486_inline (Builder_t1F6DD3118AB2A911FE6C6F257A7B051EF1950C9E * __this, const RuntimeMethod* method)
{
	{
		// public string name { get; set; }
		String_t* L_0 = __this->get_U3CnameU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_usages_m565AB9F1578DEA1A853FD37AC283E82838B7F934_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  ___value0, const RuntimeMethod* method)
{
	{
		// public ReadOnlyArray<InternedString> usages { get; internal set; }
		ReadOnlyArray_1_t9B36E6A19983213B1DC0531766E5BB7242F1381C  L_0 = ___value0;
		__this->set_U3CusagesU3Ek__BackingField_6(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_parameters_m70663F346869784CF8C4E6C5BADDE822F98B8B24_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  ___value0, const RuntimeMethod* method)
{
	{
		// public ReadOnlyArray<NamedValue> parameters { get; internal set; }
		ReadOnlyArray_1_t851C200D7DC2D0506E36559F1D46E7A0F5E8A1F8  L_0 = ___value0;
		__this->set_U3CparametersU3Ek__BackingField_8(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_processors_m9A9EF453FBB41590F5DC79775533A7DB5781B8C9_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  ___value0, const RuntimeMethod* method)
{
	{
		// public ReadOnlyArray<NameAndParameters> processors { get; internal set; }
		ReadOnlyArray_1_t6DC10546A52DE606A51289535CFCF98B0B4D262F  L_0 = ___value0;
		__this->set_U3CprocessorsU3Ek__BackingField_9(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_defaultState_mB9603018DBC8D71A72B9E74B0179AD2E4965D681_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  ___value0, const RuntimeMethod* method)
{
	{
		// public PrimitiveValue defaultState { get; internal set; }
		PrimitiveValue_tB100F9C42BB438CE358E5989697410B27AFB3ADA  L_0 = ___value0;
		__this->set_U3CdefaultStateU3Ek__BackingField_16(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_useStateFrom_m2483939EAAD5950014A020C5A056DE99484CAF86_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// public string useStateFrom { get; internal set; }
		String_t* L_0 = ___value0;
		__this->set_U3CuseStateFromU3Ek__BackingField_3(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ControlItem_set_arraySize_mB8DE5DE08FBE9A89D6878878D0DF5618EA24ECFB_inline (ControlItem_tE80D7AB28DDEB6D515E566B444D86A8303CB778D * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public int arraySize { get; internal set; }
		int32_t L_0 = ___value0;
		__this->set_U3CarraySizeU3Ek__BackingField_15(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * InputControl_get_device_m238E9124B28FCDD64BCB24DD187503F3621B1B03_inline (InputControl_tEC322F9612E643CD72B7759D8542E56DE84F9713 * __this, const RuntimeMethod* method)
{
	{
		// public InputDevice device => m_Device;
		InputDevice_t32674BAC770EE0590FA5023A70AE7D3B3AA9A154 * L_0 = __this->get_m_Device_9();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Match_get_requirementIndex_mD05676A71BCB0583CDC59F9E20C31341048D2519_inline (Match_tF8E25BC160894A799358F44EB19C42365DAF0828 * __this, const RuntimeMethod* method)
{
	{
		// public int requirementIndex => m_RequirementIndex;
		int32_t L_0 = __this->get_m_RequirementIndex_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void DeviceRequirement_set_controlPath_mAE0850C485197021FD454C20922F00322370908E_inline (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// set => m_ControlPath = value;
		String_t* L_0 = ___value0;
		__this->set_m_ControlPath_0(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* DeviceRequirement_get_controlPath_m30D76119C4E712E3177B17FF34359FD3426601DC_inline (DeviceRequirement_t02A255131C3F591837F4E6FA3241BD329A0E1807 * __this, const RuntimeMethod* method)
{
	{
		// get => m_ControlPath;
		String_t* L_0 = __this->get_m_ControlPath_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t DeviceInfo_get_deviceId_m2B26439F4A8C1BAAECA5DFFC538B6F675F877988_inline (DeviceInfo_t0F58482F2971F416BD84AE9C6D9024F6B5D6DA0D * __this, const RuntimeMethod* method)
{
	{
		// get => m_DeviceId;
		int32_t L_0 = __this->get_m_DeviceId_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ReadOnlyArray_1_get_Count_mE2A826A6A8EC79EB232A3D5C79208F7F67BDFE21_gshared_inline (ReadOnlyArray_1_t838D76309E9783F02B1E4A7AA7DFD33F97256A03 * __this, const RuntimeMethod* method)
{
	{
		// public int Count => m_Length;
		int32_t L_0 = (int32_t)__this->get_m_Length_2();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject * KeyValuePair_2_get_Key_m4E9ACD2B4E097B0AF5B15D923092D10E257C64E7_gshared_inline (KeyValuePair_2_tEE5D23BECC9903E80CE9C9EA17D3C6D530F7987E * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = (RuntimeObject *)__this->get_key_0();
		return (RuntimeObject *)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  KeyValuePair_2_get_Value_m5D03130FB6F2A36980DDE053BC7BA6EA77FC9ECF_gshared_inline (KeyValuePair_2_tEE5D23BECC9903E80CE9C9EA17D3C6D530F7987E * __this, const RuntimeMethod* method)
{
	{
		JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F  L_0 = (JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F )__this->get_value_1();
		return (JsonValue_t4A09AABA8A49BE4FD4182C9438D340BC8F38831F )L_0;
	}
}
