﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void I18N.Common.ByteEncoding::.ctor(System.Int32,System.Char[],System.String,System.String,System.String,System.String,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32)
extern void ByteEncoding__ctor_m38C66F0BDFF6CDAF86DA35A4771938B1DA64F2B5 (void);
// 0x00000002 System.Boolean I18N.Common.ByteEncoding::IsAlwaysNormalized(System.Text.NormalizationForm)
extern void ByteEncoding_IsAlwaysNormalized_mC5F4B5C601C2FF9B3E804DE9ACE031F9ED8D28A8 (void);
// 0x00000003 System.Boolean I18N.Common.ByteEncoding::get_IsSingleByte()
extern void ByteEncoding_get_IsSingleByte_m6E1501A5A55EBDD54255A2B14867060344FB69C7 (void);
// 0x00000004 System.Int32 I18N.Common.ByteEncoding::GetByteCount(System.String)
extern void ByteEncoding_GetByteCount_m8FB3044DB589FE30BA04EF40D002B7A391B75650 (void);
// 0x00000005 System.Int32 I18N.Common.ByteEncoding::GetByteCountImpl(System.Char*,System.Int32)
extern void ByteEncoding_GetByteCountImpl_m99C9C53EDEEFC07231F168AED3034C204C0F7DEE (void);
// 0x00000006 System.Void I18N.Common.ByteEncoding::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
// 0x00000007 System.Void I18N.Common.ByteEncoding::ToBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteEncoding_ToBytes_mCBC1D288BF5D1A8F9FB5F6E68F5229672C3C58F4 (void);
// 0x00000008 System.Int32 I18N.Common.ByteEncoding::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void ByteEncoding_GetBytesImpl_m07CC2A819FCF95CAF142E9DA3E523491A1B18C88 (void);
// 0x00000009 System.Int32 I18N.Common.ByteEncoding::GetCharCount(System.Byte[],System.Int32,System.Int32)
extern void ByteEncoding_GetCharCount_mE6B5B76D10429177968DE019E425D70B38710172 (void);
// 0x0000000A System.Int32 I18N.Common.ByteEncoding::GetChars(System.Byte[],System.Int32,System.Int32,System.Char[],System.Int32)
extern void ByteEncoding_GetChars_m5495D938A75FE94A7827D5A5DB2FF6D19D7C617A (void);
// 0x0000000B System.Int32 I18N.Common.ByteEncoding::GetMaxByteCount(System.Int32)
extern void ByteEncoding_GetMaxByteCount_m5EC1C9F3D809019E18325573C5345313DB33E3E1 (void);
// 0x0000000C System.Int32 I18N.Common.ByteEncoding::GetMaxCharCount(System.Int32)
extern void ByteEncoding_GetMaxCharCount_m358DC46FB20534C823FE3D30CB7D4FA0DA4A723B (void);
// 0x0000000D System.String I18N.Common.ByteEncoding::GetString(System.Byte[],System.Int32,System.Int32)
extern void ByteEncoding_GetString_mA8CC2AB25F0C918F34DC18C10BE41FAA7CC2D5BE (void);
// 0x0000000E System.String I18N.Common.ByteEncoding::GetString(System.Byte[])
extern void ByteEncoding_GetString_mBC8EAEE9FEF9CBC1DDEE803F5C79A91C4AD7298E (void);
// 0x0000000F System.String I18N.Common.ByteEncoding::get_BodyName()
extern void ByteEncoding_get_BodyName_mA59733E84E65405BB89E82499B2AD4839C1622DF (void);
// 0x00000010 System.String I18N.Common.ByteEncoding::get_EncodingName()
extern void ByteEncoding_get_EncodingName_mDF1256257184D52A554D9F06474D68BC5F834953 (void);
// 0x00000011 System.String I18N.Common.ByteEncoding::get_HeaderName()
extern void ByteEncoding_get_HeaderName_mAE2E81B75BCFA79CBAF31C215C78888374214300 (void);
// 0x00000012 System.Boolean I18N.Common.ByteEncoding::get_IsBrowserDisplay()
extern void ByteEncoding_get_IsBrowserDisplay_mFD3094AEE504A3B79D0751C850D323451A84316A (void);
// 0x00000013 System.Boolean I18N.Common.ByteEncoding::get_IsBrowserSave()
extern void ByteEncoding_get_IsBrowserSave_mA4B77F70BFEA771DC9C2B16CFCB6C49C6A4D8541 (void);
// 0x00000014 System.Boolean I18N.Common.ByteEncoding::get_IsMailNewsDisplay()
extern void ByteEncoding_get_IsMailNewsDisplay_m05707CDCD940828E9224199966FC3C6899655900 (void);
// 0x00000015 System.Boolean I18N.Common.ByteEncoding::get_IsMailNewsSave()
extern void ByteEncoding_get_IsMailNewsSave_mDB2CE0FBBFE869DCBA53E9257BEA6666E953F8B8 (void);
// 0x00000016 System.String I18N.Common.ByteEncoding::get_WebName()
extern void ByteEncoding_get_WebName_m0E09751158B22101E208216AC6DF25498E307D19 (void);
// 0x00000017 System.Int32 I18N.Common.ByteEncoding::get_WindowsCodePage()
extern void ByteEncoding_get_WindowsCodePage_mA8584F2363F717B8F3FD644F0B865F613C40376F (void);
// 0x00000018 System.Void I18N.Common.ByteSafeEncoding::.ctor(System.Int32,System.Char[],System.String,System.String,System.String,System.String,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32)
extern void ByteSafeEncoding__ctor_mAA133509A388075F2C545081B2EB216A4E1BF62B (void);
// 0x00000019 System.Boolean I18N.Common.ByteSafeEncoding::IsAlwaysNormalized(System.Text.NormalizationForm)
extern void ByteSafeEncoding_IsAlwaysNormalized_mE9E66564A52334DBE5B8F13600095DBCF9F05CD2 (void);
// 0x0000001A System.Boolean I18N.Common.ByteSafeEncoding::get_IsSingleByte()
extern void ByteSafeEncoding_get_IsSingleByte_mB21592ED29BE54F4162279F554AA2539BDB80A3A (void);
// 0x0000001B System.Int32 I18N.Common.ByteSafeEncoding::GetByteCount(System.String)
extern void ByteSafeEncoding_GetByteCount_m2EE6C008875A5214349CAE10D27BD74AA95F64DB (void);
// 0x0000001C System.Int32 I18N.Common.ByteSafeEncoding::GetByteCount(System.Char[],System.Int32,System.Int32)
extern void ByteSafeEncoding_GetByteCount_mE87B7F6E0955F9F2B63B72DBE13D5D41FA52694D (void);
// 0x0000001D System.Int32 I18N.Common.ByteSafeEncoding::GetByteCount(System.Char*,System.Int32)
extern void ByteSafeEncoding_GetByteCount_m7A6149E0E4C45D940638353EDA9872B86800B665 (void);
// 0x0000001E System.Void I18N.Common.ByteSafeEncoding::ToBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
// 0x0000001F System.Void I18N.Common.ByteSafeEncoding::ToBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteSafeEncoding_ToBytes_m598D47FAC4DFDF427734E8E8D77F1C8392ABEABF (void);
// 0x00000020 System.Int32 I18N.Common.ByteSafeEncoding::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteSafeEncoding_GetBytes_m8049AEAB95088D90E2A816556E40B7FE57D0715E (void);
// 0x00000021 System.Int32 I18N.Common.ByteSafeEncoding::GetBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteSafeEncoding_GetBytes_m50C1B6AE7C89B9192EA1BB5614BB3850A72B5D82 (void);
// 0x00000022 System.Byte[] I18N.Common.ByteSafeEncoding::GetBytes(System.String)
extern void ByteSafeEncoding_GetBytes_m068EE64B76F6966A383DF8D3C6847799B444627F (void);
// 0x00000023 System.Int32 I18N.Common.ByteSafeEncoding::GetCharCount(System.Byte[],System.Int32,System.Int32)
extern void ByteSafeEncoding_GetCharCount_m7C27CB4952F2248CE407DED2F50E8AF5B0876EB6 (void);
// 0x00000024 System.Int32 I18N.Common.ByteSafeEncoding::GetChars(System.Byte[],System.Int32,System.Int32,System.Char[],System.Int32)
extern void ByteSafeEncoding_GetChars_mC6D51C6728B806289D5A3252689F06C4FDB700D5 (void);
// 0x00000025 System.Int32 I18N.Common.ByteSafeEncoding::GetMaxByteCount(System.Int32)
extern void ByteSafeEncoding_GetMaxByteCount_mF9415810897BD31A62376C3F5230B22ED942936B (void);
// 0x00000026 System.Int32 I18N.Common.ByteSafeEncoding::GetMaxCharCount(System.Int32)
extern void ByteSafeEncoding_GetMaxCharCount_mE5D1C79B2D2F7AEEC470B86AFCAEE04F2DD8820E (void);
// 0x00000027 System.String I18N.Common.ByteSafeEncoding::GetString(System.Byte[],System.Int32,System.Int32)
extern void ByteSafeEncoding_GetString_mE39038E06D0D37972E53746B60C5B9D6AB1BB1FA (void);
// 0x00000028 System.String I18N.Common.ByteSafeEncoding::GetString(System.Byte[])
extern void ByteSafeEncoding_GetString_m65241A49A3F9B7707EAF7FC5CAA35BD99E8DD452 (void);
// 0x00000029 System.String I18N.Common.ByteSafeEncoding::get_BodyName()
extern void ByteSafeEncoding_get_BodyName_mBB1AC25A787310D52CB86B76A40F369A0A202F6B (void);
// 0x0000002A System.String I18N.Common.ByteSafeEncoding::get_EncodingName()
extern void ByteSafeEncoding_get_EncodingName_m1822D2F8289D7ABD3CAFA44309CFA3C2C2D93F9A (void);
// 0x0000002B System.String I18N.Common.ByteSafeEncoding::get_HeaderName()
extern void ByteSafeEncoding_get_HeaderName_m9DC4921170DB74C7BF108828870996F2D6591632 (void);
// 0x0000002C System.Boolean I18N.Common.ByteSafeEncoding::get_IsBrowserDisplay()
extern void ByteSafeEncoding_get_IsBrowserDisplay_mA1CE4AC487EB4489AF10571690996DE5EAE0A373 (void);
// 0x0000002D System.Boolean I18N.Common.ByteSafeEncoding::get_IsBrowserSave()
extern void ByteSafeEncoding_get_IsBrowserSave_m435865F2D7DA85C717AF0950C956B871D25965BC (void);
// 0x0000002E System.Boolean I18N.Common.ByteSafeEncoding::get_IsMailNewsDisplay()
extern void ByteSafeEncoding_get_IsMailNewsDisplay_m07DDFC50172E844AFC557EDA94A96584680674E4 (void);
// 0x0000002F System.Boolean I18N.Common.ByteSafeEncoding::get_IsMailNewsSave()
extern void ByteSafeEncoding_get_IsMailNewsSave_m8E768A612CD5DEA217A58ADEC740EE9B2DACCCEF (void);
// 0x00000030 System.String I18N.Common.ByteSafeEncoding::get_WebName()
extern void ByteSafeEncoding_get_WebName_m299126058040355275B883FDB0C2B1500C31DDA0 (void);
// 0x00000031 System.Int32 I18N.Common.ByteSafeEncoding::get_WindowsCodePage()
extern void ByteSafeEncoding_get_WindowsCodePage_mCA082AC3036B26E46D6900238E43AF491288FC97 (void);
// 0x00000032 System.Void I18N.Common.ReferenceSourceDefaultEncoder::.ctor(System.Text.Encoding)
extern void ReferenceSourceDefaultEncoder__ctor_m7090AFACABDD8675F578CEDD39264CDC8DEA5946 (void);
// 0x00000033 System.Void I18N.Common.ReferenceSourceDefaultEncoder::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void ReferenceSourceDefaultEncoder__ctor_mC12B5F7EED6439D76E716111B385D6C553296DD7 (void);
// 0x00000034 System.Object I18N.Common.ReferenceSourceDefaultEncoder::GetRealObject(System.Runtime.Serialization.StreamingContext)
extern void ReferenceSourceDefaultEncoder_GetRealObject_m0A4C2E49102C7F7C352AB59AB8DBEE41B837C96D (void);
// 0x00000035 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetByteCount(System.Char[],System.Int32,System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetByteCount_m92201417A4881040DCAB395CA750E106B44AD8DE (void);
// 0x00000036 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetByteCount(System.Char*,System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetByteCount_m5662FDC6C6557D3773366F0757E3184F5AA8ED46 (void);
// 0x00000037 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetBytes_mFBF11D101A49955B78350EC945884AAE6D5B24C6 (void);
// 0x00000038 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetBytes(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetBytes_m274B795FC6343562DFABF8E9A431D90C3B5C6AC0 (void);
// 0x00000039 System.String I18N.Common.Handlers::GetAlias(System.String)
extern void Handlers_GetAlias_mEDFC1F3F147DC92897349F9F8FBB18ED2DC3BAD6 (void);
// 0x0000003A System.Void I18N.Common.Handlers::BuildHash()
extern void Handlers_BuildHash_mADC0028DFE14D83888DE4AC164C29FD8C3862F3D (void);
// 0x0000003B System.Void I18N.Common.Handlers::.ctor()
extern void Handlers__ctor_m5FAD017ABD90757790C9833F5F99B6CD5061BD80 (void);
// 0x0000003C System.Void I18N.Common.Handlers::.cctor()
extern void Handlers__cctor_m6C48BFDFEA6E210CD2E8717860D3D0ECF8F38066 (void);
// 0x0000003D System.Void I18N.Common.Manager::.ctor()
extern void Manager__ctor_m157CDC52071566CDAE381033E0B103CD885B7BD1 (void);
// 0x0000003E I18N.Common.Manager I18N.Common.Manager::get_PrimaryManager()
extern void Manager_get_PrimaryManager_m574141D8176D63178B4B19F804929FE6F083D5C5 (void);
// 0x0000003F System.String I18N.Common.Manager::Normalize(System.String)
extern void Manager_Normalize_mE1CA84850160947FBDBDBD5BBB5DF647E27D0256 (void);
// 0x00000040 System.Text.Encoding I18N.Common.Manager::GetEncoding(System.Int32)
extern void Manager_GetEncoding_m81EE9C716F1588F0A6F3437D866E7A1158B9EA8A (void);
// 0x00000041 System.Text.Encoding I18N.Common.Manager::GetEncoding(System.String)
extern void Manager_GetEncoding_m8F33D56FDFA8C5649A647C56F8457F4F2F39A506 (void);
// 0x00000042 System.Globalization.CultureInfo I18N.Common.Manager::GetCulture(System.Int32,System.Boolean)
extern void Manager_GetCulture_m5A2E65CD1A9B98C40D997FCE3D689D5DF2471115 (void);
// 0x00000043 System.Globalization.CultureInfo I18N.Common.Manager::GetCulture(System.String,System.Boolean)
extern void Manager_GetCulture_mBBE409E2726C2A2316793EFF02A7844B2DF607E6 (void);
// 0x00000044 System.Object I18N.Common.Manager::Instantiate(System.String)
extern void Manager_Instantiate_mA30266D1D5B53F4676EAB2EE134D99562D7A7990 (void);
// 0x00000045 System.Void I18N.Common.Manager::LoadClassList()
extern void Manager_LoadClassList_m0024AE70797E5EF091E346AD43654F7946734A6C (void);
// 0x00000046 System.Void I18N.Common.Manager::LoadInternalClasses()
extern void Manager_LoadInternalClasses_mC028C6EBDBC2954075CA172BE793E0510267158D (void);
// 0x00000047 System.Void I18N.Common.Manager::.cctor()
extern void Manager__cctor_mDB4A990FE31B794DE4A1EA43FA14704A87CF15B3 (void);
// 0x00000048 System.Void I18N.Common.MonoEncoding::.ctor(System.Int32)
extern void MonoEncoding__ctor_m2E7B79595A50ACD69079284AFF115A0E69BDE26C (void);
// 0x00000049 System.Void I18N.Common.MonoEncoding::.ctor(System.Int32,System.Int32)
extern void MonoEncoding__ctor_mB367889EF8D926DD51A23293AC9846AD10E8C8F5 (void);
// 0x0000004A System.Int32 I18N.Common.MonoEncoding::get_WindowsCodePage()
extern void MonoEncoding_get_WindowsCodePage_m2AB321342B4826453910C96967972A577BF22D2D (void);
// 0x0000004B System.Int32 I18N.Common.MonoEncoding::GetBytesInternal(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean,System.Object)
extern void MonoEncoding_GetBytesInternal_m1B6EA81FACE6A16F312AF41936F34C4656587FF0 (void);
// 0x0000004C System.Void I18N.Common.MonoEncoding::HandleFallback(System.Text.EncoderFallbackBuffer&,System.Char*,System.Int32&,System.Int32&,System.Byte*,System.Int32&,System.Int32&,System.Object)
extern void MonoEncoding_HandleFallback_mFE7F30B6B519909C462D20EDC96DCEE0C491A0DA (void);
// 0x0000004D System.Void I18N.Common.MonoEncoding::HandleFallback(System.Text.EncoderFallbackBuffer&,System.Char*,System.Int32&,System.Int32&,System.Byte*,System.Int32&,System.Int32&)
extern void MonoEncoding_HandleFallback_m5BBB9A58548D7F4FC29EB94C8033AF716387D94F (void);
// 0x0000004E System.Int32 I18N.Common.MonoEncoding::GetByteCount(System.Char[],System.Int32,System.Int32)
extern void MonoEncoding_GetByteCount_m1C453DE6D1CF144A90CD8437563AF0081904227A (void);
// 0x0000004F System.Int32 I18N.Common.MonoEncoding::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void MonoEncoding_GetBytes_m51001B7613025B8323292E9D5A8CF0961946B125 (void);
// 0x00000050 System.Int32 I18N.Common.MonoEncoding::GetBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32)
extern void MonoEncoding_GetBytes_m8C356C925A221EA45D91C6657662014A9E88A676 (void);
// 0x00000051 System.Int32 I18N.Common.MonoEncoding::GetByteCount(System.Char*,System.Int32)
extern void MonoEncoding_GetByteCount_m50F65084E18BDCD56C650E7845D21A076E2754C6 (void);
// 0x00000052 System.Int32 I18N.Common.MonoEncoding::GetBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void MonoEncoding_GetBytes_mAF7CD6176F55318CCBB9960BA945789C3AFF3524 (void);
// 0x00000053 System.Int32 I18N.Common.MonoEncoding::GetByteCountImpl(System.Char*,System.Int32)
// 0x00000054 System.Int32 I18N.Common.MonoEncoding::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
// 0x00000055 System.Text.Encoder I18N.Common.MonoEncoding::GetEncoder()
extern void MonoEncoding_GetEncoder_m81EC2ECEBE7E900755DFB03BCAD23A5A8F475088 (void);
// 0x00000056 System.Void I18N.Common.MonoEncoder::.ctor(I18N.Common.MonoEncoding)
extern void MonoEncoder__ctor_m1C6AE7955137A5BE32A2DD9F66148C8EA5062E5C (void);
// 0x00000057 System.Int32 I18N.Common.MonoEncoder::GetByteCount(System.Char[],System.Int32,System.Int32,System.Boolean)
extern void MonoEncoder_GetByteCount_mF9081AD52DA9C83822A7BCBFA1060AEA7AEBE1F1 (void);
// 0x00000058 System.Int32 I18N.Common.MonoEncoder::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Boolean)
extern void MonoEncoder_GetBytes_m711A149DE91B221061CF6C512DBCD8EC377DB5FC (void);
// 0x00000059 System.Int32 I18N.Common.MonoEncoder::GetByteCountImpl(System.Char*,System.Int32,System.Boolean)
// 0x0000005A System.Int32 I18N.Common.MonoEncoder::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean)
// 0x0000005B System.Int32 I18N.Common.MonoEncoder::GetBytes(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean)
extern void MonoEncoder_GetBytes_mA5D13CFF80967A80895F952744E1612ED4EDF123 (void);
// 0x0000005C System.Void I18N.Common.MonoEncoder::HandleFallback(System.Char*,System.Int32&,System.Int32&,System.Byte*,System.Int32&,System.Int32&,System.Object)
extern void MonoEncoder_HandleFallback_m1F6005121DDF2C9E41ACB7F5E472D5C7285CF772 (void);
// 0x0000005D System.Void I18N.Common.MonoEncodingDefaultEncoder::.ctor(System.Text.Encoding)
extern void MonoEncodingDefaultEncoder__ctor_mFB66B8F2114655EC5A2E0B2443B5A4F87C2B5126 (void);
// 0x0000005E System.Void I18N.Common.MonoEncodingDefaultEncoder::Convert(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean,System.Int32&,System.Int32&,System.Boolean&)
extern void MonoEncodingDefaultEncoder_Convert_m3696413D31C90A0F88CF248AD6E79F3469B5A784 (void);
// 0x0000005F System.Void I18N.Common.MonoEncodingDefaultEncoder::Convert(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32,System.Boolean,System.Int32&,System.Int32&,System.Boolean&)
extern void MonoEncodingDefaultEncoder_Convert_m35968C7F61AE8AFD20A1E4D45FC339A7C22EB0F7 (void);
// 0x00000060 System.Void I18N.Common.MonoEncodingDefaultEncoder::CheckArguments(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void MonoEncodingDefaultEncoder_CheckArguments_m5AFAD5EB7AE7CDEB4E6C9815021664E8A17CB0D9 (void);
// 0x00000061 System.Void I18N.Common.MonoSafeEncoding::.ctor(System.Int32)
extern void MonoSafeEncoding__ctor_mE4BC6943BA58B3A96D2EA100044BF295A470E83F (void);
// 0x00000062 System.Void I18N.Common.MonoSafeEncoding::.ctor(System.Int32,System.Int32)
extern void MonoSafeEncoding__ctor_m22024C3A28920B9112728E9CF9CF218621D880E5 (void);
// 0x00000063 System.Int32 I18N.Common.MonoSafeEncoding::get_WindowsCodePage()
extern void MonoSafeEncoding_get_WindowsCodePage_m5E82A5B3688220B134F45B5D3137EEEB3885FFF5 (void);
// 0x00000064 System.Int32 I18N.Common.MonoSafeEncoding::GetBytesInternal(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Boolean,System.Object)
extern void MonoSafeEncoding_GetBytesInternal_m5FDAB0920EA4CA891AEE264F00520E1D26CF0C86 (void);
// 0x00000065 System.Void I18N.Common.MonoSafeEncoding::HandleFallback(System.Text.EncoderFallbackBuffer&,System.Char[],System.Int32&,System.Int32&,System.Byte[],System.Int32&,System.Int32&,System.Object)
extern void MonoSafeEncoding_HandleFallback_mEA25FB4276523DC9F36C3C03F97F7682C0C31DDF (void);
// 0x00000066 System.Void I18N.Common.MonoSafeEncoder::.ctor(I18N.Common.MonoSafeEncoding)
extern void MonoSafeEncoder__ctor_mE2203C5488EEAE1D2D9D8E3F1FC21ECE168DAADC (void);
// 0x00000067 System.Void I18N.Common.MonoSafeEncoder::HandleFallback(System.Char[],System.Int32&,System.Int32&,System.Byte[],System.Int32&,System.Int32&,System.Object)
extern void MonoSafeEncoder_HandleFallback_m5616797BE059754055D104BF351A4473D615C4C5 (void);
// 0x00000068 System.String I18N.Common.Strings::GetString(System.String)
extern void Strings_GetString_m84B4205ADF9BD4AB96836BE778BE485A0DDCF9A1 (void);
// 0x00000069 System.Void I18N.Common.Strings::.ctor()
extern void Strings__ctor_m51CB9794BF813310A9D919BFD267F3FCBD411DEE (void);
static Il2CppMethodPointer s_methodPointers[105] = 
{
	ByteEncoding__ctor_m38C66F0BDFF6CDAF86DA35A4771938B1DA64F2B5,
	ByteEncoding_IsAlwaysNormalized_mC5F4B5C601C2FF9B3E804DE9ACE031F9ED8D28A8,
	ByteEncoding_get_IsSingleByte_m6E1501A5A55EBDD54255A2B14867060344FB69C7,
	ByteEncoding_GetByteCount_m8FB3044DB589FE30BA04EF40D002B7A391B75650,
	ByteEncoding_GetByteCountImpl_m99C9C53EDEEFC07231F168AED3034C204C0F7DEE,
	NULL,
	ByteEncoding_ToBytes_mCBC1D288BF5D1A8F9FB5F6E68F5229672C3C58F4,
	ByteEncoding_GetBytesImpl_m07CC2A819FCF95CAF142E9DA3E523491A1B18C88,
	ByteEncoding_GetCharCount_mE6B5B76D10429177968DE019E425D70B38710172,
	ByteEncoding_GetChars_m5495D938A75FE94A7827D5A5DB2FF6D19D7C617A,
	ByteEncoding_GetMaxByteCount_m5EC1C9F3D809019E18325573C5345313DB33E3E1,
	ByteEncoding_GetMaxCharCount_m358DC46FB20534C823FE3D30CB7D4FA0DA4A723B,
	ByteEncoding_GetString_mA8CC2AB25F0C918F34DC18C10BE41FAA7CC2D5BE,
	ByteEncoding_GetString_mBC8EAEE9FEF9CBC1DDEE803F5C79A91C4AD7298E,
	ByteEncoding_get_BodyName_mA59733E84E65405BB89E82499B2AD4839C1622DF,
	ByteEncoding_get_EncodingName_mDF1256257184D52A554D9F06474D68BC5F834953,
	ByteEncoding_get_HeaderName_mAE2E81B75BCFA79CBAF31C215C78888374214300,
	ByteEncoding_get_IsBrowserDisplay_mFD3094AEE504A3B79D0751C850D323451A84316A,
	ByteEncoding_get_IsBrowserSave_mA4B77F70BFEA771DC9C2B16CFCB6C49C6A4D8541,
	ByteEncoding_get_IsMailNewsDisplay_m05707CDCD940828E9224199966FC3C6899655900,
	ByteEncoding_get_IsMailNewsSave_mDB2CE0FBBFE869DCBA53E9257BEA6666E953F8B8,
	ByteEncoding_get_WebName_m0E09751158B22101E208216AC6DF25498E307D19,
	ByteEncoding_get_WindowsCodePage_mA8584F2363F717B8F3FD644F0B865F613C40376F,
	ByteSafeEncoding__ctor_mAA133509A388075F2C545081B2EB216A4E1BF62B,
	ByteSafeEncoding_IsAlwaysNormalized_mE9E66564A52334DBE5B8F13600095DBCF9F05CD2,
	ByteSafeEncoding_get_IsSingleByte_mB21592ED29BE54F4162279F554AA2539BDB80A3A,
	ByteSafeEncoding_GetByteCount_m2EE6C008875A5214349CAE10D27BD74AA95F64DB,
	ByteSafeEncoding_GetByteCount_mE87B7F6E0955F9F2B63B72DBE13D5D41FA52694D,
	ByteSafeEncoding_GetByteCount_m7A6149E0E4C45D940638353EDA9872B86800B665,
	NULL,
	ByteSafeEncoding_ToBytes_m598D47FAC4DFDF427734E8E8D77F1C8392ABEABF,
	ByteSafeEncoding_GetBytes_m8049AEAB95088D90E2A816556E40B7FE57D0715E,
	ByteSafeEncoding_GetBytes_m50C1B6AE7C89B9192EA1BB5614BB3850A72B5D82,
	ByteSafeEncoding_GetBytes_m068EE64B76F6966A383DF8D3C6847799B444627F,
	ByteSafeEncoding_GetCharCount_m7C27CB4952F2248CE407DED2F50E8AF5B0876EB6,
	ByteSafeEncoding_GetChars_mC6D51C6728B806289D5A3252689F06C4FDB700D5,
	ByteSafeEncoding_GetMaxByteCount_mF9415810897BD31A62376C3F5230B22ED942936B,
	ByteSafeEncoding_GetMaxCharCount_mE5D1C79B2D2F7AEEC470B86AFCAEE04F2DD8820E,
	ByteSafeEncoding_GetString_mE39038E06D0D37972E53746B60C5B9D6AB1BB1FA,
	ByteSafeEncoding_GetString_m65241A49A3F9B7707EAF7FC5CAA35BD99E8DD452,
	ByteSafeEncoding_get_BodyName_mBB1AC25A787310D52CB86B76A40F369A0A202F6B,
	ByteSafeEncoding_get_EncodingName_m1822D2F8289D7ABD3CAFA44309CFA3C2C2D93F9A,
	ByteSafeEncoding_get_HeaderName_m9DC4921170DB74C7BF108828870996F2D6591632,
	ByteSafeEncoding_get_IsBrowserDisplay_mA1CE4AC487EB4489AF10571690996DE5EAE0A373,
	ByteSafeEncoding_get_IsBrowserSave_m435865F2D7DA85C717AF0950C956B871D25965BC,
	ByteSafeEncoding_get_IsMailNewsDisplay_m07DDFC50172E844AFC557EDA94A96584680674E4,
	ByteSafeEncoding_get_IsMailNewsSave_m8E768A612CD5DEA217A58ADEC740EE9B2DACCCEF,
	ByteSafeEncoding_get_WebName_m299126058040355275B883FDB0C2B1500C31DDA0,
	ByteSafeEncoding_get_WindowsCodePage_mCA082AC3036B26E46D6900238E43AF491288FC97,
	ReferenceSourceDefaultEncoder__ctor_m7090AFACABDD8675F578CEDD39264CDC8DEA5946,
	ReferenceSourceDefaultEncoder__ctor_mC12B5F7EED6439D76E716111B385D6C553296DD7,
	ReferenceSourceDefaultEncoder_GetRealObject_m0A4C2E49102C7F7C352AB59AB8DBEE41B837C96D,
	ReferenceSourceDefaultEncoder_GetByteCount_m92201417A4881040DCAB395CA750E106B44AD8DE,
	ReferenceSourceDefaultEncoder_GetByteCount_m5662FDC6C6557D3773366F0757E3184F5AA8ED46,
	ReferenceSourceDefaultEncoder_GetBytes_mFBF11D101A49955B78350EC945884AAE6D5B24C6,
	ReferenceSourceDefaultEncoder_GetBytes_m274B795FC6343562DFABF8E9A431D90C3B5C6AC0,
	Handlers_GetAlias_mEDFC1F3F147DC92897349F9F8FBB18ED2DC3BAD6,
	Handlers_BuildHash_mADC0028DFE14D83888DE4AC164C29FD8C3862F3D,
	Handlers__ctor_m5FAD017ABD90757790C9833F5F99B6CD5061BD80,
	Handlers__cctor_m6C48BFDFEA6E210CD2E8717860D3D0ECF8F38066,
	Manager__ctor_m157CDC52071566CDAE381033E0B103CD885B7BD1,
	Manager_get_PrimaryManager_m574141D8176D63178B4B19F804929FE6F083D5C5,
	Manager_Normalize_mE1CA84850160947FBDBDBD5BBB5DF647E27D0256,
	Manager_GetEncoding_m81EE9C716F1588F0A6F3437D866E7A1158B9EA8A,
	Manager_GetEncoding_m8F33D56FDFA8C5649A647C56F8457F4F2F39A506,
	Manager_GetCulture_m5A2E65CD1A9B98C40D997FCE3D689D5DF2471115,
	Manager_GetCulture_mBBE409E2726C2A2316793EFF02A7844B2DF607E6,
	Manager_Instantiate_mA30266D1D5B53F4676EAB2EE134D99562D7A7990,
	Manager_LoadClassList_m0024AE70797E5EF091E346AD43654F7946734A6C,
	Manager_LoadInternalClasses_mC028C6EBDBC2954075CA172BE793E0510267158D,
	Manager__cctor_mDB4A990FE31B794DE4A1EA43FA14704A87CF15B3,
	MonoEncoding__ctor_m2E7B79595A50ACD69079284AFF115A0E69BDE26C,
	MonoEncoding__ctor_mB367889EF8D926DD51A23293AC9846AD10E8C8F5,
	MonoEncoding_get_WindowsCodePage_m2AB321342B4826453910C96967972A577BF22D2D,
	MonoEncoding_GetBytesInternal_m1B6EA81FACE6A16F312AF41936F34C4656587FF0,
	MonoEncoding_HandleFallback_mFE7F30B6B519909C462D20EDC96DCEE0C491A0DA,
	MonoEncoding_HandleFallback_m5BBB9A58548D7F4FC29EB94C8033AF716387D94F,
	MonoEncoding_GetByteCount_m1C453DE6D1CF144A90CD8437563AF0081904227A,
	MonoEncoding_GetBytes_m51001B7613025B8323292E9D5A8CF0961946B125,
	MonoEncoding_GetBytes_m8C356C925A221EA45D91C6657662014A9E88A676,
	MonoEncoding_GetByteCount_m50F65084E18BDCD56C650E7845D21A076E2754C6,
	MonoEncoding_GetBytes_mAF7CD6176F55318CCBB9960BA945789C3AFF3524,
	NULL,
	NULL,
	MonoEncoding_GetEncoder_m81EC2ECEBE7E900755DFB03BCAD23A5A8F475088,
	MonoEncoder__ctor_m1C6AE7955137A5BE32A2DD9F66148C8EA5062E5C,
	MonoEncoder_GetByteCount_mF9081AD52DA9C83822A7BCBFA1060AEA7AEBE1F1,
	MonoEncoder_GetBytes_m711A149DE91B221061CF6C512DBCD8EC377DB5FC,
	NULL,
	NULL,
	MonoEncoder_GetBytes_mA5D13CFF80967A80895F952744E1612ED4EDF123,
	MonoEncoder_HandleFallback_m1F6005121DDF2C9E41ACB7F5E472D5C7285CF772,
	MonoEncodingDefaultEncoder__ctor_mFB66B8F2114655EC5A2E0B2443B5A4F87C2B5126,
	MonoEncodingDefaultEncoder_Convert_m3696413D31C90A0F88CF248AD6E79F3469B5A784,
	MonoEncodingDefaultEncoder_Convert_m35968C7F61AE8AFD20A1E4D45FC339A7C22EB0F7,
	MonoEncodingDefaultEncoder_CheckArguments_m5AFAD5EB7AE7CDEB4E6C9815021664E8A17CB0D9,
	MonoSafeEncoding__ctor_mE4BC6943BA58B3A96D2EA100044BF295A470E83F,
	MonoSafeEncoding__ctor_m22024C3A28920B9112728E9CF9CF218621D880E5,
	MonoSafeEncoding_get_WindowsCodePage_m5E82A5B3688220B134F45B5D3137EEEB3885FFF5,
	MonoSafeEncoding_GetBytesInternal_m5FDAB0920EA4CA891AEE264F00520E1D26CF0C86,
	MonoSafeEncoding_HandleFallback_mEA25FB4276523DC9F36C3C03F97F7682C0C31DDF,
	MonoSafeEncoder__ctor_mE2203C5488EEAE1D2D9D8E3F1FC21ECE168DAADC,
	MonoSafeEncoder_HandleFallback_m5616797BE059754055D104BF351A4473D615C4C5,
	Strings_GetString_m84B4205ADF9BD4AB96836BE778BE485A0DDCF9A1,
	Strings__ctor_m51CB9794BF813310A9D919BFD267F3FCBD411DEE,
};
static const int32_t s_InvokerIndices[105] = 
{
	7,
	1669,
	2394,
	1398,
	744,
	389,
	202,
	230,
	483,
	142,
	1387,
	1387,
	532,
	1532,
	2372,
	2372,
	2372,
	2394,
	2394,
	2394,
	2394,
	2372,
	2357,
	7,
	1669,
	2394,
	1398,
	483,
	744,
	202,
	202,
	142,
	142,
	1532,
	483,
	142,
	1387,
	1387,
	532,
	1532,
	2372,
	2372,
	2372,
	2394,
	2394,
	2394,
	2394,
	2372,
	2357,
	1941,
	1162,
	1535,
	245,
	476,
	78,
	141,
	3653,
	3845,
	2413,
	3845,
	2413,
	3821,
	3653,
	1526,
	1532,
	825,
	835,
	1532,
	2413,
	2413,
	3845,
	1927,
	1045,
	2357,
	76,
	28,
	54,
	483,
	142,
	142,
	744,
	230,
	744,
	230,
	2372,
	1941,
	245,
	78,
	476,
	141,
	141,
	55,
	1941,
	29,
	11,
	389,
	1927,
	1045,
	2357,
	46,
	30,
	1941,
	60,
	3653,
	2413,
};
extern const CustomAttributesCacheGenerator g_I18N_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_I18N_CodeGenModule;
const Il2CppCodeGenModule g_I18N_CodeGenModule = 
{
	"I18N.dll",
	105,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_I18N_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
