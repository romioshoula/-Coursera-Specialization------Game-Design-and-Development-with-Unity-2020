﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.UIElements.PointerId::.cctor()
extern void PointerId__cctor_m78A847AFC9330255BA877654E46EF8A9B7E199E9 (void);
static Il2CppMethodPointer s_methodPointers[1] = 
{
	PointerId__cctor_m78A847AFC9330255BA877654E46EF8A9B7E199E9,
};
static const int32_t s_InvokerIndices[1] = 
{
	3845,
};
extern const CustomAttributesCacheGenerator g_UnityEngine_UIElementsModule_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_UIElementsModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UIElementsModule_CodeGenModule = 
{
	"UnityEngine.UIElementsModule.dll",
	1,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_UnityEngine_UIElementsModule_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
