﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void LookAtTarget::Start()
extern void LookAtTarget_Start_mA520BD8AAF18B39E54E362D1357B7745371798AA (void);
// 0x00000002 System.Void LookAtTarget::Update()
extern void LookAtTarget_Update_m95F4E845EB06EFFCB91E538AB4D9E202C8A5ED4A (void);
// 0x00000003 System.Void LookAtTarget::.ctor()
extern void LookAtTarget__ctor_m703918182EBF7CB00768408C95434F29761BBEFE (void);
// 0x00000004 System.Void Projectile::Update()
extern void Projectile_Update_m382C5B499BD4599FE34A04DA3DA0701077C710B2 (void);
// 0x00000005 System.Void Projectile::MoveProjectile()
extern void Projectile_MoveProjectile_m29D8098E768ECAD550EEC481BC9704BC51E7984C (void);
// 0x00000006 System.Void Projectile::.ctor()
extern void Projectile__ctor_m22DAC83BA9B394316027755FD2ADFCA806EE39BB (void);
// 0x00000007 System.Void RotateAround::Start()
extern void RotateAround_Start_m0E65CABB7DCAB95A8EFCB756906354C3A4C21C55 (void);
// 0x00000008 System.Void RotateAround::Update()
extern void RotateAround_Update_mB59786F87DC788EC2B9394A823A7821541239DEF (void);
// 0x00000009 System.Void RotateAround::.ctor()
extern void RotateAround__ctor_m864285B5B460AC963938CDDC5EE18B1E93B443A8 (void);
// 0x0000000A System.Void Spawner::Start()
extern void Spawner_Start_m61D97BD980BD1B1877634A1E7626E47418D5D6D8 (void);
// 0x0000000B System.Void Spawner::Update()
extern void Spawner_Update_m8E44DB2210E6C1692B202D38D0867961E9720AA9 (void);
// 0x0000000C System.Void Spawner::.ctor()
extern void Spawner__ctor_m08E8D40AAA40F4329D8A95EEE2B2B6BE842CEB9C (void);
static Il2CppMethodPointer s_methodPointers[12] = 
{
	LookAtTarget_Start_mA520BD8AAF18B39E54E362D1357B7745371798AA,
	LookAtTarget_Update_m95F4E845EB06EFFCB91E538AB4D9E202C8A5ED4A,
	LookAtTarget__ctor_m703918182EBF7CB00768408C95434F29761BBEFE,
	Projectile_Update_m382C5B499BD4599FE34A04DA3DA0701077C710B2,
	Projectile_MoveProjectile_m29D8098E768ECAD550EEC481BC9704BC51E7984C,
	Projectile__ctor_m22DAC83BA9B394316027755FD2ADFCA806EE39BB,
	RotateAround_Start_m0E65CABB7DCAB95A8EFCB756906354C3A4C21C55,
	RotateAround_Update_mB59786F87DC788EC2B9394A823A7821541239DEF,
	RotateAround__ctor_m864285B5B460AC963938CDDC5EE18B1E93B443A8,
	Spawner_Start_m61D97BD980BD1B1877634A1E7626E47418D5D6D8,
	Spawner_Update_m8E44DB2210E6C1692B202D38D0867961E9720AA9,
	Spawner__ctor_m08E8D40AAA40F4329D8A95EEE2B2B6BE842CEB9C,
};
static const int32_t s_InvokerIndices[12] = 
{
	1226,
	1226,
	1226,
	1226,
	1226,
	1226,
	1226,
	1226,
	1226,
	1226,
	1226,
	1226,
};
extern const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	12,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_AssemblyU2DCSharp_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
